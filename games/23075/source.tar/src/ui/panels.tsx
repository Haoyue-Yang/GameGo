import { useEffect, useRef } from "react";
import { Btn, Glyph, Panel, Portrait, Rule, Tag } from "./bits";
import { CHARACTERS, EVIDENCE_BY_ID, MARKERS_BY_SITE, METHODS, SITES, TAGS, TOPICS } from "../game/case";
import { coverage, filedReal, REAL_TOTAL_LABEL, topicState } from "../game/engine";
import type { GameState, MethodId } from "../game/types";

/* =========================================================================
   LAYER 2 — UNLIT FLAT VECTOR UI
   ========================================================================= */

export function TopBar({ s, onAccuse }: { s: GameState; onAccuse: () => void }) {
  const site = SITES.find((x) => x.id === s.site)!;
  const cov = Math.round(coverage(s) * 100);
  const real = filedReal(s).length;
  return (
    <div className="v v-flat pointer-events-auto flex items-stretch">
      <div className="flex flex-col justify-center border-r border-rule px-3 py-2">
        <div className="text-[11px] v-tracked text-amber">THE VANTAGE WING</div>
        <div className="text-[9px] v-tracked text-paper/40">CASE 44-B · REVIEWING</div>
      </div>
      <div className="flex flex-col justify-center border-r border-rule px-3 py-2">
        <div className="text-[11px] v-tracked text-paper">{site.name}</div>
        <div className="text-[9px] v-tracked text-paper/40">{site.sub}</div>
      </div>
      <Stat label="EVIDENCE" value={`${real}/${REAL_TOTAL_LABEL}`} />
      <Stat label="COVERAGE" value={`${cov}%`} />
      <Stat label="CLAIMS BROKEN" value={`${s.upheld.length}/3`} tone={s.upheld.length === 3 ? "teal" : "plain"} />
      <Stat label="MISTAKES" value={`${s.mistakes}`} tone={s.mistakes ? "rust" : "plain"} />
      <div className="flex items-center px-3">
        <Btn onClick={onAccuse} tone="rust" disabled={s.upheld.length === 0} title="Accuse a suspect with three key exhibits">
          ACCUSE
        </Btn>
      </div>
    </div>
  );
}

function Stat({ label, value, tone = "plain" }: { label: string; value: string; tone?: "plain" | "rust" | "teal" }) {
  const c = tone === "rust" ? "text-rust" : tone === "teal" ? "text-teal" : "text-paper";
  return (
    <div className="flex flex-col justify-center border-r border-rule px-3 py-2">
      <div className="text-[9px] v-tracked text-paper/40">{label}</div>
      <div className={`text-[13px] v-tracked v-num ${c}`}>{value}</div>
    </div>
  );
}

export function SiteTabs({ s, onSite }: { s: GameState; onSite: (id: string) => void }) {
  return (
    <div className="v v-flat pointer-events-auto flex flex-col">
      <div className="border-b border-rule px-3 py-1.5 text-[9px] v-tracked text-paper/40">FIXED FRAMES</div>
      {SITES.map((site) => {
        const open = s.sitesOpen.includes(site.id);
        const active = s.site === site.id;
        return (
          <button
            key={site.id}
            className={`px-3 py-2 text-left text-[10px] v-tracked ${
              active ? "bg-amber text-ink" : open ? "text-paper hover:bg-ink-3" : "text-paper/25"
            } ${open && !active ? "border-l-2 border-amber/40" : "border-l-2 border-transparent"}`}
            disabled={!open}
            onClick={() => onSite(site.id)}
            aria-current={active}
          >
            {open ? site.name : "— SEALED —"}
            <div className="text-[8px] v-tracked opacity-60">{open ? site.sub : "no access"}</div>
          </button>
        );
      })}
    </div>
  );
}

export function MethodBar({ s, onMethod }: { s: GameState; onMethod: (m: MethodId | null) => void }) {
  return (
    <div className="v v-flat pointer-events-auto flex flex-col">
      <div className="border-b border-rule px-3 py-1.5 text-[9px] v-tracked text-paper/40">METHODS</div>
      {METHODS.map((m) => {
        const open = s.methodsOpen.includes(m.id);
        const on = s.activeMethod === m.id;
        return (
          <button
            key={m.id}
            className={`px-3 py-2 text-left text-[10px] v-tracked ${
              on ? "bg-teal text-ink" : open ? "text-teal hover:bg-ink-3" : "text-paper/25"
            }`}
            disabled={!open}
            onClick={() => onMethod(on ? null : m.id)}
            aria-pressed={on}
            title={open ? m.blurb : `Unlocks after ${m.unlockAt} real exhibits filed`}
          >
            <span className="v-num">{m.code}</span> · {m.name}
            <div className="text-[8px] v-tracked opacity-60">{open ? (on ? "ACTIVE" : "ready") : `${m.unlockAt} exhibits`}</div>
          </button>
        );
      })}
    </div>
  );
}

export function FindingsPanel({ s }: { s: GameState }) {
  const real = filedReal(s);
  const decoys = s.filed.filter((id) => EVIDENCE_BY_ID[id]?.decoy);
  const tags = new Set<string>();
  real.forEach((id) => EVIDENCE_BY_ID[id].tags.forEach((t) => tags.add(t)));
  return (
    <Panel title="FILED EVIDENCE" code={`${real.length} HOLD · ${decoys.length} VOID`}>
      <div className="v-scroll h-full overflow-y-auto px-3 py-2">
        {real.length === 0 && (
          <p className="text-[10px] leading-relaxed text-paper/40">
            Nothing filed. Search the frame — every marker is one-shot.
          </p>
        )}
        <ul className="space-y-1.5">
          {real.map((id) => {
            const e = EVIDENCE_BY_ID[id];
            return (
              <li key={id} className="border border-rule px-2 py-1.5">
                <div className="flex items-start gap-2">
                  <span className="text-amber">
                    <Glyph k={e.glyph} size={18} />
                  </span>
                  <div className="min-w-0 flex-1">
                    <div className="text-[10px] v-tracked text-paper">{e.name}</div>
                    <p className="mt-1 text-[9px] leading-relaxed text-paper/50">{e.note}</p>
                    <div className="mt-1 flex flex-wrap gap-1">
                      {e.tags.map((t) => (
                        <Tag key={t} tone="amber">
                          {TAGS[t] ?? t}
                        </Tag>
                      ))}
                    </div>
                  </div>
                </div>
              </li>
            );
          })}
        </ul>
        {decoys.length > 0 && (
          <>
            <Rule />
            <div className="text-[9px] v-tracked text-paper/35">VOID — NO EVIDENTIARY VALUE</div>
            <ul className="mt-1.5 space-y-1">
              {decoys.map((id) => (
                <li key={id} className="flex items-center gap-2 px-1 text-[10px] text-paper/35 line-through">
                  <Glyph k={EVIDENCE_BY_ID[id].glyph} size={14} />
                  {EVIDENCE_BY_ID[id].name}
                </li>
              ))}
            </ul>
          </>
        )}
      </div>
    </Panel>
  );
}

export function SearchHint({ s }: { s: GameState }) {
  const site = s.site;
  const all = MARKERS_BY_SITE[site] ?? [];
  const spent = all.filter((m) => s.spent.includes(m.id)).length;
  const visible = all.filter((m) => !m.hiddenBy || s.activeMethod === m.hiddenBy).length;
  const visibleSpent = all.filter((m) => s.spent.includes(m.id) && (!m.hiddenBy || s.activeMethod === m.hiddenBy)).length;
  const hidden = all.filter((m) => m.hiddenBy && s.activeMethod !== m.hiddenBy).length;
  return (
    <div className="v v-flat pointer-events-auto px-3 py-2 text-[9px] v-tracked text-paper/50">
      <div>
        MARKERS SPENT <span className="text-paper v-num">{spent}</span> / {all.length}
      </div>
      <div>
        IN FRAME <span className="text-amber v-num">{visible - visibleSpent}</span>
      </div>
      <div className={hidden ? "text-teal" : ""}>
        UNDER METHOD <span className="v-num">{hidden}</span>
      </div>
    </div>
  );
}

export function InterviewPanel({
  s,
  who,
  onAsk,
  onLeave,
}: {
  s: GameState;
  who: string;
  onAsk: (topicId: string) => void;
  onLeave: () => void;
}) {
  const c = CHARACTERS.find((x) => x.id === who)!;
  const topics = TOPICS.filter((t) => t.who === who).map((t) => topicState(s, t.id));

  return (
    <Panel title="INTERVIEW" code={c.role} onClose={onLeave}>
      <div className="v-scroll h-full overflow-y-auto">
        <div className="flex items-start gap-3 border-b border-rule px-3 py-2">
          <Portrait who={c.face} size={52} />
          <div className="min-w-0">
            <div className="text-[11px] v-tracked text-amber">{c.name}</div>
            <p className="mt-1 text-[10px] leading-relaxed text-paper/55">{c.intro}</p>
          </div>
        </div>
        <div className="px-3 py-2">
          <div className="text-[9px] v-tracked text-paper/40">TOPICS — UNLOCKED BY EVIDENCE TAGS</div>
          <ul className="mt-1.5 space-y-1">
            {topics.map((t) => {
              const lock = !t.available;
              const reason = t.asked
                ? "asked"
                : !t.tagOk
                  ? `needs tag ${t.missingTags.map((x) => TAGS[x] ?? x).join(" + ")}`
                  : !t.methodOk
                    ? `needs ${t.missingMethods.map((m) => (m === "trace" ? "TRACE" : "HANDWRITING")).join(" + ")}`
                    : !t.solOk
                      ? "coverage incomplete"
                      : "";
              return (
                <li key={t.topic.id}>
                  <button
                    className={`w-full border px-2 py-1.5 text-left text-[10px] leading-snug ${
                      t.asked
                        ? "border-rule/40 text-paper/30"
                        : t.available
                          ? "border-amber/60 text-paper hover:bg-amber hover:text-ink"
                          : "border-rule text-paper/30"
                    }`}
                    disabled={lock}
                    onClick={() => onAsk(t.topic.id)}
                    title={reason}
                  >
                    <span className="v-tracked">{t.topic.prompt}</span>
                    {lock && !t.asked && (
                      <span className="mt-0.5 block text-[8px] v-tracked text-rust/70">LOCKED · {reason}</span>
                    )}
                    {t.asked && <span className="mt-0.5 block text-[8px] v-tracked">— asked</span>}
                  </button>
                </li>
              );
            })}
          </ul>
        </div>
      </div>
    </Panel>
  );
}

export function Transcript({ s }: { s: GameState }) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (ref.current) ref.current.scrollTop = ref.current.scrollHeight;
  }, [s.log.length]);
  return (
    <div ref={ref} className="v-scroll h-full overflow-y-auto px-3 py-2">
      <ul className="space-y-1.5">
        {s.log.map((l) => {
          if (l.kind === "sys")
            return (
              <li key={l.id} className="text-[10px] leading-relaxed text-paper/45">
                <span className="text-rule">·</span> {l.text}
              </li>
            );
          if (l.kind === "who")
            return (
              <li key={l.id} className="text-[10px] v-tracked text-amber">
                ▸ {l.text}
              </li>
            );
          if (l.kind === "say")
            return (
              <li key={l.id} className="border-l-2 border-rule pl-2 text-[11px] leading-relaxed text-paper/80">
                “{l.text}”
              </li>
            );
          if (l.kind === "claim")
            return (
              <li key={l.id} className="border-l-2 border-rust pl-2 text-[11px] leading-relaxed text-rust">
                <span className="text-[8px] v-tracked">FLAWED CLAIM</span>
                <br />
                “{l.text}”
              </li>
            );
          if (l.kind === "ok")
            return (
              <li key={l.id} className="border-l-2 border-teal pl-2 text-[10px] leading-relaxed text-teal">
                {l.text}
              </li>
            );
          return (
            <li key={l.id} className="border-l-2 border-rust pl-2 text-[10px] leading-relaxed text-rust">
              {l.text}
            </li>
          );
        })}
      </ul>
    </div>
  );
}

export function Toast({ text, k }: { text: string; k: number }) {
  return (
    <div
      key={k}
      className="v v-flat v-flash pointer-events-none absolute left-1/2 top-24 -translate-x-1/2 border-amber px-4 py-2 text-[11px] v-tracked text-amber"
    >
      {text}
    </div>
  );
}
