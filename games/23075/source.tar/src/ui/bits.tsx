import type * as React from "react";
import type { GlyphKey } from "../game/types";

/* =========================================================================
   LAYER 2 — UNLIT FLAT VECTOR.
   Solid fills, hard rules, no gradients, no shadows, no blur, no transforms.
   ========================================================================= */

export function Panel({
  title,
  code,
  children,
  className = "",
  onClose,
}: {
  title: string;
  code?: string;
  children: React.ReactNode;
  className?: string;
  onClose?: () => void;
}) {
  return (
    <section className={`v v-flat flex h-full min-h-0 flex-col ${className}`} aria-label={title}>
      <header className="flex items-center justify-between gap-2 border-b border-rule px-3 py-2">
        <h2 className="text-[11px] v-tracked text-amber">{title}</h2>
        <div className="flex items-center gap-2">
          {code && <span className="text-[10px] v-tracked text-paper/40 v-num">{code}</span>}
          {onClose && (
            <button className="v-btn px-1.5 py-0.5 text-[10px] leading-none" onClick={onClose} aria-label="Close panel">
              ✕
            </button>
          )}
        </div>
      </header>
      <div className="min-h-0 flex-1">{children}</div>
    </section>
  );
}

export function Btn({
  children,
  onClick,
  disabled,
  tone = "plain",
  className = "",
  ...rest
}: {
  children: React.ReactNode;
  onClick?: () => void;
  disabled?: boolean;
  tone?: "plain" | "amber" | "rust" | "teal";
  className?: string;
} & React.ButtonHTMLAttributes<HTMLButtonElement>) {
  const tones: Record<string, string> = {
    plain: "v-btn",
    amber: "v-btn !border-amber !bg-amber !text-ink hover:!bg-amber",
    rust: "v-btn !border-rust !text-rust hover:!bg-rust hover:!text-paper",
    teal: "v-btn !border-teal !text-teal hover:!bg-teal hover:!text-ink",
  };
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      className={`px-3 py-1.5 text-[11px] v-tracked ${tones[tone]} ${className}`}
      {...rest}
    >
      {children}
    </button>
  );
}

export function Rule() {
  return <div className="v-rule my-2" />;
}

export function Tag({ children, tone = "plain" }: { children: React.ReactNode; tone?: "plain" | "amber" | "teal" }) {
  const c =
    tone === "amber"
      ? "border-amber text-amber"
      : tone === "teal"
        ? "border-teal text-teal"
        : "border-rule text-paper/70";
  return <span className={`border px-1.5 py-0.5 text-[9px] v-tracked ${c}`}>{children}</span>;
}

/* ---------------- evidence glyphs: flat vector marks ---------------- */
export function Glyph({ k, size = 22 }: { k: GlyphKey; size?: number }) {
  const s = { stroke: "currentColor", strokeWidth: 1.4, fill: "none" } as const;
  const p: Record<GlyphKey, React.ReactNode> = {
    card: (
      <>
        <rect x="3" y="6" width="18" height="12" {...s} />
        <path d="M6 10h5M6 13h3" {...s} />
        <rect x="14" y="12" width="4" height="3" {...s} />
      </>
    ),
    key: (
      <>
        <circle cx="8" cy="9" r="3.5" {...s} />
        <path d="M10.5 11.5L19 20M16 17l2-2M18 19l2-2" {...s} />
      </>
    ),
    page: (
      <>
        <path d="M5 3h10l4 4v14H5z" {...s} />
        <path d="M15 3v4h4M8 12h8M8 16h8M8 8h4" {...s} />
      </>
    ),
    smear: (
      <>
        <path d="M3 15c3-4 6 2 9-2s5 1 9-3" {...s} />
        <path d="M4 19h16" {...s} />
      </>
    ),
    board: (
      <>
        <rect x="3" y="7" width="18" height="10" {...s} />
        <path d="M3 12h18M9 7v10M15 7v10" {...s} />
      </>
    ),
    plush: (
      <>
        <circle cx="12" cy="10" r="5" {...s} />
        <circle cx="7" cy="5" r="2" {...s} />
        <circle cx="17" cy="5" r="2" {...s} />
        <path d="M8 18h8" {...s} />
      </>
    ),
    match: (
      <>
        <rect x="4" y="12" width="16" height="7" {...s} />
        <path d="M12 12V6M10 4h4" {...s} />
      </>
    ),
    tire: (
      <>
        <circle cx="12" cy="12" r="8" {...s} />
        <circle cx="12" cy="12" r="3" {...s} />
        <path d="M12 4v3M12 17v3M4 12h3M17 12h3" {...s} />
      </>
    ),
    timer: (
      <>
        <rect x="4" y="4" width="16" height="16" {...s} />
        <path d="M7 9h10M7 13h6" {...s} />
        <circle cx="16" cy="16" r="1.5" {...s} />
      </>
    ),
    lantern: (
      <>
        <path d="M9 4h6M12 4v2" {...s} />
        <rect x="7" y="6" width="10" height="12" {...s} />
        <path d="M12 9v6" {...s} />
      </>
    ),
    fiber: (
      <>
        <path d="M4 18c4-2 6-8 16-12" {...s} />
        <path d="M10 12l3 3M13 9l3 3M7 15l3 3" {...s} />
      </>
    ),
    boot: (
      <>
        <path d="M7 4h4v9h6l3 4v3H7z" {...s} />
        <path d="M7 16h13" {...s} />
      </>
    ),
    oil: (
      <>
        <path d="M12 3c3 5 5 7 5 10a5 5 0 01-10 0c0-3 2-5 5-10z" {...s} />
        <path d="M6 20h12" {...s} />
      </>
    ),
    can: (
      <>
        <rect x="8" y="4" width="8" height="16" {...s} />
        <path d="M8 8h8M8 16h8" {...s} />
      </>
    ),
    nest: (
      <>
        <path d="M3 14c3-4 15-4 18 0-3 4-15 4-18 0z" {...s} />
        <circle cx="10" cy="13" r="1.4" {...s} />
        <circle cx="14" cy="13" r="1.4" {...s} />
      </>
    ),
    ledger: (
      <>
        <rect x="3" y="5" width="18" height="14" {...s} />
        <path d="M3 9h18M3 13h18M3 17h18M7 5v14" {...s} />
      </>
    ),
    carbon: (
      <>
        <rect x="4" y="4" width="16" height="16" {...s} />
        <rect x="7" y="7" width="10" height="10" {...s} />
        <path d="M9 11h6M9 14h4" {...s} />
      </>
    ),
    dispenser: (
      <>
        <rect x="6" y="3" width="12" height="18" {...s} />
        <rect x="9" y="7" width="6" height="4" {...s} />
        <path d="M9 15h6M9 18h6" {...s} />
      </>
    ),
    coat: (
      <>
        <path d="M9 4l3 2 3-2 4 3-2 3v11H7V10L5 7z" {...s} />
        <path d="M12 6v14" {...s} />
      </>
    ),
    ink: (
      <>
        <path d="M4 18c2-6 5-2 7-8s3 4 9-2" {...s} />
        <path d="M4 21h16" {...s} />
      </>
    ),
    cabinet: (
      <>
        <rect x="5" y="3" width="14" height="18" {...s} />
        <path d="M5 9h14M5 15h14M10 6h4M10 12h4M10 18h4" {...s} />
      </>
    ),
    lamp: (
      <>
        <path d="M6 10l6-6 6 6z" {...s} />
        <path d="M12 10v9M8 21h8" {...s} />
      </>
    ),
  };
  return (
    <svg viewBox="0 0 24 24" width={size} height={size} aria-hidden="true" className="shrink-0">
      {p[k]}
    </svg>
  );
}

/* ---------------- the fixed frame, drawn in flat vector ---------------- */
export function FrameBrackets({ pose }: { pose: string }) {
  return (
    <div className="pointer-events-none absolute inset-x-0 bottom-1 flex justify-center">
      <div className="text-[8px] v-tracked text-paper/25 v-num">{pose}</div>
    </div>
  );
}

/* ---------------- flat vector portraits ---------------- */
export function Portrait({ who, size = 54 }: { who: "maren" | "renk" | "cassia"; size?: number }) {
  const common = { stroke: "#0d1013", strokeWidth: 1.6, fill: "none" } as const;
  const body = (
    <>
      <path d="M4 26c0-6 6-9 13-9s13 3 13 9z" fill="#2a343d" stroke="#0d1013" strokeWidth="1.6" />
    </>
  );
  const maren = (
    <>
      {body}
      <circle cx="17" cy="12" r="7" fill="#c9a887" stroke="#0d1013" strokeWidth="1.6" />
      <path d="M10 11c0-5 3-7 7-7s7 2 7 7c0-2-2-3-7-3s-7 1-7 3z" fill="#3a3128" stroke="#0d1013" strokeWidth="1.4" />
      <path d="M14 13h2M19 13h2" {...common} />
      <path d="M15 17c1 1 3 1 4 0" {...common} />
      <path d="M24 20l3 2" {...common} />
    </>
  );
  const renk = (
    <>
      {body}
      <circle cx="17" cy="12" r="7" fill="#b08d6b" stroke="#0d1013" strokeWidth="1.6" />
      <path d="M9 8h16l-1 3H10z" fill="#3a4650" stroke="#0d1013" strokeWidth="1.4" />
      <path d="M14 14h2M19 14h2" {...common} />
      <path d="M13 18h8" {...common} />
      <path d="M12 10c1-4 9-4 10 0" {...common} />
    </>
  );
  const cassia = (
    <>
      {body}
      <circle cx="17" cy="12" r="7" fill="#d8b894" stroke="#0d1013" strokeWidth="1.6" />
      <path d="M9 12c0-6 3-8 8-8s8 2 8 8l-2 6-2-5h-8l-2 5z" fill="#22303f" stroke="#0d1013" strokeWidth="1.4" />
      <path d="M14 14h2M19 14h2" {...common} />
      <path d="M15 18h4" {...common} />
    </>
  );
  return (
    <svg viewBox="0 0 34 28" width={size} height={(size * 28) / 34} aria-hidden="true" className="shrink-0">
      {who === "maren" ? maren : who === "renk" ? renk : cassia}
    </svg>
  );
}
