import { useEffect, useMemo, useState } from "react";
import { Btn, Glyph, Panel, Portrait, Rule, Tag } from "./bits";
import { CHAR_BY_ID, CULPRIT, EVIDENCE_BY_ID, KEY_EXHIBITS, REBUTTAL_BY_ID, SUSPECTS, TAGS } from "../game/case";
import { computeVerdict, filedReal, gradeOf, MAX_ATTEMPTS, REAL_TOTAL_LABEL } from "../game/engine";
import type { GameState } from "../game/types";

/* =========================================================================
   CROSS-EXAMINATION — the unordered slot set must equal the solution exactly.
   Partial hits fail, and the gap is never named.
   ========================================================================= */

export function RebuttalPanel({
  s,
  onSlot,
  onSubmit,
  onClear,
}: {
  s: GameState;
  onSlot: (i: number, ev: string | null) => void;
  onSubmit: () => void;
  onClear: () => void;
}) {
  const r = REBUTTAL_BY_ID[s.openRebuttal!];
  const claimant = CHAR_BY_ID[r.claimant];
  const cards = filedReal(s);
  const [sel, setSel] = useState<string | null>(null);
  const [drag, setDrag] = useState<{ ev: string; x: number; y: number } | null>(null);

  useEffect(() => {
    if (!drag) return;
    const move = (e: PointerEvent) => setDrag((d) => (d ? { ...d, x: e.clientX, y: e.clientY } : d));
    const up = (e: PointerEvent) => {
      const el = document.elementFromPoint(e.clientX, e.clientY) as HTMLElement | null;
      const host = el?.closest("[data-slot]") as HTMLElement | null;
      if (host) onSlot(Number(host.dataset.slot), drag.ev);
      setDrag(null);
    };
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", up);
    return () => {
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", up);
    };
  }, [drag, onSlot]);

  const full = s.slots.every((x) => !!x);
  const hint = r.hints[Math.min(s.hintLevel, r.hints.length - 1)];

  return (
    <Panel title="CROSS-EXAMINATION" code={`${r.id} · ATTEMPT ${s.attempts}/${MAX_ATTEMPTS}`}>
      <div className="v-scroll h-full overflow-y-auto">
        {/* the flawed claim */}
        <div className="border-b border-rule px-3 py-2">
          <div className="flex items-start gap-2">
            <Portrait who={claimant.face} size={38} />
            <div>
              <div className="text-[10px] v-tracked text-rust">{claimant.name}</div>
              <p className="mt-1 text-[11px] leading-relaxed text-paper/85">“{r.claim}”</p>
            </div>
          </div>
        </div>

        {/* attempts */}
        <div className="flex items-center gap-2 border-b border-rule px-3 py-2">
          <span className="text-[9px] v-tracked text-paper/40">ATTEMPTS</span>
          <div className="flex gap-1">
            {Array.from({ length: MAX_ATTEMPTS }).map((_, i) => (
              <span
                key={i}
                className={`h-2.5 w-4 border ${i < s.attempts ? "border-amber bg-amber" : "border-rule bg-transparent"}`}
              />
            ))}
          </div>
          <span className="ml-auto text-[9px] v-tracked text-paper/40 v-num">{r.solution.length} SLOTS</span>
        </div>

        {/* numbered slots */}
        <div className="px-3 py-2">
          <div className="text-[9px] v-tracked text-paper/40">
            DRAG EXHIBITS INTO THE SLOTS — ORDER DOES NOT MATTER, THE SET MUST BE EXACT
          </div>
          <div className="mt-2 grid grid-cols-3 gap-2">
            {s.slots.map((ev, i) => {
              const e = ev ? EVIDENCE_BY_ID[ev] : null;
              return (
                <div
                  key={i}
                  data-slot={i}
                  className={`flex h-24 flex-col items-center justify-center border px-1 text-center ${
                    e ? "border-amber bg-amber/10" : "border-dashed border-rule"
                  }`}
                  onClick={() => {
                    if (sel) {
                      onSlot(i, sel);
                      setSel(null);
                    } else if (e) onSlot(i, null);
                  }}
                  role="button"
                  tabIndex={0}
                  aria-label={`Slot ${i + 1}${e ? `: ${e.name}` : " empty"}`}
                  onKeyDown={(ev2) => {
                    if (ev2.key === "Enter" || ev2.key === " ") {
                      ev2.preventDefault();
                      if (sel) {
                        onSlot(i, sel);
                        setSel(null);
                      } else if (e) onSlot(i, null);
                    }
                  }}
                >
                  <span className="text-[9px] v-tracked text-paper/40 v-num">{i + 1}</span>
                  {e ? (
                    <>
                      <span className="text-amber">
                        <Glyph k={e.glyph} size={22} />
                      </span>
                      <span className="mt-1 text-[8px] v-tracked leading-tight text-paper">{e.name}</span>
                    </>
                  ) : (
                    <span className="text-[8px] v-tracked text-paper/25">EMPTY</span>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* evidence cards */}
        <div className="border-t border-rule px-3 py-2">
          <div className="text-[9px] v-tracked text-paper/40">EXHIBITS ON FILE · {cards.length}</div>
          <ul className="mt-2 grid grid-cols-2 gap-1.5">
            {cards.map((id) => {
              const e = EVIDENCE_BY_ID[id];
              const used = s.slots.includes(id);
              const isSel = sel === id;
              return (
                <li key={id}>
                  <button
                    className={`w-full border px-2 py-1.5 text-left ${
                      isSel ? "border-amber bg-amber/20" : used ? "border-rule/40 opacity-45" : "border-rule hover:border-amber"
                    }`}
                    onPointerDown={(ev) => {
                      setSel(id);
                      setDrag({ ev: id, x: ev.clientX, y: ev.clientY });
                    }}
                    onClick={() => setSel((x) => (x === id ? null : id))}
                    aria-pressed={isSel}
                  >
                    <div className="flex items-center gap-1.5">
                      <span className="text-amber">
                        <Glyph k={e.glyph} size={16} />
                      </span>
                      <span className="text-[9px] v-tracked leading-tight text-paper">{e.name}</span>
                    </div>
                    <div className="mt-1 flex flex-wrap gap-1">
                      {e.tags.map((t) => (
                        <Tag key={t}>{TAGS[t] ?? t}</Tag>
                      ))}
                    </div>
                  </button>
                </li>
              );
            })}
          </ul>
        </div>

        {/* escalating hint */}
        <div className="border-t border-rule px-3 py-2">
          <div className="text-[9px] v-tracked text-paper/40">
            HINT LEVEL <span className="v-num text-teal">{s.hintLevel + 1}</span> / {r.hints.length}
          </div>
          <p className="mt-1 text-[10px] leading-relaxed text-teal">{hint}</p>
        </div>

        <div className="flex items-center gap-2 border-t border-rule px-3 py-2">
          <Btn tone="amber" onClick={onSubmit} disabled={!full}>
            REBUT
          </Btn>
          <Btn onClick={onClear}>CLEAR</Btn>
          <span className="ml-auto text-[9px] v-tracked text-paper/35">
            {s.attempts === 1 ? "LAST ATTEMPT" : `${s.attempts} LEFT`}
          </span>
        </div>
      </div>

      {drag && (
        <div
          className="v v-flat pointer-events-none fixed z-50 border-amber px-2 py-1 text-[9px] v-tracked text-amber"
          style={{ left: drag.x + 10, top: drag.y + 10 }}
        >
          {EVIDENCE_BY_ID[drag.ev].name}
        </div>
      )}
    </Panel>
  );
}

/* ------------------------------------------------------------------ *
 *  ACCUSATION — one suspect, three key exhibits
 * ------------------------------------------------------------------ */

export function AccusePanel({
  s,
  onAccuse,
  onClose,
}: {
  s: GameState;
  onAccuse: (suspect: string, exhibits: string[]) => void;
  onClose: () => void;
}) {
  const [suspect, setSuspect] = useState<string | null>(null);
  const [picks, setPicks] = useState<string[]>([]);
  const cards = filedReal(s);
  const toggle = (id: string) =>
    setPicks((p) => (p.includes(id) ? p.filter((x) => x !== id) : p.length >= 3 ? p : [...p, id]));

  return (
    <Panel title="ACCUSATION" code="ONE SUSPECT · THREE EXHIBITS" onClose={onClose}>
      <div className="v-scroll h-full overflow-y-auto">
        <p className="border-b border-rule px-3 py-2 text-[10px] leading-relaxed text-paper/55">
          Name the person who killed Ilse Vantage and file the three exhibits that carry it. Coverage and mistakes are
          counted.
        </p>
        <div className="px-3 py-2">
          <div className="text-[9px] v-tracked text-paper/40">SUSPECT</div>
          <ul className="mt-1.5 space-y-1">
            {SUSPECTS.map((x) => (
              <li key={x.id}>
                <button
                  className={`flex w-full items-center gap-2 border px-2 py-1.5 text-left ${
                    suspect === x.id ? "border-rust bg-rust/15" : "border-rule hover:border-rust"
                  }`}
                  onClick={() => setSuspect(x.id)}
                  aria-pressed={suspect === x.id}
                >
                  <Portrait who={x.face} size={34} />
                  <div>
                    <div className="text-[10px] v-tracked text-paper">{x.name}</div>
                    <div className="text-[9px] v-tracked text-paper/40">{x.alibi}</div>
                  </div>
                </button>
              </li>
            ))}
          </ul>
        </div>
        <Rule />
        <div className="px-3 py-2">
          <div className="text-[9px] v-tracked text-paper/40">
            KEY EXHIBITS <span className="v-num text-amber">{picks.length}</span>/3
          </div>
          <ul className="mt-1.5 grid grid-cols-2 gap-1.5">
            {cards.map((id) => {
              const e = EVIDENCE_BY_ID[id];
              const on = picks.includes(id);
              return (
                <li key={id}>
                  <button
                    className={`w-full border px-2 py-1.5 text-left ${on ? "border-amber bg-amber/20" : "border-rule hover:border-amber"}`}
                    onClick={() => toggle(id)}
                    disabled={!on && picks.length >= 3}
                    aria-pressed={on}
                  >
                    <div className="flex items-center gap-1.5">
                      <span className="text-amber">
                        <Glyph k={e.glyph} size={16} />
                      </span>
                      <span className="text-[9px] v-tracked leading-tight text-paper">{e.name}</span>
                    </div>
                  </button>
                </li>
              );
            })}
          </ul>
        </div>
        <div className="flex items-center gap-2 border-t border-rule px-3 py-2">
          <Btn tone="rust" disabled={!suspect || picks.length !== 3} onClick={() => suspect && onAccuse(suspect, picks)}>
            FILE ACCUSATION
          </Btn>
          <span className="ml-auto text-[9px] v-tracked text-paper/35">
            {s.upheld.length}/3 CLAIMS BROKEN
          </span>
        </div>
      </div>
    </Panel>
  );
}

/* ------------------------------------------------------------------ *
 *  VERDICT
 * ------------------------------------------------------------------ */

export function VerdictPanel({ s, onRestart }: { s: GameState; onRestart: () => void }) {
  const v = computeVerdict(s);
  const g = gradeOf(v.score);
  const accused = SUSPECTS.find((x) => x.id === s.accused?.suspect)!;
  const right = accused.id === CULPRIT;
  const rows = useMemo(
    () => [
      ["KEY EXHIBITS", `${v.keyHits}/3`, `${v.keyHits * 18} pts`],
      ["CLUE COVERAGE", `${Math.round(v.cov * 100)}%`, `${Math.round(v.cov * 40)} pts`],
      ["MISTAKES", `${s.mistakes}`, `${Math.max(0, 22 - s.mistakes * 6)} pts`],
      ["SUSPECT", right ? "CORRECT" : "WRONG", right ? "—" : "CAPPED AT 38"],
    ],
    [v, s.mistakes, right],
  );
  return (
    <Panel title="VERDICT" code={`GRADE ${g.g}`}>
      <div className="v-scroll h-full overflow-y-auto">
        <div className="border-b border-rule px-3 py-3 text-center">
          <div className="text-5xl leading-none text-amber">{g.g}</div>
          <div className="mt-1 text-[11px] v-tracked text-paper">{g.label}</div>
          <div className="mt-1 text-[10px] v-tracked text-paper/40 v-num">{v.score} / 100</div>
        </div>
        <div className="flex items-start gap-3 border-b border-rule px-3 py-2">
          <Portrait who={accused.face} size={44} />
          <div>
            <div className="text-[10px] v-tracked text-rust">ACCUSED · {accused.name}</div>
            <div className="mt-1 text-[10px] leading-relaxed text-paper/60">
              {right
                ? "Maren Holt released the east door with card #4 at 21:04, four minutes after the ledger had her signing out. She forged the annex register at 21:00 to stand over her own absence, drove Cassia's sedan up the drive, and left through the window with a torn navy coat."
                : "The file does not support this name. The card, the lock and the carbon all point elsewhere."}
            </div>
          </div>
        </div>
        <div className="px-3 py-2">
          <div className="text-[9px] v-tracked text-paper/40">EXHIBITS FILED</div>
          <ul className="mt-1.5 space-y-1">
            {s.accused?.exhibits.map((id) => {
              const e = EVIDENCE_BY_ID[id];
              const key = KEY_EXHIBITS.includes(id);
              return (
                <li key={id} className="flex items-center gap-2 border border-rule px-2 py-1">
                  <span className={key ? "text-teal" : "text-paper/40"}>
                    <Glyph k={e.glyph} size={16} />
                  </span>
                  <span className="text-[9px] v-tracked text-paper">{e.name}</span>
                  <span className={`ml-auto text-[8px] v-tracked ${key ? "text-teal" : "text-rust/70"}`}>
                    {key ? "KEY" : "SUPPORTING"}
                  </span>
                </li>
              );
            })}
          </ul>
        </div>
        <div className="px-3 py-2">
          <div className="text-[9px] v-tracked text-paper/40">SCORING</div>
          <ul className="mt-1.5 space-y-0.5">
            {rows.map(([a, b, c]) => (
              <li key={a} className="flex items-center justify-between text-[10px] v-tracked">
                <span className="text-paper/50">{a}</span>
                <span className="text-paper">{b}</span>
                <span className="text-paper/40 v-num">{c}</span>
              </li>
            ))}
          </ul>
        </div>
        <div className="border-t border-rule px-3 py-2">
          <Btn tone="amber" onClick={onRestart}>
            REOPEN THE CASE
          </Btn>
        </div>
      </div>
    </Panel>
  );
}

/* ------------------------------------------------------------------ *
 *  TITLE / BRIEF
 * ------------------------------------------------------------------ */

export function TitleScreen({ onStart }: { onStart: () => void }) {
  return (
    <div className="v v-flat v-in pointer-events-auto w-[min(680px,92vw)]">
      <div className="border-b border-rule px-6 py-5">
        <div className="text-[10px] v-tracked text-paper/40">CASE 44-B · REVIEWING INVESTIGATION</div>
        <h1 className="mt-1 text-3xl v-tracked text-amber">THE VANTAGE WING</h1>
        <p className="mt-3 text-[12px] leading-relaxed text-paper/70">
          14 November. The east wing of Vantage Lodge burns to the frame. Ilse Vantage dies inside. It was ruled
          accidental at the scene.
        </p>
        <p className="mt-2 text-[12px] leading-relaxed text-paper/70">
          Three fixed frames. Three people who were near it. Search each frame — every marker is one-shot. File what
          holds, break what does not.
        </p>
      </div>
      <ul className="space-y-1 px-6 py-4 text-[10px] leading-relaxed text-paper/50">
        <li>
          <span className="text-amber">SEARCH</span> — click markers in the frame. Some are decoys. Some stay hidden until
          the matching trace or handwriting method is active. Spent markers dim to imprints.
        </li>
        <li>
          <span className="text-amber">FILE</span> — filed evidence carries tags. Tags unlock interview topics.
        </li>
        <li>
          <span className="text-amber">REBUT</span> — a flawed claim opens cross-examination. The slot set must equal the
          solution exactly. Partial hits fail without naming the gap. Five attempts; hints escalate.
        </li>
        <li>
          <span className="text-amber">CLOSE</span> — accuse one suspect on three key exhibits. Graded on coverage and
          mistakes.
        </li>
      </ul>
      <div className="flex items-center gap-3 border-t border-rule px-6 py-4">
        <Btn tone="amber" onClick={onStart}>
          OPEN THE CASE
        </Btn>
        <span className="text-[9px] v-tracked text-paper/35">
          FIXED CAMERA · NO ORBIT · NO PAN · NO ZOOM
        </span>
      </div>
    </div>
  );
}

export function BriefScreen({ onStart }: { onStart: () => void }) {
  return (
    <div className="v v-flat v-in pointer-events-auto w-[min(620px,92vw)]">
      <div className="border-b border-rule px-5 py-4">
        <div className="text-[10px] v-tracked text-amber">BRIEF</div>
        <p className="mt-2 text-[12px] leading-relaxed text-paper/75">
          You have three fixed frames and no camera control. The lodge and the yard are open. The archive annex stays
          sealed until you break the first claim.
        </p>
        <p className="mt-2 text-[12px] leading-relaxed text-paper/75">
          Six to eight markers per frame. Spend them well — a marker spent is a marker gone, and the imprint it leaves
          tells you nothing you could not have had.
        </p>
      </div>
      <div className="flex items-center gap-3 px-5 py-4">
        <Btn tone="amber" onClick={onStart}>
          ENTER THE LODGE
        </Btn>
        <span className="text-[9px] v-tracked text-paper/35">
          {REAL_TOTAL_LABEL} EXHIBITS CARRY WEIGHT · {KEY_EXHIBITS.length} CARRY THE CASE
        </span>
      </div>
    </div>
  );
}
