import { useEffect, useMemo, useReducer, useState } from "react";
import type * as React from "react";
import DioramaView from "./three/Diorama";
import {
  BriefScreen,
  AccusePanel,
  RebuttalPanel,
  TitleScreen,
  VerdictPanel,
} from "./ui/flow";
import {
  FindingsPanel,
  InterviewPanel,
  MethodBar,
  SearchHint,
  SiteTabs,
  Toast,
  TopBar,
  Transcript,
} from "./ui/panels";
import { FrameBrackets } from "./ui/bits";
import { CHARACTERS, MARKERS_BY_SITE, SITE_BY_ID } from "./game/case";
import { auditCase, initialState, reducer } from "./game/engine";

export default function App() {
  const [s, dispatch] = useReducer(reducer, undefined, initialState);
  const [fade, setFade] = useState(false);
  const [who, setWho] = useState<string>("maren");

  /* site switches are fades */
  useEffect(() => {
    if (!s.flashKey) return;
    setFade(true);
    const id = window.setTimeout(() => setFade(false), 30);
    return () => clearTimeout(id);
  }, [s.flashKey]);

  /* the invariant: every solution exhibit must be collectable before its rebuttal fires */
  useEffect(() => {
    const issues = auditCase();
    if (issues.length) console.warn("[case audit]", issues);
    else console.info("[case audit] clean — every rebuttal solution is collectable before it can fire");
  }, []);

  /* markers visible in the current fixed frame */
  const markers = useMemo(
    () => (MARKERS_BY_SITE[s.site] ?? []).filter((m) => !m.hiddenBy || s.activeMethod === m.hiddenBy),
    [s.site, s.activeMethod],
  );

  const searching = s.phase === "site";

  return (
    <div className="relative h-full w-full overflow-hidden bg-ink text-paper select-none">
      {/* ---------------- LAYER 1 — lit, faceted, low-poly ---------------- */}
      <DioramaView
        site={s.site}
        markers={markers}
        spent={s.spent}
        onSpend={(id) => dispatch({ t: "spend", marker: id })}
        shakeKey={s.shakeKey}
        interactive={searching}
      />

      {/* ---------------- LAYER 2 — unlit flat vector ---------------- */}
      <div className="pointer-events-none absolute inset-0 flex flex-col">
        <div className="flex items-start justify-between gap-3 p-3">
          <TopBar s={s} onAccuse={() => dispatch({ t: "accuseOpen" })} />
          <div className="flex min-h-0 flex-1 items-start justify-end">
            <div className="pointer-events-auto flex h-[min(78vh,760px)] w-[392px] flex-col gap-2">
              {s.phase === "rebuttal" && (
                <RebuttalPanel
                  s={s}
                  onSlot={(i, ev) => dispatch({ t: "slot", index: i, ev })}
                  onSubmit={() => dispatch({ t: "submit" })}
                  onClear={() => dispatch({ t: "clearSlots" })}
                />
              )}
              {s.phase === "interview" && (
                <>
                  <div className="min-h-0 flex-[3]">
                    <InterviewPanel
                      s={s}
                      who={who}
                      onAsk={(topic) => dispatch({ t: "ask", topic })}
                      onLeave={() => dispatch({ t: "leave" })}
                    />
                  </div>
                  <div className="min-h-0 flex-[2]">
                    <PanelWrap title="TRANSCRIPT" code="CASE LOG">
                      <Transcript s={s} />
                    </PanelWrap>
                  </div>
                </>
              )}
              {s.phase === "accuse" && (
                <AccusePanel
                  s={s}
                  onAccuse={(suspect, exhibits) => dispatch({ t: "accuse", suspect, exhibits })}
                  onClose={() => dispatch({ t: "leave" })}
                />
              )}
              {s.phase === "verdict" && <VerdictPanel s={s} onRestart={() => dispatch({ t: "start" })} />}
              {(s.phase === "site" || s.phase === "brief") && <FindingsPanel s={s} />}
            </div>
          </div>
        </div>

        <div className="flex flex-1 items-end justify-between gap-3 p-3">
          <div className="pointer-events-auto flex items-end gap-2">
            <SiteTabs s={s} onSite={(site) => dispatch({ t: "site", site })} />
            <MethodBar s={s} onMethod={(method) => dispatch({ t: "method", method })} />
            <div className="flex flex-col gap-2">
              <SearchHint s={s} />
              <div className="v v-flat pointer-events-auto flex flex-col">
                <div className="border-b border-rule px-3 py-1.5 text-[9px] v-tracked text-paper/40">INTERVIEW</div>
                {CHARACTERS.map((c) => (
                  <button
                    key={c.id}
                    className="border-l-2 border-transparent px-3 py-1.5 text-left text-[10px] v-tracked text-paper hover:border-amber hover:bg-ink-3"
                    onClick={() => {
                      setWho(c.id);
                      dispatch({ t: "interview", who: c.id });
                    }}
                  >
                    {c.name}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {searching && (
            <div className="v v-flat pointer-events-auto max-w-[460px] px-3 py-2 text-[10px] leading-relaxed text-paper/55">
              <span className="text-amber">SEARCH</span> the frame. Markers are one-shot — spend one and it dims to an
              imprint. Hidden traces need the matching method active.
            </div>
          )}
        </div>
      </div>

      {/* toast */}
      {s.toast && <Toast text={s.toast.text} k={s.toast.key} />}

      {/* title / brief */}
      {(s.phase === "title" || s.phase === "brief") && (
        <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
          {s.phase === "title" ? (
            <TitleScreen onStart={() => dispatch({ t: "start" })} />
          ) : (
            <BriefScreen onStart={() => dispatch({ t: "enter" })} />
          )}
        </div>
      )}

      {/* the fixed frame, drawn in flat vector over the lit diorama */}
      <FrameBrackets
        pose={`${SITE_BY_ID[s.site].cam.height.toFixed(1)}M UP · PITCH ${SITE_BY_ID[s.site].cam.pitchDeg}° · AZ ${
          SITE_BY_ID[s.site].cam.azimuthDeg
        }° · READ-ONLY`}
      />

      {/* fade — site switches only */}
      <div
        className="pointer-events-none absolute inset-0 bg-ink transition-opacity duration-300"
        style={{ opacity: fade ? 1 : 0 }}
      />
    </div>
  );
}

function PanelWrap({
  title,
  code,
  children,
}: {
  title: string;
  code?: string;
  children: React.ReactNode;
}) {
  return (
    <section className="v v-flat flex h-full flex-col" aria-label={title}>
      <header className="flex items-center justify-between border-b border-rule px-3 py-2">
        <h2 className="text-[11px] v-tracked text-amber">{title}</h2>
        {code && <span className="text-[10px] v-tracked text-paper/40 v-num">{code}</span>}
      </header>
      <div className="min-h-0 flex-1">{children}</div>
    </section>
  );
}
