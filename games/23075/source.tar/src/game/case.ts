import type { Character, Evidence, Marker, Method, Rebuttal, Site, Suspect, Topic } from "./types";

/* =========================================================================
   THE VANTAGE WING
   14 November. The east wing of Vantage Lodge burns. Ilse Vantage dies
   inside. It is ruled accidental. You are the reviewing investigator.
   ========================================================================= */

export const CASE_TITLE = "THE VANTAGE WING";
export const CASE_SUB = "Case 44-B · reviewing investigation";
export const CASE_BRIEF = [
  "On the night of 14 November the east wing of Vantage Lodge burned to the frame. Ilse Vantage, its founder, died inside. The fire was ruled accidental at the scene.",
  "You have three fixed frames — the burnt wing, the yard, and the archive annex — and three people who were near it. Search each frame. File what holds. Break what does not.",
];

export const TAGS: Record<string, string> = {
  card4: "CARD #4",
  t2104: "21:04",
  t2101: "21:01",
  t2100: "21:00",
  "key-east": "EAST WING KEY",
  "hand-m": "HAND: M. HOLT",
  "trace-glass": "TRACE: GLASS",
  "rain-2040": "RAIN FROM 20:40",
  "car-cassia": "SEDAN: C. VANTAGE",
  "lamp-out": "LANTERN UNLIT",
  "fiber-navy": "FIBER: NAVY",
  "boot-42": "BOOT: 42",
  "oil-sedan": "OIL: SEDAN",
  "trace-ink": "TRACE: INK",
};

export const SITES: Site[] = [
  {
    id: "lodge",
    name: "VANTAGE LODGE",
    sub: "east wing · burnt",
    brief: "Timber frame, scorched to the sill. The east door, the desk, and the window you cannot see the other side of.",
    cam: { target: [0.2, 1.1, 0.8], height: 10, pitchDeg: 40, azimuthDeg: 34, margin: 1.05 },
  },
  {
    id: "yard",
    name: "THE YARD",
    sub: "wet concrete · 01:20",
    brief: "Rain from 20:40 and never stopped. Two vehicles, a fence, a hut, and a row of conifers holding the line.",
    cam: { target: [0, 0.9, -1.8], height: 11, pitchDeg: 40, azimuthDeg: 34, margin: 1.04 },
  },
  {
    id: "archive",
    name: "ARCHIVE ANNEX",
    sub: "records · cold",
    brief: "Shelving to the ceiling, one working lamp, and a card dispenser with a gap in it.",
    cam: { target: [0, 1.0, 0.8], height: 10, pitchDeg: 40, azimuthDeg: 36, margin: 1.05 },
  },
];

export const METHODS: Method[] = [
  {
    id: "trace",
    name: "TRACE METHOD",
    code: "TRC",
    blurb: "Reads residue the eye skips: soot on glass, prints in wet concrete, oil, ink.",
    unlockAt: 3,
  },
  {
    id: "hand",
    name: "HANDWRITING METHOD",
    code: "HND",
    blurb: "Compares hands across documents. Reveals copies that were never meant to be seen.",
    unlockAt: 6,
  },
];

export const EVIDENCE: Evidence[] = [
  /* ---- SITE 1 · TIMBER LODGE ---- */
  {
    id: "E_KEYLOG",
    name: "Key-Card Reader Log",
    site: "lodge",
    glyph: "card",
    note: "The reader by the east door survived the fire. Its last line is card #4, 21:04, door released.",
    tags: ["card4", "t2104"],
  },
  {
    id: "E_BRASSKEY",
    name: "Melted Brass Key",
    site: "lodge",
    glyph: "key",
    note: "A brass key fused inside the east lock. A key only stays in a lock that is shut on it — from the outside.",
    tags: ["key-east"],
  },
  {
    id: "E_LEDGER",
    name: "Guest Ledger Page",
    site: "lodge",
    glyph: "page",
    note: "The wing ledger, open at the night of the 14th. M. HOLT signs out at 21:00, in a hand that presses hard.",
    tags: ["hand-m", "t2100"],
  },
  {
    id: "E_SOOT",
    name: "Soot Smear",
    site: "lodge",
    glyph: "smear",
    note: "A palm-width smear of soot across the window sill, dragged outward. Someone left through the glass.",
    tags: ["trace-glass"],
  },
  {
    id: "E_FLOOR",
    name: "Water-Stained Board",
    site: "lodge",
    glyph: "board",
    note: "A floorboard dark with standing water, still damp at 01:20. Rain began at 20:40.",
    tags: ["rain-2040"],
  },
  { id: "E_BEAR", name: "Charred Plush", site: "lodge", glyph: "plush", note: "A child's toy, burned. Sentiment, not evidence.", tags: [], decoy: true },
  { id: "E_MATCH", name: "Burnt Matchbox", site: "lodge", glyph: "match", note: "A matchbox, empty. Every lodge has a hundred of these.", tags: [], decoy: true },

  /* ---- SITE 2 · THE YARD ---- */
  {
    id: "E_SEDAN",
    name: "Wet Sedan Tires",
    site: "yard",
    glyph: "tire",
    note: "A grey sedan, Cassia Vantage's registration. Tires still dark with rain, mud on the sills, engine warm at 01:20.",
    tags: ["car-cassia", "rain-2040"],
  },
  {
    id: "E_GATE",
    name: "Gate Timer Log",
    site: "yard",
    glyph: "timer",
    note: "The gate timer logged a pass at 21:01. Its fault lamp is dead — the clock, however, kept running.",
    tags: ["t2101"],
  },
  {
    id: "E_LANTERN",
    name: "Warden's Lantern",
    site: "yard",
    glyph: "lantern",
    note: "The warden's lantern on the hut step. Wick dry, reservoir cold. It was never lit that night.",
    tags: ["lamp-out"],
  },
  {
    id: "E_FIBER",
    name: "Torn Jacket Fiber",
    site: "yard",
    glyph: "fiber",
    note: "Navy wool fiber caught and torn on a conifer branch beside the sedan. Torn outward, at shoulder height.",
    tags: ["fiber-navy"],
  },
  {
    id: "E_BOOT",
    name: "Boot Print",
    site: "yard",
    glyph: "boot",
    note: "A size-42 boot pressed into the wet concrete on the gate line, heading up the drive.",
    tags: ["boot-42"],
  },
  {
    id: "E_OIL",
    name: "Oil Drip Trail",
    site: "yard",
    glyph: "oil",
    note: "A fresh oil trail running from the sedan's sump to the drive. New oil, not old.",
    tags: ["oil-sedan"],
  },
  { id: "E_CAN", name: "Empty Soda Can", site: "yard", glyph: "can", note: "A can, crushed, three days old. Nothing to say with it.", tags: [], decoy: true },
  { id: "E_NEST", name: "Bird Nest", site: "yard", glyph: "nest", note: "A nest on a fence post. The yard has eleven of these.", tags: [], decoy: true },

  /* ---- SITE 3 · ARCHIVE ANNEX ---- */
  {
    id: "E_FORGE",
    name: "Forged Ledger Entry",
    site: "archive",
    glyph: "ledger",
    note: "The annex register. The 14th's entry for M. HOLT is in a hand that copies her own signature badly.",
    tags: ["hand-m", "card4"],
  },
  {
    id: "E_CARBON",
    name: "Carbon Copy",
    site: "archive",
    glyph: "carbon",
    note: "A carbon left in the drawer: the same entry, written at 21:00 — before the wing burned.",
    tags: ["hand-m", "t2100"],
  },
  {
    id: "E_DISPENSER",
    name: "Card Dispenser",
    site: "archive",
    glyph: "dispenser",
    note: "The wall dispenser. Slot four is empty; the counter reads 401. Card #4 left the annex that night.",
    tags: ["card4"],
  },
  {
    id: "E_COAT",
    name: "Soaked Navy Coat",
    site: "archive",
    glyph: "coat",
    note: "A navy wool coat on the annex hook, still soaked through, hem torn at the left shoulder.",
    tags: ["fiber-navy", "rain-2040"],
  },
  {
    id: "E_INK",
    name: "Ink Smear",
    site: "archive",
    glyph: "ink",
    note: "A smear of blue-black ink on the drawer edge, thumb-printed. Someone wrote here in a hurry.",
    tags: ["trace-ink"],
  },
  { id: "E_CABINET", name: "Dusty Filing Cabinet", site: "archive", glyph: "cabinet", note: "A cabinet, undisturbed, dust unbroken. It was never opened.", tags: [], decoy: true },
  { id: "E_LAMP", name: "Broken Desk Lamp", site: "archive", glyph: "lamp", note: "A lamp with a cracked shade. Broken for years; the annex has two.", tags: [], decoy: true },
];

export const REAL_TOTAL = EVIDENCE.filter((e) => !e.decoy).length;
export const KEY_EXHIBITS = ["E_KEYLOG", "E_FORGE", "E_CARBON"];
export const CULPRIT = "maren";

/* ---------------- MARKERS: one-shot, pinned to the fixed frame ---------------- */
export const MARKERS: Marker[] = [
  /* lodge */
  { id: "mk_reader", site: "lodge", label: "Card reader", pos: [-4.82, 1.36, 1.55], size: [0.6, 0.6, 0.5], evidence: "E_KEYLOG" },
  { id: "mk_ash", site: "lodge", label: "Ash pile", pos: [-3.55, 0.16, 0.5], size: [1.0, 0.5, 1.0], evidence: "E_BRASSKEY" },
  { id: "mk_ledger", site: "lodge", label: "Open ledger", pos: [1.72, 0.94, 1.5], size: [0.8, 0.35, 0.6], evidence: "E_LEDGER" },
  { id: "mk_sill", site: "lodge", label: "Window sill", pos: [2.2, 1.14, -3.78], size: [1.4, 0.4, 0.5], evidence: "E_SOOT", hiddenBy: "trace" },
  { id: "mk_board", site: "lodge", label: "Dark board", pos: [-1.5, 0.06, -1.0], size: [1.3, 0.3, 1.0], evidence: "E_FLOOR" },
  { id: "mk_bear", site: "lodge", label: "Charred shape", pos: [3.5, 0.24, -2.4], size: [0.7, 0.6, 0.7], evidence: "E_BEAR", decoy: true },
  { id: "mk_match", site: "lodge", label: "Small box", pos: [-0.4, 0.1, 2.25], size: [0.45, 0.3, 0.45], evidence: "E_MATCH", decoy: true },

  /* yard */
  { id: "mk_sedan", site: "yard", label: "Grey sedan", pos: [2.5, 0.85, -1.0], size: [2.6, 1.5, 2.4], evidence: "E_SEDAN" },
  { id: "mk_gate", site: "yard", label: "Gate timer", pos: [6.0, 1.55, -6.0], size: [1.0, 1.1, 1.0], evidence: "E_GATE" },
  { id: "mk_lantern", site: "yard", label: "Lantern", pos: [-6.0, 0.62, 1.8], size: [0.9, 0.9, 0.9], evidence: "E_LANTERN" },
  { id: "mk_fiber", site: "yard", label: "Branch", pos: [-2.0, 1.55, -5.0], size: [1.3, 1.3, 1.3], evidence: "E_FIBER" },
  { id: "mk_boot", site: "yard", label: "Wet concrete", pos: [4.5, 0.08, -4.2], size: [1.5, 0.5, 1.5], evidence: "E_BOOT", hiddenBy: "trace" },
  { id: "mk_oil", site: "yard", label: "Drip line", pos: [3.9, 0.06, 0.3], size: [1.7, 0.4, 1.3], evidence: "E_OIL", hiddenBy: "trace" },
  { id: "mk_can", site: "yard", label: "Crushed can", pos: [-2.0, 0.1, 0.6], size: [0.6, 0.5, 0.6], evidence: "E_CAN", decoy: true },
  { id: "mk_nest", site: "yard", label: "Nest", pos: [0.5, 1.95, 1.2], size: [1.0, 0.8, 1.0], evidence: "E_NEST", decoy: true },

  /* archive */
  { id: "mk_forge", site: "archive", label: "Annex register", pos: [2.6, 0.9, 1.25], size: [0.9, 0.4, 0.7], evidence: "E_FORGE" },
  { id: "mk_carbon", site: "archive", label: "Open drawer", pos: [2.35, 0.62, 1.95], size: [0.9, 0.4, 0.6], evidence: "E_CARBON", hiddenBy: "hand" },
  { id: "mk_dispenser", site: "archive", label: "Dispenser", pos: [-4.85, 1.62, -1.0], size: [0.5, 0.9, 0.9], evidence: "E_DISPENSER" },
  { id: "mk_coat", site: "archive", label: "Coat on hook", pos: [-4.5, 1.25, 2.2], size: [0.8, 1.6, 0.8], evidence: "E_COAT" },
  { id: "mk_ink", site: "archive", label: "Drawer edge", pos: [3.3, 0.64, 1.95], size: [0.6, 0.4, 0.6], evidence: "E_INK", hiddenBy: "trace" },
  { id: "mk_cabinet", site: "archive", label: "Cabinet", pos: [-3.0, 0.6, 2.6], size: [1.4, 1.4, 1.0], evidence: "E_CABINET", decoy: true },
  { id: "mk_lamp", site: "archive", label: "Cracked lamp", pos: [4.6, 0.32, 2.2], size: [0.7, 0.9, 0.7], evidence: "E_LAMP", decoy: true },
];

/* ---------------- CHARACTERS ---------------- */
export const CHARACTERS: Character[] = [
  {
    id: "maren",
    name: "DR. MAREN HOLT",
    role: "lodge physician · 41",
    face: "maren",
    intro: "She has been answering the same three questions for a week. She has gotten very good at the third one.",
  },
  {
    id: "renk",
    name: "TOBIAS RENK",
    role: "night warden · 58",
    face: "renk",
    intro: "He watches the drive from a hut with one working window. He has not slept since the bell.",
  },
  {
    id: "cassia",
    name: "CASSIA VANTAGE",
    role: "heir · 29",
    face: "cassia",
    intro: "She has not been to the hill in a week, by her account. She is very particular about the week.",
  },
];

export const SUSPECTS: Suspect[] = [
  { id: "maren", name: "DR. MAREN HOLT", role: "lodge physician", face: "maren", alibi: "Archive annex, 20:30–22:00." },
  { id: "renk", name: "TOBIAS RENK", role: "night warden", face: "renk", alibi: "Asleep in the hut after 20:40." },
  { id: "cassia", name: "CASSIA VANTAGE", role: "heir", face: "cassia", alibi: "In the city since Sunday." },
];

/* ---------------- TOPICS: unlocked by evidence tags ---------------- */
export const TOPICS: Topic[] = [
  {
    id: "m_where",
    who: "maren",
    requires: [],
    prompt: "Where were you at 21:00?",
    lines: [
      "I was in the archive annex. I logged in at twenty past eight and I did not leave until the fire took the wing.",
      "You can check the annex register. I signed in. I signed nothing else.",
    ],
  },
  {
    id: "m_door",
    who: "maren",
    requires: ["card4"],
    prompt: "The east wing door",
    lines: [
      "The east wing was locked from the inside. Ilse locked herself in — she did that every night when she was cross.",
      "I never had a card that night. Not one.",
    ],
    rebuttal: "R1",
  },
  {
    id: "m_coat",
    who: "maren",
    requires: ["fiber-navy"],
    prompt: "The navy coat in the annex",
    lines: [
      "That is Cassia's coat. She wore it to her grandmother's funeral, two winters back.",
      "It has not been out of the annex wardrobe since.",
    ],
  },
  {
    id: "m_card4",
    who: "maren",
    requires: ["card4", "t2104"],
    prompt: "Card number four",
    lines: [
      "Four is the annex key. It opens the annex and nothing else.",
      "Unless someone has been copying numbers. People do that.",
    ],
  },

  {
    id: "r_round",
    who: "renk",
    requires: [],
    prompt: "The night round",
    lines: [
      "I walked the round at twenty to nine with the lantern. Then I slept in the hut until the bell.",
      "The hut is warm. I do not wake for much.",
    ],
  },
  {
    id: "r_gate",
    who: "renk",
    requires: ["t2101"],
    requiresMethods: ["trace"],
    prompt: "The gate",
    lines: [
      "Nobody passed the gate after eight. I would have heard the chain.",
      "The timer is broken — it has been since August. It logs nothing but its own fault.",
    ],
    rebuttal: "R2",
  },
  {
    id: "r_sedan",
    who: "renk",
    requires: ["car-cassia"],
    prompt: "The grey sedan",
    lines: [
      "That is the young lady's car. It came up the drive before dark, if you ask me.",
      "I do not ask. I watch.",
    ],
  },

  {
    id: "c_where",
    who: "cassia",
    requires: [],
    prompt: "Where were you that night?",
    lines: [
      "I was in the city. I have not been to the lodge since Sunday.",
      "I have not seen the yard, the drive or the annex in a week.",
    ],
  },
  {
    id: "c_coat",
    who: "cassia",
    requires: ["fiber-navy"],
    prompt: "The navy coat",
    lines: [
      "That coat is mine. It has been in my city wardrobe since Sunday.",
      "Nobody wore it on the hill. Nobody.",
    ],
    rebuttal: "R3",
  },
  {
    id: "c_card",
    who: "cassia",
    requires: ["card4", "t2104"],
    prompt: "The card log",
    lines: [
      "Maren had a card. She had a card for everything.",
      "She also had a key to the annex. Ask her what she was filing at nine.",
    ],
  },
];

/* ---------------- REBUTTALS ---------------- */
export const REBUTTALS: Rebuttal[] = [
  {
    id: "R1",
    claimant: "maren",
    claim:
      "The east wing was locked from the inside. Ilse locked herself in. I never had a card that night.",
    solution: ["E_KEYLOG", "E_BRASSKEY", "E_LEDGER"],
    resolution:
      "Card #4 released the east door at 21:04 — four minutes after the ledger already had her signing out at 21:00. And the brass key melted inside the lock, which is where a key goes when the door is shut on it from the outside.",
    hints: [
      "Three exhibits. No more, no fewer. A partial set does not hold.",
      "The claim has three pillars — the lock, the card, and her whereabouts. Strike all three.",
      "One exhibit is a machine that keeps its own time. It is by the east door.",
      "The brass key is an exhibit. So is the page she signed.",
      "Reader log, brass key, ledger page.",
    ],
    opensSite: "archive",
  },
  {
    id: "R2",
    claimant: "renk",
    claim: "Nobody passed the gate after eight. The timer is broken.",
    solution: ["E_GATE", "E_BOOT", "E_LANTERN"],
    resolution:
      "The timer logged a pass at 21:01 — the fault is in its lamp, not its clock. A size-42 boot pressed the wet concrete on the gate line. And the warden's wick is dry: he never carried the lantern out.",
    hints: [
      "Three exhibits. No more, no fewer. A partial set does not hold.",
      "He denies the pass, the timer and the round. One exhibit for each.",
      "The timer itself is an exhibit. A broken instrument still keeps time.",
      "Look at the concrete. Then look at the wick.",
      "Gate timer, boot print, lantern.",
    ],
  },
  {
    id: "R3",
    claimant: "cassia",
    claim:
      "That coat is mine and it has been in my city wardrobe since Sunday. Nobody wore it on the hill.",
    solution: ["E_COAT", "E_FIBER", "E_SEDAN"],
    resolution:
      "The coat is soaked and hanging in the annex. The navy fiber is torn on a conifer beside the sedan. And the sedan that carries it stands on wet concrete with its tires still dark. It came up the hill that night — driven.",
    hints: [
      "Three exhibits. No more, no fewer. A partial set does not hold.",
      "The coat, what it tore, and what carried it.",
      "The coat is an exhibit. So is the fiber on the branch.",
      "Something in the yard moved that night.",
      "Soaked coat, torn fiber, wet sedan.",
    ],
  },
];

/* ---------------- lookups ---------------- */
export const byId = <T extends { id: string }>(list: T[], id: string): T => {
  const found = list.find((x) => x.id === id);
  if (!found) throw new Error(`missing ${id}`);
  return found;
};

export const EVIDENCE_BY_ID: Record<string, Evidence> = Object.fromEntries(EVIDENCE.map((e) => [e.id, e]));
export const REBUTTAL_BY_ID: Record<string, Rebuttal> = Object.fromEntries(REBUTTALS.map((r) => [r.id, r]));
export const SITE_BY_ID: Record<string, Site> = Object.fromEntries(SITES.map((s) => [s.id, s]));
export const CHAR_BY_ID: Record<string, Character> = Object.fromEntries(CHARACTERS.map((c) => [c.id, c]));
export const SUSPECT_BY_ID: Record<string, Suspect> = Object.fromEntries(SUSPECTS.map((s) => [s.id, s]));
export const MARKERS_BY_SITE: Record<string, Marker[]> = SITES.reduce(
  (acc, s) => {
    acc[s.id] = MARKERS.filter((m) => m.site === s.id);
    return acc;
  },
  {} as Record<string, Marker[]>,
);
