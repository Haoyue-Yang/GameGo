/**
 * THE VANTAGE WING — case data model.
 *
 * The loop:
 *   search fixed frame -> one-shot markers -> filed evidence carries TAGS
 *   -> TAGS unlock interview topics -> a topic makes a character state a
 *      flawed CLAIM -> cross-examination (unordered slot set must equal the
 *      solution exactly) -> upheld rebuttal -> new site / accusation.
 */

export type MethodId = "trace" | "hand";

export interface Method {
  id: MethodId;
  name: string;
  code: string;
  blurb: string;
  /** number of real (non-decoy) exhibits that must be filed before it unlocks */
  unlockAt: number;
}

/** A one-shot marker pinned to a fixed frame. Spent markers dim to an imprint. */
export interface Marker {
  id: string;
  site: string;
  label: string;
  /** world-space centre of the hit volume */
  pos: [number, number, number];
  /** world-space size of the hit volume (raycast target) */
  size: [number, number, number];
  /** evidence filed when the marker is spent */
  evidence: string;
  /** hidden until this method is active */
  hiddenBy?: MethodId;
  /** decoy markers file nothing of evidentiary value */
  decoy?: boolean;
}

export interface Evidence {
  id: string;
  name: string;
  site: string;
  /** short vector glyph key drawn in the card */
  glyph: GlyphKey;
  /** flat description, unlit vector copy */
  note: string;
  tags: string[];
  decoy?: boolean;
}

export type GlyphKey =
  | "card"
  | "key"
  | "page"
  | "smear"
  | "board"
  | "plush"
  | "match"
  | "tire"
  | "timer"
  | "lantern"
  | "fiber"
  | "boot"
  | "oil"
  | "can"
  | "nest"
  | "ledger"
  | "carbon"
  | "dispenser"
  | "coat"
  | "ink"
  | "cabinet"
  | "lamp";

export interface Site {
  id: string;
  name: string;
  sub: string;
  /** fixed read-only camera pose */
  cam: {
    target: [number, number, number];
    height: number;
    pitchDeg: number;
    azimuthDeg: number;
    /** framing margin; 1 = exact fit */
    margin: number;
  };
  brief: string;
}

export interface Rebuttal {
  id: string;
  claimant: string;
  /** the flawed claim, verbatim */
  claim: string;
  /** the unordered set of evidence ids that must exactly fill the slots */
  solution: string[];
  /** why it holds, revealed only after the rebuttal is upheld */
  resolution: string;
  /** escalating hints; index = attempts already burned */
  hints: string[];
  /** unlocks a site once upheld */
  opensSite?: string;
}

export interface Topic {
  id: string;
  who: string;
  /** evidence tags required before the topic exists */
  requires: string[];
  /** methods that must be unlocked before the topic may be asked */
  requiresMethods?: MethodId[];
  prompt: string;
  lines: string[];
  /** asking this topic makes the character state a flawed claim */
  rebuttal?: string;
}

export interface Character {
  id: string;
  name: string;
  role: string;
  /** flat vector portrait key */
  face: "maren" | "renk" | "cassia";
  intro: string;
}

export interface Suspect {
  id: string;
  name: string;
  role: string;
  face: "maren" | "renk" | "cassia";
  alibi: string;
}

export interface GameState {
  phase: "title" | "brief" | "site" | "interview" | "rebuttal" | "accuse" | "verdict";
  site: string;
  sitesOpen: string[];
  /** markers whose one-shot has been spent */
  spent: string[];
  /** evidence filed to the board */
  filed: string[];
  activeMethod: MethodId | null;
  methodsOpen: MethodId[];
  askedTopics: string[];
  openRebuttal: string | null;
  upheld: string[];
  attempts: number;
  hintLevel: number;
  mistakes: number;
  /** evidence dragged into the numbered slots, by slot index */
  slots: (string | null)[];
  /** pre-rebuttal snapshot; rolled back when attempts hit zero */
  checkpoint: Checkpoint | null;
  accused: { suspect: string; exhibits: string[] } | null;
  log: LogLine[];
  shakeKey: number;
  flashKey: number;
  toast: { text: string; key: number } | null;
}

export interface Checkpoint {
  phase: GameState["phase"];
  site: string;
  askedTopics: string[];
  activeMethod: MethodId | null;
  openRebuttal: string | null;
  attempts: number;
  hintLevel: number;
  slots: (string | null)[];
  log: LogLine[];
}

export interface LogLine {
  id: number;
  kind: "sys" | "who" | "say" | "claim" | "ok" | "fail";
  text: string;
  who?: string;
}
