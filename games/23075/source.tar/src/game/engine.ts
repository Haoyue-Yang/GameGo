import {
  CULPRIT,
  EVIDENCE,
  EVIDENCE_BY_ID,
  KEY_EXHIBITS,
  MARKERS,
  REAL_TOTAL,
  REBUTTAL_BY_ID,
  REBUTTALS,
  SITES,
  TOPICS,
  CHAR_BY_ID,
} from "./case";
import type { Checkpoint, GameState, LogLine, MethodId } from "./types";

export const MAX_ATTEMPTS = 5;
export const REAL_TOTAL_LABEL = String(REAL_TOTAL);

let logSeq = 0;
let toastSeq = 0;
const line = (kind: LogLine["kind"], text: string, who?: string): LogLine => ({
  id: ++logSeq,
  kind,
  text,
  who,
});

export function initialState(): GameState {
  return {
    phase: "title",
    site: "lodge",
    sitesOpen: ["lodge", "yard"],
    spent: [],
    filed: [],
    activeMethod: null,
    methodsOpen: [],
    askedTopics: [],
    openRebuttal: null,
    upheld: [],
    attempts: MAX_ATTEMPTS,
    hintLevel: 0,
    mistakes: 0,
    slots: [],
    checkpoint: null,
    accused: null,
    log: [],
    shakeKey: 0,
    flashKey: 0,
    toast: null,
  };
}

/* ------------------------------------------------------------------ *
 *  derived helpers
 * ------------------------------------------------------------------ */

export const filedReal = (s: GameState) => s.filed.filter((id) => !EVIDENCE_BY_ID[id]?.decoy);

export function tagsOf(s: GameState): Set<string> {
  const out = new Set<string>();
  for (const id of filedReal(s)) for (const t of EVIDENCE_BY_ID[id].tags) out.add(t);
  return out;
}

export function methodsOpenFor(s: GameState): MethodId[] {
  const n = filedReal(s).length;
  return (["trace", "hand"] as MethodId[]).filter((m) => {
    const def = { trace: 3, hand: 6 }[m];
    return n >= def;
  });
}

/** Can this exhibit still be found? Site open AND its method unlocked. */
export function collectable(s: GameState, evId: string): boolean {
  const ev = EVIDENCE_BY_ID[evId];
  const mk = MARKERS.find((m) => m.evidence === evId);
  if (!ev || !mk) return false;
  if (!s.sitesOpen.includes(mk.site)) return false;
  if (mk.hiddenBy && !s.methodsOpen.includes(mk.hiddenBy)) return false;
  return true;
}

/**
 * THE INVARIANT — a rebuttal may never fire unless every exhibit in its
 * solution is collectable first. Enforced at the topic gate below.
 */
export function solutionCollectable(s: GameState, rebuttalId: string): boolean {
  const r = REBUTTAL_BY_ID[rebuttalId];
  if (!r) return false;
  return r.solution.every((e) => collectable(s, e));
}

export function topicState(s: GameState, topicId: string) {
  const t = TOPICS.find((x) => x.id === topicId)!;
  const tags = tagsOf(s);
  const asked = s.askedTopics.includes(t.id);
  const tagOk = t.requires.every((r) => tags.has(r));
  const methodOk = (t.requiresMethods ?? []).every((m) => s.methodsOpen.includes(m));
  const solOk = t.rebuttal ? solutionCollectable(s, t.rebuttal) : true;
  const missingTags = t.requires.filter((r) => !tags.has(r));
  const missingMethods = (t.requiresMethods ?? []).filter((m) => !s.methodsOpen.includes(m));
  return {
    topic: t,
    asked,
    available: tagOk && methodOk && solOk && !asked,
    tagOk,
    methodOk,
    solOk,
    missingTags,
    missingMethods,
  };
}

export const evidenceUnlocked = (s: GameState) => s.filed.map((id) => EVIDENCE_BY_ID[id]);

/**
 * DATA AUDIT — run at boot in development.
 *
 * The hard invariant of the case: every exhibit in a rebuttal solution must be
 * collectable before that rebuttal can fire. A topic is never selectable unless
 * `solutionCollectable()` passes, so this audit only has to prove the data is
 * sound enough for that gate to be satisfiable.
 */
export function auditCase(): string[] {
  const issues: string[] = [];

  // every tag a topic asks for must be obtainable somewhere
  const allTags = new Set<string>();
  for (const m of MARKERS) {
    const e = EVIDENCE_BY_ID[m.evidence];
    if (!e.decoy) e.tags.forEach((t) => allTags.add(t));
  }
  for (const t of TOPICS)
    for (const r of t.requires) if (!allTags.has(r)) issues.push(`${t.id}: tag "${r}" is never obtainable`);

  // solutions must be exactly three distinct, non-decoy exhibits, each marked
  for (const r of REBUTTALS) {
    const evs = r.solution.map((id) => EVIDENCE_BY_ID[id]);
    if (evs.length !== 3) issues.push(`${r.id}: solution is not three exhibits`);
    if (new Set(evs.map((e) => e.id)).size !== evs.length) issues.push(`${r.id}: duplicate exhibits`);
    if (evs.some((e) => e.decoy)) issues.push(`${r.id}: solution includes a decoy`);
    for (const e of evs) if (!MARKERS.some((m) => m.evidence === e.id)) issues.push(`${r.id}: ${e.id} has no marker`);
  }

  // the rebuttal that opens the third site must already be collectable at boot
  const boot = initialState();
  for (const r of REBUTTALS)
    if (r.opensSite && !solutionCollectable(boot, r.id))
      issues.push(`${r.id}: opens ${r.opensSite} but is not collectable at boot`);

  return issues;
}

export function coverage(s: GameState) {
  return filedReal(s).length / REAL_TOTAL;
}

/* ------------------------------------------------------------------ *
 *  actions
 * ------------------------------------------------------------------ */

export type Action =
  | { t: "start" }
  | { t: "enter" }
  | { t: "site"; site: string }
  | { t: "spend"; marker: string }
  | { t: "method"; method: MethodId | null }
  | { t: "interview"; who: string }
  | { t: "ask"; topic: string }
  | { t: "leave" }
  | { t: "slot"; index: number; ev: string | null }
  | { t: "clearSlots" }
  | { t: "submit" }
  | { t: "accuseOpen" }
  | { t: "accuse"; suspect: string; exhibits: string[] }
  | { t: "toastOff" };

const push = (s: GameState, ...ls: LogLine[]): LogLine[] => [...s.log, ...ls].slice(-120);

export function reducer(state: GameState, a: Action): GameState {
  switch (a.t) {
    case "start":
      return {
        ...initialState(),
        phase: "brief",
        log: [line("sys", "Case 44-B opened. Three frames assigned. Search is one-shot — a marker spent is a marker gone.")],
      };

    case "enter":
      return { ...state, phase: "site", openRebuttal: null, flashKey: state.flashKey + 1 };

    case "site": {
      if (!state.sitesOpen.includes(a.site) || a.site === state.site) return state;
      return { ...state, phase: "site", site: a.site, openRebuttal: null, flashKey: state.flashKey + 1 };
    }

    case "spend": {
      const mk = MARKERS.find((m) => m.id === a.marker);
      if (!mk || state.spent.includes(mk.id)) return state;
      if (mk.hiddenBy && state.activeMethod !== mk.hiddenBy) return state;
      const spent = [...state.spent, mk.id];
      const ev = EVIDENCE_BY_ID[mk.evidence];
      const filed = ev.decoy ? state.filed : [...state.filed, ev.id];
      const methodsOpen = methodsOpenFor({ ...state, filed });
      const newMethods = methodsOpen.filter((m) => !state.methodsOpen.includes(m));
      let log = push(
        state,
        mk.decoy
          ? line("sys", `${ev.name} — no evidentiary value. Marked as imprint.`)
          : line("ok", `Filed ${ev.name}. Tags: ${ev.tags.map((t) => t.toUpperCase()).join(" · ") || "none"}`),
      );
      for (const m of newMethods) {
        const def = m === "trace" ? "TRACE METHOD" : "HANDWRITING METHOD";
        log = [...log, line("ok", `${def} available. Hidden traces now resolve in the frames.`)];
      }
      return {
        ...state,
        spent,
        filed,
        methodsOpen,
        log,
        toast: {
          text: mk.decoy ? `${ev.name} — no evidentiary value` : `Filed ${ev.name}`,
          key: ++toastSeq,
        },
      };
    }

    case "method":
      return { ...state, activeMethod: a.method };

    case "interview": {
      const c = CHAR_BY_ID[a.who];
      return { ...state, phase: "interview", openRebuttal: null, log: push(state, line("sys", `Interview — ${c.name}.`)) };
    }

    case "ask": {
      const st = topicState(state, a.topic);
      if (!st.available) return state;
      const t = st.topic;
      let log = push(state, line("who", t.prompt), ...t.lines.map((l) => line("say", l, t.who)));
      let next: GameState = { ...state, askedTopics: [...state.askedTopics, t.id], log };

      if (t.rebuttal) {
        const r = REBUTTAL_BY_ID[t.rebuttal];
        log = push(next, line("claim", r.claim, t.who));
        next = {
          ...next,
          log,
          openRebuttal: r.id,
          phase: "rebuttal",
          attempts: MAX_ATTEMPTS,
          hintLevel: 0,
          slots: r.solution.map(() => null),
          // checkpoint = the moment before the claim was stated
          checkpoint: {
            phase: "interview",
            site: state.site,
            askedTopics: state.askedTopics,
            activeMethod: state.activeMethod,
            openRebuttal: null,
            attempts: MAX_ATTEMPTS,
            hintLevel: 0,
            slots: [],
            log: state.log,
          } as Checkpoint,
        };
      }
      return next;
    }

    case "leave":
      return { ...state, phase: "site", openRebuttal: null, slots: [] };

    case "slot": {
      const r = state.openRebuttal ? REBUTTAL_BY_ID[state.openRebuttal] : null;
      if (!r) return state;
      const slots = [...state.slots];
      if (a.ev) {
        // an exhibit occupies one slot only
        const prev = slots.indexOf(a.ev);
        if (prev >= 0) slots[prev] = null;
      }
      slots[a.index] = a.ev;
      return { ...state, slots };
    }

    case "clearSlots":
      return { ...state, slots: state.openRebuttal ? REBUTTAL_BY_ID[state.openRebuttal].solution.map(() => null) : [] };

    case "submit": {
      const r = state.openRebuttal ? REBUTTAL_BY_ID[state.openRebuttal] : null;
      if (!r) return state;
      const placed = state.slots.filter((x): x is string => !!x);
      const sol = r.solution;
      // unordered set equality — partial hits fail, and the gap is never named
      const exact =
        placed.length === sol.length && sol.every((s) => placed.includes(s)) && placed.every((p) => sol.includes(p));

      if (exact) {
        const sitesOpen = r.opensSite && !state.sitesOpen.includes(r.opensSite) ? [...state.sitesOpen, r.opensSite] : state.sitesOpen;
        const siteName = r.opensSite ? SITES.find((s) => s.id === r.opensSite)!.name : null;
        return {
          ...state,
          upheld: [...state.upheld, r.id],
          sitesOpen,
          openRebuttal: null,
          slots: [],
          phase: "interview",
          flashKey: state.flashKey + 1,
          log: push(
            state,
            line("ok", `REBUTTAL UPHOLD — ${r.id}.`),
            line("sys", r.resolution),
            ...(siteName ? [line("ok", `Frame released: ${siteName}.`)] : []),
          ),
        };
      }

      const attempts = state.attempts - 1;
      const hintLevel = Math.min(r.hints.length - 1, state.hintLevel + 1);
      const shakeKey = state.shakeKey + 1;
      let log = push(state, line("fail", "The claim holds. Your rebuttal does not."));

      if (attempts <= 0) {
        const cp = state.checkpoint;
        log = push(state, line("fail", "Attempts exhausted. Rolling back to the pre-rebuttal checkpoint."));
        return {
          ...state,
          ...cp,
          phase: "interview",
          openRebuttal: null,
          attempts: MAX_ATTEMPTS,
          hintLevel: 0,
          slots: [],
          mistakes: state.mistakes + 1,
          shakeKey,
          log: [...(cp?.log ?? state.log), ...log.slice(state.log.length)],
          toast: { text: "Rollback — attempts refilled, evidence kept, one mistake tallied", key: ++toastSeq },
        };
      }
      return { ...state, attempts, hintLevel, shakeKey, log };
    }

    case "accuseOpen":
      return { ...state, phase: "accuse", openRebuttal: null, slots: [] };

    case "accuse":
      return {
        ...state,
        phase: "verdict",
        accused: { suspect: a.suspect, exhibits: a.exhibits },
        flashKey: state.flashKey + 1,
        log: push(state, line("sys", `Accusation filed: ${a.suspect.toUpperCase()} on ${a.exhibits.length} exhibits.`)),
        toast: { text: "Case closed", key: ++toastSeq },
      };

    case "toastOff":
      return { ...state, toast: null };

    default:
      return state;
  }
}

/** The verdict is a pure function of the accusation, coverage and mistakes. */
export function computeVerdict(s: GameState): Verdict {
  const exhibits = s.accused?.exhibits ?? [];
  const keyHits = exhibits.filter((e) => KEY_EXHIBITS.includes(e)).length;
  const wrong = exhibits.filter((e) => !KEY_EXHIBITS.includes(e)).length;
  const cov = coverage(s);
  let score = keyHits * 18 + Math.round(cov * 40) + Math.max(0, 22 - s.mistakes * 6);
  if (s.accused?.suspect !== CULPRIT) score = Math.min(score, 38);
  return { score: Math.max(0, Math.min(100, score)), keyHits, wrong, cov };
}

export function gradeOf(score: number) {
  if (score >= 90) return { g: "A", label: "UPHELD IN FULL" };
  if (score >= 75) return { g: "B", label: "UPHELD" };
  if (score >= 58) return { g: "C", label: "UPHELD, PARTIALLY" };
  if (score >= 40) return { g: "D", label: "THIN" };
  return { g: "E", label: "OVERTURNED" };
}

export type Verdict = { score: number; keyHits: number; wrong: number; cov: number };

export const totalEvidence = EVIDENCE.length;
