import * as THREE from "three";
import { Diorama, makeMaterials, type MatDef } from "./kit";

/* =========================================================================
   SITE 3 — ARCHIVE ANNEX
   x ∈ [-5, 5]   z ∈ [-4, 4]   walls at -x and -z
   ========================================================================= */

export const archiveMaterials: Record<string, MatDef> = {
  tile: { color: 0x5c5e5f, rough: 0.9 },
  tile2: { color: 0x4e5051, rough: 0.9 },
  wall: { color: 0x6a6a66, rough: 0.95 },
  wallDark: { color: 0x4a4a48, rough: 0.95 },
  pilaster: { color: 0x565652, rough: 0.95 },
  steel: { color: 0x4a5055, rough: 0.4, metal: 0.55 },
  steelDark: { color: 0x33383c, rough: 0.5, metal: 0.4 },
  box1: { color: 0x6a5a3c, rough: 0.92 },
  box2: { color: 0x5a4a3a, rough: 0.92 },
  box3: { color: 0x4a5548, rough: 0.92 },
  paper: { color: 0xcfc4a8, rough: 0.9 },
  paper2: { color: 0xb0a488, rough: 0.9 },
  navy: { color: 0x22303f, rough: 0.95 },
  navyDark: { color: 0x161f28, rough: 0.95 },
  wood: { color: 0x4a3626, rough: 0.92 },
  woodDark: { color: 0x33251a, rough: 0.92 },
  brass: { color: 0xb08a3c, rough: 0.35, metal: 0.75 },
  lamp: { color: 0xfff0d0, rough: 0.4, emissive: 0xffe0a0, emissiveI: 2.0 },
  ink: { color: 0x1e2a4a, rough: 0.6 },
  glass: { color: 0x2b3d4f, rough: 0.1, metal: 0.55 },
  tube: { color: 0xdfe8f0, rough: 0.3, emissive: 0xbcd4ee, emissiveI: 1.8 },
  wet: { color: 0x2a3238, rough: 0.06, metal: 0.42 },
  dark: { color: 0x14161a, rough: 1 },
};

function shelfUnit(d: Diorama, x: number, z: number, w = 2.2, h = 2.7) {
  d.box("steel", 0.1, h, 0.92, x - w / 2, h / 2, z, { b: 0.02 });
  d.box("steel", 0.1, h, 0.92, x + w / 2, h / 2, z, { b: 0.02 });
  d.box("steelDark", w, h, 0.07, x, h / 2, z - 0.43, { b: 0.02 });
  for (let i = 0; i < 5; i++) d.box("steel", w, 0.07, 0.92, x, 0.24 + i * 0.58, z, { b: 0.015 });
  for (const sx of [-0.34, 0, 0.34]) d.box("steelDark", 0.07, h, 0.07, x + sx * w, h / 2, z + 0.43, { b: 0.015 });
  const mats = ["box1", "box2", "box3"];
  for (let s = 0; s < 4; s++)
    for (let i = 0; i < 4; i++) {
      if ((s + i) % 7 === 3) continue;
      const bw = w / 5;
      d.box(mats[(i + s) % 3], bw, 0.4, 0.7, x - w / 2 + bw / 2 + i * bw, 0.5 + s * 0.58, z, { b: 0.02 });
      d.box("paper2", bw * 0.5, 0.04, 0.14, x - w / 2 + bw / 2 + i * bw, 0.5 + s * 0.58, z + 0.36, { b: 0.008 });
    }
}

export function buildArchive(d: Diorama) {
  /* ---- tiled floor ---- */
  d.grid("tile", 8, 8, 1.25, 1.0, 0.05, -4.375, -0.05, -3.5, 0.1);
  d.grid("tile2", 8, 8, 1.25, 1.0, 0.05, -4.375, -0.14, -3.5, 0.08);

  /* ---- walls with pilasters ---- */
  d.box("wall", 10.6, 3.8, 0.3, 0, 1.9, -4.2, { b: 0.05 });
  d.box("wall", 0.3, 3.8, 8.4, -5.2, 1.9, 0, { b: 0.05 });
  for (const x of [-4.2, -1.4, 1.4, 4.2]) d.box("pilaster", 0.34, 3.8, 0.16, x, 1.9, -3.98, { b: 0.04 });
  for (const z of [-2.6, 0.2, 3.0]) d.box("pilaster", 0.16, 3.8, 0.34, -4.98, 1.9, z, { b: 0.04 });
  d.box("wallDark", 10.6, 0.3, 0.44, 0, 3.65, -4.2, { b: 0.05 });
  d.box("wallDark", 0.44, 0.3, 8.4, -5.2, 3.65, 0, { b: 0.05 });
  d.box("wallDark", 10.2, 0.24, 0.14, 0, 0.12, -3.98, { b: 0.03 });
  d.box("wallDark", 0.14, 0.24, 8.0, -4.98, 0.12, 0, { b: 0.03 });

  /* ---- ceiling, kept to the back so the frame stays readable ---- */
  d.box("wallDark", 10.4, 0.2, 1.9, 0, 3.5, -3.1, { b: 0.04 });
  for (const x of [-3.0, 0, 3.0]) d.box("steelDark", 0.22, 0.22, 1.9, x, 3.3, -3.1, { b: 0.03 });
  d.box("steelDark", 0.3, 0.16, 0.3, 0, 3.28, -2.2, { b: 0.03 });
  d.box("tube", 1.6, 0.1, 0.22, 0, 3.2, -2.2, { b: 0.02 });

  /* ---- shelving ---- */
  shelfUnit(d, -3.4, -3.4);
  shelfUnit(d, 0.0, -3.4);
  shelfUnit(d, 3.4, -3.4);

  /* ---- archive desk ---- */
  d.box("wood", 2.2, 0.12, 1.3, 2.6, 0.78, 1.4, { b: 0.03 });
  d.box("woodDark", 2.0, 0.5, 1.1, 2.6, 0.5, 1.4, { b: 0.04 });
  for (const sx of [-1, 1])
    for (const sz of [-1, 1]) d.box("woodDark", 0.12, 0.76, 0.12, 2.6 + sx * 0.95, 0.38, 1.4 + sz * 0.5, { b: 0.02 });
  /* drawer, pulled out — the carbon copy lives in here */
  d.box("wood", 0.84, 0.24, 0.94, 2.35, 0.62, 1.95, { b: 0.02 });
  d.box("woodDark", 0.78, 0.16, 0.86, 2.35, 0.6, 1.95, { b: 0.015 });
  d.box("paper", 0.52, 0.02, 0.38, 2.35, 0.75, 1.95, { ry: -0.2, b: 0.006 });
  d.box("paper2", 0.48, 0.02, 0.34, 2.35, 0.78, 1.95, { ry: -0.2, b: 0.006 });
  d.slab("ink", 0.18, 0.14, 3.3, 0.65, 1.95, 0.03);
  /* the annex register, open on the desk */
  d.box("paper", 0.62, 0.09, 0.46, 2.6, 0.88, 1.25, { ry: 0.15, b: 0.012 });
  d.box("paper2", 0.56, 0.02, 0.4, 2.6, 0.93, 1.25, { ry: 0.15, b: 0.006 });
  d.box("brass", 0.1, 0.04, 0.04, 2.6, 0.95, 1.05, { b: 0.01 });

  /* ---- working desk lamp ---- */
  d.box("steel", 0.26, 0.06, 0.26, 3.55, 0.86, 0.9, { b: 0.02 });
  d.box("steel", 0.06, 0.46, 0.06, 3.55, 1.08, 0.9, { b: 0.015 });
  d.box("steel", 0.06, 0.06, 0.3, 3.55, 1.3, 1.02, { b: 0.015 });
  d.cone("steel", 0.2, 0.26, 3.55, 1.22, 1.16, 8);
  d.box("lamp", 0.12, 0.06, 0.12, 3.55, 1.12, 1.16, { b: 0.01 });

  /* ---- decoy: broken lamp, knocked off the desk ---- */
  d.box("steel", 0.24, 0.06, 0.24, 4.6, 0.06, 2.2, { b: 0.02 });
  d.box("steel", 0.06, 0.5, 0.06, 4.6, 0.3, 2.2, { b: 0.015 });
  d.cone("steelDark", 0.2, 0.24, 4.6, 0.6, 2.2, 8);

  /* ---- card dispenser on the left wall ---- */
  d.box("steelDark", 0.32, 0.94, 0.94, -4.95, 1.62, -1.0, { b: 0.03 });
  d.frame("steel", 0.16, 0.52, 0.18, 0.05, -4.78, 1.72, -1.0, Math.PI / 2);
  d.box("paper", 0.05, 0.15, 0.22, -4.78, 1.6, -1.0, { b: 0.01 });
  d.box("lamp", 0.07, 0.07, 0.07, -4.78, 1.92, -1.0, { b: 0.01 });
  d.box("paper2", 0.04, 0.2, 0.3, -4.78, 1.32, -1.0, { b: 0.01 });

  /* ---- coat hook and the soaked navy coat ---- */
  d.box("steel", 0.12, 1.9, 0.12, -4.9, 0.95, 2.2, { b: 0.02 });
  d.box("steel", 0.08, 0.08, 0.34, -4.76, 1.86, 2.2, { b: 0.02 });
  d.box("navy", 0.52, 1.32, 0.36, -4.6, 1.2, 2.2, { b: 0.05 });
  d.box("navy", 0.17, 0.92, 0.26, -4.6, 1.42, 1.99, { b: 0.04 });
  d.box("navy", 0.17, 0.92, 0.26, -4.6, 1.42, 2.41, { b: 0.04 });
  d.box("navyDark", 0.36, 0.16, 0.32, -4.6, 1.88, 2.2, { b: 0.03 });
  d.box("navyDark", 0.22, 0.1, 0.12, -4.6, 0.58, 2.05, { b: 0.02 });
  d.slab("wet", 0.5, 0.5, -4.3, 0.02, 2.2, 0.03);

  /* ---- decoy: dusty filing cabinet ---- */
  d.box("steelDark", 1.1, 1.2, 0.7, -3.0, 0.6, 2.6, { b: 0.03 });
  for (let i = 0; i < 3; i++) {
    d.box("steel", 1.0, 0.34, 0.06, -3.0, 0.25 + i * 0.38, 2.26, { b: 0.015 });
    d.box("brass", 0.26, 0.05, 0.05, -3.0, 0.25 + i * 0.38, 2.21, { b: 0.01 });
  }
  d.slab("paper2", 1.0, 0.6, -3.0, 1.22, 2.6, 0.02);

  /* ---- clutter ---- */
  d.box("woodDark", 0.9, 0.14, 0.7, -1.6, 0.07, 3.2, { b: 0.03 });
  d.box("woodDark", 0.9, 0.14, 0.7, -1.6, 0.21, 3.2, { b: 0.03 });
  d.box("box2", 0.6, 0.4, 0.5, -1.6, 0.5, 3.2, { b: 0.02 });
  d.box("box1", 0.5, 0.34, 0.44, -1.5, 0.87, 3.15, { b: 0.02 });
  d.box("steelDark", 0.7, 0.5, 0.5, 4.4, 0.25, 3.2, { b: 0.03 });
  d.box("paper", 0.4, 0.06, 0.3, 4.4, 0.53, 3.2, { ry: 0.3, b: 0.01 });
  d.box("glass", 0.06, 1.0, 0.06, 4.8, 0.5, -3.6, { b: 0.015 });
  d.box("paper", 0.3, 0.4, 0.02, 4.8, 1.0, -3.6, { b: 0.006 });
}

export function archiveMaterialsBuilt() {
  return makeMaterials(archiveMaterials);
}

export function archiveLights(scene: THREE.Scene) {
  scene.add(new THREE.AmbientLight(0x30343a, 0.5));
  scene.add(new THREE.HemisphereLight(0x3a4250, 0x1a1a18, 0.35));

  const cool = new THREE.DirectionalLight(0xbcd4ee, 0.9);
  cool.position.set(-6, 10, 4);
  cool.castShadow = true;
  cool.shadow.mapSize.set(1024, 1024);
  const c = cool.shadow.camera;
  c.left = -8;
  c.right = 8;
  c.top = 8;
  c.bottom = -8;
  c.near = 1;
  c.far = 28;
  cool.shadow.bias = -0.0012;
  scene.add(cool);

  const tube = new THREE.PointLight(0xcfe0f0, 11, 13, 2);
  tube.position.set(0, 3.0, -2.2);
  scene.add(tube);

  const desk = new THREE.PointLight(0xffd9a0, 7, 7, 2);
  desk.position.set(3.55, 1.1, 1.16);
  scene.add(desk);

  const fill = new THREE.PointLight(0x8fa8c0, 4, 9, 2);
  fill.position.set(-3.0, 1.6, 1.0);
  scene.add(fill);
}
