import * as THREE from "three";
import { Diorama, makeMaterials, type MatDef } from "./kit";

/* =========================================================================
   SITE 2 — THE YARD (WET CONCRETE)
   x ∈ [-8, 8]   z ∈ [-7, 2]   fence + conifers at -z, hut at -x
   ========================================================================= */

export const yardMaterials: Record<string, MatDef> = {
  concrete: { color: 0x585a5c, rough: 0.95 },
  concrete2: { color: 0x494b4d, rough: 0.95 },
  wet: { color: 0x2a3238, rough: 0.06, metal: 0.42 },
  tire: { color: 0x191b1d, rough: 0.9 },
  grey: { color: 0x6e747a, rough: 0.5, metal: 0.25 },
  greyDark: { color: 0x474c51, rough: 0.6, metal: 0.2 },
  van: { color: 0x30353a, rough: 0.6, metal: 0.2 },
  glass: { color: 0x27384a, rough: 0.1, metal: 0.55 },
  lamp: { color: 0xffd9a0, rough: 0.4, emissive: 0xffc070, emissiveI: 2.2 },
  rust: { color: 0x8a3a26, rough: 0.8 },
  metal: { color: 0x474d54, rough: 0.4, metal: 0.6 },
  bark: { color: 0x3d2c1e, rough: 0.95 },
  needle: { color: 0x22402c, rough: 0.9 },
  needle2: { color: 0x2c4c34, rough: 0.9 },
  fence: { color: 0x3d4347, rough: 0.5, metal: 0.5 },
  wood: { color: 0x4a3626, rough: 0.92 },
  woodDark: { color: 0x33251a, rough: 0.92 },
  brick: { color: 0x5a3a30, rough: 0.95 },
  paper: { color: 0xcfc4a8, rough: 0.9 },
  can: { color: 0x8a8f94, rough: 0.35, metal: 0.7 },
  nest: { color: 0x4a3a26, rough: 1 },
  dark: { color: 0x14161a, rough: 1 },
};

function car(
  d: Diorama,
  body: string,
  trim: string,
  x: number,
  z: number,
  ry: number,
  L = 4.2,
  W = 1.8,
  H = 0.7,
  cab = 2.1,
  cabH = 0.6,
) {
  const c = Math.cos(ry),
    s = Math.sin(ry);
  const P = (lx: number, lz: number): [number, number] => [x + lx * c + lz * s, z - lx * s + lz * c];
  let [px, pz] = P(0, 0);
  d.box(body, L, H, W, px, 0.53, pz, { ry, b: 0.07 });
  [px, pz] = P(-0.14, 0);
  d.box(body, cab, cabH, W - 0.16, px, 0.53 + H / 2 + cabH / 2, pz, { ry, b: 0.07 });
  [px, pz] = P(-0.14, 0);
  d.box("glass", cab - 0.3, cabH - 0.2, W + 0.02, px, 0.53 + H / 2 + cabH / 2, pz, { ry, b: 0.03 });
  [px, pz] = P(L / 2 - 0.38, 0);
  d.box(trim, 0.5, 0.12, W - 0.3, px, 0.53 + H / 2 + 0.03, pz, { ry, b: 0.02 });
  for (const sz of [-1, 1]) {
    [px, pz] = P(L / 2 - 0.06, sz * (W / 2 - 0.3));
    d.box("lamp", 0.1, 0.15, 0.28, px, 0.6, pz, { ry, b: 0.02 });
    [px, pz] = P(-L / 2 + 0.06, sz * (W / 2 - 0.3));
    d.box("rust", 0.1, 0.13, 0.24, px, 0.6, pz, { ry, b: 0.02 });
    [px, pz] = P(L / 2 - 0.9, sz * (W / 2 - 0.06));
    d.wheel("tire", 0.34, 0.25, px, 0.34, pz, 8, ry);
    [px, pz] = P(-(L / 2 - 0.9), sz * (W / 2 - 0.06));
    d.wheel("tire", 0.34, 0.25, px, 0.34, pz, 8, ry);
  }
  for (const sx of [-1, 1]) {
    [px, pz] = P(sx * (L / 2 + 0.06), 0);
    d.box(trim, 0.18, 0.22, W - 0.12, px, 0.4, pz, { ry, b: 0.03 });
  }
}

function conifer(d: Diorama, x: number, z: number, s = 1, seed = 1) {
  d.box("bark", 0.28 * s, 1.4 * s, 0.28 * s, x, 0.7 * s, z, { b: 0.04 });
  d.cone("needle", 1.15 * s, 1.8 * s, x, 1.4 * s, z, 7, seed);
  d.cone("needle", 0.92 * s, 1.6 * s, x, 2.25 * s, z, 7, seed + 1);
  d.cone("needle2", 0.66 * s, 1.4 * s, x, 3.0 * s, z, 7, seed + 2);
}

export function buildYard(d: Diorama) {
  /* ---- concrete apron: bevelled slabs with expansion joints ---- */
  d.grid("concrete", 8, 5, 2.0, 1.8, 0.06, -7, -0.06, -6.1, 0.14);
  d.box("dark", 16.6, 0.3, 9.6, 0, -0.28, -2.5, { b: 0.06 });

  /* ---- puddles ---- */
  const puddles: [number, number, number, number][] = [
    [-4.0, 1.0, 2.8, 1.4],
    [0.6, 0.6, 2.0, 1.2],
    [5.4, 0.2, 1.8, 1.4],
    [-6.6, -0.6, 2.2, 1.4],
    [2.8, -4.4, 2.4, 1.4],
    [-1.2, -2.0, 1.6, 1.0],
    [6.6, -3.0, 1.4, 1.2],
    [-3.4, 1.4, 1.8, 1.0],
  ];
  puddles.forEach(([x, z, w, dd]) => d.slab("wet", w, dd, x, 0.015, z, 0.035));

  /* ---- tire marks from the gate to the sedan ---- */
  const path: [number, number][] = [
    [6.0, -5.4],
    [5.6, -4.6],
    [5.0, -3.8],
    [4.4, -3.0],
    [3.8, -2.4],
    [3.3, -1.9],
    [2.9, -1.5],
  ];
  path.forEach(([x, z], i) => {
    d.slab("wet", 0.32, 1.3, x, 0.012, z, 0.03, i * 0.28);
    d.slab("wet", 0.32, 1.3, x + 0.8, 0.012, z + 0.08, 0.03, i * 0.28);
  });

  /* ---- fence along the back, mesh of real bars ---- */
  for (let i = 0; i <= 8; i++) d.box("fence", 0.22, 2.6, 0.22, -8 + i * 2.0, 1.3, -6.8, { b: 0.03 });
  d.box("fence", 16.4, 0.1, 0.1, 0, 2.4, -6.8, { b: 0.02 });
  d.box("fence", 16.4, 0.1, 0.1, 0, 1.25, -6.8, { b: 0.02 });
  d.box("fence", 16.4, 0.1, 0.1, 0, 0.2, -6.8, { b: 0.02 });
  for (let i = 0; i < 27; i++) d.box("fence", 0.05, 2.4, 0.05, -7.9 + i * 0.6, 1.3, -6.8, { b: 0.012 });

  /* ---- gate ---- */
  d.box("fence", 0.28, 2.8, 0.28, 4.85, 1.4, -6.8, { b: 0.04 });
  d.box("fence", 0.28, 2.8, 0.28, 7.15, 1.4, -6.8, { b: 0.04 });
  d.frame("fence", 2.3, 2.3, 0.22, 0.16, 6.0, 1.35, -6.8);
  for (let i = 0; i < 6; i++) d.box("fence", 0.07, 1.98, 0.07, 5.2 + i * 0.32, 1.35, -6.8, { b: 0.015 });
  d.box("fence", 2.0, 0.09, 0.09, 6.0, 1.9, -6.8, { b: 0.02 });

  /* ---- gate timer post ---- */
  d.box("fence", 0.2, 1.9, 0.2, 6.0, 0.95, -6.0, { b: 0.03 });
  d.box("metal", 0.4, 0.52, 0.18, 6.0, 1.55, -6.0, { b: 0.03 });
  d.box("lamp", 0.24, 0.15, 0.04, 6.0, 1.62, -5.9, { b: 0.01 });
  d.box("rust", 0.1, 0.08, 0.05, 6.0, 1.4, -5.9, { b: 0.01 });

  /* ---- conifers ---- */
  conifer(d, -7.0, -5.6, 0.95, 1);
  conifer(d, -4.5, -5.6, 0.8, 4);
  conifer(d, -2.0, -5.6, 1.05, 7);
  conifer(d, 1.0, -5.6, 0.85, 10);
  conifer(d, 4.0, -5.6, 0.95, 13);
  conifer(d, 7.2, -5.6, 0.75, 16);
  conifer(d, -7.6, -3.0, 0.65, 19);
  /* the torn branch */
  d.box("bark", 0.85, 0.12, 0.12, -2.0, 1.55, -5.0, { rz: 0.3, b: 0.02 });
  d.box("paper", 0.14, 0.05, 0.05, -1.62, 1.62, -4.98, { ry: 0.6, b: 0.01 });

  /* ---- vehicles ---- */
  car(d, "grey", "greyDark", 2.5, -1.0, -0.35);
  car(d, "van", "greyDark", -5.0, -2.8, 0.18, 4.6, 2.0, 0.86, 2.4, 0.76);

  /* ---- warden's hut ---- */
  d.box("wood", 3.2, 2.4, 0.2, -6.0, 1.2, -1.2, { b: 0.04 });
  d.box("wood", 0.2, 2.4, 2.6, -7.6, 1.2, 0.2, { b: 0.04 });
  d.box("wood", 0.2, 2.4, 2.6, -4.4, 1.2, 0.2, { b: 0.04 });
  d.box("wood", 1.0, 2.4, 0.2, -7.1, 1.2, 1.6, { b: 0.04 });
  d.box("wood", 1.0, 2.4, 0.2, -4.9, 1.2, 1.6, { b: 0.04 });
  d.box("wood", 1.2, 0.6, 0.2, -6.0, 2.1, 1.6, { b: 0.04 });
  d.frame("woodDark", 1.24, 1.84, 0.2, 0.14, -6.0, 0.9, 1.64);
  d.box("woodDark", 0.94, 1.54, 0.09, -6.0, 0.79, 1.6, { b: 0.02 });
  d.frame("woodDark", 0.92, 0.72, 0.16, 0.12, -7.1, 1.55, 1.72);
  d.box("glass", 0.7, 0.5, 0.06, -7.1, 1.55, 1.7, { b: 0.02 });
  d.box("brick", 0.5, 1.1, 0.5, -7.0, 3.3, -0.6, { b: 0.05 });
  d.box("brick", 0.62, 0.14, 0.62, -7.0, 3.9, -0.6, { b: 0.03 });
  /* roof: two bevelled slabs meeting on a ridge cap */
  d.box("woodDark", 3.6, 0.16, 1.9, -6.0, 2.75, -0.65, { rx: -0.393, b: 0.04 });
  d.box("woodDark", 3.6, 0.16, 1.9, -6.0, 2.75, 1.05, { rx: 0.393, b: 0.04 });
  d.box("woodDark", 3.7, 0.14, 0.24, -6.0, 3.16, 0.2, { b: 0.04 });
  /* step, crate, lantern */
  d.box("concrete2", 2.2, 0.18, 0.8, -6.0, 0.09, 1.8, { b: 0.03 });
  d.box("woodDark", 0.44, 0.3, 0.44, -6.0, 0.33, 1.8, { b: 0.03 });
  d.box("metal", 0.24, 0.32, 0.24, -6.0, 0.62, 1.8, { b: 0.03 });
  d.box("glass", 0.18, 0.2, 0.18, -6.0, 0.62, 1.8, { b: 0.02 });
  d.box("metal", 0.05, 0.14, 0.05, -6.0, 0.84, 1.8, { b: 0.01 });

  /* ---- boot print in the wet concrete ---- */
  d.slab("wet", 0.32, 0.58, 4.5, 0.02, -4.2, 0.03, 0.4);
  d.slab("wet", 0.28, 0.52, 4.85, 0.02, -3.78, 0.03, 0.4);

  /* ---- oil drip trail ---- */
  const oil: [number, number, number][] = [
    [3.8, 0.2, 0.38],
    [4.1, 0.6, 0.3],
    [4.4, 1.0, 0.24],
    [4.7, 1.4, 0.18],
  ];
  oil.forEach(([x, z, r]) => d.rock("wet", r, x, 0.02, z, Math.round(x * 10), [1, 0.12, 1]));

  /* ---- decoy: crushed can ---- */
  d.box("can", 0.1, 0.1, 0.1, -2.0, 0.06, 0.6, { ry: 0.6, b: 0.015 });
  d.box("can", 0.14, 0.06, 0.12, -1.85, 0.04, 0.75, { ry: 1.1, b: 0.015 });

  /* ---- decoy: nest on a post ---- */
  d.box("woodDark", 0.18, 2.0, 0.18, 0.5, 1.0, 1.2, { b: 0.03 });
  d.rock("nest", 0.34, 0.5, 1.95, 1.2, 51, [1.1, 0.5, 1.1], 0.5);
  d.rock("nest", 0.14, 0.5, 2.1, 1.2, 52);

  /* ---- yard clutter ---- */
  d.box("metal", 0.9, 0.7, 0.6, -7.4, 0.35, 1.4, { b: 0.04 });
  d.box("metal", 0.8, 0.6, 0.5, -7.4, 1.0, 1.4, { b: 0.04 });
  d.box("rust", 0.7, 0.5, 0.5, 7.2, 0.25, 1.2, { b: 0.04 });
  d.box("woodDark", 1.1, 0.14, 0.7, 6.6, 0.07, -1.6, { b: 0.03 });
  d.box("woodDark", 1.1, 0.14, 0.7, 6.6, 0.21, -1.6, { b: 0.03 });
  d.rock("concrete2", 0.36, -2.8, 0.18, 1.5, 61, [1.2, 0.5, 1.0], 0.3);
  d.rock("concrete2", 0.28, 2.0, 0.14, 1.6, 62, [1.1, 0.45, 1.0], 1.2);
  d.box("fence", 0.16, 1.6, 0.16, 8.0, 0.8, -4.0, { b: 0.03 });
  d.box("fence", 0.16, 1.6, 0.16, 8.0, 0.8, 0.5, { b: 0.03 });
}

export function yardMaterialsBuilt() {
  return makeMaterials(yardMaterials);
}

export function yardLights(scene: THREE.Scene) {
  scene.add(new THREE.AmbientLight(0x2a3340, 0.55));
  scene.add(new THREE.HemisphereLight(0x3a4a68, 0x1a1c1e, 0.5));

  const moon = new THREE.DirectionalLight(0x9dbcff, 1.35);
  moon.position.set(-7, 10, -5);
  moon.castShadow = true;
  moon.shadow.mapSize.set(2048, 2048);
  const c = moon.shadow.camera;
  c.left = -11;
  c.right = 11;
  c.top = 11;
  c.bottom = -11;
  c.near = 1;
  c.far = 36;
  moon.shadow.bias = -0.0012;
  scene.add(moon);

  const lamp = new THREE.PointLight(0xffb060, 12, 13, 2);
  lamp.position.set(-6.0, 2.4, 2.6);
  scene.add(lamp);

  const gate = new THREE.PointLight(0x7fb0ff, 6, 11, 2);
  gate.position.set(6.0, 2.2, -5.6);
  scene.add(gate);

  const rim = new THREE.PointLight(0xffd0a0, 5, 9, 2);
  rim.position.set(2.5, 1.1, 0.2);
  scene.add(rim);
}
