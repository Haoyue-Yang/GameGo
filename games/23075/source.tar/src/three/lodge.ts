import * as THREE from "three";
import { Diorama, makeMaterials, type MatDef } from "./kit";

/* =========================================================================
   SITE 1 — TIMBER LODGE, EAST WING (BURNT)
   x ∈ [-5, 5]   z ∈ [-4, 4]   walls at -x and -z, camera looks in from +x+z
   ========================================================================= */

export const lodgeMaterials: Record<string, MatDef> = {
  plank: { color: 0x7a5636, rough: 0.92 },
  plankDark: { color: 0x5b3f28, rough: 0.95 },
  timber: { color: 0x6b4a2f, rough: 0.9 },
  timberDark: { color: 0x452f1e, rough: 0.9 },
  timberAsh: { color: 0x2c2523, rough: 0.98 },
  stone: { color: 0x5a5751, rough: 0.95 },
  stoneDark: { color: 0x3b3833, rough: 0.95 },
  ash: { color: 0x201d1b, rough: 1 },
  soot: { color: 0x1a1716, rough: 1 },
  rug: { color: 0x6b2f2a, rough: 0.98 },
  rugDark: { color: 0x4a201d, rough: 0.98 },
  paper: { color: 0xcfc4a8, rough: 0.9 },
  paper2: { color: 0xb9ad90, rough: 0.9 },
  brass: { color: 0xb08a3c, rough: 0.35, metal: 0.75 },
  metal: { color: 0x474d54, rough: 0.4, metal: 0.6 },
  glass: { color: 0x2b3d4f, rough: 0.12, metal: 0.55 },
  ember: { color: 0xff6a1e, rough: 0.6, emissive: 0xff5a10, emissiveI: 2.4 },
  water: { color: 0x2b3a44, rough: 0.08, metal: 0.35 },
  book1: { color: 0x4a3b52, rough: 0.9 },
  book2: { color: 0x3d4a3a, rough: 0.9 },
  book3: { color: 0x5a4030, rough: 0.9 },
  dark: { color: 0x14120f, rough: 1 },
};

export function buildLodge(d: Diorama) {
  /* ---- floor: eight bevelled planks over a subfloor ---- */
  for (let i = 0; i < 8; i++)
    d.box(i % 2 ? "plank" : "plankDark", 10.2, 0.24, 0.92, 0, -0.12, -3.5 + i * 1.0, { b: 0.03 });
  d.box("dark", 10.6, 0.3, 8.6, 0, -0.34, 0, { b: 0.05 });

  /* ---- rug ---- */
  d.slab("rugDark", 4.5, 3.3, 0.2, 0.02, 0.6, 0.05);
  d.slab("rug", 4.1, 2.9, 0.2, 0.045, 0.6, 0.05);

  /* ---- walls: stacked log courses, charred at the base ---- */
  for (let i = 0; i < 9; i++) {
    const m = i < 3 ? "timberAsh" : "timber";
    d.box(m, 10.6, 0.38, 0.36, 0, 0.2 + i * 0.4, -4.2, { b: 0.05 });
    d.box(m, 0.36, 0.38, 8.4, -5.2, 0.2 + i * 0.4, 0, { b: 0.05 });
  }
  d.box("timberDark", 0.54, 3.8, 0.54, -5.2, 1.9, -4.2, { b: 0.07 });
  d.box("timberDark", 10.6, 0.34, 0.52, 0, 3.72, -4.2, { b: 0.05 });
  d.box("timberDark", 0.52, 0.34, 8.4, -5.2, 3.72, 0, { b: 0.05 });
  d.box("timberDark", 10.2, 0.24, 0.16, 0, 0.12, -3.98, { b: 0.03 });
  d.box("timberDark", 0.16, 0.24, 8.0, -4.98, 0.12, 0, { b: 0.03 });

  /* ---- rafters, kept to the back so the frame stays readable ---- */
  for (const x of [-3.2, -0.6, 2.0, 4.2]) d.box("timberDark", 0.26, 0.26, 1.7, x, 3.48, -3.4, { b: 0.04 });
  d.box("timberDark", 10.2, 0.24, 0.24, 0, 3.48, -3.4, { b: 0.04 });

  /* ---- window on the back wall: frame of eight pieces, glass inside ---- */
  d.box("dark", 2.7, 2.1, 0.12, 2.2, 2.0, -4.02, { b: 0.02 });
  d.frame("timberDark", 2.7, 2.1, 0.2, 0.19, 2.2, 2.0, -3.97);
  d.box("timberDark", 0.09, 1.72, 0.14, 2.2, 2.0, -3.94, { b: 0.02 });
  d.box("timberDark", 2.32, 0.09, 0.14, 2.2, 2.0, -3.94, { b: 0.02 });
  d.box("glass", 2.32, 1.72, 0.07, 2.2, 2.0, -4.0, { b: 0.02 });
  d.box("timberDark", 3.0, 0.16, 0.54, 2.2, 1.04, -3.84, { b: 0.04 });
  d.slab("soot", 0.95, 0.36, 2.2, 1.14, -3.79, 0.03);

  /* ---- east door on the left wall ---- */
  d.frame("timberDark", 1.75, 2.55, 0.22, 0.19, -4.98, 1.28, 0.5, Math.PI / 2);
  d.box("timberAsh", 1.36, 2.16, 0.1, -4.92, 1.22, 0.5, { ry: Math.PI / 2, b: 0.02 });
  d.box("timberAsh", 0.1, 2.0, 0.07, -4.86, 1.22, 0.12, { ry: Math.PI / 2, b: 0.015 });
  d.box("timberAsh", 0.1, 2.0, 0.07, -4.86, 1.22, 0.88, { ry: Math.PI / 2, b: 0.015 });
  d.box("brass", 0.09, 0.09, 0.24, -4.83, 1.16, 0.86, { ry: Math.PI / 2, b: 0.02 });
  d.box("brass", 0.12, 0.12, 0.08, -4.86, 1.02, 0.9, { ry: Math.PI / 2, b: 0.02 });
  d.rock("brass", 0.09, -4.84, 1.02, 0.9, 5);

  /* ---- key-card reader beside the door ---- */
  d.box("metal", 0.18, 0.34, 0.12, -4.9, 1.36, 1.55, { b: 0.02 });
  d.box("ember", 0.07, 0.07, 0.03, -4.81, 1.47, 1.55, { b: 0.01 });
  d.box("paper2", 0.03, 0.12, 0.07, -4.81, 1.28, 1.55, { b: 0.01 });

  /* ---- ash pile in front of the door ---- */
  d.rock("ash", 0.52, -3.55, 0.12, 0.5, 3, [1.35, 0.42, 1.1], 0.4);
  d.rock("ash", 0.32, -3.18, 0.1, 0.16, 7, [1.1, 0.36, 1.0], 1.1);
  d.rock("timberAsh", 0.24, -3.92, 0.12, 0.74, 11, [1.2, 0.4, 0.9], 2.0);
  d.rock("ash", 0.2, -3.3, 0.1, 0.9, 13, [1.1, 0.34, 1.0], 0.7);

  /* ---- desk ---- */
  d.box("timber", 2.4, 0.14, 1.2, 2.0, 0.8, 1.6, { b: 0.03 });
  d.box("timberDark", 2.2, 0.5, 1.0, 2.0, 0.5, 1.6, { b: 0.04 });
  for (const sx of [-1, 1])
    for (const sz of [-1, 1]) d.box("timberDark", 0.14, 0.76, 0.14, 2.0 + sx * 1.05, 0.38, 1.6 + sz * 0.5, { b: 0.02 });
  d.box("timberAsh", 0.82, 0.16, 0.05, 1.5, 0.62, 1.11, { b: 0.015 });
  d.box("brass", 0.18, 0.04, 0.05, 1.5, 0.62, 1.08, { b: 0.01 });
  d.box("timberAsh", 0.82, 0.16, 0.05, 2.4, 0.62, 1.11, { b: 0.015 });
  d.box("brass", 0.18, 0.04, 0.05, 2.4, 0.62, 1.08, { b: 0.01 });

  /* ---- ledger, open, on the desk ---- */
  d.box("paper", 0.58, 0.08, 0.42, 1.72, 0.91, 1.5, { ry: -0.25, b: 0.012 });
  d.box("paper2", 0.52, 0.02, 0.36, 1.72, 0.96, 1.5, { ry: -0.25, b: 0.006 });
  d.box("metal", 0.11, 0.12, 0.11, 2.52, 0.92, 1.28, { b: 0.02 });
  d.box("paper2", 0.02, 0.02, 0.32, 2.52, 1.0, 1.16, { ry: 0.4, b: 0.005 });

  /* ---- chair ---- */
  d.box("timber", 0.58, 0.09, 0.58, 0.45, 0.52, 1.7, { b: 0.02 });
  d.box("timber", 0.58, 0.64, 0.09, 0.45, 0.86, 1.4, { b: 0.02 });
  for (const sx of [-1, 1])
    for (const sz of [-1, 1]) d.box("timberDark", 0.08, 0.5, 0.08, 0.45 + sx * 0.22, 0.25, 1.7 + sz * 0.22, { b: 0.015 });

  /* ---- hearth ---- */
  d.box("stone", 2.7, 0.42, 0.52, -1.0, 0.21, -3.86, { b: 0.05 });
  d.box("stoneDark", 0.5, 2.2, 0.52, -2.15, 1.1, -3.86, { b: 0.05 });
  d.box("stoneDark", 0.5, 2.2, 0.52, 0.15, 1.1, -3.86, { b: 0.05 });
  d.box("stone", 2.7, 0.4, 0.52, -1.0, 2.3, -3.86, { b: 0.05 });
  d.box("dark", 1.62, 1.8, 0.32, -1.0, 1.1, -3.96, { b: 0.03 });
  d.box("timberDark", 3.1, 0.2, 0.74, -1.0, 2.58, -3.8, { b: 0.05 });
  d.box("ember", 0.95, 0.12, 0.32, -1.0, 0.3, -3.8, { b: 0.02 });
  d.rock("ash", 0.3, -1.0, 0.34, -3.7, 31, [1.4, 0.4, 0.8], 0.2);
  d.box("timberAsh", 0.9, 0.1, 0.1, -1.0, 0.42, -3.72, { rz: 0.2, b: 0.02 });
  d.box("timberAsh", 0.9, 0.1, 0.1, -1.0, 0.46, -3.74, { rz: -0.15, b: 0.02 });

  /* ---- bookshelf on the left wall ---- */
  d.frame("timberDark", 2.3, 2.5, 0.52, 0.15, -4.84, 1.25, -2.5, Math.PI / 2);
  for (let i = 0; i < 4; i++) d.box("timber", 0.46, 0.07, 2.06, -4.84, 0.32 + i * 0.6, -2.5, { b: 0.02 });
  const books = ["book1", "book2", "book3"];
  for (let s = 0; s < 3; s++)
    for (let i = 0; i < 7; i++) {
      const h = 0.26 + ((i * 7 + s * 3) % 5) * 0.03;
      d.box(books[(i + s) % 3], 0.34, h, 0.13, -4.84, 0.36 + s * 0.6 + h / 2, -3.32 + i * 0.26, { b: 0.015 });
    }

  /* ---- hanging lamp ---- */
  d.box("metal", 0.05, 0.9, 0.05, 0.4, 3.0, -2.4, { b: 0.01 });
  d.cone("metal", 0.44, 0.36, 0.4, 2.46, -2.4, 8);
  d.box("ember", 0.14, 0.07, 0.14, 0.4, 2.3, -2.4, { b: 0.01 });

  /* ---- water-stained board ---- */
  d.slab("water", 1.25, 0.95, -1.5, 0.02, -1.0, 0.03);

  /* ---- burnt debris ---- */
  const debris: [number, number, number, number][] = [
    [1.0, -3.2, 0.16, 41],
    [-2.6, -3.0, 0.13, 42],
    [3.9, 0.2, 0.14, 43],
    [-4.2, 2.6, 0.15, 44],
    [0.9, 2.9, 0.12, 45],
    [-2.2, 1.4, 0.1, 46],
    [4.3, -1.4, 0.13, 47],
    [2.9, 2.6, 0.11, 48],
  ];
  debris.forEach(([x, z, r, seed], i) => d.rock("ash", r, x, r * 0.5, z, seed, [1.2, 0.5, 1.0], i));

  /* ---- decoy: charred plush ---- */
  d.rock("timberAsh", 0.23, 3.5, 0.22, -2.4, 21, [1, 0.9, 1]);
  d.rock("timberAsh", 0.13, 3.5, 0.44, -2.4, 22);
  d.rock("timberAsh", 0.09, 3.34, 0.44, -2.4, 23);
  d.rock("timberAsh", 0.09, 3.66, 0.44, -2.4, 24);
  d.rock("timberAsh", 0.1, 3.5, 0.06, -2.62, 25);

  /* ---- decoy: burnt matchbox ---- */
  d.box("timberAsh", 0.24, 0.11, 0.15, -0.4, 0.06, 2.25, { ry: 0.5, b: 0.012 });
  d.box("paper2", 0.17, 0.02, 0.1, -0.4, 0.13, 2.25, { ry: 0.5, b: 0.006 });
}

export function lodgeMaterialsBuilt() {
  return makeMaterials(lodgeMaterials);
}

export function lodgeLights(scene: THREE.Scene) {
  scene.add(new THREE.AmbientLight(0x3a3026, 0.6));
  const hemi = new THREE.HemisphereLight(0x2a3550, 0x2a1a10, 0.4);
  scene.add(hemi);

  const moon = new THREE.DirectionalLight(0xa8c4ff, 1.15);
  moon.position.set(7, 9, -7);
  moon.castShadow = true;
  moon.shadow.mapSize.set(1024, 1024);
  const c = moon.shadow.camera;
  c.left = -9;
  c.right = 9;
  c.top = 9;
  c.bottom = -9;
  c.near = 1;
  c.far = 30;
  moon.shadow.bias = -0.0012;
  scene.add(moon);

  const fire = new THREE.PointLight(0xff7a2a, 16, 12, 2);
  fire.position.set(-1.0, 0.55, -3.4);
  scene.add(fire);

  const lamp = new THREE.PointLight(0xffb060, 7, 9, 2);
  lamp.position.set(0.4, 2.28, -2.4);
  scene.add(lamp);

  const win = new THREE.PointLight(0x8fb4ff, 6, 10, 2);
  win.position.set(2.2, 2.0, -3.4);
  scene.add(win);
}
