import { useEffect, useMemo, useRef, useState } from "react";
import * as THREE from "three";
import { Diorama } from "./kit";
import { buildLodge, lodgeLights, lodgeMaterialsBuilt } from "./lodge";
import { buildYard, yardLights, yardMaterialsBuilt } from "./yard";
import { buildArchive, archiveLights, archiveMaterialsBuilt } from "./archive";
import { SITE_BY_ID } from "../game/case";
import type { Marker } from "../game/types";

/* =========================================================================
   LAYER 1 HOST — one fixed read-only pose per site.
   No orbit, no pan, no zoom. Site switches are fades (handled upstream).
   Any impact shake decays back to the exact pose.
   ========================================================================= */

const BUILDERS: Record<string, (d: Diorama) => void> = {
  lodge: buildLodge,
  yard: buildYard,
  archive: buildArchive,
};
const MATERIALS: Record<string, () => Record<string, THREE.Material>> = {
  lodge: lodgeMaterialsBuilt,
  yard: yardMaterialsBuilt,
  archive: archiveMaterialsBuilt,
};
const LIGHTS: Record<string, (s: THREE.Scene) => void> = {
  lodge: lodgeLights,
  yard: yardLights,
  archive: archiveLights,
};
const BG: Record<string, number> = { lodge: 0x0b0a09, yard: 0x0a0d12, archive: 0x0c0e11 };

export interface ScreenMark {
  id: string;
  x: number;
  y: number;
  spent: boolean;
  label: string;
}

interface Props {
  site: string;
  markers: Marker[];
  spent: string[];
  onSpend: (id: string) => void;
  shakeKey: number;
  interactive: boolean;
}

export default function DioramaView({ site, markers, spent, onSpend, shakeKey, interactive }: Props) {
  const hostRef = useRef<HTMLDivElement>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const camRef = useRef<THREE.PerspectiveCamera | null>(null);
  const basePos = useRef(new THREE.Vector3());
  const target = useRef(new THREE.Vector3());
  const offset = useRef(new THREE.Vector3());
  const shakeT = useRef(-1);
  const dirty = useRef(true);
  const raycaster = useRef(new THREE.Raycaster());
  const boxes = useRef(new Map<string, THREE.Mesh>());
  const markerGroup = useRef<THREE.Group | null>(null);
  const spentRef = useRef(spent);
  const interactiveRef = useRef(interactive);
  const markersRef = useRef(markers);
  const [marks, setMarks] = useState<ScreenMark[]>([]);
  const [hover, setHover] = useState<string | null>(null);

  spentRef.current = spent;
  interactiveRef.current = interactive;
  markersRef.current = markers;

  /* ---------- build the site ---------- */
  useEffect(() => {
    const host = hostRef.current;
    if (!host) return;

    if (!rendererRef.current) {
      const r = new THREE.WebGLRenderer({ antialias: true, alpha: false });
      r.setPixelRatio(Math.min(window.devicePixelRatio, 2));
      r.shadowMap.enabled = true;
      r.shadowMap.type = THREE.PCFSoftShadowMap;
      r.toneMapping = THREE.ACESFilmicToneMapping;
      r.toneMappingExposure = 1.05;
      host.appendChild(r.domElement);
      rendererRef.current = r;
    }
    const renderer = rendererRef.current;

    // tear down the previous site
    if (sceneRef.current) {
      sceneRef.current.traverse((o) => {
        const m = o as THREE.Mesh;
        if (m.geometry) m.geometry.dispose();
      });
      sceneRef.current.clear();
    }

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(BG[site] ?? 0x0b0a09);
    scene.fog = new THREE.Fog(BG[site] ?? 0x0b0a09, 16, 46);
    sceneRef.current = scene;

    const d = new Diorama();
    BUILDERS[site](d);
    d.build(scene, MATERIALS[site]());
    LIGHTS[site](scene);

    const cam = new THREE.PerspectiveCamera(45, 1, 0.5, 120);
    camRef.current = cam;

    // fixed pose: ~10 m up, ~40° pitch, three-quarter overhead
    const def = SITE_BY_ID[site];
    const pitch = (def.cam.pitchDeg * Math.PI) / 180;
    const az = (def.cam.azimuthDeg * Math.PI) / 180;
    target.current.set(def.cam.target[0], def.cam.target[1], def.cam.target[2]);
    const horiz = (def.cam.height - def.cam.target[1]) / Math.tan(pitch);
    basePos.current.set(
      def.cam.target[0] + horiz * Math.sin(az),
      def.cam.height,
      def.cam.target[2] + horiz * Math.cos(az),
    );
    cam.position.copy(basePos.current);
    cam.lookAt(target.current);

    fitCamera(renderer, scene, cam, def.cam.margin);
    dirty.current = true;
    return () => {
      scene.traverse((o) => {
        const m = o as THREE.Mesh;
        if (m.geometry) m.geometry.dispose();
      });
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [site]);

  /* ---------- marker hit volumes: real bounding boxes, raycast targets ---------- */
  useEffect(() => {
    const scene = sceneRef.current;
    if (!scene) return;
    const mg = new THREE.Group();
    boxes.current.clear();
    const invisible = new THREE.MeshBasicMaterial({ transparent: true, opacity: 0, depthWrite: false });
    for (const m of markers) {
      const mesh = new THREE.Mesh(new THREE.BoxGeometry(m.size[0], m.size[1], m.size[2]), invisible);
      mesh.position.set(m.pos[0], m.pos[1], m.pos[2]);
      mesh.userData.markerId = m.id;
      mg.add(mesh);
      boxes.current.set(m.id, mesh);
    }
    markerGroup.current = mg;
    scene.add(mg);
    return () => {
      scene.remove(mg);
      mg.traverse((o) => {
        const m = o as THREE.Mesh;
        if (m.geometry) m.geometry.dispose();
      });
    };
  }, [site, markers]);

  /* ---------- impact shake ---------- */
  useEffect(() => {
    if (shakeKey > 0) shakeT.current = 0;
  }, [shakeKey]);

  /* ---------- resize ---------- */
  useEffect(() => {
    const onResize = () => {
      const host = hostRef.current;
      const renderer = rendererRef.current;
      const cam = camRef.current;
      const scene = sceneRef.current;
      if (!host || !renderer || !cam || !scene) return;
      const w = host.clientWidth;
      const h = host.clientHeight;
      renderer.setSize(w, h, false);
      cam.aspect = w / h;
      const def = SITE_BY_ID[site];
      fitCamera(renderer, scene, cam, def.cam.margin);
      dirty.current = true;
    };
    onResize();
    const ro = new ResizeObserver(onResize);
    if (hostRef.current) ro.observe(hostRef.current);
    window.addEventListener("resize", onResize);
    return () => {
      ro.disconnect();
      window.removeEventListener("resize", onResize);
    };
  }, [site]);

  /* ---------- render loop ---------- */
  useEffect(() => {
    let raf = 0;
    let last = performance.now();
    const tick = (now: number) => {
      raf = requestAnimationFrame(tick);
      const renderer = rendererRef.current;
      const cam = camRef.current;
      const scene = sceneRef.current;
      if (!renderer || !cam || !scene) return;
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;

      if (shakeT.current >= 0) {
        shakeT.current += dt;
        const decay = Math.exp(-shakeT.current * 6.5);
        const amp = 0.3 * decay;
        const t = shakeT.current;
        offset.current.set(Math.sin(t * 47) * amp, Math.sin(t * 61 + 1.3) * amp * 0.8, Math.cos(t * 53 + 2.1) * amp);
        if (decay < 0.012) {
          shakeT.current = -1;
          offset.current.set(0, 0, 0);
          dirty.current = true;
        } else dirty.current = true;
      } else if (offset.current.lengthSq() > 0) {
        offset.current.set(0, 0, 0);
        dirty.current = true;
      }

      cam.position.copy(basePos.current).add(offset.current);
      const look = target.current.clone().add(offset.current.clone().multiplyScalar(0.25));
      cam.lookAt(look);

      renderer.render(scene, cam);

      if (dirty.current) {
        dirty.current = false;
        project();
      }
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  /* ---------- project markers into the constant-size overlay ---------- */
  const project = () => {
    const cam = camRef.current;
    const host = hostRef.current;
    if (!cam || !host) return;
    const w = host.clientWidth;
    const h = host.clientHeight;
    const v = new THREE.Vector3();
    const out: ScreenMark[] = [];
    for (const m of markersRef.current) {
      v.set(m.pos[0], m.pos[1], m.pos[2]);
      v.project(cam);
      if (v.z > 1) continue;
      out.push({
        id: m.id,
        x: (v.x * 0.5 + 0.5) * w,
        y: (-v.y * 0.5 + 0.5) * h,
        spent: spentRef.current.includes(m.id),
        label: m.label,
      });
    }
    setMarks(out);
  };

  useEffect(() => {
    dirty.current = true;
  }, [markers, spent]);

  /* ---------- raycast a marker click against its bounding box ---------- */
  const fire = (id: string, clientX: number, clientY: number) => {
    const host = hostRef.current;
    const cam = camRef.current;
    const mg = markerGroup.current;
    if (!host || !cam || !mg || !interactiveRef.current) return;
    const r = host.getBoundingClientRect();
    const ndc = new THREE.Vector2(((clientX - r.left) / r.width) * 2 - 1, -((clientY - r.top) / r.height) * 2 + 1);
    raycaster.current.setFromCamera(ndc, cam);
    const hits = raycaster.current.intersectObjects(Array.from(boxes.current.values()), false);
    const hit = hits.find((h) => h.object.userData.markerId === id);
    if (!hit) return;
    onSpend(id);
  };

  const spentSet = useMemo(() => new Set(spent), [spent]);

  return (
    <div className="diorama absolute inset-0" ref={hostRef}>
      {/* constant-size marker overlay — never scaled by depth */}
      <div className="pointer-events-none absolute inset-0">
        {marks.map((mk) => {
          const isSpent = spentSet.has(mk.id);
          return (
            <button
              key={mk.id}
              className="mk pointer-events-auto"
              style={{ left: mk.x, top: mk.y, opacity: isSpent ? 0.3 : 1 }}
              aria-label={isSpent ? `${mk.label} — spent, imprint` : `Examine ${mk.label}`}
              disabled={isSpent}
              onMouseEnter={() => setHover(mk.id)}
              onMouseLeave={() => setHover((h) => (h === mk.id ? null : h))}
              onFocus={() => setHover(mk.id)}
              onBlur={() => setHover((h) => (h === mk.id ? null : h))}
              onClick={(e) => fire(mk.id, e.clientX, e.clientY)}
            >
              {isSpent ? (
                <svg viewBox="0 0 30 30" width="30" height="30" aria-hidden="true">
                  <circle cx="15" cy="15" r="9" fill="none" stroke="#8a949c" strokeWidth="1" strokeDasharray="2 3" />
                  <circle cx="15" cy="15" r="1.4" fill="#8a949c" />
                </svg>
              ) : (
                <svg viewBox="0 0 30 30" width="30" height="30" aria-hidden="true">
                  <rect
                    x="7"
                    y="7"
                    width="16"
                    height="16"
                    transform="rotate(45 15 15)"
                    fill="none"
                    stroke={hover === mk.id ? "#f4f0e6" : "#e2a33c"}
                    strokeWidth="1.6"
                  />
                  <rect x="13.4" y="13.4" width="3.2" height="3.2" fill={hover === mk.id ? "#f4f0e6" : "#e2a33c"} />
                </svg>
              )}
            </button>
          );
        })}
      </div>
      {/* hover readout — flat vector, unlit */}
      {hover && (
        <div className="pointer-events-none absolute bottom-3 left-3 v v-flat px-2 py-1 text-[10px] v-tracked text-paper/70">
          {marks.find((m) => m.id === hover)?.label}
        </div>
      )}
    </div>
  );
}

/* ---------- frame the whole space in one shot, at any aspect ---------- */
function fitCamera(
  renderer: THREE.WebGLRenderer,
  scene: THREE.Scene,
  cam: THREE.PerspectiveCamera,
  margin: number,
) {
  const host = renderer.domElement.parentElement;
  const w = host?.clientWidth || 1;
  const h = host?.clientHeight || 1;
  cam.aspect = w / h;
  cam.updateMatrixWorld(true);
  const inv = cam.matrixWorldInverse;
  const box = new THREE.Box3().setFromObject(scene);
  const v = new THREE.Vector3();
  let maxTan = 0.001;
  for (let i = 0; i < 8; i++) {
    v.set(i & 1 ? box.max.x : box.min.x, i & 2 ? box.max.y : box.min.y, i & 4 ? box.max.z : box.min.z);
    v.applyMatrix4(inv);
    const dist = -v.z;
    if (dist <= 0.2) continue;
    maxTan = Math.max(maxTan, Math.abs(v.y) / dist, Math.abs(v.x) / dist / cam.aspect);
  }
  cam.fov = Math.min(62, (2 * Math.atan(maxTan * margin) * 180) / Math.PI);
  cam.updateProjectionMatrix();
}
