import * as THREE from "three";

/* =========================================================================
   LAYER 1 — LIT, FACETED, LOW-POLY.
   Every solid is a chamfered box with REAL bevels. Every frame is eight
   pieces of geometry that tile exactly, so corners are closed by geometry
   and never by a bare plane.
   ========================================================================= */

const geoCache = new Map<string, THREE.BufferGeometry>();

/** A chamfered (bevelled) box. 6 faces + 12 edge bevels + 8 corner tris. */
export function bevelBox(w: number, h: number, d: number, b = 0.02): THREE.BufferGeometry {
  const key = `b${w.toFixed(4)}_${h.toFixed(4)}_${d.toFixed(4)}_${b.toFixed(4)}`;
  const hit = geoCache.get(key);
  if (hit) return hit;

  const X = w / 2,
    Y = h / 2,
    Z = d / 2;
  const bx = Math.max(0.0005, Math.min(b, X * 0.45));
  const by = Math.max(0.0005, Math.min(b, Y * 0.45));
  const bz = Math.max(0.0005, Math.min(b, Z * 0.45));

  const pos: number[] = [];
  const V = (sg: number[], ax: number): number[] =>
    ax === 0
      ? [sg[0] * X, sg[1] * (Y - by), sg[2] * (Z - bz)]
      : ax === 1
        ? [sg[0] * (X - bx), sg[1] * Y, sg[2] * (Z - bz)]
        : [sg[0] * (X - bx), sg[1] * (Y - by), sg[2] * Z];

  const tri = (a: number[], c: number[], e: number[]) => pos.push(...a, ...c, ...e);

  // winding guard for triangles
  const triFix = (a: number[], c: number[], e: number[], n: number[]) => {
    const u = [c[0] - a[0], c[1] - a[1], c[2] - a[2]];
    const v = [e[0] - a[0], e[1] - a[1], e[2] - a[2]];
    const cr = [u[1] * v[2] - u[2] * v[1], u[2] * v[0] - u[0] * v[2], u[0] * v[1] - u[1] * v[0]];
    if (cr[0] * n[0] + cr[1] * n[1] + cr[2] * n[2] >= 0) tri(a, c, e);
    else tri(a, e, c);
  };

  // winding guard: flip the quad if its normal disagrees with the outward normal
  const quad = (a: number[], c: number[], e: number[], f: number[], n: number[]) => {
    const u = [c[0] - a[0], c[1] - a[1], c[2] - a[2]];
    const v = [e[0] - a[0], e[1] - a[1], e[2] - a[2]];
    const cr = [u[1] * v[2] - u[2] * v[1], u[2] * v[0] - u[0] * v[2], u[0] * v[1] - u[1] * v[0]];
    const ok = cr[0] * n[0] + cr[1] * n[1] + cr[2] * n[2] >= 0;
    if (ok) {
      tri(a, c, e);
      tri(a, e, f);
    } else {
      tri(a, f, e);
      tri(a, e, c);
    }
  };

  const CYC = [
    [-1, -1],
    [-1, 1],
    [1, 1],
    [1, -1],
  ];
  const signs = (ax: number, sg: number, u: number, v: number, i: number) => {
    const o = [0, 0, 0];
    o[ax] = sg;
    o[u] = CYC[i][0];
    o[v] = CYC[i][1];
    return o;
  };

  // 6 main faces
  for (let ax = 0; ax < 3; ax++) {
    const u = (ax + 1) % 3,
      v = (ax + 2) % 3;
    for (const sg of [-1, 1]) {
      const n = [0, 0, 0];
      n[ax] = sg;
      const q = [0, 1, 2, 3].map((i) => V(signs(ax, sg, u, v, i), ax));
      quad(q[0], q[1], q[2], q[3], n);
    }
  }

  // 12 edge bevels
  for (let i = 0; i < 3; i++) {
    for (let j = i + 1; j < 3; j++) {
      const k = 3 - i - j;
      for (const si of [-1, 1]) {
        for (const sj of [-1, 1]) {
          const n = [0, 0, 0];
          n[i] = si;
          n[j] = sj;
          const mk = (sk: number, ax: number) => {
            const o = [0, 0, 0];
            o[i] = si;
            o[j] = sj;
            o[k] = sk;
            return V(o, ax);
          };
          quad(mk(-1, i), mk(1, i), mk(1, j), mk(-1, j), n);
        }
      }
    }
  }

  // 8 corner triangles — closes the bevel ring at every corner
  for (const sx of [-1, 1])
    for (const sy of [-1, 1])
      for (const sz of [-1, 1]) {
        const sg = [sx, sy, sz];
        triFix(V(sg, 0), V(sg, 1), V(sg, 2), [sx, sy, sz]);
      }

  const g = new THREE.BufferGeometry();
  g.setAttribute("position", new THREE.Float32BufferAttribute(pos, 3));
  g.setAttribute("normal", new THREE.Float32BufferAttribute(new Array(pos.length).fill(0), 3));
  g.setAttribute("uv", new THREE.Float32BufferAttribute(new Array((pos.length / 3) * 2).fill(0), 2));
  g.computeVertexNormals();
  g.computeBoundingSphere();
  geoCache.set(key, g);
  return g;
}

/**
 * A frame built from eight pieces of geometry: four bars and four corner
 * blocks that tile exactly. Corners are closed by geometry — never a plane.
 * Centred on the origin, in XY, extruded along Z.
 */
export function bevelFrame(w: number, h: number, depth: number, bar: number, b = 0.015): THREE.BufferGeometry {
  const key = `f${w}_${h}_${depth}_${bar}_${b}`;
  const hit = geoCache.get(key);
  if (hit) return hit;
  const inner = Math.max(0.01, w - 2 * bar);
  const innerH = Math.max(0.01, h - 2 * bar);
  const parts: THREE.BufferGeometry[] = [];
  const push = (gw: number, gh: number, gd: number, x: number, y: number) => {
    const g = bevelBox(gw, gh, gd, b).clone();
    g.translate(x, y, 0);
    parts.push(g);
  };
  push(inner, bar, depth, 0, h / 2 - bar / 2);
  push(inner, bar, depth, 0, -h / 2 + bar / 2);
  push(bar, innerH, depth, -w / 2 + bar / 2, 0);
  push(bar, innerH, depth, w / 2 - bar / 2, 0);
  for (const sx of [-1, 1])
    for (const sy of [-1, 1]) push(bar, bar, depth, sx * (w / 2 - bar / 2), sy * (h / 2 - bar / 2));
  const merged = mergeGeos(parts);
  geoCache.set(key, merged);
  return merged;
}

/** Faceted low-poly boulder / ash lump. */
export function lump(r: number, seed = 1): THREE.BufferGeometry {
  const key = `l${r}_${seed}`;
  const hit = geoCache.get(key);
  if (hit) return hit;
  const g = new THREE.IcosahedronGeometry(r, 0).clone();
  const p = g.getAttribute("position") as THREE.BufferAttribute;
  let s = seed * 9301 + 49297;
  const rnd = () => {
    s = (s * 9301 + 49297) % 233280;
    return s / 233280;
  };
  for (let i = 0; i < p.count; i++) {
    const f = 0.72 + rnd() * 0.5;
    p.setXYZ(i, p.getX(i) * f, p.getY(i) * f, p.getZ(i) * f);
  }
  g.computeVertexNormals();
  geoCache.set(key, g);
  return g;
}

/** Faceted conifer tier. */
export function tier(r: number, h: number, seg = 7): THREE.BufferGeometry {
  const key = `t${r}_${h}_${seg}`;
  const hit = geoCache.get(key);
  if (hit) return hit;
  const g = new THREE.ConeGeometry(r, h, seg, 1);
  geoCache.set(key, g);
  return g;
}

export function wheel(r: number, w: number, seg = 8): THREE.BufferGeometry {
  const key = `w${r}_${w}_${seg}`;
  const hit = geoCache.get(key);
  if (hit) return hit;
  const g = new THREE.CylinderGeometry(r, r, w, seg, 1);
  geoCache.set(key, g);
  return g;
}

/* ---------------- flat merge (position/normal/uv only) ---------------- */
export function mergeGeos(list: THREE.BufferGeometry[]): THREE.BufferGeometry {
  let total = 0;
  for (const g of list) total += g.getAttribute("position").count;
  const pos = new Float32Array(total * 3);
  const nor = new Float32Array(total * 3);
  const uv = new Float32Array(total * 2);
  let o = 0;
  for (const g of list) {
    const p = g.getAttribute("position");
    const n = g.getAttribute("normal");
    const u = g.getAttribute("uv");
    pos.set(p.array as Float32Array, o * 3);
    if (n) nor.set(n.array as Float32Array, o * 3);
    if (u) uv.set(u.array as Float32Array, o * 2);
    o += p.count;
    g.dispose();
  }
  const out = new THREE.BufferGeometry();
  out.setAttribute("position", new THREE.BufferAttribute(pos, 3));
  out.setAttribute("normal", new THREE.BufferAttribute(nor, 3));
  out.setAttribute("uv", new THREE.BufferAttribute(uv, 2));
  out.computeBoundingSphere();
  return out;
}

function strip(g: THREE.BufferGeometry) {
  for (const name of Object.keys(g.attributes)) {
    if (name !== "position" && name !== "normal" && name !== "uv") g.deleteAttribute(name);
  }
  if (!g.getAttribute("normal")) g.computeVertexNormals();
  if (!g.getAttribute("uv")) {
    const n = g.getAttribute("position").count;
    g.setAttribute("uv", new THREE.BufferAttribute(new Float32Array(n * 2), 2));
  }
  return g;
}

export interface BoxOpts {
  b?: number;
  rx?: number;
  ry?: number;
  rz?: number;
  s?: [number, number, number];
}

/** Accumulates geometry per material so each site renders in a handful of draws. */
export class Diorama {
  private buckets = new Map<string, THREE.BufferGeometry[]>();
  private m = new THREE.Matrix4();
  private q = new THREE.Quaternion();
  private e = new THREE.Euler();
  private p = new THREE.Vector3();
  private sc = new THREE.Vector3();

  add(
    mat: string,
    geo: THREE.BufferGeometry,
    x = 0,
    y = 0,
    z = 0,
    rx = 0,
    ry = 0,
    rz = 0,
    s: [number, number, number] = [1, 1, 1],
  ) {
    const g = strip(geo.index ? geo.toNonIndexed() : geo.clone());
    this.e.set(rx, ry, rz, "YXZ");
    this.q.setFromEuler(this.e);
    this.p.set(x, y, z);
    this.sc.set(s[0], s[1], s[2]);
    this.m.compose(this.p, this.q, this.sc);
    g.applyMatrix4(this.m);
    let arr = this.buckets.get(mat);
    if (!arr) {
      arr = [];
      this.buckets.set(mat, arr);
    }
    arr.push(g);
  }

  box(mat: string, w: number, h: number, d: number, x: number, y: number, z: number, o: BoxOpts = {}) {
    this.add(mat, bevelBox(w, h, d, o.b ?? 0.02), x, y, z, o.rx ?? 0, o.ry ?? 0, o.rz ?? 0, o.s ?? [1, 1, 1]);
  }

  /** thin bevelled slab — a floor, a shelf, a puddle. Still geometry, never a plane. */
  slab(mat: string, w: number, d: number, x: number, y: number, z: number, t = 0.05, ry = 0) {
    this.box(mat, w, t, d, x, y, z, { b: 0.012, ry });
  }

  frame(mat: string, w: number, h: number, depth: number, bar: number, x: number, y: number, z: number, ry = 0) {
    this.add(mat, bevelFrame(w, h, depth, bar), x, y, z, 0, ry, 0);
  }

  rock(mat: string, r: number, x: number, y: number, z: number, seed = 1, s: [number, number, number] = [1, 1, 1], ry = 0) {
    this.add(mat, lump(r, seed), x, y, z, 0, ry, 0, s);
  }

  cone(mat: string, r: number, h: number, x: number, y: number, z: number, seg = 7, ry = 0) {
    this.add(mat, tier(r, h, seg), x, y, z, 0, ry, 0);
  }

  wheel(mat: string, r: number, w: number, x: number, y: number, z: number, seg = 8, ry = 0) {
    this.add(mat, wheel(r, w, seg), x, y, z, 0, ry, Math.PI / 2);
  }

  /** regular grid of bevelled slabs — plank floors, concrete tiles */
  grid(
    mat: string,
    cols: number,
    rows: number,
    cw: number,
    ch: number,
    gap: number,
    x0: number,
    y: number,
    z0: number,
    t = 0.06,
  ) {
    for (let i = 0; i < cols; i++)
      for (let j = 0; j < rows; j++)
        this.slab(mat, cw - gap, ch - gap, x0 + i * cw, y, z0 + j * ch, t);
  }

  build(scene: THREE.Scene, materials: Record<string, THREE.Material>, shadow = true) {
    for (const [key, list] of this.buckets) {
      const merged = mergeGeos(list);
      const mesh = new THREE.Mesh(merged, materials[key] ?? materials.default);
      mesh.castShadow = shadow;
      mesh.receiveShadow = shadow;
      mesh.name = `mat:${key}`;
      scene.add(mesh);
    }
    this.buckets.clear();
  }
}

/* ---------------- materials: lit, faceted, flat-shaded ---------------- */
export interface MatDef {
  color: number;
  rough?: number;
  metal?: number;
  emissive?: number;
  emissiveI?: number;
  transparent?: boolean;
  opacity?: number;
}

export function makeMaterials(defs: Record<string, MatDef>): Record<string, THREE.Material> {
  const out: Record<string, THREE.Material> = {};
  for (const [k, d] of Object.entries(defs)) {
    out[k] = new THREE.MeshStandardMaterial({
      color: d.color,
      roughness: d.rough ?? 0.85,
      metalness: d.metal ?? 0.04,
      flatShading: true,
      emissive: d.emissive ?? 0x000000,
      emissiveIntensity: d.emissiveI ?? 1,
      transparent: d.transparent ?? false,
      opacity: d.opacity ?? 1,
    });
  }
  return out;
}
