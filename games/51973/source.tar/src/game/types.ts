export type MatId = 0 | 1 | 2 | 3;
export type EffectKind = 'burn' | 'ice' | 'poison' | 'impact';

export interface MatInfo {
  id: MatId;
  name: string;
  weapon: string;
  effect: EffectKind;
  effectName: string;
  effectDesc: string;
  color: number;
  accent: number;
  css: string;
  css2: string;
}

export interface Gem {
  id: number;
  mat: MatId;
  x: number;
  y: number;
}
export type Grid = (Gem | null)[];

export interface Weapon {
  id: number;
  mat: MatId;
  name: string;
  atk: number;
  effect: EffectKind;
  tier: number;
}

export interface Status {
  burn: number;
  burnDmg: number;
  poison: number;
  poisonDmg: number;
  frozen: number;
  guard: number;
}

export type EnemyKind = 'crawler' | 'brute' | 'stalker' | 'wisp' | 'sentinel' | 'boss';

export interface Enemy {
  id: number;
  name: string;
  kind: EnemyKind;
  boss: boolean;
  hp: number;
  maxHp: number;
  atk: number;
  guard: number;
  scale: number;
  body: number;
  accent: number;
  phase: number;
  maxPhase: number;
  pattern: string[];
  pi: number;
  status: Status;
  slot: number;
  alive: boolean;
  flash: number;
}

export interface Hero {
  hp: number;
  maxHp: number;
  power: number;
  level: number;
  hexed: number;
}

export interface Meta {
  level: number;
  maxHp: number;
  power: number;
  gold: number;
  embers: number;
  mastery: [number, number, number, number];
  unlocks: string[];
  bestDistrict: number;
  runs: number;
  wins: number;
}

export interface Boon {
  id: string;
  name: string;
  desc: string;
  mat: MatId;
}

export type Phase = 'title' | 'forge' | 'throw' | 'enemy' | 'reward' | 'dead' | 'cleared';

export interface Reward {
  boons: Boon[];
  gold: number;
  embers: number;
  district: number;
}

export interface GameState {
  phase: Phase;
  grid: Grid;
  weapons: (Weapon | null)[];
  slots: number;
  hero: Hero;
  enemies: Enemy[];
  swaps: number;
  maxSwaps: number;
  turn: number;
  district: number;
  room: number;
  rooms: number;
  isBossRoom: boolean;
  selCell: number | null;
  selWeapon: number | null;
  boons: string[];
  meta: Meta;
  log: string[];
  busy: boolean;
  reward: Reward | null;
  forgeFull: number;
  banner: { text: string; sub: string; id: number } | null;
}

export type GameEvent =
  | { t: 'swap'; a: number; b: number }
  | { t: 'clear'; indices: number[]; cascade: number }
  | { t: 'forge'; weapon: Weapon; slot: number }
  | { t: 'forgeFull' }
  | { t: 'throw'; weapon: Weapon; slot: number; enemyId: number; dmg: number; crit: boolean; effect: EffectKind }
  | { t: 'status'; enemyId: number; kind: EffectKind; turns: number }
  | { t: 'tick'; enemyId: number; dmg: number; kind: 'burn' | 'poison' }
  | { t: 'enemyAct'; enemyId: number; move: string; dmg: number; heal: number }
  | { t: 'die'; enemyId: number }
  | { t: 'heroHit'; dmg: number }
  | { t: 'heroHeal'; amount: number }
  | { t: 'shake'; px: number }
  | { t: 'bossPhase'; enemyId: number; phase: number }
  | { t: 'spawn'; enemy: Enemy }
  | { t: 'banner'; text: string; sub: string };
