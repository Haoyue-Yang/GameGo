import type { Boon, EnemyKind, MatInfo } from './types';

export const MATS: MatInfo[] = [
  {
    id: 0,
    name: 'Ember',
    weapon: 'Cinder Cleaver',
    effect: 'burn',
    effectName: 'Burn',
    effectDesc: 'Ignites the target: damage over time.',
    color: 0xff5a24,
    accent: 0xffc247,
    css: '#ff5a24',
    css2: '#ffc247',
  },
  {
    id: 1,
    name: 'Frost',
    weapon: 'Rime Lance',
    effect: 'ice',
    effectName: 'Frost',
    effectDesc: 'Freezes the target: it loses its next action.',
    color: 0x35c2ff,
    accent: 0xd6f4ff,
    css: '#35c2ff',
    css2: '#d6f4ff',
  },
  {
    id: 2,
    name: 'Venom',
    weapon: 'Blight Dart',
    effect: 'poison',
    effectName: 'Poison',
    effectDesc: 'Drains the target every turn.',
    color: 0x6fd93a,
    accent: 0xd8ff86,
    css: '#6fd93a',
    css2: '#d8ff86',
  },
  {
    id: 3,
    name: 'Iron',
    weapon: 'Iron Maul',
    effect: 'impact',
    effectName: 'Impact',
    effectDesc: 'No status, but +30% raw damage and ignores guard.',
    color: 0xb6c2d6,
    accent: 0xfff3d6,
    css: '#b6c2d6',
    css2: '#fff3d6',
  },
];

export const EFFECT_LABEL: Record<string, string> = {
  burn: 'Burn',
  ice: 'Frost',
  poison: 'Poison',
  impact: 'Impact',
};

/* ------------------------------------------------------------------ enemies */

export interface Archetype {
  kind: EnemyKind;
  prefix: string[];
  suffix: string[];
  hp: [number, number];
  atk: [number, number];
  guard: [number, number];
  scale: [number, number];
  body: number;
  accent: number;
  patterns: string[][];
}

export const ARCHETYPES: Record<Exclude<EnemyKind, 'boss'>, Archetype> = {
  crawler: {
    kind: 'crawler',
    prefix: ['Gnaw', 'Grub', 'Slag', 'Mite', 'Rust', 'Grist'],
    suffix: ['Crawler', 'Skitter', 'Husk', 'Biter', 'Creeper'],
    hp: [16, 26],
    atk: [4, 7],
    guard: [0, 1],
    scale: [0.82, 1.0],
    body: 0x6d4b8f,
    accent: 0xff5a24,
    patterns: [
      ['slash', 'slash', 'ranged'],
      ['slash', 'thrust', 'guard'],
      ['maul', 'slash'],
    ],
  },
  brute: {
    kind: 'brute',
    prefix: ['Slag', 'Cinder', 'Molten', 'Iron', 'Grave', 'Dross'],
    suffix: ['Brute', 'Hauler', 'Anvil', 'Bulwark', 'Warden'],
    hp: [34, 52],
    atk: [6, 10],
    guard: [1, 3],
    scale: [1.12, 1.34],
    body: 0x8a4a32,
    accent: 0xffb347,
    patterns: [
      ['maul', 'maul', 'guard'],
      ['maul', 'heavy', 'slash'],
      ['guard', 'maul', 'aoe'],
    ],
  },
  stalker: {
    kind: 'stalker',
    prefix: ['Hollow', 'Ash', 'Pale', 'Grave', 'Night', 'Gloom'],
    suffix: ['Stalker', 'Shade', 'Reaver', 'Wraith', 'Lash'],
    hp: [20, 32],
    atk: [7, 11],
    guard: [0, 1],
    scale: [0.95, 1.15],
    body: 0x2f4a6b,
    accent: 0x35c2ff,
    patterns: [
      ['thrust', 'thrust', 'heavy'],
      ['thrust', 'hex', 'slash'],
      ['heavy', 'ranged', 'guard'],
    ],
  },
  wisp: {
    kind: 'wisp',
    prefix: ['Ember', 'Frost', 'Blight', 'Spark', 'Hollow'],
    suffix: ['Wisp', 'Mote', 'Chime', 'Cinder', 'Shard'],
    hp: [14, 24],
    atk: [5, 9],
    guard: [0, 0],
    scale: [0.8, 0.98],
    body: 0x3a6f8f,
    accent: 0xd6f4ff,
    patterns: [
      ['ranged', 'ranged', 'aoe'],
      ['ranged', 'hex', 'heal'],
      ['aoe', 'ranged'],
    ],
  },
  sentinel: {
    kind: 'sentinel',
    prefix: ['Forge', 'Vault', 'Slag', 'Deep', 'Anvil'],
    suffix: ['Sentinel', 'Keeper', 'Golem', 'Bastion', 'Warden'],
    hp: [40, 60],
    atk: [8, 12],
    guard: [2, 4],
    scale: [1.15, 1.4],
    body: 0x4a5064,
    accent: 0xd9a24a,
    patterns: [
      ['guard', 'maul', 'maul'],
      ['guard', 'aoe', 'heavy'],
      ['maul', 'guard', 'thrust'],
    ],
  },
};

export const BOSS_NAMES: { name: string; title: string }[] = [
  { name: 'The Slag Tyrant', title: 'Warden of the First Pour' },
  { name: 'Furnace Warden', title: 'Keeper of the Cold Bellows' },
  { name: 'Ashen Colossus', title: 'Last Anvil of the Deep' },
  { name: 'The Molten Choir', title: 'Voice of the Emberheart' },
];

export const DISTRICTS: { name: string; rooms: number; scale: number; count: [number, number] }[] = [
  { name: 'Slagworks Approach', rooms: 3, scale: 1.0, count: [2, 3] },
  { name: 'Cinder Vaults', rooms: 4, scale: 1.35, count: [3, 4] },
  { name: 'The Cold Forge', rooms: 4, scale: 1.75, count: [3, 4] },
  { name: 'Emberheart', rooms: 5, scale: 2.25, count: [4, 5] },
];

export const MOVES: Record<string, { label: string; mult: number; kind: 'dmg' | 'guard' | 'heal' | 'hex' }> = {
  slash: { label: 'Slash', mult: 1.0, kind: 'dmg' },
  thrust: { label: 'Thrust', mult: 0.85, kind: 'dmg' },
  maul: { label: 'Maul', mult: 1.5, kind: 'dmg' },
  ranged: { label: 'Spit', mult: 0.75, kind: 'dmg' },
  aoe: { label: 'Quake', mult: 0.65, kind: 'dmg' },
  hex: { label: 'Hex', mult: 0.35, kind: 'hex' },
  guard: { label: 'Brace', mult: 0, kind: 'guard' },
  heal: { label: 'Siphon', mult: 0, kind: 'heal' },
  heavy: { label: 'Crushing Blow', mult: 2.15, kind: 'dmg' },
};

/* -------------------------------------------------------------------- boons */

export const BOONS: Boon[] = [
  { id: 'swaps', name: 'Extra Bellows', desc: '+2 swaps every turn.', mat: 3 },
  { id: 'atk', name: 'Whetstone', desc: '+25% forged weapon attack.', mat: 3 },
  { id: 'hp', name: 'Bulwark Plate', desc: '+35 max HP and heal 35.', mat: 3 },
  { id: 'burn', name: 'Wildfire', desc: 'Burn damage +90%.', mat: 0 },
  { id: 'poison', name: 'Rot Essence', desc: 'Poison lasts +2 turns.', mat: 2 },
  { id: 'frost', name: 'Deep Rime', desc: 'Frost freezes for 2 turns.', mat: 1 },
  { id: 'crit', name: 'Keen Edge', desc: '30% chance to double throw damage.', mat: 3 },
  { id: 'slots', name: 'Fifth Rack', desc: '+1 weapon slot.', mat: 3 },
  { id: 'thorns', name: 'Serrated Guard', desc: 'Attackers take 5 damage.', mat: 3 },
  { id: 'sanguine', name: 'Sanguine Forge', desc: 'Heal 4 HP per throw.', mat: 0 },
  { id: 'overload', name: 'Overload', desc: 'Cascade tier bonus doubled.', mat: 0 },
  { id: 'ward', name: 'Slag Ward', desc: 'Take 20% less damage.', mat: 1 },
];

export const MASTERY_COST = (level: number) => 3 + level * 2;

export const UNLOCKS: { id: string; name: string; desc: string; cost: number }[] = [
  { id: 'u_auto', name: 'Auto-Sort Rack', desc: 'Weapons auto-select the weakest enemy when thrown.', cost: 6 },
  { id: 'u_reroll', name: 'Bellows Charm', desc: '+1 swap on every odd turn.', cost: 8 },
  { id: 'u_ember', name: 'Ember Lens', desc: 'Clears drop +2 embers per district boss.', cost: 10 },
];
