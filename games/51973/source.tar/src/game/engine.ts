import {
  applyGravity,
  createGrid,
  findAnyMove,
  findMatches,
  mulberry32,
  refill,
  reshuffle,
  swapCells,
  areAdjacent,
} from './board';
import { ARCHETYPES, BOONS, BOSS_NAMES, DISTRICTS, MASTERY_COST, MATS, MOVES, UNLOCKS } from './content';
import type {
  Boon,
  Enemy,
  EnemyKind,
  GameEvent,
  GameState,
  MatId,
  Meta,
  Phase,
  Weapon,
} from './types';

const SAVE_KEY = 'emberforge.meta.v1';
const wait = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));

const BASE_META: Meta = {
  level: 1,
  maxHp: 60,
  power: 0,
  gold: 0,
  embers: 0,
  mastery: [0, 0, 0, 0],
  unlocks: [],
  bestDistrict: 0,
  runs: 0,
  wins: 0,
};

function loadMeta(): Meta {
  try {
    const raw = localStorage.getItem(SAVE_KEY);
    if (!raw) return { ...BASE_META, mastery: [0, 0, 0, 0], unlocks: [] };
    const p = JSON.parse(raw) as Partial<Meta>;
    return {
      ...BASE_META,
      ...p,
      mastery: (p.mastery ?? [0, 0, 0, 0]).slice(0, 4) as [number, number, number, number],
      unlocks: p.unlocks ?? [],
    };
  } catch {
    return { ...BASE_META, mastery: [0, 0, 0, 0], unlocks: [] };
  }
}

const BOSS_PATTERNS: string[][][] = [
  [
    ['maul', 'aoe', 'guard'],
    ['maul', 'slash', 'aoe'],
  ],
  [
    ['heavy', 'aoe', 'maul'],
    ['aoe', 'heavy', 'hex'],
  ],
  [
    ['heavy', 'heavy', 'aoe'],
    ['hex', 'heavy', 'aoe'],
  ],
];

export class Engine {
  s: GameState;
  private rnd = mulberry32((Math.random() * 1e9) | 0);
  private listeners: { state?: (s: GameState) => void; event?: (e: GameEvent) => void }[] = [];
  private eid = 1;
  private bid = 1;
  private disposed = false;

  constructor() {
    const meta = loadMeta();
    this.s = {
      phase: 'title',
      grid: [],
      weapons: [null, null, null, null],
      slots: 4,
      hero: { hp: meta.maxHp, maxHp: meta.maxHp, power: meta.power, level: meta.level, hexed: 0 },
      enemies: [],
      swaps: 3,
      maxSwaps: 3,
      turn: 1,
      district: 0,
      room: 0,
      rooms: DISTRICTS[0].rooms,
      isBossRoom: false,
      selCell: null,
      selWeapon: null,
      boons: [],
      meta,
      log: [],
      busy: false,
      reward: null,
      forgeFull: 0,
      banner: null,
    };
  }

  on(l: { state?: (s: GameState) => void; event?: (e: GameEvent) => void }) {
    this.listeners.push(l);
    return () => {
      this.listeners = this.listeners.filter((x) => x !== l);
    };
  }

  private emit(e: GameEvent) {
    this.listeners.forEach((l) => l.event?.(e));
  }

  private sync() {
    const s = this.s;
    this.s = {
      ...s,
      grid: s.grid.slice(),
      weapons: s.weapons.slice(),
      enemies: s.enemies.map((e) => ({ ...e, status: { ...e.status } })),
      hero: { ...s.hero },
      meta: { ...s.meta, mastery: [...s.meta.mastery] as [number, number, number, number], unlocks: [...s.meta.unlocks] },
      log: s.log.slice(),
      boons: s.boons.slice(),
    };
    this.listeners.forEach((l) => l.state?.(this.s));
  }

  private save() {
    try {
      localStorage.setItem(SAVE_KEY, JSON.stringify(this.s.meta));
    } catch {
      /* storage unavailable */
    }
  }

  private log(msg: string) {
    this.s.log = [msg, ...this.s.log].slice(0, 7);
  }

  private banner(text: string, sub = '') {
    this.s.banner = { text, sub, id: this.bid++ };
  }

  private has(id: string) {
    return this.s.boons.includes(id) || this.s.meta.unlocks.includes(id);
  }

  private nextId() {
    return this.eid++;
  }

  /* ------------------------------------------------------------- run setup */

  startRun() {
    const m = this.s.meta;
    m.runs++;
    this.s.boons = [];
    this.s.slots = 4;
    this.s.weapons = [null, null, null, null];
    this.s.hero = { hp: m.maxHp, maxHp: m.maxHp, power: m.power, level: m.level, hexed: 0 };
    this.s.district = 0;
    this.s.room = 0;
    this.s.reward = null;
    this.s.log = [];
    this.enterRoom();
  }

  toTitle() {
    this.s.phase = 'title';
    this.s.enemies = [];
    this.s.grid = [];
    this.sync();
  }

  private enterRoom() {
    const d = DISTRICTS[Math.min(this.s.district, DISTRICTS.length - 1)];
    this.s.rooms = d.rooms;
    this.s.isBossRoom = this.s.room >= d.rooms;
    this.s.grid = createGrid(this.rnd);
    this.s.turn = 1;
    this.s.enemies = [];
    this.s.selCell = null;
    this.s.selWeapon = null;
    this.s.phase = 'forge';
    this.s.busy = false;
    const count = this.s.isBossRoom
      ? 1
      : d.count[0] + Math.floor(this.rnd() * (d.count[1] - d.count[0] + 1));
    for (let i = 0; i < count; i++) {
      const e = this.genEnemy(this.s.isBossRoom ? 'boss' : undefined, i, count);
      this.s.enemies.push(e);
      this.emit({ t: 'spawn', enemy: e });
    }
    this.s.swaps = this.maxSwaps();
    this.banner(
      this.s.isBossRoom ? 'BOSS' : `ROOM ${this.s.room + 1} / ${d.rooms + 1}`,
      this.s.isBossRoom ? BOSS_NAMES[Math.min(this.s.district, 3)].title : d.name,
    );
    this.log(this.s.isBossRoom ? 'A colossal shape rises from the furnace.' : `Entered ${d.name}.`);
    this.sync();
  }

  private maxSwaps() {
    let n = 3 + (this.has('swaps') ? 2 : 0);
    if (this.has('u_reroll') && this.s.turn % 2 === 1) n += 1;
    return n;
  }

  /* --------------------------------------------------------------- enemies */

  private genEnemy(kind?: EnemyKind, slot = 0, total = 1): Enemy {
    const d = DISTRICTS[Math.min(this.s.district, DISTRICTS.length - 1)];
    const sc = d.scale;
    if (kind === 'boss') {
      const info = BOSS_NAMES[Math.min(this.s.district, 3)];
      const maxHp = Math.round((95 + this.s.district * 34) * sc);
      return {
        id: this.nextId(),
        name: info.name,
        kind: 'boss',
        boss: true,
        hp: maxHp,
        maxHp,
        atk: Math.round(11 * sc),
        guard: 2,
        scale: 2.05,
        body: 0x5a2f3c,
        accent: 0xff8a3c,
        phase: 0,
        maxPhase: 3,
        pattern: BOSS_PATTERNS[0][0],
        pi: 0,
        status: { burn: 0, burnDmg: 0, poison: 0, poisonDmg: 0, frozen: 0, guard: 0 },
        slot,
        alive: true,
        flash: 0,
      };
    }
    const keys = Object.keys(ARCHETYPES) as (keyof typeof ARCHETYPES)[];
    const arch = ARCHETYPES[keys[Math.floor(this.rnd() * keys.length)]];
    const rr = (r: [number, number]) => r[0] + this.rnd() * (r[1] - r[0]);
    const maxHp = Math.round(rr(arch.hp) * sc);
    const name = `${arch.prefix[Math.floor(this.rnd() * arch.prefix.length)]} ${
      arch.suffix[Math.floor(this.rnd() * arch.suffix.length)]
    }`;
    const pat = arch.patterns[Math.floor(this.rnd() * arch.patterns.length)];
    return {
      id: this.nextId(),
      name,
      kind: arch.kind,
      boss: false,
      hp: maxHp,
      maxHp,
      atk: Math.round(rr(arch.atk) * (1 + this.s.district * 0.34)),
      guard: Math.round(rr(arch.guard)),
      scale: rr(arch.scale),
      body: arch.body,
      accent: arch.accent,
      phase: 0,
      maxPhase: 1,
      pattern: pat,
      pi: Math.floor(this.rnd() * pat.length),
      status: { burn: 0, burnDmg: 0, poison: 0, poisonDmg: 0, frozen: 0, guard: 0 },
      slot: total > 1 ? slot : 0,
      alive: true,
      flash: 0,
    };
  }

  /* ------------------------------------------------------------------ input */

  async tapCell(i: number) {
    const s = this.s;
    if (s.busy || s.phase !== 'forge' || s.grid[i] === null) return;
    if (s.selCell === null) {
      s.selCell = i;
      this.sync();
      return;
    }
    if (s.selCell === i) {
      s.selCell = null;
      this.sync();
      return;
    }
    if (!areAdjacent(s.selCell, i)) {
      s.selCell = i;
      this.sync();
      return;
    }
    const a = s.selCell;
    s.selCell = null;
    await this.doSwap(a, i);
  }

  private async doSwap(a: number, b: number) {
    const s = this.s;
    s.busy = true;
    swapCells(s.grid, a, b);
    this.emit({ t: 'swap', a, b });
    this.sync();
    await wait(190);
    if (this.disposed) return;

    let groups = findMatches(s.grid);
    let cascade = 0;
    while (groups.length > 0) {
      cascade++;
      const cleared: number[] = [];
      for (const g of groups) for (const c of g) if (!cleared.includes(c)) cleared.push(c);

      for (const g of groups) {
        const first = s.grid[g[0]];
        if (!first) continue;
        const filled = s.weapons.filter(Boolean).length;
        if (filled >= s.slots) {
          s.forgeFull = Date.now();
          this.emit({ t: 'forgeFull' });
          this.log('Rack is full — no room to forge.');
          break;
        }
        const w = this.forge(first.mat, g.length, cascade);
        const slot = s.weapons.findIndex((x) => x === null);
        s.weapons[slot] = w;
        this.emit({ t: 'forge', weapon: w, slot });
        this.log(`Forged ${w.name} — ${w.atk} ATK (T${cascade}).`);
      }

      this.emit({ t: 'clear', indices: cleared, cascade });
      this.emit({ t: 'shake', px: Math.min(6, 2 + cascade) });
      for (const c of cleared) s.grid[c] = null;
      this.sync();
      await wait(250);
      if (this.disposed) return;
      applyGravity(s.grid);
      refill(s.grid, this.rnd);
      this.sync();
      await wait(230);
      if (this.disposed) return;
      groups = findMatches(s.grid);
    }

    if (cascade === 0) {
      swapCells(s.grid, a, b);
      this.emit({ t: 'swap', a, b });
      this.log('No match — swap rejected.');
      this.sync();
      await wait(200);
      if (this.disposed) return;
    } else {
      s.swaps = Math.max(0, s.swaps - 1);
    }
    if (!findAnyMove(s.grid)) {
      reshuffle(s.grid, this.rnd);
      this.log('No moves left — the board reflows.');
      this.emit({ t: 'shake', px: 4 });
    }
    s.busy = false;
    if (s.swaps <= 0) {
      this.log('Swaps spent. Throw your weapons!');
      await this.enterThrow();
    } else {
      this.sync();
    }
  }

  private forge(mat: MatId, size: number, cascade: number): Weapon {
    const base = size >= 5 ? 18 + (size - 5) * 4 : [0, 7, 12][size - 3];
    const cdMult = 1 + (this.has('overload') ? 0.7 : 0.35) * (cascade - 1);
    const mastery = 1 + 0.16 * this.s.meta.mastery[mat];
    const boon = this.has('atk') ? 1.25 : 1;
    const atk = Math.max(1, Math.round(base * cdMult * mastery * boon));
    return {
      id: this.nextId(),
      mat,
      name: MATS[mat].weapon,
      atk,
      effect: MATS[mat].effect,
      tier: cascade,
    };
  }

  /* ------------------------------------------------------------- throw phase */

  /** Swaps are spent — hand control back to the player for the throw phase. */
  private enterThrow() {
    this.s.phase = 'throw';
    this.s.selCell = null;
    this.s.busy = false;
    this.banner('THROW PHASE', 'Spend your weapons');
    this.sync();
  }

  tapWeapon(i: number) {
    const s = this.s;
    if (s.busy || s.phase !== 'throw') return;
    if (!s.weapons[i]) return;
    s.selWeapon = s.selWeapon === i ? null : i;
    this.sync();
  }

  tapEnemy(id: number) {
    const s = this.s;
    if (s.busy || s.phase !== 'throw') return;
    const e = s.enemies.find((x) => x.id === id);
    if (!e || !e.alive) return;
    if (s.selWeapon === null) {
      const first = s.weapons.findIndex((w) => w !== null);
      if (first < 0) return;
      s.selWeapon = first;
      this.sync();
      return;
    }
    void this.doThrow(s.selWeapon, id);
  }

  private async doThrow(slot: number, enemyId: number) {
    const s = this.s;
    const w = s.weapons[slot];
    const e = s.enemies.find((x) => x.id === enemyId);
    if (!w || !e || !e.alive) return;
    s.busy = true;
    s.selWeapon = null;

    let dmg = w.atk;
    let crit = false;
    if (this.has('crit') && this.rnd() < 0.3) {
      crit = true;
      dmg *= 2;
    }
    if (w.effect === 'impact') dmg = Math.round(dmg * 1.3);
    dmg = Math.round(dmg * (1 + 0.06 * s.hero.power));
    const pierce = w.effect === 'impact';
    dmg = Math.max(1, dmg - (pierce ? 0 : e.guard + e.status.guard));

    e.hp -= dmg;
    s.weapons[slot] = null;
    this.emit({ t: 'throw', weapon: w, slot, enemyId, dmg, crit, effect: w.effect });
    this.emit({ t: 'shake', px: crit ? 6 : 3 });

    if (w.effect === 'burn') {
      const bd = Math.max(2, Math.round(w.atk * 0.3 * (this.has('burn') ? 1.9 : 1)));
      e.status.burn = Math.max(e.status.burn, 3);
      e.status.burnDmg = Math.max(e.status.burnDmg, bd);
      this.emit({ t: 'status', enemyId, kind: 'burn', turns: 3 });
    } else if (w.effect === 'poison') {
      const pd = Math.max(2, Math.round(w.atk * 0.22));
      const turns = 3 + (this.has('poison') ? 2 : 0);
      e.status.poison = Math.max(e.status.poison, turns);
      e.status.poisonDmg = Math.max(e.status.poisonDmg, pd);
      this.emit({ t: 'status', enemyId, kind: 'poison', turns });
    } else if (w.effect === 'ice') {
      e.status.frozen = Math.max(e.status.frozen, this.has('frost') ? 2 : 1);
      this.emit({ t: 'status', enemyId, kind: 'ice', turns: e.status.frozen });
    }
    if (this.has('sanguine')) {
      s.hero.hp = Math.min(s.hero.maxHp, s.hero.hp + 4);
      this.emit({ t: 'heroHeal', amount: 4 });
    }
    this.sync();
    await wait(430);
    if (this.disposed) return;

    this.checkBoss(e);
    if (e.hp <= 0) await this.killEnemy(e);
    if (this.disposed) return;

    if (s.enemies.every((x) => !x.alive)) {
      s.busy = false;
      await this.roomCleared();
      return;
    }
    const anyLeft = s.weapons.some(Boolean);
    if (!anyLeft) {
      s.busy = false;
      await this.enemyPhase();
    } else {
      s.busy = false;
      this.sync();
    }
  }

  private checkBoss(e: Enemy) {
    if (!e.boss || !e.alive) return;
    const frac = e.hp / e.maxHp;
    const want = frac <= 0.34 ? 2 : frac <= 0.67 ? 1 : 0;
    if (want > e.phase) {
      e.phase = want;
      e.atk = Math.round(e.atk * 1.18);
      e.hp = Math.min(e.maxHp, e.hp + Math.round(e.maxHp * 0.06));
      this.emit({ t: 'bossPhase', enemyId: e.id, phase: e.phase });
      this.emit({ t: 'shake', px: 6 });
      this.log(`${e.name} shifts to phase ${e.phase + 1}!`);
      this.banner(`PHASE ${e.phase + 1}`, e.name);
    }
  }

  private async killEnemy(e: Enemy) {
    e.hp = 0;
    e.alive = false;
    this.emit({ t: 'die', enemyId: e.id });
    this.log(`${e.name} is destroyed.`);
    this.s.meta.embers += 1;
    this.s.meta.gold += 2;
    this.sync();
    await wait(360);
  }

  async endTurn() {
    const s = this.s;
    if (s.busy) return;
    if (s.phase === 'forge') {
      s.swaps = 0;
      await this.enterThrow();
    } else if (s.phase === 'throw') {
      await this.enemyPhase();
    }
  }

  /* ------------------------------------------------------------- enemy phase */

  private async enemyPhase() {
    const s = this.s;
    s.busy = true;
    s.phase = 'enemy';
    s.selWeapon = null;
    this.sync();
    await wait(300);
    if (this.disposed) return;

    for (const e of s.enemies) {
      if (!e.alive) continue;
      // status ticks
      if (e.status.burn > 0) {
        const d = Math.max(1, Math.round(e.status.burnDmg));
        e.hp -= d;
        e.status.burn--;
        this.emit({ t: 'tick', enemyId: e.id, dmg: d, kind: 'burn' });
        this.sync();
        await wait(280);
        if (this.disposed) return;
        if (e.hp <= 0) {
          await this.killEnemy(e);
          if (this.disposed) return;
          continue;
        }
      }
      if (e.status.poison > 0) {
        const d = Math.max(1, Math.round(e.status.poisonDmg));
        e.hp -= d;
        e.status.poison--;
        this.emit({ t: 'tick', enemyId: e.id, dmg: d, kind: 'poison' });
        this.sync();
        await wait(280);
        if (this.disposed) return;
        if (e.hp <= 0) {
          await this.killEnemy(e);
          if (this.disposed) return;
          continue;
        }
      }
      this.checkBoss(e);
      if (e.status.frozen > 0) {
        e.status.frozen--;
        this.emit({ t: 'enemyAct', enemyId: e.id, move: 'frozen', dmg: 0, heal: 0 });
        this.sync();
        await wait(420);
        if (this.disposed) return;
        continue;
      }
      await this.enemyAct(e);
      if (this.disposed) return;
      if (s.hero.hp <= 0) {
        await this.die();
        return;
      }
    }

    if (s.hero.hexed > 0) s.hero.hexed--;
    s.turn++;
    s.phase = 'forge';
    s.swaps = this.maxSwaps();
    s.busy = false;
    this.banner(`TURN ${s.turn}`, 'Forge phase');
    this.sync();
  }

  private aiMove(e: Enemy): string {
    const p = e.boss ? BOSS_PATTERNS[Math.min(e.phase, 2)][e.pi % 2] : e.pattern;
    const hpF = e.hp / e.maxHp;
    const heroF = this.s.hero.hp / this.s.hero.maxHp;
    if (heroF < 0.3 && p.includes('heavy') && this.rnd() < 0.72) return 'heavy';
    if (hpF < 0.32 && p.includes('guard') && this.rnd() < 0.5) return 'guard';
    if (hpF < 0.45 && p.includes('heal') && this.rnd() < 0.6) return 'heal';
    if (p.includes('hex') && this.s.hero.hexed <= 0 && this.rnd() < 0.3) return 'hex';
    return p[e.pi % p.length];
  }

  private async enemyAct(e: Enemy) {
    const s = this.s;
    const move = this.aiMove(e);
    e.pi++;
    const mv = MOVES[move] ?? MOVES.slash;
    let dmg = 0;
    let heal = 0;
    if (mv.kind === 'dmg') {
      dmg = Math.round(e.atk * mv.mult * (0.9 + this.rnd() * 0.2));
      if (this.has('ward')) dmg = Math.round(dmg * 0.8);
      if (s.hero.hexed > 0) dmg = Math.round(dmg * 0.85);
      s.hero.hp -= dmg;
    } else if (mv.kind === 'hex') {
      dmg = Math.round(e.atk * mv.mult);
      s.hero.hp -= dmg;
      s.hero.hexed = 2;
    } else if (mv.kind === 'guard') {
      e.status.guard += 4;
    } else if (mv.kind === 'heal') {
      heal = Math.round(e.maxHp * 0.14);
      e.hp = Math.min(e.maxHp, e.hp + heal);
    }
    if (this.has('thorns') && dmg > 0) {
      e.hp -= 5;
    }
    this.emit({ t: 'enemyAct', enemyId: e.id, move, dmg, heal });
    if (dmg > 0) this.emit({ t: 'heroHit', dmg });
    this.emit({ t: 'shake', px: dmg > 0 ? Math.min(6, 2 + Math.round(dmg / 6)) : 1 });
    this.log(`${e.name} uses ${mv.label}${dmg ? ` — ${dmg} dmg` : ''}.`);
    this.sync();
    await wait(470);
    if (this.disposed) return;

    if (e.hp <= 0) {
      await this.killEnemy(e);
      if (this.disposed) return;
      if (s.enemies.every((x) => !x.alive)) {
        await this.roomCleared();
        return;
      }
    }
  }

  private async roomCleared() {
    const s = this.s;
    this.emit({ t: 'shake', px: 5 });
    if (s.isBossRoom) {
      const gold = 14 + s.district * 10 + Math.floor(this.rnd() * 8);
      const embers = 3 + s.district * 2 + (this.has('u_ember') ? 2 : 0);
      const owned = new Set(s.boons);
      const pool = BOONS.filter((b) => !owned.has(b.id));
      const picks: Boon[] = [];
      while (picks.length < 3 && pool.length > 0) {
        picks.push(pool.splice(Math.floor(this.rnd() * pool.length), 1)[0]);
      }
      s.reward = { boons: picks, gold, embers, district: s.district };
      s.phase = 'reward';
      s.busy = false;
      this.banner('DISTRICT CLEARED', 'Claim your reward');
      this.sync();
      return;
    }
    s.room++;
    this.enterRoom();
  }

  pickReward(i: number) {
    const s = this.s;
    if (s.phase !== 'reward' || !s.reward) return;
    if (i >= 0 && i < s.reward.boons.length) {
      const b = s.reward.boons[i];
      s.boons.push(b.id);
      if (b.id === 'hp') {
        s.hero.maxHp += 35;
        s.hero.hp = Math.min(s.hero.maxHp, s.hero.hp + 35);
      }
      if (b.id === 'slots') {
        s.slots++;
        s.weapons.push(null);
      }
      this.log(`Boon taken: ${b.name}.`);
    } else {
      s.meta.gold += s.reward.gold;
      s.meta.embers += s.reward.embers;
      this.log(`Banked ${s.reward.gold} gold and ${s.reward.embers} embers.`);
    }
    s.meta.embers += s.reward.embers;
    s.meta.gold += Math.round(s.reward.gold * 0.4);
    s.reward = null;
    this.save();
    if (s.district >= DISTRICTS.length - 1) {
      s.meta.wins++;
      s.phase = 'cleared';
      s.busy = false;
      this.banner('THE DEPTHS ARE SILENT', 'Run complete');
      this.sync();
      return;
    }
    s.district++;
    s.room = 0;
    s.hero.level = s.meta.level;
    this.enterRoom();
  }

  private async die() {
    const s = this.s;
    s.hero.hp = 0;
    s.phase = 'dead';
    s.busy = false;
    s.meta.bestDistrict = Math.max(s.meta.bestDistrict, s.district + 1);
    this.save();
    this.emit({ t: 'shake', px: 6 });
    this.banner('THE FORGE GOES COLD', 'Run over');
    this.sync();
  }

  /* ------------------------------------------------------- meta progression */

  buyMastery(mat: MatId) {
    const s = this.s;
    const cost = MASTERY_COST(s.meta.mastery[mat]);
    if (s.meta.embers < cost) return;
    s.meta.embers -= cost;
    s.meta.mastery[mat]++;
    this.save();
    this.sync();
  }

  buyUnlock(id: string) {
    const s = this.s;
    const u = UNLOCKS.find((x) => x.id === id);
    if (!u || s.meta.unlocks.includes(id) || s.meta.gold < u.cost) return;
    s.meta.gold -= u.cost;
    s.meta.unlocks.push(id);
    this.save();
    this.sync();
  }

  buyUpgrade(kind: 'hp' | 'power') {
    const s = this.s;
    const cost = kind === 'hp' ? 10 + s.meta.maxHp / 10 : 14 + s.meta.power * 4;
    if (s.meta.gold < cost) return;
    s.meta.gold -= Math.round(cost);
    if (kind === 'hp') s.meta.maxHp += 10;
    else s.meta.power += 1;
    this.save();
    this.sync();
  }

  upgradeCost(kind: 'hp' | 'power') {
    return Math.round(kind === 'hp' ? 10 + this.s.meta.maxHp / 10 : 14 + this.s.meta.power * 4);
  }

  private async grantLevel() {
    const s = this.s;
    s.meta.level++;
    s.meta.maxHp += 8;
    s.meta.power += 2;
    s.hero.level = s.meta.level;
    s.hero.maxHp += 8;
    s.hero.hp = Math.min(s.hero.maxHp, s.hero.hp + 8);
    s.hero.power = s.meta.power;
    this.save();
    this.banner('ATTRIBUTE GAINED', `Level ${s.meta.level} — +8 HP, +2 Power`);
    this.sync();
  }

  async claimLevel() {
    await this.grantLevel();
  }

  dispose() {
    this.disposed = true;
    this.listeners = [];
  }
}

export type { Phase };
