import type { Gem, Grid, MatId } from './types';

export const W = 7;
export const H = 7;
export const N = W * H;

export const idx = (x: number, y: number) => y * W + x;
export const inB = (x: number, y: number) => x >= 0 && x < W && y >= 0 && y < H;

let _gid = 1;
export const nextGemId = () => _gid++;

export function mulberry32(seed: number) {
  let a = seed >>> 0;
  return function () {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function makeGem(x: number, y: number, mat: MatId): Gem {
  return { id: nextGemId(), mat, x, y };
}

/** Build a full grid guaranteed to contain no pre-existing match and at least one legal move. */
export function createGrid(rnd: () => number): Grid {
  for (let attempt = 0; attempt < 200; attempt++) {
    const g: Grid = new Array(N).fill(null);
    for (let y = 0; y < H; y++) {
      for (let x = 0; x < W; x++) {
        const banned = new Set<MatId>();
        if (x >= 2) {
          const a = g[idx(x - 1, y)];
          const b = g[idx(x - 2, y)];
          if (a && b && a.mat === b.mat) banned.add(a.mat);
        }
        if (y >= 2) {
          const a = g[idx(x, y - 1)];
          const b = g[idx(x, y - 2)];
          if (a && b && a.mat === b.mat) banned.add(a.mat);
        }
        const pool: MatId[] = ([0, 1, 2, 3] as MatId[]).filter((m) => !banned.has(m));
        g[idx(x, y)] = makeGem(x, y, pool[Math.floor(rnd() * pool.length)]);
      }
    }
    if (findAnyMove(g)) return g;
  }
  return new Array(N).fill(null).map((_, i) => makeGem(i % W, (i / W) | 0, (i % 4) as MatId));
}

/** Returns merged groups (overlapping runs unioned) of indices, each >= 3. */
export function findMatches(g: Grid): number[][] {
  const runs: number[][] = [];
  const scan = (get: (a: number, b: number) => number) => {
    for (let a = 0; a < W; a++) {
      let run = [get(a, 0)];
      for (let b = 1; b < W; b++) {
        const i = get(a, b);
        const prev = g[run[run.length - 1]];
        const cur = g[i];
        if (cur && prev && cur.mat === prev.mat) run.push(i);
        else {
          if (run.length >= 3) runs.push(run.slice());
          run = [i];
        }
      }
      if (run.length >= 3) runs.push(run.slice());
    }
  };
  scan((x, y) => idx(x, y));
  scan((y, x) => idx(x, y));

  // union-find merge of overlapping runs so a cross shape forges one bigger weapon
  const parent = runs.map((_, i) => i);
  const find = (i: number): number => (parent[i] === i ? i : (parent[i] = find(parent[i])));
  const union = (a: number, b: number) => {
    const ra = find(a);
    const rb = find(b);
    if (ra !== rb) parent[ra] = rb;
  };
  const owner = new Map<number, number>();
  runs.forEach((r, i) => {
    for (const c of r) {
      const o = owner.get(c);
      if (o === undefined) owner.set(c, i);
      else union(o, i);
    }
  });
  const buckets = new Map<number, number[]>();
  runs.forEach((r, i) => {
    const k = find(i);
    const arr = buckets.get(k) ?? [];
    for (const c of r) if (!arr.includes(c)) arr.push(c);
    buckets.set(k, arr);
  });
  return [...buckets.values()].filter((r) => r.length >= 3);
}

export function swapCells(g: Grid, a: number, b: number) {
  const ga = g[a];
  const gb = g[b];
  g[a] = gb;
  g[b] = ga;
  if (ga) {
    ga.x = b % W;
    ga.y = (b / W) | 0;
  }
  if (gb) {
    gb.x = a % W;
    gb.y = (a / W) | 0;
  }
}

export function areAdjacent(a: number, b: number) {
  const ax = a % W;
  const ay = (a / W) | 0;
  const bx = b % W;
  const by = (b / W) | 0;
  return Math.abs(ax - bx) + Math.abs(ay - by) === 1;
}

/** Collapse gems toward the bottom of each column. Returns moved gem ids. */
export function applyGravity(g: Grid): number[] {
  const moved: number[] = [];
  for (let x = 0; x < W; x++) {
    let write = H - 1;
    for (let y = H - 1; y >= 0; y--) {
      const gem = g[idx(x, y)];
      if (gem) {
        if (write !== y) {
          g[idx(x, write)] = gem;
          g[idx(x, y)] = null;
          gem.y = write;
          moved.push(gem.id);
        }
        write--;
      }
    }
  }
  return moved;
}

export function refill(g: Grid, rnd: () => number): number[] {
  const spawned: number[] = [];
  for (let x = 0; x < W; x++) {
    for (let y = H - 1; y >= 0; y--) {
      if (!g[idx(x, y)]) {
        const gem = makeGem(x, y, Math.floor(rnd() * 4) as MatId);
        g[idx(x, y)] = gem;
        spawned.push(gem.id);
      }
    }
  }
  return spawned;
}

export function findAnyMove(g: Grid): [number, number] | null {
  for (let y = 0; y < H; y++) {
    for (let x = 0; x < W; x++) {
      const a = idx(x, y);
      for (const [dx, dy] of [
        [1, 0],
        [0, 1],
      ]) {
        const nx = x + dx;
        const ny = y + dy;
        if (!inB(nx, ny)) continue;
        const b = idx(nx, ny);
        swapCells(g, a, b);
        const ok = findMatches(g).length > 0;
        swapCells(g, a, b);
        if (ok) return [a, b];
      }
    }
  }
  return null;
}

/** Reshuffle materials in place until a move exists (keeps gem ids so the board animates). */
export function reshuffle(g: Grid, rnd: () => number) {
  const mats = g.map((c) => (c ? c.mat : 0));
  for (let attempt = 0; attempt < 300; attempt++) {
    for (let i = mats.length - 1; i > 0; i--) {
      const j = Math.floor(rnd() * (i + 1));
      [mats[i], mats[j]] = [mats[j], mats[i]];
    }
    g.forEach((c, i) => {
      if (c) c.mat = mats[i];
    });
    if (findMatches(g).length === 0 && findAnyMove(g)) return true;
  }
  return false;
}
