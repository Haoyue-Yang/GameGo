import { useEffect, useState } from 'react';
import { MATS, MOVES, DISTRICTS, BOONS, MASTERY_COST, UNLOCKS, EFFECT_LABEL } from '../game/content';
import type { Engine } from '../game/engine';
import type { GameState, MatId, Weapon } from '../game/types';

/* ------------------------------------------------------------------- icons */

export function WeaponIcon({ mat, size = 30 }: { mat: MatId; size?: number }) {
  const c = MATS[mat].css;
  const a = MATS[mat].css2;
  const common = { stroke: '#06060a', strokeWidth: 2.4, strokeLinejoin: 'round' as const };
  return (
    <svg width={size} height={size} viewBox="0 0 32 32" aria-hidden="true">
      {mat === 0 && (
        <>
          <path d="M16 3 L23 12 L19 22 L13 22 L9 12 Z" fill={c} {...common} />
          <path d="M16 6 L19.5 12 L16 19 L12.5 12 Z" fill={a} {...common} />
          <path d="M14 22 h4 v7 h-4 z" fill="#4a3524" {...common} />
        </>
      )}
      {mat === 1 && (
        <>
          <path d="M16 2 L21 12 L11 12 Z" fill={c} {...common} />
          <path d="M16 6 L18.5 11 L13.5 11 Z" fill={a} {...common} />
          <path d="M14.6 12 h2.8 v17 h-2.8 z" fill="#4a3524" {...common} />
          <path d="M11 15 h10" stroke={a} strokeWidth={2.6} />
        </>
      )}
      {mat === 2 && (
        <>
          <path d="M16 2 L20 10 L16 14 L12 10 Z" fill={c} {...common} />
          <path d="M14.6 13 h2.8 v16 h-2.8 z" fill="#4a3524" {...common} />
          <path d="M11 16 l5 -3 l5 3" stroke={a} strokeWidth={2.6} fill="none" {...common} />
          <circle cx={16} cy={22} r={2.6} fill={a} {...common} />
        </>
      )}
      {mat === 3 && (
        <>
          <path d="M8 6 h16 v10 h-16 z" fill={c} {...common} />
          <path d="M11 9 h10 v4 h-10 z" fill={a} {...common} />
          <path d="M14 16 h4 v13 h-4 z" fill="#4a3524" {...common} />
        </>
      )}
    </svg>
  );
}

function GemIcon({ mat, size = 16 }: { mat: MatId; size?: number }) {
  const c = MATS[mat].css;
  const a = MATS[mat].css2;
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" aria-hidden="true">
      <path d="M12 2 L22 12 L12 22 L2 12 Z" fill={c} stroke="#06060a" strokeWidth={2.2} strokeLinejoin="round" />
      <path d="M12 6 L18 12 L12 18 L6 12 Z" fill={a} opacity={0.85} />
    </svg>
  );
}

/* ------------------------------------------------------------------- pieces */

function Bar({ frac, color, h = 14 }: { frac: number; color: string; h?: number }) {
  return (
    <div className="bar relative" style={{ height: h }}>
      <i style={{ width: `${Math.max(0, Math.min(1, frac)) * 100}%`, background: color }} />
      <div className="tick" />
    </div>
  );
}

function WeaponCard({
  w,
  selected,
  onClick,
  disabled,
}: {
  w: Weapon | null;
  selected: boolean;
  onClick: () => void;
  disabled: boolean;
}) {
  if (!w) {
    return (
      <div className="plate-flat h-[74px] w-[92px] flex items-center justify-center text-[10px] tracking-widest text-slate-500">
        EMPTY
      </div>
    );
  }
  const m = MATS[w.mat];
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className={`plate relative h-[74px] w-[92px] flex flex-col items-center justify-center gap-0.5 ${
        selected ? 'slotpick pulse' : ''
      } ${disabled ? 'opacity-60' : ''}`}
      style={{ borderColor: '#06060a' }}
      aria-label={`${w.name}, ${w.atk} attack, ${EFFECT_LABEL[w.effect]}`}
    >
      <WeaponIcon mat={w.mat} size={30} />
      <div className="text-[10px] font-black tracking-wider" style={{ color: m.css2 }}>
        {w.atk}
      </div>
      <div className="text-[8px] font-bold tracking-wider text-slate-300 uppercase">{EFFECT_LABEL[w.effect]}</div>
      <div className="absolute top-0.5 right-1 text-[8px] font-black text-slate-400">T{w.tier}</div>
      <div
        className="absolute bottom-0 left-0 h-[3px] w-full"
        style={{ background: `linear-gradient(90deg,${m.css},${m.css2})` }}
      />
    </button>
  );
}

/* ---------------------------------------------------------------------- HUD */

export function Hud({
  s,
  engine,
  onPickWeapon,
}: {
  s: GameState;
  engine: Engine;
  onPickWeapon: (i: number) => void;
}) {
  const [showHelp, setShowHelp] = useState(true);
  const d = DISTRICTS[Math.min(s.district, DISTRICTS.length - 1)];
  const hpFrac = s.hero.hp / s.hero.maxHp;
  const phaseLabel =
    s.phase === 'forge' ? 'FORGE PHASE' : s.phase === 'throw' ? 'THROW PHASE' : s.phase === 'enemy' ? 'ENEMY PHASE' : '';

  useEffect(() => {
    if (s.turn === 1 && s.room === 0 && s.district === 0) {
      const t = setTimeout(() => setShowHelp(false), 9000);
      return () => clearTimeout(t);
    }
  }, [s.turn, s.room, s.district]);

  return (
    <div className="pointer-events-none absolute inset-0 select-none">
      {/* ---------------- top left: hero ---------------- */}
      <div className="absolute left-3 top-3 w-[248px]">
        <div className="plate px-3 py-2">
          <div className="flex items-baseline justify-between">
            <span className="text-[11px] font-black tracking-[0.18em] text-amber-200">THE FORGEHAND</span>
            <span className="text-[10px] font-bold text-slate-400">LV {s.hero.level}</span>
          </div>
          <div className="mt-1.5">
            <Bar frac={hpFrac} color="linear-gradient(180deg,#ff8a5c,#c22f2f)" h={16} />
          </div>
          <div className="mt-1 flex items-center justify-between text-[10px] font-bold">
            <span className="text-slate-200">
              {Math.max(0, Math.ceil(s.hero.hp))} / {s.hero.maxHp} HP
            </span>
            <span className="text-amber-300">PWR {s.hero.power}</span>
          </div>
          {s.hero.hexed > 0 && (
            <div className="mt-1 text-[9px] font-black tracking-wider text-fuchsia-300">HEXED — WEAKER HITS</div>
          )}
        </div>
        {s.boons.length > 0 && (
          <div className="plate-flat mt-2 px-2 py-1.5">
            <div className="mb-1 text-[9px] font-black tracking-[0.16em] text-slate-400">RUN BOONS</div>
            <div className="flex flex-wrap gap-1">
              {s.boons.map((b) => {
                const info = BOONS.find((x) => x.id === b);
                return (
                  <span
                    key={b}
                    className="rounded-sm border-2 border-black px-1.5 py-0.5 text-[9px] font-black uppercase"
                    style={{
                      background: info ? MATS[info.mat].css : '#444',
                      color: '#06060a',
                    }}
                    title={info?.desc}
                  >
                    {info?.name ?? b}
                  </span>
                );
              })}
            </div>
          </div>
        )}
      </div>

      {/* ---------------- top right: district ---------------- */}
      <div className="absolute right-3 top-3 w-[236px]">
        <div className="plate px-3 py-2 text-right">
          <div className="text-[11px] font-black tracking-[0.16em] text-cyan-200">{d.name.toUpperCase()}</div>
          <div className="text-[10px] font-bold text-slate-400">
            {s.isBossRoom ? 'BOSS CHAMBER' : `ROOM ${s.room + 1} / ${d.rooms + 1}`} · TURN {s.turn}
          </div>
          <div className="mt-1 flex justify-end gap-3 text-[10px] font-black">
            <span className="text-amber-300">◆ {s.meta.gold}</span>
            <span className="text-orange-400">✦ {s.meta.embers}</span>
          </div>
        </div>
        <div className="plate-flat mt-2 max-h-[132px] overflow-hidden px-2 py-1.5">
          <div className="mb-1 text-[9px] font-black tracking-[0.16em] text-slate-400">{phaseLabel}</div>
          <div className="scroll flex flex-col gap-0.5">
            {s.log.slice(0, 5).map((l, i) => (
              <div key={i} className="text-[9px] leading-tight" style={{ color: i === 0 ? '#ffe0b0' : '#8b93a7' }}>
                {l}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* ---------------- bottom: rack + controls ---------------- */}
      <div className="absolute bottom-3 left-1/2 flex -translate-x-1/2 items-end gap-3">
        <div className="plate pointer-events-auto flex items-center gap-2 px-3 py-2">
          <div className="text-[9px] font-black leading-tight tracking-[0.14em] text-slate-400">
            SWAPS
            <br />
            <span className="text-lg text-amber-300">{s.swaps}</span>
          </div>
          <div className="flex flex-col gap-1">
            {Array.from({ length: s.maxSwaps }).map((_, i) => (
              <div
                key={i}
                className="h-2 w-2 rounded-full border-2 border-black"
                style={{ background: i < s.swaps ? '#ffb347' : '#2a2f3d' }}
              />
            ))}
          </div>
        </div>

        <div className="plate pointer-events-auto flex items-center gap-2 px-3 py-2">
          <div className="text-[9px] font-black tracking-[0.14em] text-slate-400">RACK</div>
          <div className="flex gap-2">
            {s.weapons.map((w, i) => (
              <WeaponCard
                key={i}
                w={w}
                selected={s.selWeapon === i}
                disabled={s.phase !== 'throw' || s.busy}
                onClick={() => onPickWeapon(i)}
              />
            ))}
          </div>
        </div>

        <button
          className="btn pointer-events-auto h-[74px] w-[124px] px-2 text-[12px] text-slate-950"
          style={{ background: 'linear-gradient(180deg,#ffd27a,#ff8a3c)' }}
          disabled={s.busy || s.phase === 'reward' || s.phase === 'dead' || s.phase === 'cleared'}
          onClick={() => void engine.endTurn()}
        >
          {s.phase === 'forge' ? 'END TURN' : s.phase === 'throw' ? 'SKIP TO ENEMIES' : '…'}
        </button>
      </div>

      {/* ---------------- prompt ---------------- */}
      {s.phase === 'throw' && !s.busy && (
        <div className="absolute left-1/2 top-[19%] -translate-x-1/2">
          <div className="plate pop px-4 py-1.5 text-[11px] font-black tracking-[0.2em] text-amber-200">
            {s.selWeapon === null ? 'TAP A WEAPON, THEN A LIVING ENEMY' : 'NOW TAP A LIVING ENEMY'}
          </div>
        </div>
      )}
      {s.phase === 'forge' && !s.busy && s.selCell === null && (
        <div className="absolute left-1/2 top-[19%] -translate-x-1/2">
          <div className="plate-flat px-4 py-1.5 text-[11px] font-black tracking-[0.2em] text-slate-300">
            TAP TWO ADJACENT GEMS TO SWAP
          </div>
        </div>
      )}
      {s.phase === 'enemy' && (
        <div className="absolute left-1/2 top-[19%] -translate-x-1/2">
          <div className="plate px-4 py-1.5 text-[11px] font-black tracking-[0.2em] text-rose-300">ENEMIES ACT</div>
        </div>
      )}

      {/* ---------------- banner ---------------- */}
      {s.banner && (
        <div key={s.banner.id} className="absolute left-1/2 top-[30%] -translate-x-1/2 text-center">
          <div className="flash">
            <div
              className="text-[42px] font-black leading-none tracking-[0.06em]"
              style={{
                color: '#ffd9a0',
                textShadow: '4px 0 0 #06060a,-4px 0 0 #06060a,0 4px 0 #06060a,0 -4px 0 #06060a,0 0 26px rgba(255,120,40,.7)',
              }}
            >
              {s.banner.text}
            </div>
            {s.banner.sub && (
              <div className="mt-1 text-[13px] font-black tracking-[0.24em] text-cyan-200">{s.banner.sub}</div>
            )}
          </div>
        </div>
      )}

      {/* ---------------- help ---------------- */}
      {showHelp && s.phase !== 'reward' && (
        <div className="plate pointer-events-auto absolute bottom-[104px] left-1/2 w-[430px] -translate-x-1/2 px-4 py-3">
          <div className="mb-1.5 flex items-center justify-between">
            <span className="text-[11px] font-black tracking-[0.18em] text-amber-200">HOW THE FORGE WORKS</span>
            <button className="text-[10px] font-black text-slate-400" onClick={() => setShowHelp(false)}>
              ✕
            </button>
          </div>
          <ol className="space-y-1 text-[10px] leading-snug text-slate-300">
            <li>
              <b className="text-amber-200">1.</b> Match 3+ gems of a material. Every match forges a weapon into one of
              your rack slots — a full rack blocks forging.
            </li>
            <li>
              <b className="text-amber-200">2.</b> Cascades raise the tier and the attack value.
            </li>
            <li>
              <b className="text-amber-200">3.</b> When swaps run out you enter the throw phase: tap a weapon, then a
              living enemy. Ember burns, Frost skips a turn, Venom drains, Iron hits hardest.
            </li>
            <li>
              <b className="text-amber-200">4.</b> Then the enemies act on you. Clear the district boss to claim a boon.
            </li>
          </ol>
        </div>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ screens */

function Shop({ s, engine }: { s: GameState; engine: Engine }) {
  return (
    <div className="grid grid-cols-2 gap-3">
      <div className="plate px-3 py-2">
        <div className="mb-2 text-[10px] font-black tracking-[0.18em] text-orange-300">
          WEAPON MASTERY · ✦ {s.meta.embers}
        </div>
        <div className="flex flex-col gap-1.5">
          {MATS.map((m, i) => {
            const lv = s.meta.mastery[i as MatId];
            const cost = MASTERY_COST(lv);
            const can = s.meta.embers >= cost;
            return (
              <button
                key={m.id}
                className="btn flex items-center justify-between gap-2 px-2 py-1.5 text-[10px] text-slate-950"
                style={{ background: `linear-gradient(180deg,${m.css2},${m.css})` }}
                disabled={!can}
                onClick={() => engine.buyMastery(i as MatId)}
              >
                <span className="flex items-center gap-1.5">
                  <GemIcon mat={m.id} size={14} />
                  <b>{m.name}</b>
                </span>
                <span>
                  LV {lv} · +{Math.round(lv * 16)}% · ✦{cost}
                </span>
              </button>
            );
          })}
        </div>
      </div>
      <div className="plate px-3 py-2">
        <div className="mb-2 text-[10px] font-black tracking-[0.18em] text-amber-300">
          ATTRIBUTES &amp; UNLOCKS · ◆ {s.meta.gold}
        </div>
        <div className="flex flex-col gap-1.5">
          <button
            className="btn px-2 py-1.5 text-[10px] text-slate-950"
            style={{ background: 'linear-gradient(180deg,#ff9a7a,#c22f2f)' }}
            disabled={s.meta.gold < engine.upgradeCost('hp')}
            onClick={() => engine.buyUpgrade('hp')}
          >
            TEMPER BODY · +10 MAX HP · ◆{engine.upgradeCost('hp')}
          </button>
          <button
            className="btn px-2 py-1.5 text-[10px] text-slate-950"
            style={{ background: 'linear-gradient(180deg,#ffe08a,#d98a2a)' }}
            disabled={s.meta.gold < engine.upgradeCost('power')}
            onClick={() => engine.buyUpgrade('power')}
          >
            SHARPEN · +1 POWER · ◆{engine.upgradeCost('power')}
          </button>
          {UNLOCKS.map((u) => {
            const owned = s.meta.unlocks.includes(u.id);
            return (
              <button
                key={u.id}
                className="btn px-2 py-1.5 text-left text-[10px] text-slate-950"
                style={{ background: owned ? 'linear-gradient(180deg,#9aa4bb,#5b6480)' : 'linear-gradient(180deg,#8fdcff,#3a7fbf)' }}
                disabled={owned || s.meta.gold < u.cost}
                onClick={() => engine.buyUnlock(u.id)}
                title={u.desc}
              >
                {u.name}
                {owned ? ' · OWNED' : ` · ◆${u.cost}`}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}

export function TitleScreen({ s, engine }: { s: GameState; engine: Engine }) {
  return (
    <div className="pointer-events-auto absolute inset-0 flex items-center justify-center bg-[#05060a]/72 px-4">
      <div className="pop w-full max-w-[720px]">
        <div className="mb-3 text-center">
          <div
            className="text-[13px] font-black tracking-[0.4em] text-cyan-300"
            style={{ textShadow: '0 2px 0 #06060a' }}
          >
            A MATCH-3 FORGING DESCENT
          </div>
          <h1
            className="text-[54px] font-black leading-none tracking-[0.02em] text-amber-200"
            style={{
              textShadow: '5px 0 0 #06060a,-5px 0 0 #06060a,0 5px 0 #06060a,0 -5px 0 #06060a,0 0 34px rgba(255,110,40,.55)',
            }}
          >
            EMBERFORGE DEPTHS
          </h1>
        </div>
        <div className="plate px-4 py-3">
          <div className="mb-3 grid grid-cols-4 gap-2 text-center">
            {[
              ['LEVEL', s.meta.level],
              ['MAX HP', s.meta.maxHp],
              ['POWER', s.meta.power],
              ['BEST DISTRICT', s.meta.bestDistrict],
            ].map(([k, v]) => (
              <div key={k as string} className="plate-flat py-1.5">
                <div className="text-[9px] font-black tracking-[0.14em] text-slate-400">{k}</div>
                <div className="text-[18px] font-black text-amber-200">{v}</div>
              </div>
            ))}
          </div>
          <Shop s={s} engine={engine} />
          <button
            className="btn mt-3 w-full py-3 text-[16px] text-slate-950"
            style={{ background: 'linear-gradient(180deg,#ffd27a,#ff6a2b)' }}
            onClick={() => engine.startRun()}
          >
            DESCEND
          </button>
          <div className="mt-2 text-center text-[9px] font-bold tracking-wider text-slate-500">
            RUNS {s.meta.runs} · DISTRICTS CLEARED {s.meta.wins} · BOONS ARE LOST ON DEATH, ATTRIBUTES AND MASTERY ARE KEPT
          </div>
        </div>
      </div>
    </div>
  );
}

export function RewardScreen({ s, engine }: { s: GameState; engine: Engine }) {
  if (!s.reward) return null;
  const r = s.reward;
  return (
    <div className="pointer-events-auto absolute inset-0 flex items-center justify-center bg-[#05060a]/78 px-4">
      <div className="pop w-full max-w-[760px]">
        <div className="mb-3 text-center">
          <h2
            className="text-[38px] font-black leading-none tracking-[0.04em] text-amber-200"
            style={{ textShadow: '4px 0 0 #06060a,-4px 0 0 #06060a,0 4px 0 #06060a,0 -4px 0 #06060a' }}
          >
            DISTRICT CLEARED
          </h2>
          <div className="text-[11px] font-black tracking-[0.24em] text-cyan-300">CHOOSE ONE — IT LASTS THIS RUN ONLY</div>
        </div>
        <div className="grid grid-cols-3 gap-3">
          {r.boons.map((b, i) => (
            <button
              key={b.id}
              className="plate pop flex flex-col items-center gap-2 px-3 py-4 text-center"
              style={{ boxShadow: `0 0 0 3px #06060a, inset 0 0 0 2px ${MATS[b.mat].css}` }}
              onClick={() => engine.pickReward(i)}
            >
              <div
                className="flex h-14 w-14 items-center justify-center rounded-sm border-[3px] border-black"
                style={{ background: `linear-gradient(180deg,${MATS[b.mat].css2},${MATS[b.mat].css})` }}
              >
                <GemIcon mat={b.mat} size={26} />
              </div>
              <div className="text-[13px] font-black tracking-wide text-amber-100">{b.name}</div>
              <div className="text-[10px] leading-snug text-slate-300">{b.desc}</div>
            </button>
          ))}
        </div>
        <button
          className="btn mt-3 w-full py-3 text-[13px] text-slate-950"
          style={{ background: 'linear-gradient(180deg,#ffe08a,#d98a2a)' }}
          onClick={() => engine.pickReward(99)}
        >
          DECLINE BOONS · BANK ◆{r.gold} AND ✦{r.embers} INSTEAD
        </button>
      </div>
    </div>
  );
}

export function EndScreen({ s, engine }: { s: GameState; engine: Engine }) {
  const dead = s.phase === 'dead';
  return (
    <div className="pointer-events-auto absolute inset-0 flex items-center justify-center bg-[#05060a]/82 px-4">
      <div className="pop w-full max-w-[520px] text-center">
        <h2
          className="text-[42px] font-black leading-none tracking-[0.04em]"
          style={{
            color: dead ? '#ff8a8a' : '#ffd9a0',
            textShadow: '4px 0 0 #06060a,-4px 0 0 #06060a,0 4px 0 #06060a,0 -4px 0 #06060a',
          }}
        >
          {dead ? 'THE FORGE GOES COLD' : 'THE DEPTHS ARE SILENT'}
        </h2>
        <div className="plate mt-3 px-4 py-3">
          <div className="mb-2 text-[11px] font-black tracking-[0.2em] text-cyan-300">
            {dead ? 'RUN BOONS LOST · PROGRESSION KEPT' : 'ALL DISTRICTS CLEARED'}
          </div>
          <div className="grid grid-cols-3 gap-2 text-center">
            {[
              ['DISTRICT', s.district + 1],
              ['ROOM', s.room + 1],
              ['TURNS', s.turn],
            ].map(([k, v]) => (
              <div key={k as string} className="plate-flat py-1.5">
                <div className="text-[9px] font-black tracking-[0.14em] text-slate-400">{k}</div>
                <div className="text-[18px] font-black text-amber-200">{v}</div>
              </div>
            ))}
          </div>
          <div className="mt-2 text-[10px] text-slate-400">
            ◆ {s.meta.gold} gold · ✦ {s.meta.embers} embers · LV {s.meta.level} · PWR {s.meta.power}
          </div>
          <button
            className="btn mt-3 w-full py-3 text-[14px] text-slate-950"
            style={{ background: 'linear-gradient(180deg,#ffd27a,#ff6a2b)' }}
            onClick={() => engine.toTitle()}
          >
            RETURN TO THE ANVIL
          </button>
        </div>
      </div>
    </div>
  );
}

export function MoveLegend() {
  return (
    <div className="plate-flat pointer-events-none absolute bottom-3 left-3 px-2 py-1.5">
      <div className="mb-1 text-[9px] font-black tracking-[0.16em] text-slate-400">ENEMY MOVES</div>
      <div className="flex flex-col gap-0.5">
        {Object.entries(MOVES).map(([k, v]) => (
          <div key={k} className="text-[9px] text-slate-500">
            <b className="text-slate-300">{v.label}</b> ×{v.mult || '—'}
          </div>
        ))}
      </div>
    </div>
  );
}
