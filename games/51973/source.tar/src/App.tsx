import { useEffect, useRef, useState } from 'react';
import { Engine } from './game/engine';
import { GameView } from './three/GameView';
import { EndScreen, Hud, RewardScreen, TitleScreen } from './ui/Hud';
import type { GameState } from './game/types';

export default function App() {
  const hostRef = useRef<HTMLDivElement>(null);
  const engineRef = useRef<Engine | null>(null);
  const viewRef = useRef<GameView | null>(null);
  const [state, setState] = useState<GameState | null>(null);

  useEffect(() => {
    const engine = new Engine();
    engineRef.current = engine;
    const offState = engine.on({ state: setState });
    setState(engine.s);

    const host = hostRef.current;
    if (!host) return;
    const view = new GameView(host, (p) => {
      if (p.type === 'cell') void engine.tapCell(p.index);
      else if (p.type === 'enemy') engine.tapEnemy(p.id);
      else engine.tapWeapon(p.slot);
    });
    viewRef.current = view;
    const offEvent = engine.on({ event: (e) => view.handleEvent(e) });

    return () => {
      offState();
      offEvent();
      view.dispose();
      engine.dispose();
      viewRef.current = null;
      engineRef.current = null;
    };
  }, []);

  useEffect(() => {
    if (state) viewRef.current?.sync(state);
  }, [state]);

  const engine = engineRef.current;
  const inRun = state && state.phase !== 'title';

  return (
    <div className="relative h-full w-full overflow-hidden bg-[#07070b]">
      <div ref={hostRef} className="absolute inset-0" />

      {/* atmosphere: vignette + warm bloom wash */}
      <div
        className="pointer-events-none absolute inset-0"
        style={{
          background:
            'radial-gradient(120% 90% at 50% 42%, rgba(255,150,60,0.07) 0%, rgba(0,0,0,0) 46%), radial-gradient(100% 100% at 50% 50%, rgba(0,0,0,0) 42%, rgba(4,4,8,0.72) 100%)',
        }}
      />
      <div
        className="pointer-events-none absolute inset-0 opacity-[0.06] mix-blend-overlay"
        style={{
          backgroundImage:
            'repeating-linear-gradient(0deg, rgba(255,255,255,.5) 0 1px, rgba(0,0,0,0) 1px 3px)',
        }}
      />

      {state && engine && inRun && <Hud s={state} engine={engine} onPickWeapon={(i) => engine.tapWeapon(i)} />}
      {state && engine && state.phase === 'title' && <TitleScreen s={state} engine={engine} />}
      {state && engine && state.phase === 'reward' && <RewardScreen s={state} engine={engine} />}
      {state && engine && (state.phase === 'dead' || state.phase === 'cleared') && (
        <EndScreen s={state} engine={engine} />
      )}

      {!state && (
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-[12px] font-black tracking-[0.3em] text-amber-300">STOKING THE FURNACE…</div>
        </div>
      )}
    </div>
  );
}
