import * as THREE from 'three';
import {
  AZ,
  BOARD_Y,
  CAM_DIST,
  CELL,
  EL,
  FRUSTUM,
  LEDGE_Y,
  LEDGE_Z,
  TARGET,
  buildDais,
  buildDungeon,
  buildRack,
  cellToWorld,
  rackWorld,
} from './dungeon';
import { Composite, glowMat, slab } from './composite';
import { GEM_GEO, buildEnemyView, buildGems, buildWeaponView, gemMesh } from './props';
import { MATS } from '../game/content';
import type { Enemy, GameEvent, GameState, MatId } from '../game/types';

export type Pick = { type: 'cell'; index: number } | { type: 'enemy'; id: number } | { type: 'weapon'; slot: number };

interface GemView {
  id: number;
  mat: MatId;
  mesh: THREE.Mesh;
  target: THREE.Vector3;
  spin: number;
  dying: number;
  born: number;
}

interface EnemyView {
  id: number;
  group: THREE.Group;
  body: THREE.Group;
  eyes: THREE.Mesh[];
  hit: THREE.Mesh;
  mat: THREE.MeshToonMaterial;
  bar: HTMLDivElement;
  fill: HTMLDivElement;
  name: HTMLDivElement;
  headY: number;
  base: THREE.Vector3;
  baseScale: number;
  knock: number;
  flash: number;
  dying: number;
  spawn: number;
  phase: number;
}

interface WeaponView {
  id: number;
  slot: number;
  mat: MatId;
  group: THREE.Group;
  flying: boolean;
  selected: boolean;
  ring: THREE.Mesh;
}

interface Tween {
  t: number;
  dur: number;
  fn: (p: number) => void;
  done?: () => void;
}

interface Floater {
  el: HTMLDivElement;
  pos: THREE.Vector3;
  vel: THREE.Vector3;
  life: number;
  max: number;
}

const HEAD_Y: Record<string, number> = { boss: 6.6, wisp: 2.6, crawler: 1.9, brute: 3.9, stalker: 3.7, sentinel: 4.2 };

export class GameView {
  private renderer: THREE.WebGLRenderer;
  private scene = new THREE.Scene();
  private camera: THREE.OrthographicCamera;
  private raycaster = new THREE.Raycaster();
  private clock = new THREE.Clock();
  private container: HTMLElement;
  private overlay: HTMLDivElement;

  private camBase = new THREE.Vector3();
  private camQuat = new THREE.Quaternion();
  private shakeAmp = 0;
  private shakeT = 0;

  private stage!: THREE.Group;
  private pickables: THREE.Object3D[] = [];
  // taps ray-cast onto the board plane at gem-centre height so picks line up with what you see
  private boardPlane = new THREE.Plane(new THREE.Vector3(0, 1, 0), -(BOARD_Y + 0.44));
  private flames: THREE.Object3D[] = [];
  private torches: THREE.PointLight[] = [];
  private coldLight!: THREE.PointLight;

  private gemRoot = new THREE.Group();
  private gems = new Map<number, GemView>();
  private enemies = new Map<number, EnemyView>();
  private weapons = new Map<number, WeaponView>();
  private flying: THREE.Group[] = [];
  private tweens: Tween[] = [];
  private floaters: Floater[] = [];
  private particles: { m: THREE.Mesh; v: THREE.Vector3; life: number; max: number }[] = [];
  private selRing!: THREE.Mesh;
  private hintRing!: THREE.Mesh;
  private rackGroup: THREE.Group | null = null;
  private rackCount = 0;

  private state: GameState | null = null;
  private raf = 0;
  private disposed = false;
  private onPick: (p: Pick) => void;
  private tmp = new THREE.Vector3();
  private tmp2 = new THREE.Vector3();

  constructor(container: HTMLElement, onPick: (p: Pick) => void) {
    this.container = container;
    this.onPick = onPick;

    this.renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    this.renderer.setClearColor(0x07070b, 1);
    container.appendChild(this.renderer.domElement);

    this.overlay = document.createElement('div');
    this.overlay.style.cssText = 'position:absolute;inset:0;pointer-events:none;overflow:hidden;';
    container.appendChild(this.overlay);

    this.scene.fog = new THREE.Fog(0x0a0c14, CAM_DIST - 6, CAM_DIST + 52);
    this.camera = new THREE.OrthographicCamera(-1, 1, 1, -1, 0.5, 400);

    const dir = new THREE.Vector3(Math.cos(EL) * Math.sin(AZ), Math.sin(EL), Math.cos(EL) * Math.cos(AZ));
    this.camBase.copy(TARGET).addScaledVector(dir, CAM_DIST);
    this.camera.position.copy(this.camBase);
    this.camera.lookAt(TARGET);
    this.camera.updateMatrixWorld();
    this.camQuat.copy(this.camera.quaternion);

    this.build();
    this.resize();

    window.addEventListener('resize', this.resize);
    const el = this.renderer.domElement;
    el.addEventListener('pointerdown', this.onDown);
    el.addEventListener('wheel', this.block, { passive: false });
    el.addEventListener('contextmenu', this.block);
    el.addEventListener('touchstart', this.blockTouch, { passive: false });
    this.loop();
  }

  /* ------------------------------------------------------------- scene build */

  private build() {
    const d = buildDungeon();
    this.scene.add(d.root);
    this.stage = d.stage;
    this.flames = d.flames;
    this.torches = d.torches;
    this.coldLight = d.coldLight;
    this.scene.add(d.boardLight);

    this.scene.add(new THREE.AmbientLight(0x2b3550, 0.85));
    const hemi = new THREE.HemisphereLight(0x415a86, 0x120e14, 0.7);
    this.scene.add(hemi);
    const key = new THREE.DirectionalLight(0xffd7a8, 0.55);
    key.position.set(6, 14, 10);
    this.scene.add(key);
    const rim = new THREE.DirectionalLight(0x6fa8ff, 0.35);
    rim.position.set(-10, 6, -14);
    this.scene.add(rim);

    this.scene.add(buildDais());
    this.scene.add(this.gemRoot);

    // board tiles (merged)
    const tc = new Composite();
    for (let y = 0; y < 7; y++) {
      for (let x = 0; x < 7; x++) {
        const p = cellToWorld(x, y);
        const light = (x + y) % 2 === 0;
        tc.add(slab(CELL * 0.94, 0.34, CELL * 0.94, 0.09), light ? 0x4d556d : 0x3f4658, [p.x, BOARD_Y - 0.17, p.z]);
        tc.add(slab(CELL * 0.62, 0.1, CELL * 0.62, 0.05), light ? 0x5b6480 : 0x4a5266, [p.x, BOARD_Y - 0.02, p.z]);
      }
    }
    this.scene.add(tc.build(0.04));

    this.selRing = new THREE.Mesh(
      slab(CELL * 1.02, 0.1, CELL * 1.02, 0.05),
      glowMat(0xffb347, 0.95),
    );
    this.selRing.position.y = BOARD_Y + 0.02;
    this.selRing.visible = false;
    this.scene.add(this.selRing);

    this.hintRing = new THREE.Mesh(
      slab(CELL * 1.02, 0.1, CELL * 1.02, 0.05),
      glowMat(0x8fd6ff, 0.5),
    );
    this.hintRing.position.y = BOARD_Y + 0.02;
    this.hintRing.visible = false;
    this.scene.add(this.hintRing);

    buildGems();
  }

  private ensureRack(count: number) {
    if (this.rackCount === count && this.rackGroup) return;
    if (this.rackGroup) {
      this.scene.remove(this.rackGroup);
      this.rackGroup.traverse((o) => {
        const m = o as THREE.Mesh;
        if (m.geometry) m.geometry.dispose();
      });
    }
    this.rackGroup = buildRack(count);
    this.scene.add(this.rackGroup);
    this.rackCount = count;
  }

  /* ------------------------------------------------------------------- sync */

  sync(s: GameState) {
    this.state = s;
    this.ensureRack(s.slots);

    // ---- gems
    const seen = new Set<number>();
    for (let i = 0; i < s.grid.length; i++) {
      const g = s.grid[i];
      if (!g) continue;
      seen.add(g.id);
      let v = this.gems.get(g.id);
      if (!v) {
        const mesh = gemMesh(g.mat);
        const p = cellToWorld(g.x, g.y);
        mesh.position.set(p.x, p.y + 5.5 + Math.random() * 3, p.z);
        mesh.scale.setScalar(0.01);
        this.gemRoot.add(mesh);
        v = { id: g.id, mat: g.mat, mesh, target: new THREE.Vector3(), spin: Math.random() * 6.28, dying: 0, born: 0 };
        this.gems.set(g.id, v);
      }
      const p = cellToWorld(g.x, g.y);
      v.target.set(p.x, p.y + 0.44, p.z);
    }
    for (const [id, v] of this.gems) {
      if (!seen.has(id) && v.dying === 0) {
        v.dying = 0.0001;
        const c = MATS[v.mat];
        this.burst(v.mesh.position, c.color, 9);
        this.burst(v.mesh.position, c.accent, 5);
      }
    }

    // ---- enemies
    const seenE = new Set<number>();
    for (const e of s.enemies) {
      seenE.add(e.id);
      let v = this.enemies.get(e.id);
      if (!v) v = this.makeEnemy(e);
      v.bar.style.display = e.alive ? 'block' : 'none';
      const frac = Math.max(0, e.hp / e.maxHp);
      v.fill.style.width = `${frac * 100}%`;
      v.fill.style.background = e.boss ? 'linear-gradient(180deg,#ff9a4d,#c22f2f)' : 'linear-gradient(180deg,#ff7a5c,#a32a3c)';
      v.name.textContent = `${e.name}  ${Math.max(0, Math.ceil(e.hp))}/${e.maxHp}`;
      if (!e.alive && v.dying === 0) {
        v.dying = 0.0001;
        this.burst(v.group.position, e.accent, 22, 2.4);
      }
    }
    for (const [id, v] of this.enemies) {
      if (!seenE.has(id) && v.dying === 0) v.dying = 0.0001;
    }

    // ---- weapons
    const seenW = new Set<number>();
    for (let i = 0; i < s.weapons.length; i++) {
      const w = s.weapons[i];
      if (!w) continue;
      seenW.add(w.id);
      let v = this.weapons.get(w.id);
      if (!v) {
        const group = buildWeaponView(w.mat);
        const p = rackWorld(i, s.slots);
        group.position.set(p.x, p.y, p.z);
        group.rotation.y = -AZ;
        group.traverse((o) => {
          if (o.name === 'hitbox') {
            o.userData.pick = 'weapon';
            o.userData.slot = i;
            this.pickables.push(o);
          }
        });
        this.scene.add(group);
        const ring = new THREE.Mesh(slab(1.5, 0.12, 1.5, 0.05), glowMat(MATS[w.mat].accent, 0.9));
        ring.position.y = 0.06;
        ring.visible = false;
        group.add(ring);
        v = { id: w.id, slot: i, mat: w.mat, group, flying: false, selected: false, ring };
        this.weapons.set(w.id, v);
      }
      const p = rackWorld(v.slot, s.slots);
      v.group.position.set(p.x, p.y, p.z);
      v.selected = s.selWeapon === v.slot;
      v.ring.visible = v.selected;
    }
    for (const [id, v] of this.weapons) {
      if (!seenW.has(id) && !v.flying) this.removeWeapon(v);
    }

    // ---- selection rings
    if (s.selCell !== null && s.phase === 'forge') {
      const p = cellToWorld(s.selCell % 7, Math.floor(s.selCell / 7));
      this.selRing.position.set(p.x, BOARD_Y + 0.03, p.z);
      this.selRing.visible = true;
      const x = s.selCell % 7;
      const y = Math.floor(s.selCell / 7);
      const hx = x + 1 < 7 ? x + 1 : x - 1;
      const hy = y + 1 < 7 ? y + 1 : y - 1;
      const hp = cellToWorld(hx, hy);
      this.hintRing.position.set(hp.x, BOARD_Y + 0.03, hp.z);
      this.hintRing.visible = true;
    } else {
      this.selRing.visible = false;
      this.hintRing.visible = false;
    }
  }

  private makeEnemy(e: Enemy): EnemyView {
    const baseScale = e.boss ? 1.42 : e.scale;
    const view = buildEnemyView(e.kind, e.body, e.accent, baseScale);
    const n = Math.max(1, this.state?.enemies.length ?? 1);
    const spread = e.boss ? 0 : (e.slot - (n - 1) / 2) * 5.6;
    const base = new THREE.Vector3(spread, LEDGE_Y + 0.42, LEDGE_Z - 0.6);
    view.group.position.copy(base);
    view.group.scale.setScalar(0.01);
    view.hit.userData.pick = 'enemy';
    view.hit.userData.id = e.id;
    view.hit.name = 'hitbox';
    this.pickables.push(view.hit);
    this.stage.add(view.group);

    const bar = document.createElement('div');
    bar.className = `ebar${e.boss ? ' boss' : ''}`;
    bar.innerHTML = `<div class="nm"></div><div class="bar"><i style="width:100%"></i></div>`;
    this.overlay.appendChild(bar);
    const name = bar.querySelector('.nm') as HTMLDivElement;
    const fill = bar.querySelector('i') as HTMLDivElement;

    const v: EnemyView = {
      id: e.id,
      group: view.group,
      body: view.body,
      eyes: view.eyes,
      hit: view.hit,
      mat: (view.body.children[0] as THREE.Mesh).material as THREE.MeshToonMaterial,
      bar,
      fill,
      name,
      headY: HEAD_Y[e.kind] ?? 3.4,
      base,
      baseScale,
      knock: 0,
      flash: 0,
      dying: 0,
      spawn: 0,
      phase: e.phase,
    };
    this.enemies.set(e.id, v);
    return v;
  }

  private removeWeapon(v: WeaponView) {
    this.scene.remove(v.group);
    const dead: THREE.Object3D[] = [];
    v.group.traverse((o) => {
      if (o.name === 'hitbox') dead.push(o);
    });
    this.pickables = this.pickables.filter((o) => !dead.includes(o));
    this.weapons.delete(v.id);
  }

  /* ------------------------------------------------------------------ events */

  handleEvent(ev: GameEvent) {
    if (ev.t === 'shake') {
      this.shake(ev.px);
      return;
    }
    if (ev.t === 'throw') {
      const v = this.weapons.get(ev.weapon.id);
      const target = this.enemies.get(ev.enemyId);
      if (v && !v.flying && target) {
        v.flying = true;
        v.ring.visible = false;
        const dead: THREE.Object3D[] = [];
        v.group.traverse((o) => {
          if (o.name === 'hitbox') dead.push(o);
        });
        this.pickables = this.pickables.filter((o) => !dead.includes(o));
        const from = v.group.position.clone();
        const to = target.group.position.clone();
        to.y += 1.6;
        this.flying.push(v.group);
        this.tweens.push({
          t: 0,
          dur: 0.42,
          fn: (p) => {
            const e = p * p;
            v.group.position.lerpVectors(from, to, e);
            v.group.position.y += Math.sin(p * Math.PI) * 5.2;
            v.group.rotation.y += 0.34;
            v.group.rotation.z = Math.sin(p * Math.PI * 2) * 0.5;
          },
          done: () => {
            this.scene.remove(v.group);
            this.flying = this.flying.filter((g) => g !== v.group);
            this.weapons.delete(v.id);
            this.burst(target.group.position.clone().setY(target.group.position.y + 1.8), MATS[ev.weapon.mat].color, 20, 2.2);
            this.burst(target.group.position.clone().setY(target.group.position.y + 1.8), MATS[ev.weapon.mat].accent, 12, 1.6);
            target.knock = 1;
            target.flash = 1;
            this.floater(
              target.group.position.clone().setY(target.group.position.y + 2.4),
              `-${ev.dmg}${ev.crit ? '!' : ''}`,
              ev.crit ? '#ffe066' : '#fff2d8',
              ev.crit ? 40 : 30,
            );
          },
        });
      }
      return;
    }
    if (ev.t === 'tick') {
      const v = this.enemies.get(ev.enemyId);
      if (v) {
        v.flash = 0.8;
        const col = ev.kind === 'burn' ? 0xff7a2a : 0x74e03c;
        this.burst(v.group.position.clone().setY(v.group.position.y + 1.6), col, 10, 1.5);
        this.floater(v.group.position.clone().setY(v.group.position.y + 2.2), `-${ev.dmg}`, ev.kind === 'burn' ? '#ff9a4d' : '#a8f06a', 22);
      }
      return;
    }
    if (ev.t === 'status') {
      const v = this.enemies.get(ev.enemyId);
      if (!v) return;
      const label = ev.kind === 'burn' ? 'BURN' : ev.kind === 'poison' ? 'POISON' : 'FROZEN';
      const col = ev.kind === 'burn' ? '#ff9a4d' : ev.kind === 'poison' ? '#a8f06a' : '#8fdcff';
      this.floater(v.group.position.clone().setY(v.group.position.y + 3.0), label, col, 22);
      this.burst(v.group.position.clone().setY(v.group.position.y + 1.8), new THREE.Color(col).getHex(), 14, 1.8);
      return;
    }
    if (ev.t === 'enemyAct') {
      const v = this.enemies.get(ev.enemyId);
      if (v) {
        v.knock = -1;
        if (ev.move === 'frozen') {
          this.burst(v.group.position.clone().setY(v.group.position.y + 1.6), 0x8fdcff, 14, 1.6);
          this.floater(v.group.position.clone().setY(v.group.position.y + 2.6), 'SKIPPED', '#8fdcff', 20);
        } else if (ev.heal > 0) {
          this.floater(v.group.position.clone().setY(v.group.position.y + 2.6), `+${ev.heal}`, '#a8f06a', 24);
        } else if (ev.dmg > 0) {
          this.floater(new THREE.Vector3(0, 2.2, 6.5), `-${ev.dmg}`, '#ff6a6a', 34);
        }
      }
      return;
    }
    if (ev.t === 'heroHit') {
      this.shake(Math.min(6, 2 + ev.dmg / 8));
      return;
    }
    if (ev.t === 'heroHeal') {
      this.floater(new THREE.Vector3(0, 2.6, 6.5), `+${ev.amount}`, '#a8f06a', 22);
      return;
    }
    if (ev.t === 'bossPhase') {
      const v = this.enemies.get(ev.enemyId);
      if (v) {
        v.phase = ev.phase;
        this.burst(v.group.position.clone().setY(v.group.position.y + 3), 0xffb347, 30, 3);
        this.floater(v.group.position.clone().setY(v.group.position.y + 4), `PHASE ${ev.phase + 1}`, '#ffb347', 30);
      }
      return;
    }
    if (ev.t === 'forge') {
      const p = rackWorld(ev.slot, this.state?.slots ?? 4);
      this.burst(p.clone().setY(p.y + 1.2), MATS[ev.weapon.mat].accent, 14, 1.6);
      return;
    }
  }

  /* ------------------------------------------------------------------ effects */

  shake(px: number) {
    this.shakeAmp = Math.min(6, Math.max(this.shakeAmp, px));
    this.shakeT = 0;
  }

  private burst(pos: THREE.Vector3, color: number, count: number, power = 1.6) {
    const mat = glowMat(color, 1);
    for (let i = 0; i < count; i++) {
      const m = new THREE.Mesh(GEM_GEO[0], mat);
      m.position.copy(pos);
      const s = 0.12 + Math.random() * 0.2;
      m.scale.setScalar(s);
      this.scene.add(m);
      this.particles.push({
        m,
        v: new THREE.Vector3(
          (Math.random() - 0.5) * 6 * power,
          (2 + Math.random() * 5) * power,
          (Math.random() - 0.5) * 6 * power,
        ),
        life: 0,
        max: 0.5 + Math.random() * 0.5,
      });
    }
  }

  private floater(pos: THREE.Vector3, text: string, color: string, size: number) {
    const el = document.createElement('div');
    el.className = 'floater';
    el.textContent = text;
    el.style.color = color;
    el.style.fontSize = `${size}px`;
    this.overlay.appendChild(el);
    this.floaters.push({ el, pos: pos.clone(), vel: new THREE.Vector3((Math.random() - 0.5) * 1.2, 3.4, 0), life: 0, max: 1.0 });
  }

  /* ------------------------------------------------------------------ picking */

  private block = (e: Event) => e.preventDefault();
  private blockTouch = (e: TouchEvent) => {
    if (e.touches.length > 1) e.preventDefault();
  };

  private onDown = (e: PointerEvent) => {
    if (e.button !== 0 && e.pointerType === 'mouse') return;
    const rect = this.renderer.domElement.getBoundingClientRect();
    const ndc = new THREE.Vector2(
      ((e.clientX - rect.left) / rect.width) * 2 - 1,
      -((e.clientY - rect.top) / rect.height) * 2 + 1,
    );
    this.raycaster.setFromCamera(ndc, this.camera);
    const hits = this.raycaster.intersectObjects(this.pickables, false);
    if (hits.length > 0) {
      const u = hits[0].object.userData;
      if (u.pick === 'enemy') {
        this.onPick({ type: 'enemy', id: u.id as number });
        return;
      }
      if (u.pick === 'weapon') {
        this.onPick({ type: 'weapon', slot: u.slot as number });
        return;
      }
    }
    const p = this.raycaster.ray.intersectPlane(this.boardPlane, this.tmp);
    if (p) {
      const gx = Math.round(p.x / CELL + 3);
      const gy = Math.round(p.z / CELL + 3);
      if (gx >= 0 && gx < 7 && gy >= 0 && gy < 7) this.onPick({ type: 'cell', index: gy * 7 + gx });
    }
  };

  /* ------------------------------------------------------------------- frame */

  private resize = () => {
    const w = this.container.clientWidth || window.innerWidth;
    const h = this.container.clientHeight || window.innerHeight;
    const aspect = w / h;
    const fh = Math.max(FRUSTUM, 21 / aspect);
    this.camera.top = fh / 2;
    this.camera.bottom = -fh / 2;
    this.camera.left = (-fh * aspect) / 2;
    this.camera.right = (fh * aspect) / 2;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(w, h, false);
    this.renderer.domElement.style.width = '100%';
    this.renderer.domElement.style.height = '100%';
  };

  private loop = () => {
    if (this.disposed) return;
    this.raf = requestAnimationFrame(this.loop);
    const dt = Math.min(0.05, this.clock.getDelta());
    const t = this.clock.elapsedTime;

    // tweens
    for (let i = this.tweens.length - 1; i >= 0; i--) {
      const tw = this.tweens[i];
      tw.t += dt;
      const p = Math.min(1, tw.t / tw.dur);
      tw.fn(p);
      if (p >= 1) {
        tw.done?.();
        this.tweens.splice(i, 1);
      }
    }

    // gems
    for (const [id, v] of this.gems) {
      if (v.dying > 0) {
        v.dying += dt;
        const p = Math.min(1, v.dying / 0.28);
        v.mesh.scale.setScalar(Math.max(0.001, 1 - p) * (1 + p * 0.7));
        v.mesh.position.y += dt * 3.2;
        v.mesh.rotation.y += dt * 12;
        if (p >= 1) {
          this.gemRoot.remove(v.mesh);
          this.gems.delete(id);
        }
        continue;
      }
      if (v.born < 1) {
        v.born = Math.min(1, v.born + dt * 5.5);
        const e = 1 - Math.pow(1 - v.born, 3);
        v.mesh.scale.setScalar(0.2 + 0.8 * e);
      }
      v.mesh.position.lerp(v.target, 1 - Math.pow(0.0008, dt));
      v.spin += dt * 0.7;
      v.mesh.rotation.y = v.spin;
      v.mesh.rotation.x = Math.sin(v.spin * 0.7) * 0.12;
      v.mesh.position.y = v.target.y + Math.sin(t * 2 + v.spin) * 0.05;
    }

    // enemies
    for (const [id, v] of this.enemies) {
      if (v.spawn < 1) {
        v.spawn = Math.min(1, v.spawn + dt * 2.6);
        const e = 1 - Math.pow(1 - v.spawn, 3);
        v.group.scale.setScalar(v.baseScale * (0.15 + 0.85 * e));
      }
      if (v.dying > 0) {
        v.dying += dt;
        const p = Math.min(1, v.dying / 0.5);
        v.group.scale.setScalar(Math.max(0.001, v.baseScale * (1 - p)));
        v.group.rotation.z = p * 0.9;
        v.group.position.y = v.base.y - p * 1.4;
        if (p >= 1) {
          this.stage.remove(v.group);
          this.pickables = this.pickables.filter((o) => o !== v.hit);
          v.bar.remove();
          this.enemies.delete(id);
        }
        continue;
      }
      v.knock *= Math.pow(0.02, dt);
      v.group.position.set(
        v.base.x + v.knock * 0.9,
        v.base.y + Math.sin(t * 1.6 + v.id) * 0.09,
        v.base.z + v.knock * 0.4,
      );
      v.group.rotation.z = v.knock * 0.16;
      if (v.flash > 0) {
        v.flash = Math.max(0, v.flash - dt * 3.4);
        v.mat.emissive.setRGB(v.flash * 0.9, v.flash * 0.35, v.flash * 0.15);
      }
      const pulse = 0.75 + Math.sin(t * 4 + v.id) * 0.25;
      v.eyes.forEach((e) => e.scale.setScalar(pulse));
    }

    // weapons idle bob
    for (const v of this.weapons.values()) {
      if (v.flying) continue;
      v.group.position.y = rackWorld(v.slot, this.state?.slots ?? 4).y + Math.sin(t * 2 + v.slot) * 0.07;
      v.group.rotation.y = -AZ + Math.sin(t * 0.8 + v.slot) * 0.12;
      if (v.selected) v.ring.scale.setScalar(1 + Math.sin(t * 7) * 0.08);
    }

    // particles
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.life += dt;
      p.v.y -= dt * 16;
      p.m.position.addScaledVector(p.v, dt);
      p.m.rotation.x += dt * 8;
      p.m.rotation.y += dt * 6;
      const k = 1 - p.life / p.max;
      p.m.scale.setScalar(Math.max(0.001, k) * 0.28);
      if (p.life >= p.max) {
        this.scene.remove(p.m);
        this.particles.splice(i, 1);
      }
    }

    // flames + lights
    for (let i = 0; i < this.flames.length; i++) {
      const f = this.flames[i];
      const k = 0.86 + Math.sin(t * 9 + i * 1.7) * 0.1 + Math.sin(t * 21 + i) * 0.05;
      f.scale.set(k, 1 / k, k);
      f.rotation.y = t * 1.4 + i;
    }
    for (let i = 0; i < this.torches.length; i++) {
      this.torches[i].intensity = 2.2 + Math.sin(t * 11 + i * 2.3) * 0.5 + Math.sin(t * 27 + i) * 0.22;
    }
    this.coldLight.intensity = 3.0 + Math.sin(t * 1.7) * 0.5;
    if (this.selRing.visible) this.selRing.scale.setScalar(1 + Math.sin(t * 8) * 0.05);

    // html overlay
    const rect = this.renderer.domElement.getBoundingClientRect();
    for (const v of this.enemies.values()) {
      if (v.dying > 0) continue;
      this.tmp.set(0, v.headY, 0).applyMatrix4(v.group.matrixWorld);
      this.tmp2.copy(this.tmp).project(this.camera);
      const x = (this.tmp2.x * 0.5 + 0.5) * rect.width;
      const y = (-this.tmp2.y * 0.5 + 0.5) * rect.height;
      v.bar.style.transform = `translate(-50%,-100%) translate(${x.toFixed(1)}px,${(y - 6).toFixed(1)}px)`;
    }
    for (let i = this.floaters.length - 1; i >= 0; i--) {
      const f = this.floaters[i];
      f.life += dt;
      f.vel.y -= dt * 5.5;
      f.pos.addScaledVector(f.vel, dt);
      this.tmp2.copy(f.pos).project(this.camera);
      const x = (this.tmp2.x * 0.5 + 0.5) * rect.width;
      const y = (-this.tmp2.y * 0.5 + 0.5) * rect.height;
      const k = f.life / f.max;
      f.el.style.transform = `translate(-50%,-50%) translate(${x.toFixed(1)}px,${y.toFixed(1)}px) scale(${(1 + k * 0.25).toFixed(3)})`;
      f.el.style.opacity = `${Math.max(0, 1 - k * k)}`;
      if (k >= 1) {
        f.el.remove();
        this.floaters.splice(i, 1);
      }
    }

    // camera shake — always rebuilt from the exact base pose
    if (this.shakeAmp > 0.001) {
      this.shakeT += dt;
      const decay = Math.pow(0.0009, dt);
      this.shakeAmp *= decay;
      const fh = this.camera.top - this.camera.bottom;
      const unit = fh / Math.max(1, rect.height);
      const ox = Math.sin(this.shakeT * 74) * this.shakeAmp * unit;
      const oy = Math.cos(this.shakeT * 61) * this.shakeAmp * unit * 0.7;
      this.tmp.setFromMatrixColumn(this.camera.matrix, 0).multiplyScalar(ox);
      this.tmp2.setFromMatrixColumn(this.camera.matrix, 1).multiplyScalar(oy);
      this.camera.position.copy(this.camBase).add(this.tmp).add(this.tmp2);
      this.camera.quaternion.copy(this.camQuat);
      if (this.shakeAmp <= 0.001) {
        this.shakeAmp = 0;
        this.camera.position.copy(this.camBase);
        this.camera.quaternion.copy(this.camQuat);
      }
    }

    this.renderer.render(this.scene, this.camera);
  };

  dispose() {
    this.disposed = true;
    cancelAnimationFrame(this.raf);
    window.removeEventListener('resize', this.resize);
    const el = this.renderer.domElement;
    el.removeEventListener('pointerdown', this.onDown);
    el.removeEventListener('wheel', this.block);
    el.removeEventListener('contextmenu', this.block);
    el.removeEventListener('touchstart', this.blockTouch);
    this.overlay.remove();
    this.renderer.dispose();
    el.remove();
  }
}
