import * as THREE from 'three';
import {
  Composite,
  OUTLINE_MAT,
  box,
  cone,
  cyl,
  dodec,
  glowMat,
  ico,
  octa,
  slab,
  sph,
  tetra,
  toonMat,
  tor,
} from './composite';
import { MATS } from '../game/content';
import type { EnemyKind, MatId } from '../game/types';

/* -------------------------------------------------------------------- gems */

export const GEM_GEO: THREE.BufferGeometry[] = [];
export const GEM_OUT: THREE.BufferGeometry[] = [];
export const GEM_MAT: THREE.MeshToonMaterial[] = [];

export function buildGems() {
  for (let m = 0; m < 4; m++) {
    const info = MATS[m];
    const c = new Composite();
    if (m === 0) {
      // Ember — molten shard in a ring
      c.add(octa(0.62), info.color, [0, 0, 0], [0, 0.4, 0]);
      c.add(octa(0.3), info.accent, [0, 0.16, 0], [0.3, 0.9, 0.2]);
      c.add(tor(0.52, 0.075, 14, 6), info.accent, [0, -0.05, 0], [Math.PI / 2.4, 0, 0.4]);
      for (let i = 0; i < 3; i++) {
        const a = (i / 3) * Math.PI * 2;
        c.add(cone(0.1, 0.34, 5), info.accent, [Math.cos(a) * 0.44, 0.1, Math.sin(a) * 0.44], [0, 0, 0]);
      }
    } else if (m === 1) {
      // Frost — crystal cluster
      c.add(ico(0.55, 0), info.color, [0, 0, 0], [0.2, 0.5, 0.1]);
      c.add(ico(0.26, 0), info.accent, [0.2, 0.3, 0.12], [0.4, 0.2, 0.3]);
      for (let i = 0; i < 3; i++) {
        const a = (i / 3) * Math.PI * 2 + 0.5;
        c.add(cone(0.13, 0.5, 5), info.accent, [Math.cos(a) * 0.42, -0.12, Math.sin(a) * 0.42], [
          Math.sin(a) * 0.5,
          0,
          -Math.cos(a) * 0.5,
        ]);
      }
    } else if (m === 2) {
      // Venom — spiked pod
      c.add(tetra(0.72), info.color, [0, 0.04, 0], [0.2, 0.7, 0.1]);
      c.add(sph(0.24, 8), info.accent, [0, 0.02, 0]);
      c.add(tor(0.44, 0.07, 12, 6), info.accent, [0, -0.16, 0], [Math.PI / 2, 0, 0]);
      c.add(cone(0.16, 0.42, 6), info.accent, [0, 0.5, 0]);
    } else {
      // Iron — banded ingot
      c.add(slab(0.86, 0.86, 0.86, 0.14), info.color, [0, 0, 0], [0, 0.42, 0]);
      c.add(tor(0.5, 0.085, 14, 6), info.accent, [0, 0, 0], [Math.PI / 2, 0, 0]);
      c.add(slab(0.3, 0.3, 0.3, 0.06), info.accent, [0, 0.44, 0], [0, 0.42, 0]);
    }
    const built = c.build(0.05);
    GEM_GEO[m] = (built.children[0] as THREE.Mesh).geometry;
    GEM_OUT[m] = (built.children[1] as THREE.Mesh).geometry;
    GEM_MAT[m] = toonMat({
      emissive: info.color,
      emissiveIntensity: m === 0 ? 0.3 : 0.16,
    });
  }
}

export function gemMesh(mat: MatId) {
  const m = new THREE.Mesh(GEM_GEO[mat], GEM_MAT[mat]);
  m.add(new THREE.Mesh(GEM_OUT[mat], OUTLINE_MAT));
  return m;
}

/* ----------------------------------------------------------------- enemies */

const EYE = 0xffe08a;

function buildEnemyBody(kind: EnemyKind, body: number, accent: number): Composite {
  const c = new Composite();
  if (kind === 'crawler') {
    c.add(slab(1.5, 0.75, 1.9, 0.2), body, [0, 0.75, 0]);
    c.add(dodec(0.42), accent, [0, 0.95, 0.85]);
    c.add(cone(0.3, 0.5, 6), accent, [0, 1.25, 0.5], [Math.PI / 2.2, 0, 0]);
    for (let i = 0; i < 6; i++) {
      const s = i < 3 ? -1 : 1;
      const k = i % 3;
      c.add(cyl(0.09, 0.13, 1.5, 6), body, [s * 0.78, 0.7, -0.6 + k * 0.6], [0, 0, s * 0.9]);
      c.add(cyl(0.08, 0.08, 1.2, 6), accent, [s * 1.25, 0.28, -0.6 + k * 0.6], [0.5, 0, s * 0.3]);
    }
    c.add(cone(0.16, 0.6, 5), accent, [-0.28, 1.15, 0.9], [Math.PI / 3, 0, 0.4]);
    c.add(cone(0.16, 0.6, 5), accent, [0.28, 1.15, 0.9], [Math.PI / 3, 0, -0.4]);
  } else if (kind === 'brute') {
    c.add(slab(2.0, 1.7, 1.4, 0.24), body, [0, 1.7, 0]);
    c.add(slab(1.1, 0.85, 1.0, 0.18), accent, [0, 2.85, 0.1]);
    c.add(cone(0.5, 0.7, 7), accent, [0, 3.5, 0.1]);
    for (const s of [-1, 1]) {
      c.add(tor(0.62, 0.2, 12, 6), accent, [s * 1.05, 2.5, 0], [0, 0, Math.PI / 2]);
      c.add(cyl(0.3, 0.36, 1.5, 8), body, [s * 1.25, 1.7, 0.15], [0, 0, s * 0.2]);
      c.add(dodec(0.46), accent, [s * 1.5, 0.85, 0.2]);
      c.add(cyl(0.34, 0.4, 1.3, 8), body, [s * 0.62, 0.55, 0]);
    }
    c.add(slab(0.5, 0.5, 0.5, 0.1), accent, [0, 1.7, 0.75]);
  } else if (kind === 'stalker') {
    c.add(cyl(0.42, 0.62, 1.9, 9), body, [0, 1.75, 0]);
    c.add(cone(0.62, 0.9, 8), accent, [0, 3.0, 0]);
    c.add(slab(0.9, 0.5, 0.5, 0.12), body, [0, 2.5, 0.2]);
    for (const s of [-1, 1]) {
      c.add(cyl(0.14, 0.18, 1.7, 6), body, [s * 0.62, 1.9, 0.1], [0, 0, s * 0.35]);
      c.add(cone(0.16, 1.5, 6), accent, [s * 0.95, 1.0, 0.5], [1.1, 0, s * 0.3]);
      c.add(cyl(0.16, 0.2, 1.5, 6), body, [s * 0.32, 0.5, 0]);
      c.add(slab(0.4, 0.16, 0.7, 0.05), accent, [s * 0.32, 0.06, 0.2]);
    }
    c.add(tor(0.5, 0.1, 12, 6), accent, [0, 2.35, 0], [Math.PI / 2, 0, 0]);
  } else if (kind === 'wisp') {
    c.add(ico(0.72, 1), body, [0, 1.7, 0]);
    c.add(sph(0.4, 10), accent, [0, 1.7, 0]);
    for (let i = 0; i < 5; i++) {
      const a = (i / 5) * Math.PI * 2;
      c.add(tetra(0.24), accent, [Math.cos(a) * 1.05, 1.7 + Math.sin(a * 2) * 0.4, Math.sin(a) * 1.05], [a, a, 0]);
    }
    c.add(cone(0.5, 1.5, 8), body, [0, 0.6, 0], [Math.PI, 0, 0]);
    c.add(tor(1.05, 0.08, 16, 6), accent, [0, 1.7, 0], [Math.PI / 2.6, 0, 0]);
  } else if (kind === 'sentinel') {
    c.add(slab(1.9, 2.1, 1.3, 0.26), body, [0, 1.6, 0]);
    c.add(slab(1.5, 0.6, 1.1, 0.16), accent, [0, 2.8, 0]);
    c.add(box(0.9, 0.7, 0.9), body, [0, 3.3, 0.05]);
    c.add(cone(0.3, 0.9, 6), accent, [0, 3.9, 0.05]);
    for (const s of [-1, 1]) {
      c.add(tor(0.55, 0.18, 12, 6), accent, [s * 1.0, 2.55, 0], [0, 0, Math.PI / 2]);
      c.add(cyl(0.26, 0.3, 1.5, 8), body, [s * 1.1, 1.75, 0.1], [0, 0, s * 0.15]);
      c.add(cyl(0.3, 0.34, 1.3, 8), body, [s * 0.55, 0.5, 0]);
      c.add(slab(0.7, 0.3, 0.9, 0.08), accent, [s * 0.55, 0.1, 0.1]);
    }
    c.add(slab(0.4, 2.3, 1.7, 0.12), accent, [-1.35, 1.7, 0.5]);
    c.add(cone(0.34, 0.5, 6), accent, [-1.35, 3.0, 0.5], [Math.PI / 2, 0, 0]);
    c.add(cyl(0.16, 0.16, 1.6, 6), body, [1.35, 2.4, 0.3]);
    c.add(slab(0.9, 0.9, 0.9, 0.16), accent, [1.35, 3.3, 0.3]);
  } else {
    // boss
    c.add(slab(3.4, 3.0, 2.2, 0.34), body, [0, 2.6, 0]);
    c.add(cone(2.9, 2.6, 10), accent, [0, 1.5, 0.1], [Math.PI, 0, 0]);
    c.add(slab(2.0, 1.0, 1.5, 0.22), accent, [0, 4.4, 0.1]);
    c.add(box(1.5, 1.2, 1.3), body, [0, 5.2, 0.1]);
    for (let i = 0; i < 5; i++) {
      const a = -0.9 + (i / 4) * 1.8;
      c.add(cone(0.22, 1.5, 6), accent, [Math.sin(a) * 0.8, 6.0, 0.1 + Math.cos(a) * 0.2], [0.2, 0, -a * 0.7]);
    }
    c.add(tor(1.25, 0.26, 16, 8), accent, [0, 2.9, 0.9], [Math.PI / 2, 0, 0]);
    c.add(sph(0.85, 12), 0xffb347, [0, 2.9, 1.05]);
    for (const s of [-1, 1]) {
      c.add(tor(0.95, 0.3, 14, 7), accent, [s * 1.85, 3.7, 0], [0, 0, Math.PI / 2]);
      c.add(cyl(0.42, 0.5, 2.4, 8), body, [s * 2.1, 2.5, 0.2], [0, 0, s * 0.22]);
      c.add(dodec(0.75), accent, [s * 2.6, 1.2, 0.3]);
      c.add(cyl(0.5, 0.58, 1.8, 8), body, [s * 0.95, 0.9, 0]);
      c.add(slab(1.1, 0.4, 1.5, 0.12), accent, [s * 0.95, 0.2, 0.15]);
      c.add(cyl(0.3, 0.3, 2.6, 7), body, [s * 2.3, 4.6, -0.6], [0.4, 0, s * 0.5]);
      c.add(cone(0.4, 1.2, 7), accent, [s * 3.1, 5.6, -1.0], [0.4, 0, s * 0.5]);
    }
    c.add(tor(2.4, 0.22, 20, 8), 0x8a6526, [0, 5.6, 0.1], [Math.PI / 2, 0, 0]);
  }
  return c;
}

export interface EnemyView {
  group: THREE.Group;
  body: THREE.Group;
  eyes: THREE.Mesh[];
  hit: THREE.Mesh;
  float: number;
}

export function buildEnemyView(kind: EnemyKind, body: number, accent: number, scale: number): EnemyView {
  const group = new THREE.Group();
  const built = buildEnemyBody(kind, body, accent).build(0.055);
  group.add(built);
  const eyes: THREE.Mesh[] = [];
  const eyeMat = glowMat(EYE, 0.95);
  const spots: [number, number, number, number][] =
    kind === 'boss'
      ? [
          [-0.42, 5.35, 0.78, 0.16],
          [0.42, 5.35, 0.78, 0.16],
        ]
      : kind === 'wisp'
        ? [[0, 1.95, 0.62, 0.18]]
        : [
            [-0.22, 2.95, 0.5, 0.13],
            [0.22, 2.95, 0.5, 0.13],
          ];
  for (const [x, y, z, r] of spots) {
    const e = new THREE.Mesh(sph(r, 8), eyeMat);
    e.position.set(x, y, z);
    group.add(e);
    eyes.push(e);
  }
  const hit = new THREE.Mesh(
    box(kind === 'boss' ? 5.2 : 2.6, kind === 'boss' ? 7.4 : 3.8, 2.6),
    new THREE.MeshBasicMaterial({ visible: false }),
  );
  hit.position.y = (kind === 'boss' ? 7.4 : 3.8) / 2;
  group.add(hit);
  group.scale.setScalar(scale);
  return { group, body: built, eyes, hit, float: Math.random() * Math.PI * 2 };
}

/* ----------------------------------------------------------------- weapons */

export function buildWeaponView(mat: MatId): THREE.Group {
  const info = MATS[mat];
  const c = new Composite();
  const handle = 0x4a3524;
  if (mat === 0) {
    c.add(cyl(0.075, 0.09, 0.72, 6), handle, [0, 0.36, 0]);
    c.add(tor(0.16, 0.05, 10, 6), info.accent, [0, 0.72, 0], [Math.PI / 2, 0, 0]);
    c.add(slab(0.16, 0.85, 0.5, 0.06), info.color, [0, 1.2, 0]);
    c.add(cone(0.26, 0.5, 6), info.color, [0, 1.85, 0]);
    c.add(slab(0.06, 0.8, 0.16, 0.02), info.accent, [0, 1.25, 0.16]);
    c.add(sph(0.13, 8), info.accent, [0, 1.0, 0]);
  } else if (mat === 1) {
    c.add(cyl(0.06, 0.07, 1.9, 6), handle, [0, 0.95, 0]);
    c.add(cone(0.2, 0.62, 6), info.color, [0, 2.15, 0]);
    c.add(tor(0.2, 0.05, 10, 6), info.accent, [0, 1.82, 0], [Math.PI / 2, 0, 0]);
    for (let i = 0; i < 3; i++) {
      const a = (i / 3) * Math.PI * 2;
      c.add(cone(0.07, 0.34, 5), info.accent, [Math.cos(a) * 0.16, 1.86, Math.sin(a) * 0.16], [0, 0, 0]);
    }
    c.add(cone(0.1, 0.3, 5), info.accent, [0, 0.06, 0], [Math.PI, 0, 0]);
  } else if (mat === 2) {
    c.add(cyl(0.055, 0.065, 1.15, 6), handle, [0, 0.58, 0]);
    c.add(cone(0.15, 0.5, 6), info.color, [0, 1.35, 0]);
    for (let i = 0; i < 4; i++) {
      const a = (i / 4) * Math.PI * 2;
      c.add(cone(0.06, 0.3, 5), info.accent, [Math.cos(a) * 0.13, 1.12, Math.sin(a) * 0.13], [
        Math.sin(a) * 1.2,
        0,
        -Math.cos(a) * 1.2,
      ]);
    }
    c.add(sph(0.16, 8), info.accent, [0, 0.95, 0]);
    c.add(tor(0.12, 0.04, 10, 6), info.accent, [0, 0.14, 0], [Math.PI / 2, 0, 0]);
  } else {
    c.add(cyl(0.08, 0.09, 1.15, 6), handle, [0, 0.58, 0]);
    c.add(slab(0.62, 0.62, 0.62, 0.12), info.color, [0, 1.4, 0], [0, 0.5, 0]);
    c.add(tor(0.42, 0.07, 12, 6), info.accent, [0, 1.4, 0], [Math.PI / 2, 0, 0]);
    c.add(slab(0.2, 0.2, 0.2, 0.05), info.accent, [0, 1.78, 0], [0, 0.5, 0]);
    c.add(sph(0.1, 8), info.accent, [0, 0.06, 0]);
  }
  const g = c.build(0.04);
  const hit = new THREE.Mesh(box(1.35, 2.5, 1.35), new THREE.MeshBasicMaterial({ visible: false }));
  hit.position.y = 1.2;
  hit.name = 'hitbox';
  g.add(hit);
  return g;
}

export function buildSelectionRing(color: number): THREE.Mesh {
  const m = new THREE.Mesh(tor(0.95, 0.09, 22, 6), glowMat(color, 0.95));
  m.rotation.x = Math.PI / 2;
  return m;
}
