import * as THREE from 'three';
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js';

export const INK = 0x06060a;

/* ---------------------------------------------------------- toon gradient */

function makeGradient(steps: number[]): THREE.DataTexture {
  const data = new Uint8Array(steps.length);
  for (let i = 0; i < steps.length; i++) data[i] = Math.max(0, Math.min(255, steps[i]));
  const t = new THREE.DataTexture(data, steps.length, 1, THREE.RedFormat);
  t.minFilter = THREE.NearestFilter;
  t.magFilter = THREE.NearestFilter;
  t.generateMipmaps = false;
  t.needsUpdate = true;
  return t;
}

export const GRAD_4 = makeGradient([70, 148, 208, 255]);
export const GRAD_3 = makeGradient([86, 168, 255]);

export function toonMat(opts: {
  emissive?: number;
  emissiveIntensity?: number;
  transparent?: boolean;
  opacity?: number;
  side?: THREE.Side;
  steps?: number[];
} = {}) {
  return new THREE.MeshToonMaterial({
    vertexColors: true,
    gradientMap: opts.steps ? makeGradient(opts.steps) : GRAD_4,
    emissive: new THREE.Color(opts.emissive ?? 0x000000),
    emissiveIntensity: opts.emissiveIntensity ?? 1,
    transparent: opts.transparent ?? false,
    opacity: opts.opacity ?? 1,
    side: opts.side ?? THREE.FrontSide,
  });
}

export function glowMat(color: number, opacity = 1) {
  return new THREE.MeshBasicMaterial({
    color,
    transparent: opacity < 1,
    opacity,
    toneMapped: false,
  });
}

export const OUTLINE_MAT = new THREE.MeshBasicMaterial({
  color: INK,
  side: THREE.BackSide,
  toneMapped: false,
});

/* ------------------------------------------------------------- composite */

type Vec3 = [number, number, number];

/**
 * Accumulates transformed + vertex-coloured geometry so a whole prop can be
 * drawn as ONE toon mesh plus ONE inverted-hull outline shell.
 */
export class Composite {
  private parts: THREE.BufferGeometry[] = [];

  add(
    geo: THREE.BufferGeometry,
    color: number,
    pos: Vec3 = [0, 0, 0],
    rot: Vec3 = [0, 0, 0],
    scale: Vec3 | number = 1,
  ): this {
    const g = (geo.index ? geo.toNonIndexed() : geo.clone()) as THREE.BufferGeometry;
    g.deleteAttribute('uv');
    g.deleteAttribute('uv1');
    g.deleteAttribute('uv2');
    const m = new THREE.Matrix4();
    m.compose(
      new THREE.Vector3(pos[0], pos[1], pos[2]),
      new THREE.Quaternion().setFromEuler(new THREE.Euler(rot[0], rot[1], rot[2])),
      typeof scale === 'number'
        ? new THREE.Vector3(scale, scale, scale)
        : new THREE.Vector3(scale[0], scale[1], scale[2]),
    );
    g.applyMatrix4(m);
    const c = new THREE.Color(color);
    const n = g.attributes.position.count;
    const arr = new Float32Array(n * 3);
    for (let i = 0; i < n; i++) {
      arr[i * 3] = c.r;
      arr[i * 3 + 1] = c.g;
      arr[i * 3 + 2] = c.b;
    }
    g.setAttribute('color', new THREE.BufferAttribute(arr, 3));
    this.parts.push(g);
    return this;
  }

  /** Expand every part about its own centre to build a uniform-thickness shell. */
  outline(thickness = 0.045, maxScale = 1.5): THREE.BufferGeometry {
    const outs: THREE.BufferGeometry[] = [];
    for (const p of this.parts) {
      p.computeBoundingBox();
      const bb = p.boundingBox!;
      const c = bb.getCenter(new THREE.Vector3());
      const s = bb.getSize(new THREE.Vector3());
      const g = p.clone();
      g.translate(-c.x, -c.y, -c.z);
      g.scale(
        Math.min(maxScale, 1 + (2 * thickness) / Math.max(s.x, 0.02)),
        Math.min(maxScale, 1 + (2 * thickness) / Math.max(s.y, 0.02)),
        Math.min(maxScale, 1 + (2 * thickness) / Math.max(s.z, 0.02)),
      );
      g.translate(c.x, c.y, c.z);
      outs.push(g);
    }
    return mergeGeometries(outs, false) as THREE.BufferGeometry;
  }

  build(thickness = 0.045, mat?: THREE.Material): THREE.Group {
    const group = new THREE.Group();
    if (this.parts.length === 0) return group;
    const main = mergeGeometries(this.parts, false) as THREE.BufferGeometry;
    const mesh = new THREE.Mesh(main, mat ?? toonMat());
    mesh.castShadow = false;
    mesh.receiveShadow = false;
    group.add(mesh);
    const shell = new THREE.Mesh(this.outline(thickness), OUTLINE_MAT);
    group.add(shell);
    return group;
  }

  dispose() {
    this.parts.forEach((p) => p.dispose());
    this.parts = [];
  }
}

/* ------------------------------------------------------------- primitives */

const cache = new Map<string, THREE.BufferGeometry>();
function cached(key: string, make: () => THREE.BufferGeometry) {
  let g = cache.get(key);
  if (!g) {
    g = make();
    cache.set(key, g);
  }
  return g;
}

/** Chamfered slab — never a bare box. */
export function slab(w: number, h: number, d: number, ch = 0.09) {
  return cached(`slab${w}_${h}_${d}_${ch}`, () => {
    const c = Math.min(ch, w / 2.2, h / 2.2, d / 2.2);
    const parts: THREE.BufferGeometry[] = [];
    const core = new THREE.BoxGeometry(w - 2 * c, h - 2 * c, d - 2 * c);
    parts.push(core);
    const top = new THREE.BoxGeometry(w, c, d - 2 * c);
    top.translate(0, h / 2 - c / 2, 0);
    parts.push(top);
    const bot = new THREE.BoxGeometry(w, c, d - 2 * c);
    bot.translate(0, -h / 2 + c / 2, 0);
    parts.push(bot);
    const fr = new THREE.BoxGeometry(w - 2 * c, h, c);
    fr.translate(0, 0, d / 2 - c / 2);
    parts.push(fr);
    const bk = new THREE.BoxGeometry(w - 2 * c, h, c);
    bk.translate(0, 0, -d / 2 + c / 2);
    parts.push(bk);
    const lf = new THREE.BoxGeometry(c, h, d - 2 * c);
    lf.translate(w / 2 - c / 2, 0, 0);
    parts.push(lf);
    const rt = new THREE.BoxGeometry(c, h, d - 2 * c);
    rt.translate(-w / 2 + c / 2, 0, 0);
    parts.push(rt);
    const merged = mergeGeometries(
      parts.map((p) => p.toNonIndexed()),
      false,
    ) as THREE.BufferGeometry;
    parts.forEach((p) => p.dispose());
    return merged;
  });
}

export function cyl(rt: number, rb: number, h: number, seg = 10) {
  return cached(`cyl${rt}_${rb}_${h}_${seg}`, () => new THREE.CylinderGeometry(rt, rb, h, seg, 1));
}
export function sph(r: number, seg = 10) {
  return cached(`sph${r}_${seg}`, () => new THREE.SphereGeometry(r, seg, Math.max(4, seg >> 1)));
}
export function tor(r: number, t: number, seg = 14, rad = 8) {
  return cached(`tor${r}_${t}_${seg}_${rad}`, () => new THREE.TorusGeometry(r, t, rad, seg));
}
export function cone(r: number, h: number, seg = 9) {
  return cached(`cone${r}_${h}_${seg}`, () => new THREE.ConeGeometry(r, h, seg, 1));
}
export function octa(r: number) {
  return cached(`octa${r}`, () => new THREE.OctahedronGeometry(r, 0));
}
export function ico(r: number, d = 0) {
  return cached(`ico${r}_${d}`, () => new THREE.IcosahedronGeometry(r, d));
}
export function tetra(r: number) {
  return cached(`tetra${r}`, () => new THREE.TetrahedronGeometry(r, 0));
}
export function dodec(r: number) {
  return cached(`dodec${r}`, () => new THREE.DodecahedronGeometry(r, 0));
}
export function box(w: number, h: number, d: number) {
  return cached(`box${w}_${h}_${d}`, () => new THREE.BoxGeometry(w, h, d));
}

export const V = (x: number, y: number, z: number) => new THREE.Vector3(x, y, z);
