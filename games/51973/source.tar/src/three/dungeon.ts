import * as THREE from 'three';
import { Composite, box, cone, cyl, glowMat, ico, slab, sph, toonMat, tor } from './composite';
import { mulberry32 } from '../game/board';

export const AZ = THREE.MathUtils.degToRad(30);
export const EL = THREE.MathUtils.degToRad(40);
export const CAM_DIST = 90;
export const TARGET = new THREE.Vector3(0, 0.6, 0);
export const FRUSTUM = 37;

/** Board lives in world space; the dungeon shell is rotated so it reads as a stage. */
export const CELL = 1.9;
export const BOARD_Y = 1.2;
export const LEDGE_Y = 2.6;
export const LEDGE_Z = -11;

export const cellToWorld = (x: number, y: number) =>
  new THREE.Vector3((x - 3) * CELL, BOARD_Y, (y - 3) * CELL);

export const LEDGE_DIR = new THREE.Vector3(Math.cos(AZ), 0, -Math.sin(AZ));
export const LEDGE_CENTER = new THREE.Vector3(0, LEDGE_Y, LEDGE_Z);

export function slotWorld(i: number, count: number) {
  const spread = count <= 1 ? 0 : 13.5;
  const t = count <= 1 ? 0 : (i / (count - 1) - 0.5) * spread;
  return LEDGE_CENTER.clone().addScaledVector(LEDGE_DIR, t);
}

/* rack in front of the board, running along the near screen-right diagonal */
const RACK_CENTER = new THREE.Vector3(2.0, 1.75, 8.2);
const RACK_DIR = new THREE.Vector3(0.7071, 0, -0.7071);
export function rackWorld(i: number, count: number) {
  const t = (i - (count - 1) / 2) * 2.75;
  return RACK_CENTER.clone().addScaledVector(RACK_DIR, t);
}

const C = {
  stoneDark: 0x22252f,
  stone: 0x2f3442,
  stoneLit: 0x3d4354,
  stoneWarm: 0x4a4038,
  stonePale: 0x565d70,
  gold: 0xd9a24a,
  goldDark: 0x8a6526,
  cold: 0x4fb8ff,
  coldPale: 0xcdeeff,
  iron: 0x6b7285,
  rust: 0x7a4a30,
  board: 0x474e63,
  boardLit: 0x5b6480,
};

function torusArc(r: number, t: number, arc: number, seg = 16, rad = 8) {
  return new THREE.TorusGeometry(r, t, rad, seg, arc);
}

export interface DungeonRefs {
  root: THREE.Group;
  stage: THREE.Group;
  flames: THREE.Object3D[];
  torches: THREE.PointLight[];
  coldLight: THREE.PointLight;
  boardLight: THREE.PointLight;
}

/* ------------------------------------------------------------------ pieces */

function buildFloor(c: Composite, rnd: () => number) {
  const heights = [0.5, 0.62, 0.74];
  for (let gx = -8; gx <= 8; gx++) {
    for (let gz = -5; gz <= 6; gz++) {
      const x = gx * 4.6 + (rnd() - 0.5) * 0.3;
      const z = gz * 4.6 + (rnd() - 0.5) * 0.3;
      const h = heights[Math.floor(rnd() * 3)];
      const shade = rnd();
      const col = shade > 0.86 ? C.stoneLit : shade > 0.55 ? C.stone : C.stoneDark;
      c.add(slab(4.3, h, 4.3, 0.16), col, [x, h / 2 - 0.28, z], [0, (rnd() - 0.5) * 0.05, 0]);
      if (rnd() > 0.9) {
        c.add(ico(0.42, 0), C.stonePale, [x + (rnd() - 0.5) * 3, 0.05, z + (rnd() - 0.5) * 3]);
      }
    }
  }
  // rubble + broken chain piles
  for (let i = 0; i < 26; i++) {
    const a = rnd() * Math.PI * 2;
    const r = 12 + rnd() * 24;
    const x = Math.cos(a) * r;
    const z = Math.sin(a) * r * 0.7 + 2;
    c.add(ico(0.35 + rnd() * 0.55, 0), rnd() > 0.5 ? C.stone : C.stoneDark, [x, 0.12, z], [rnd(), rnd(), rnd()]);
  }
}

function buildPillar(c: Composite, x: number, z: number, h: number, r: number) {
  c.add(slab(r * 2.9, 0.7, r * 2.9, 0.14), C.stoneDark, [x, 0.35, z]);
  c.add(slab(r * 2.5, 0.5, r * 2.5, 0.12), C.stone, [x, 0.9, z]);
  c.add(cyl(r * 0.92, r, h, 12), C.stone, [x, h / 2 + 1.1, z]);
  for (let i = 0; i < 8; i++) {
    const a = (i / 8) * Math.PI * 2;
    c.add(cyl(0.16, 0.16, h - 0.6, 6), C.stoneDark, [x + Math.cos(a) * r * 0.92, h / 2 + 1.1, z + Math.sin(a) * r * 0.92]);
  }
  for (let i = 0; i < 3; i++) {
    c.add(tor(r * 1.02, 0.14, 14, 8), C.stoneLit, [x, 2.4 + i * (h / 3.2), z], [Math.PI / 2, 0, 0]);
  }
  c.add(slab(r * 2.6, 0.6, r * 2.6, 0.14), C.stoneLit, [x, h + 1.4, z]);
  c.add(slab(r * 3.1, 0.8, r * 3.1, 0.18), C.stoneDark, [x, h + 2.05, z]);
  c.add(cone(r * 1.1, 1.4, 10), C.stonePale, [x, h + 3.0, z]);
}

function buildArch(c: Composite, x: number, z: number, w: number, h: number) {
  const pw = w * 0.24;
  for (const s of [-1, 1]) {
    c.add(slab(pw * 1.5, 0.6, pw * 1.5, 0.12), C.stoneDark, [x + s * (w / 2), 0.3, z]);
    c.add(cyl(pw * 0.42, pw * 0.5, h, 10), C.stone, [x + s * (w / 2), h / 2 + 0.6, z]);
    c.add(slab(pw * 1.3, 0.5, pw * 1.3, 0.1), C.stoneLit, [x + s * (w / 2), h + 0.85, z]);
  }
  c.add(torusArc(w / 2, pw * 0.42, Math.PI, 18, 8), C.stone, [x, h + 1.1, z], [0, 0, 0]);
  c.add(torusArc(w / 2 + pw * 0.5, 0.16, Math.PI, 18, 6), C.stoneDark, [x, h + 1.1, z]);
  c.add(slab(w * 0.9, 0.7, pw * 1.2, 0.12), C.stoneLit, [x, h + 1.1 + w / 2, z]);
  // dark recess behind the arch
  c.add(box(w * 0.86, h * 0.92, 0.4), 0x0b0d14, [x, h * 0.46 + 0.6, z - 0.75]);
  c.add(cone(w * 0.2, h * 0.3, 8), 0x101522, [x, h * 0.2, z - 0.5]);
}

function buildWall(c: Composite) {
  c.add(slab(80, 34, 3.2, 0.3), C.stoneDark, [0, 17, -17.5]);
  for (let i = -7; i <= 7; i++) {
    c.add(slab(1.5, 30, 1.1, 0.16), C.stone, [i * 5.6, 15, -15.6]);
    c.add(slab(2.4, 0.7, 1.6, 0.14), C.stoneLit, [i * 5.6, 30.2, -15.4]);
  }
  c.add(slab(80, 1.6, 4.6, 0.2), C.stoneLit, [0, 31.4, -16.6]);
  c.add(slab(80, 1.1, 5.4, 0.18), C.stoneDark, [0, 32.6, -16.4]);
  for (let i = -6; i <= 6; i++) {
    c.add(cone(0.5, 1.3, 7), C.stonePale, [i * 5.6, 33.9, -16.4]);
  }
  // side walls
  for (const s of [-1, 1]) {
    c.add(slab(3.2, 34, 46, 0.3), C.stoneDark, [s * 38, 17, 4]);
    for (let i = 0; i < 6; i++) c.add(slab(1.3, 28, 1.2, 0.14), C.stone, [s * 36.2, 14, -12 + i * 6.5]);
  }
}

function buildFurnace(c: Composite) {
  const z = -30;
  c.add(slab(30, 3, 16, 0.4), C.stoneDark, [0, 1.5, z]);
  c.add(slab(24, 2.2, 12, 0.3), C.stone, [0, 3.6, z]);
  c.add(cyl(9.5, 11.5, 17, 16), C.stone, [0, 12.6, z]);
  for (let i = 0; i < 4; i++) {
    c.add(tor(10.2 - i * 0.35, 0.5, 20, 8), C.stoneDark, [0, 6 + i * 4.2, z], [Math.PI / 2, 0, 0]);
  }
  for (let i = 0; i < 16; i++) {
    const a = (i / 16) * Math.PI * 2;
    c.add(cyl(0.55, 0.7, 16, 6), C.stoneDark, [Math.cos(a) * 10.3, 12.6, z + Math.sin(a) * 10.3]);
  }
  // cold mouth
  c.add(slab(9, 7.5, 1.6, 0.3), 0x0a1420, [0, 7.2, z + 10.4]);
  c.add(box(7.4, 5.6, 0.7), 0x123a5c, [0, 7.2, z + 11.1]);
  c.add(sph(2.5, 12), 0x9fe4ff, [0, 7.2, z + 11.4]);
  c.add(tor(4.6, 0.55, 18, 8), C.iron, [0, 7.2, z + 11.2]);
  // chimney
  c.add(cyl(4.6, 6.6, 15, 14), C.stone, [0, 26.5, z]);
  c.add(tor(5.4, 0.6, 18, 8), C.stoneDark, [0, 20, z], [Math.PI / 2, 0, 0]);
  c.add(tor(4.9, 0.5, 18, 8), C.stoneDark, [0, 31, z], [Math.PI / 2, 0, 0]);
  c.add(cyl(7.4, 4.6, 3.4, 14), C.stoneLit, [0, 35.6, z]);
  c.add(cone(7.2, 3.2, 14), C.stoneDark, [0, 38.4, z]);
  for (let i = 0; i < 8; i++) {
    const a = (i / 8) * Math.PI * 2;
    c.add(cyl(0.4, 0.4, 3.2, 6), C.iron, [Math.cos(a) * 6.6, 36.4, z + Math.sin(a) * 6.6]);
  }
  // flanking pipes
  for (const s of [-1, 1]) {
    c.add(cyl(1.1, 1.1, 24, 10), C.iron, [s * 13.5, 12, z + 2]);
    c.add(tor(1.5, 0.35, 12, 8), C.rust, [s * 13.5, 8, z + 2], [Math.PI / 2, 0, 0]);
    c.add(tor(1.5, 0.35, 12, 8), C.rust, [s * 13.5, 18, z + 2], [Math.PI / 2, 0, 0]);
    c.add(sph(1.5, 10), C.rust, [s * 13.5, 24.4, z + 2]);
    c.add(cyl(1.1, 1.1, 12, 10), C.iron, [s * 11, 24, z + 7], [0, 0, Math.PI / 2.4]);
  }
}

function buildLedge(c: Composite) {
  const z = LEDGE_Z;
  c.add(slab(40, LEDGE_Y, 6.4, 0.22), C.stone, [0, LEDGE_Y / 2, z]);
  c.add(slab(41.4, 0.55, 7.6, 0.16), C.stoneLit, [0, LEDGE_Y + 0.1, z]);
  c.add(slab(41.4, 0.4, 0.7, 0.12), C.stoneDark, [0, LEDGE_Y + 0.5, z + 3.4]);
  for (let i = -9; i <= 9; i++) {
    c.add(cyl(0.22, 0.3, 1.1, 7), C.iron, [i * 2.1, LEDGE_Y + 1.05, z + 3.3]);
    if (i % 3 === 0) c.add(sph(0.34, 8), C.gold, [i * 2.1, LEDGE_Y + 1.7, z + 3.3]);
  }
  c.add(cyl(0.16, 0.16, 38, 6), C.rust, [0, LEDGE_Y + 1.6, z + 3.3], [0, 0, Math.PI / 2]);
  for (let i = -4; i <= 4; i++) {
    c.add(cyl(0.8, 1.1, LEDGE_Y, 8), C.stoneDark, [i * 4.6, LEDGE_Y / 2 - 0.1, z - 2.4]);
  }
  // braziers flanking the ledge
  for (const s of [-1, 1]) {
    c.add(cyl(1.1, 1.5, 1.2, 10), C.iron, [s * 17.5, LEDGE_Y + 0.6, z + 1.2]);
    c.add(tor(1.2, 0.22, 12, 8), C.rust, [s * 17.5, LEDGE_Y + 1.15, z + 1.2], [Math.PI / 2, 0, 0]);
  }
}

function buildChain(c: Composite, x: number, z: number, top: number, links: number, len: number) {
  c.add(sph(0.5, 8), C.iron, [x, top, z]);
  for (let i = 0; i < links; i++) {
    const y = top - (i + 1) * len;
    c.add(tor(0.3, 0.09, 10, 6), C.iron, [x, y, z], i % 2 === 0 ? [Math.PI / 2, 0, 0] : [0, Math.PI / 2, 0]);
  }
  const yb = top - links * len - 0.5;
  c.add(cyl(0.12, 0.12, 1.4, 6), C.rust, [x, yb, z]);
  c.add(tor(0.42, 0.12, 12, 6), C.rust, [x, yb - 0.9, z], [0, 0, 0]);
  c.add(cone(0.42, 0.9, 8), C.rust, [x, yb - 1.5, z], [Math.PI, 0, 0]);
}

/* -------------------------------------------------------------------- build */

export function buildDungeon(): DungeonRefs {
  const rnd = mulberry32(20260214);
  const root = new THREE.Group();
  const stage = new THREE.Group();
  stage.rotation.y = AZ;
  root.add(stage);

  const shell = new Composite();
  buildFloor(shell, rnd);
  buildWall(shell);
  for (const x of [-27, -18, -9, 0, 9, 18, 27]) buildArch(shell, x, -14.2, 5.4, 8.5);
  buildFurnace(shell);
  buildLedge(shell);
  buildPillar(shell, -21, 15, 26, 2.0);
  buildPillar(shell, 21, 15, 26, 2.0);
  buildPillar(shell, -31, 20, 30, 2.4);
  buildPillar(shell, 31, 20, 30, 2.4);
  buildPillar(shell, -26, -8, 24, 1.7);
  buildPillar(shell, 26, -8, 24, 1.7);
  buildChain(shell, -17.5, 12, 27, 15, 0.62);
  buildChain(shell, -11.5, 12, 27, 12, 0.62);
  buildChain(shell, 11.5, 12, 27, 13, 0.62);
  buildChain(shell, 17.5, 12, 27, 16, 0.62);
  // ceiling beams
  for (let i = -3; i <= 3; i++) {
    shell.add(slab(74, 1.4, 2.2, 0.2), C.stoneDark, [0, 27.5, i * 7 - 2]);
    shell.add(slab(74, 0.8, 1.2, 0.14), C.stone, [0, 28.6, i * 7 - 2]);
  }
  const shellGroup = shell.build(0.055);
  stage.add(shellGroup);

  // cold furnace glow panel (unlit, additive-ish)
  const glow = new THREE.Mesh(sph(3.4, 14), glowMat(0x8fdcff, 0.5));
  glow.position.set(0, 7.2, -18.4);
  stage.add(glow);
  const glow2 = new THREE.Mesh(sph(1.6, 12), glowMat(0xe6f8ff, 0.85));
  glow2.position.set(0, 7.2, -18.2);
  stage.add(glow2);

  /* torches */
  const flames: THREE.Object3D[] = [];
  const torches: THREE.PointLight[] = [];
  const torchSpots: [number, number, number, number][] = [
    [-21, 9.5, -14.6, 1],
    [-7, 9.5, -14.6, 1],
    [7, 9.5, -14.6, 1],
    [21, 9.5, -14.6, 1],
    [-17.5, LEDGE_Y + 1.4, LEDGE_Z + 1.2, 0.85],
    [17.5, LEDGE_Y + 1.4, LEDGE_Z + 1.2, 0.85],
    [-33, 12, -4, 0.8],
    [33, 12, -4, 0.8],
  ];
  const flameMat = toonMat({ emissive: 0xff8a2a, emissiveIntensity: 1.6, steps: [180, 240, 255] });
  const flameCore = glowMat(0xffd9a0, 0.9);
  for (const [x, y, z, s] of torchSpots) {
    const bc = new Composite();
    bc.add(cyl(0.16, 0.2, 1.6, 6), C.rust, [0, -0.8, 0]);
    bc.add(cyl(0.75, 0.42, 0.7, 9), C.iron, [0, 0.1, 0]);
    bc.add(tor(0.72, 0.14, 12, 6), C.rust, [0, 0.4, 0], [Math.PI / 2, 0, 0]);
    const bowl = bc.build(0.04);
    bowl.position.set(x, y, z);
    stage.add(bowl);

    const fc = new Composite();
    fc.add(cone(0.55 * s, 1.9 * s, 7), 0xff6a1e, [0, 0.85 * s, 0]);
    fc.add(cone(0.3 * s, 1.1 * s, 6), 0xffc247, [0, 1.15 * s, 0]);
    const fl = fc.build(0.035, flameMat);
    fl.position.set(x, y + 0.3, z);
    stage.add(fl);
    flames.push(fl);

    const core = new THREE.Mesh(sph(0.34 * s, 8), flameCore);
    core.position.set(x, y + 0.75 * s, z);
    stage.add(core);
    flames.push(core);

    const pl = new THREE.PointLight(0xff8a34, 2.4 * s, 34, 2);
    pl.position.set(x, y + 1.4, z);
    stage.add(pl);
    torches.push(pl);
  }

  const coldLight = new THREE.PointLight(0x62c8ff, 3.2, 60, 2);
  coldLight.position.set(0, 8, -17);
  stage.add(coldLight);

  const boardLight = new THREE.PointLight(0xffd9a8, 2.6, 30, 2);
  boardLight.position.set(0, 9, 0);

  return { root, stage, flames, torches, coldLight, boardLight };
}

/* ------------------------------------------------------- board dais + rack */

export function buildDais(): THREE.Group {
  const g = new THREE.Group();
  const c = new Composite();
  const half = 3 * CELL + CELL / 2 + 0.55;
  c.add(slab(half * 2 + 1.6, 0.9, half * 2 + 1.6, 0.22), C.stoneDark, [0, 0.45, 0]);
  c.add(slab(half * 2 + 0.7, 0.5, half * 2 + 0.7, 0.18), C.stone, [0, 1.0, 0]);
  c.add(slab(half * 2, 0.36, half * 2, 0.14), C.boardLit, [0, BOARD_Y - 0.16, 0]);
  // rim posts
  for (const sx of [-1, 1]) {
    for (const sz of [-1, 1]) {
      c.add(slab(1.5, 1.5, 1.5, 0.2), C.stoneLit, [sx * (half + 0.35), 0.75, sz * (half + 0.35)]);
      c.add(cone(0.85, 1.1, 8), C.gold, [sx * (half + 0.35), 1.95, sz * (half + 0.35)]);
      c.add(sph(0.3, 8), C.goldDark, [sx * (half + 0.35), 2.6, sz * (half + 0.35)]);
    }
  }
  for (const s of [-1, 1]) {
    c.add(slab(half * 2 + 1.2, 0.34, 0.5, 0.1), C.goldDark, [0, 1.3, s * (half + 0.5)]);
    c.add(slab(0.5, 0.34, half * 2 + 1.2, 0.1), C.goldDark, [s * (half + 0.5), 1.3, 0]);
  }
  g.add(c.build(0.05));

  // inlay diamond on the board surface
  const ic = new Composite();
  for (let i = 0; i < 4; i++) {
    const a = (i / 4) * Math.PI * 2 + Math.PI / 4;
    ic.add(slab(0.5, 0.06, half * 1.5, 0.02), C.board, [Math.cos(a) * 0.02, 0.03, Math.sin(a) * 0.02], [0, a, 0]);
  }
  ic.add(tor(half * 0.72, 0.07, 26, 6), C.board, [0, 0.04, 0], [Math.PI / 2, 0, 0]);
  const inlay = ic.build(0.02);
  inlay.position.y = BOARD_Y - 0.02;
  g.add(inlay);
  return g;
}

export function buildRack(count: number): THREE.Group {
  const g = new THREE.Group();
  const c = new Composite();
  const span = (count - 1) * 2.75 + 3.4;
  const dir = RACK_DIR.clone().normalize();
  const perp = new THREE.Vector3(0, 0, 0);
  for (let i = 0; i < count; i++) {
    const p = rackWorld(i, count);
    c.add(slab(2.5, 0.4, 2.5, 0.1), C.stone, [p.x, 1.5, p.z], [0, Math.atan2(dir.x, dir.z), 0]);
    c.add(cyl(0.22, 0.28, 1.5, 8), C.iron, [p.x, 0.75, p.z]);
    c.add(cyl(0.3, 0.3, 0.3, 8), C.goldDark, [p.x, 1.72, p.z]);
    perp.set(0, 0, 0);
  }
  const mid = rackWorld((count - 1) / 2, count);
  c.add(slab(span, 0.5, 1.6, 0.14), C.stoneDark, [mid.x, 0.25, mid.z], [0, Math.atan2(dir.x, dir.z), 0]);
  g.add(c.build(0.05));
  return g;
}
