import { useEffect } from "react";
import type { GameState, Toast } from "@/game/types";
import { MAX_DAY } from "@/game/engine";

const TONE: Record<Toast["tone"], { color: string; glyph: string }> = {
  gain: { color: "#74b3a6", glyph: "▲" },
  cost: { color: "#8d9aa3", glyph: "▼" },
  love: { color: "#d98a9c", glyph: "♥" },
  warn: { color: "#e6ac63", glyph: "!" },
};

export function Toasts({
  toasts,
  onDone,
}: {
  toasts: Toast[];
  onDone: (id: number) => void;
}) {
  return (
    <div className="pointer-events-none absolute right-4 top-4 z-40 flex w-[212px] flex-col gap-1.5">
      {toasts.slice(-6).map((t) => {
        const tone = TONE[t.tone];
        return (
          <div
            key={t.id}
            className="anim-toast panel relative flex items-center gap-2 rounded-lg px-2.5 py-1.5"
            onAnimationEnd={() => onDone(t.id)}
          >
            <span
              className="grid h-4 w-4 shrink-0 place-items-center rounded-full text-[8px]"
              style={{ background: `${tone.color}26`, color: tone.color }}
              aria-hidden
            >
              {tone.glyph}
            </span>
            <span className="truncate text-[11.5px]" style={{ color: `${tone.color}e6` }}>
              {t.text}
            </span>
          </div>
        );
      })}
    </div>
  );
}

export function DawnVeil({ show, day }: { show: boolean; day: number }) {
  return (
    <div
      className="pointer-events-none absolute inset-0 z-50 flex items-center justify-center transition-opacity duration-700"
      style={{
        opacity: show ? 1 : 0,
        background: "radial-gradient(120% 90% at 50% 50%, rgba(230,172,99,0.16), rgba(8,6,5,0.94))",
      }}
    >
      <div
        className="anim-fade text-center"
        style={{ opacity: show ? 1 : 0, transition: "opacity 400ms ease 200ms" }}
      >
        <div className="text-[10px] uppercase tracking-wider-xs text-brass/70">
          {day >= MAX_DAY ? "The last day" : "Dawn"}
        </div>
        <div className="display mt-2 text-[clamp(2.2rem,6vw,4rem)] font-medium leading-none text-parchment">
          Day {day}
        </div>
        <div className="mt-2 text-[11px] text-parchment/45">
          {day >= MAX_DAY ? "Twenty-eight days are up" : `${MAX_DAY - day} days left`}
        </div>
      </div>
    </div>
  );
}

export function Journal({
  state,
  onClose,
}: {
  state: GameState;
  onClose: () => void;
}) {
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  const entries = [...state.log].reverse();

  return (
    <div className="absolute inset-0 z-50 flex items-center justify-center p-6">
      <button
        type="button"
        aria-label="Close journal"
        onClick={onClose}
        className="absolute inset-0 cursor-default bg-[#080605]/78 backdrop-blur-sm"
      />
      <div className="panel grain anim-rise relative flex max-h-full w-full max-w-[620px] flex-col rounded-2xl">
        <div className="flex items-center justify-between border-b border-parchment/10 px-5 py-4">
          <div>
            <h2 className="display text-[19px] text-parchment/95">The Journal</h2>
            <p className="text-[10px] uppercase tracking-wider-xs text-parchment/35">
              {state.log.length} entries · day {state.day}
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded-lg border border-parchment/12 px-3 py-1.5 text-[10.5px] uppercase tracking-wider-xs text-parchment/55 transition-colors hover:border-parchment/28 hover:text-parchment/85"
          >
            Close
          </button>
        </div>
        <div className="min-h-0 flex-1 space-y-1.5 overflow-y-auto px-5 py-4">
          {entries.map((e, i) => (
            <div key={i} className="flex gap-3">
              <span className="display mt-[1px] w-9 shrink-0 text-right text-[10.5px] text-parchment/30">
                {e.day}
              </span>
              <span className="border-l border-parchment/10 pl-3 text-[12.5px] leading-snug text-parchment/72">
                {e.text}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
