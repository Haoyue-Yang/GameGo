import type { GameState } from "@/game/types";
import { CHARACTERS, SKILLS } from "@/game/content";
import { MAX_DAY } from "@/game/engine";
import { prognosis, totalAffection, totalSkills } from "@/game/endings";
import Portrait from "./Portrait";

function SectionTitle({ children, right }: { children: React.ReactNode; right?: React.ReactNode }) {
  return (
    <div className="mb-2.5 flex items-center justify-between">
      <h2 className="text-[9.5px] uppercase tracking-wider-xs text-parchment/40">{children}</h2>
      {right}
    </div>
  );
}

export default function Sidebar({
  state,
  onEndDay,
  onOpenLog,
}: {
  state: GameState;
  onEndDay: () => void;
  onOpenLog: () => void;
}) {
  const prog = prognosis(state);

  return (
    <aside className="panel grain relative z-20 flex w-[232px] shrink-0 flex-col overflow-hidden border-y-0 border-l-0 xl:w-[268px]">
      <div className="flex min-h-0 flex-1 flex-col gap-5 overflow-y-auto px-4 py-4">
        {/* ---- skills ---- */}
        <section>
          <SectionTitle
            right={
              <span className="display text-[11px] text-parchment/50">{totalSkills(state)}</span>
            }
          >
            Skills
          </SectionTitle>
          <div className="space-y-2.5">
            {SKILLS.map((s) => {
              const v = state.skills[s.key];
              return (
                <div key={s.key}>
                  <div className="mb-1 flex items-baseline justify-between">
                    <span className="flex items-center gap-1.5 text-[11.5px] text-parchment/80">
                      <span style={{ color: s.color }} aria-hidden>
                        {s.glyph}
                      </span>
                      {s.name}
                    </span>
                    <span className="display text-[11.5px]" style={{ color: s.color }}>
                      {v}
                    </span>
                  </div>
                  <div className="h-[6px] overflow-hidden rounded-full bg-parchment/8">
                    <div
                      className="h-full rounded-full transition-[width] duration-500 ease-out"
                      style={{
                        width: `${v}%`,
                        background: `linear-gradient(90deg, ${s.color}66, ${s.color})`,
                        boxShadow: `0 0 10px ${s.color}55`,
                      }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </section>

        <div className="hairline" />

        {/* ---- affection ---- */}
        <section>
          <SectionTitle
            right={
              <span className="display text-[11px] text-parchment/50">{totalAffection(state)}</span>
            }
          >
            Affection
          </SectionTitle>
          <div className="space-y-2">
            {CHARACTERS.map((c) => {
              const v = state.affection[c.key];
              return (
                <div key={c.key} className="panel-soft rounded-xl p-2">
                  <div className="flex items-center gap-2.5">
                    <div
                      className="h-11 w-11 shrink-0 overflow-hidden rounded-lg"
                      style={{ boxShadow: `0 0 0 1px ${c.accent}55` }}
                    >
                      <Portrait char={c.key} className="h-full w-full" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-baseline justify-between gap-2">
                        <span className="display truncate text-[13px]" style={{ color: c.accent }}>
                          {c.full}
                        </span>
                        <span className="display shrink-0 text-[11px] text-parchment/55">{v}</span>
                      </div>
                      <div className="mt-1 h-[5px] overflow-hidden rounded-full bg-parchment/10">
                        <div
                          className="h-full rounded-full transition-[width] duration-500 ease-out"
                          style={{
                            width: `${v}%`,
                            background: `linear-gradient(90deg, ${c.accent}66, ${c.accent})`,
                            boxShadow: `0 0 10px ${c.accent}55`,
                          }}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </section>

        <div className="hairline" />

        {/* ---- prognosis ---- */}
        <section>
          <SectionTitle>Where the season is going</SectionTitle>
          <div className="space-y-1.5">
            {prog.map((p) => (
              <div
                key={p.id}
                className="rounded-lg px-2.5 py-2 transition-colors"
                style={{
                  background: p.met ? `${p.accent}1f` : "rgba(243,231,211,0.03)",
                  boxShadow: p.met ? `inset 0 0 0 1px ${p.accent}66` : "inset 0 0 0 1px rgba(243,231,211,0.07)",
                }}
              >
                <div className="flex items-center justify-between gap-2">
                  <span
                    className="display text-[12.5px]"
                    style={{ color: p.met ? p.accent : "rgba(243,231,211,0.72)" }}
                  >
                    {p.met ? "✦ " : ""}
                    {p.title}
                  </span>
                  <span className="text-[9.5px] uppercase tracking-wider-xs text-parchment/35">
                    {Math.round(p.progress * 100)}%
                  </span>
                </div>
                <div className="mt-0.5 text-[10px] leading-snug text-parchment/40">{p.hint}</div>
                <div className="mt-1.5 h-[3px] overflow-hidden rounded-full bg-parchment/8">
                  <div
                    className="h-full rounded-full transition-[width] duration-700 ease-out"
                    style={{ width: `${p.progress * 100}%`, background: p.accent }}
                  />
                </div>
              </div>
            ))}
          </div>
        </section>
      </div>

      {/* ---- footer ---- */}
      <div className="shrink-0 space-y-2 border-t border-parchment/10 px-4 py-3.5">
        <button
          type="button"
          onClick={onOpenLog}
          className="w-full rounded-lg border border-parchment/12 py-2 text-[10.5px] uppercase tracking-wider-xs text-parchment/55 transition-colors hover:border-parchment/25 hover:text-parchment/80"
        >
          Read the journal
        </button>
        <button
          type="button"
          onClick={onEndDay}
          className="group relative w-full overflow-hidden rounded-xl px-4 py-3 text-left transition-transform active:scale-[0.99]"
          style={{
            background: "linear-gradient(135deg,#e6ac63,#c07f38)",
            boxShadow: "0 10px 26px -12px rgba(230,172,99,0.7)",
          }}
        >
          <span className="display block text-[14px] font-semibold text-[#2a1a08]">
            {state.day >= MAX_DAY ? "Close the season" : "End the day"}
          </span>
          <span className="block text-[10px] text-[#3d260c]/80">
            {state.day >= MAX_DAY
              ? "Twenty-eight days are up"
              : state.slots > 0
                ? `${state.slots} slot${state.slots > 1 ? "s" : ""} still unspent`
                : `Dawn · +50 energy`}
          </span>
        </button>
      </div>
    </aside>
  );
}
