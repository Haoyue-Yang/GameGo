import { useEffect, useRef, useState } from "react";
import type { GameState } from "@/game/types";
import { CHAR_MAP } from "@/game/content";
import { nextScene } from "@/game/scenes";
import Portrait from "./Portrait";

function useTypewriter(text: string, ms = 16) {
  const [n, setN] = useState(0);
  const reduce = useRef(false);

  useEffect(() => {
    reduce.current =
      typeof window !== "undefined" &&
      window.matchMedia?.("(prefers-reduced-motion: reduce)").matches === true;
  }, []);

  useEffect(() => {
    if (reduce.current) {
      setN(text.length);
      return;
    }
    setN(0);
    let i = 0;
    const id = window.setInterval(() => {
      i += 2;
      setN(i);
      if (i >= text.length) window.clearInterval(id);
    }, ms);
    return () => window.clearInterval(id);
  }, [text, ms]);

  return {
    shown: text.slice(0, n),
    done: n >= text.length,
    finish: () => setN(text.length),
  };
}

export default function DialogueBox({
  state,
  onAdvance,
  onChoose,
  onClose,
}: {
  state: GameState;
  onAdvance: () => void;
  onChoose: (i: number) => void;
  onClose: () => void;
}) {
  const d = state.dialogue;
  const scene = d ? nextScene(d.char, state.affection[d.char], state.seenScenes) : null;

  // hooks must run unconditionally, so fall back to safe values first
  const charKey = d?.char ?? "mira";
  const c = CHAR_MAP[charKey];
  const line = scene && d ? scene.lines[Math.min(d.line, scene.lines.length - 1)] : null;
  const body = d && scene ? (d.stage === "reply" ? (d.reply ?? "") : (line?.text ?? "")) : "";
  const tw = useTypewriter(body);

  if (!d || !scene || !line) return null;

  const speaker =
    line.who === "you" ? "You" : line.who && line.who !== "narr" ? c.full : null;

  const click = () => {
    if (!tw.done) {
      tw.finish();
      return;
    }
    if (d.stage === "lines") onAdvance();
    else if (d.stage === "reply") onClose();
  };

  const isNarr = d.stage === "lines" && (!line.who || line.who === "narr");

  return (
    <div className="absolute inset-0 z-30 flex flex-col justify-end">
      {/* dim the town behind the conversation */}
      <div
        className="absolute inset-0"
        style={{ background: `linear-gradient(to top, ${c.accent}22, rgba(9,7,6,0.72))` }}
      />

      <div
        className="anim-slide panel grain relative cursor-pointer border-x-0 border-b-0 px-6 pb-6 pt-5 focus:outline-none focus-visible:ring-1 focus-visible:ring-brass/50"
        role="button"
        tabIndex={0}
        aria-label="Dialogue — activate to continue"
        onClick={click}
        onKeyDown={(e) => {
          if (e.key === "Enter" || e.key === " ") {
            e.preventDefault();
            click();
          }
        }}
      >
        {/* scene label */}
        <div className="mb-3 flex items-center gap-3">
          <span
            className="h-[1px] w-8"
            style={{ background: `linear-gradient(90deg, transparent, ${c.accent})` }}
          />
          <span
            className="text-[9.5px] uppercase tracking-wider-xs"
            style={{ color: `${c.accent}cc` }}
          >
            {scene.title}
          </span>
          <span className="text-[9.5px] uppercase tracking-wider-xs text-parchment/25">
            {d.stage === "choice" ? "your turn" : "click to continue"}
          </span>
        </div>

        <div className="flex gap-5">
          {/* portrait */}
          <div className="relative hidden w-[168px] shrink-0 sm:block">
            <div
              className="overflow-hidden rounded-2xl"
              style={{ boxShadow: `0 0 0 1px ${c.accent}55, 0 20px 44px -20px ${c.accent}55` }}
            >
              <Portrait char={d.char} className="h-[212px] w-full" />
            </div>
            <div
              className="mt-2 rounded-xl px-3 py-2"
              style={{ background: `${c.accent}18`, boxShadow: `inset 0 0 0 1px ${c.accent}44` }}
            >
              <div className="display text-[14px]" style={{ color: c.accent }}>
                {c.full}
              </div>
              <div className="text-[9.5px] uppercase tracking-wider-xs text-parchment/40">
                {c.role}
              </div>
              <div className="mt-1.5 flex items-center gap-2">
                <div className="h-[4px] flex-1 overflow-hidden rounded-full bg-parchment/12">
                  <div
                    className="h-full rounded-full transition-[width] duration-700 ease-out"
                    style={{
                      width: `${state.affection[d.char]}%`,
                      background: `linear-gradient(90deg, ${c.accent}66, ${c.accent})`,
                    }}
                  />
                </div>
                <span className="display text-[10.5px] text-parchment/55">
                  {state.affection[d.char]}
                </span>
              </div>
            </div>
          </div>

          {/* text */}
          <div className="min-w-0 flex-1">
            {speaker && d.stage === "lines" && (
              <div className="display mb-1.5 text-[15px]" style={{ color: c.accent }}>
                {speaker}
              </div>
            )}
            <p
              className={`min-h-[92px] text-[15.5px] leading-[1.62] ${
                isNarr ? "italic text-parchment/62" : "text-parchment/92"
              }`}
            >
              {tw.shown}
              {!tw.done && <span className="anim-caret ml-[1px] text-brass">▍</span>}
            </p>

            {d.stage === "choice" && (
              <div className="mt-3 space-y-2">
                {scene.options.map((o, i) => (
                  <button
                    key={i}
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      onChoose(i);
                    }}
                    className="group flex w-full items-center gap-3 rounded-xl px-3.5 py-2.5 text-left transition-all duration-200 hover:-translate-y-[1px]"
                    style={{
                      background: "linear-gradient(160deg, rgba(243,231,211,0.07), rgba(243,231,211,0.02))",
                      boxShadow: "inset 0 0 0 1px rgba(243,231,211,0.12)",
                    }}
                  >
                    <span
                      className="grid h-5 w-5 shrink-0 place-items-center rounded-full text-[10px] transition-colors"
                      style={{
                        background: `${c.accent}22`,
                        color: c.accent,
                        boxShadow: `inset 0 0 0 1px ${c.accent}55`,
                      }}
                    >
                      {i + 1}
                    </span>
                    <span className="text-[13.5px] leading-snug text-parchment/88 group-hover:text-parchment">
                      {o.label}
                    </span>
                    <span className="ml-auto shrink-0 text-[10px] uppercase tracking-wider-xs text-parchment/25 transition-colors group-hover:text-parchment/45">
                      choose
                    </span>
                  </button>
                ))}
              </div>
            )}

            {d.stage === "reply" && (
              <div className="mt-3 flex items-center justify-between gap-3">
                <span
                  className="display text-[12.5px]"
                  style={{ color: c.accent }}
                >
                  ♥ {c.name} +{d.gain}
                </span>
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    onClose();
                  }}
                  className="rounded-lg px-3 py-1.5 text-[10.5px] uppercase tracking-wider-xs text-parchment/60 transition-colors hover:text-parchment"
                  style={{ boxShadow: "inset 0 0 0 1px rgba(243,231,211,0.16)" }}
                >
                  Back to the town
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
