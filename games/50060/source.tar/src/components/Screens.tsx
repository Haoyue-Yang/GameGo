import type { GameState } from "@/game/types";
import { CHARACTERS, SKILLS } from "@/game/content";
import { ENDINGS, resolveEnding, totalAffection, totalSkills } from "@/game/endings";
import { BASE_SLOTS, MAX_DAY } from "@/game/engine";
import titleArt from "@/assets/title.jpg";
import Portrait from "./Portrait";

/* ------------------------------------------------------------------ TITLE */

export function TitleScreen({ onStart }: { onStart: () => void }) {
  return (
    <div className="relative h-full w-full overflow-hidden">
      <img
        src={titleArt}
        alt="A painted view of Ashgrove at dusk"
        className="absolute inset-0 h-full w-full object-cover"
      />
      <div
        className="absolute inset-0"
        style={{
          background:
            "radial-gradient(110% 80% at 30% 40%, rgba(10,8,7,0.35), rgba(8,6,5,0.9) 80%)",
        }}
      />

      <div className="grain relative flex h-full w-full items-center overflow-y-auto px-8 py-10 sm:px-14">
        <div className="anim-rise mx-auto w-full max-w-[1180px]">
          <div className="grid gap-10 lg:grid-cols-[1.15fr_0.85fr] lg:items-center">
            <div>
              <div className="mb-5 flex items-center gap-3">
                <span className="h-[1px] w-10 bg-brass/60" />
                <span className="text-[10px] uppercase tracking-wider-xs text-brass/80">
                  A flat 2D life sim
                </span>
              </div>

              <h1 className="display text-[clamp(2.6rem,6.4vw,5rem)] font-medium leading-[0.94] tracking-tight text-parchment">
                Twenty-Eight
                <br />
                Days in
                <br />
                <span className="text-brass">Ashgrove</span>
              </h1>

              <p className="mt-6 max-w-[52ch] text-[15px] leading-[1.7] text-parchment/62">
                You have three slots a day and twenty-eight days. Spend them on the stacks, the
                ring, the counter, the kiln — or on the people who are already waiting there.
                Energy and money are the only things you can trade. What you leave behind decides
                how the season ends.
              </p>

              <div className="mt-8 flex flex-wrap items-center gap-4">
                <button
                  type="button"
                  onClick={onStart}
                  className="group relative overflow-hidden rounded-xl px-7 py-3.5 transition-transform active:scale-[0.99]"
                  style={{
                    background: "linear-gradient(135deg,#e6ac63,#c07f38)",
                    boxShadow: "0 16px 40px -16px rgba(230,172,99,0.75)",
                  }}
                >
                  <span className="display text-[16px] font-semibold text-[#2a1a08]">
                    Arrive in Ashgrove
                  </span>
                  <span className="anim-sheen pointer-events-none absolute inset-0" />
                </button>
                <span className="text-[11px] uppercase tracking-wider-xs text-parchment/35">
                  {MAX_DAY} days · {BASE_SLOTS} slots each
                </span>
              </div>

              <div className="mt-10 grid max-w-[62ch] gap-2.5 sm:grid-cols-3">
                {[
                  { t: "Spend slots", d: "Click a node on the map. Each action costs one slot." },
                  { t: "Trade energy", d: "Rest, walk, or buy a tonic. Dawn returns fifty." },
                  { t: "Earn affection", d: "Talk to Mira, Kade and Juno. Choices move them." },
                ].map((x) => (
                  <div key={x.t} className="panel-soft rounded-xl p-3">
                    <div className="display text-[12.5px] text-parchment/85">{x.t}</div>
                    <div className="mt-1 text-[10.5px] leading-snug text-parchment/45">{x.d}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* cast */}
            <div className="space-y-2.5">
              <div className="mb-1 text-[10px] uppercase tracking-wider-xs text-parchment/35">
                Three people, already here
              </div>
              {CHARACTERS.map((c) => (
                <div key={c.key} className="panel grain flex items-center gap-3 rounded-2xl p-3">
                  <div
                    className="h-16 w-16 shrink-0 overflow-hidden rounded-xl"
                    style={{ boxShadow: `0 0 0 1px ${c.accent}55` }}
                  >
                    <Portrait char={c.key} className="h-full w-full" />
                  </div>
                  <div className="min-w-0">
                    <div className="display text-[15px]" style={{ color: c.accent }}>
                      {c.full}
                    </div>
                    <div className="text-[10.5px] uppercase tracking-wider-xs text-parchment/35">
                      {c.role}
                    </div>
                    <div className="mt-1 text-[11px] leading-snug text-parchment/55">{c.likes}</div>
                  </div>
                </div>
              ))}
              <div className="pt-2">
                <div className="mb-1.5 text-[10px] uppercase tracking-wider-xs text-parchment/35">
                  Four ways this ends
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {ENDINGS.map((e) => (
                    <span
                      key={e.id}
                      className="rounded-full px-2.5 py-1 text-[10.5px]"
                      style={{
                        background: `${e.accent}18`,
                        color: e.accent,
                        boxShadow: `inset 0 0 0 1px ${e.accent}44`,
                      }}
                    >
                      {e.title}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ----------------------------------------------------------------- ENDING */

export function EndingScreen({
  state,
  onRestart,
}: {
  state: GameState;
  onRestart: () => void;
}) {
  const ending = resolveEnding(state);
  const checks = ending.checks(state);
  const others = ENDINGS.filter((e) => e.id !== ending.id);

  return (
    <div className="relative h-full w-full overflow-hidden">
      <img
        src={titleArt}
        alt=""
        className="absolute inset-0 h-full w-full object-cover"
        style={{ filter: "saturate(0.7) brightness(0.7)" }}
      />
      <div
        className="absolute inset-0"
        style={{
          background: `radial-gradient(110% 80% at 50% 30%, ${ending.accent}22, rgba(8,6,5,0.92) 72%)`,
        }}
      />

      <div className="grain relative h-full w-full overflow-y-auto px-8 py-12 sm:px-14">
        <div className="anim-rise mx-auto max-w-[980px]">
          <div className="mb-4 flex items-center gap-3">
            <span className="h-[1px] w-10" style={{ background: `${ending.accent}99` }} />
            <span
              className="text-[10px] uppercase tracking-wider-xs"
              style={{ color: `${ending.accent}cc` }}
            >
              Ending {ending.priority} of 4 · Day {MAX_DAY}
            </span>
          </div>

          <h1
            className="display text-[clamp(2.4rem,6vw,4.4rem)] font-medium leading-[0.96] tracking-tight"
            style={{ color: ending.accent }}
          >
            {ending.title}
          </h1>
          <p className="display mt-3 text-[20px] italic text-parchment/70">{ending.tagline}</p>

          <div className="mt-8 space-y-4">
            {ending.body.map((p, i) => (
              <p
                key={i}
                className="max-w-[68ch] text-[15px] leading-[1.75] text-parchment/72"
                style={{ animationDelay: `${i * 90}ms` }}
              >
                {p}
              </p>
            ))}
          </div>

          <div className="mt-10 grid gap-4 lg:grid-cols-2">
            {/* scorecard */}
            <div className="panel grain rounded-2xl p-5">
              <h2 className="mb-3 text-[10px] uppercase tracking-wider-xs text-parchment/40">
                How this was decided
              </h2>
              <div className="space-y-2">
                {checks.map((c) => (
                  <div key={c.label} className="flex items-center justify-between gap-3">
                    <span className="text-[12.5px] text-parchment/72">{c.label}</span>
                    <span
                      className="display shrink-0 text-[12.5px]"
                      style={{ color: c.met ? ending.accent : "rgba(243,231,211,0.4)" }}
                    >
                      {c.met ? "✓ " : "· "}
                      {c.value}
                    </span>
                  </div>
                ))}
              </div>
              <div className="hairline my-4" />
              <h3 className="mb-2 text-[10px] uppercase tracking-wider-xs text-parchment/35">
                Endings you didn't reach
              </h3>
              <div className="space-y-1.5">
                {others.map((e) => (
                  <div key={e.id} className="flex items-center justify-between gap-3">
                    <span className="display text-[12.5px] text-parchment/45">{e.title}</span>
                    <span className="text-[10.5px] text-parchment/28">{e.tagline}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* final ledger */}
            <div className="panel grain rounded-2xl p-5">
              <h2 className="mb-3 text-[10px] uppercase tracking-wider-xs text-parchment/40">
                The final ledger
              </h2>
              <div className="grid grid-cols-2 gap-x-5 gap-y-2.5">
                {SKILLS.map((s) => (
                  <div key={s.key}>
                    <div className="mb-1 flex items-baseline justify-between">
                      <span className="text-[11.5px] text-parchment/65">{s.name}</span>
                      <span className="display text-[12px]" style={{ color: s.color }}>
                        {state.skills[s.key]}
                      </span>
                    </div>
                    <div className="h-[5px] overflow-hidden rounded-full bg-parchment/8">
                      <div
                        className="h-full rounded-full"
                        style={{
                          width: `${state.skills[s.key]}%`,
                          background: `linear-gradient(90deg, ${s.color}66, ${s.color})`,
                        }}
                      />
                    </div>
                  </div>
                ))}
                {CHARACTERS.map((c) => (
                  <div key={c.key}>
                    <div className="mb-1 flex items-baseline justify-between">
                      <span className="text-[11.5px] text-parchment/65">{c.name}</span>
                      <span className="display text-[12px]" style={{ color: c.accent }}>
                        {state.affection[c.key]}
                      </span>
                    </div>
                    <div className="h-[5px] overflow-hidden rounded-full bg-parchment/8">
                      <div
                        className="h-full rounded-full"
                        style={{
                          width: `${state.affection[c.key]}%`,
                          background: `linear-gradient(90deg, ${c.accent}66, ${c.accent})`,
                        }}
                      />
                    </div>
                  </div>
                ))}
              </div>
              <div className="hairline my-4" />
              <div className="grid grid-cols-3 gap-3 text-center">
                {[
                  { l: "Skills", v: totalSkills(state) },
                  { l: "Affection", v: totalAffection(state) },
                  { l: "Money", v: state.money },
                ].map((x) => (
                  <div key={x.l} className="panel-soft rounded-xl py-2.5">
                    <div className="display text-[19px] text-parchment/90">{x.v}</div>
                    <div className="text-[9.5px] uppercase tracking-wider-xs text-parchment/40">
                      {x.l}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="mt-9 flex flex-wrap items-center gap-4 pb-4">
            <button
              type="button"
              onClick={onRestart}
              className="rounded-xl px-6 py-3 transition-transform active:scale-[0.99]"
              style={{
                background: "linear-gradient(135deg,#e6ac63,#c07f38)",
                boxShadow: "0 16px 40px -16px rgba(230,172,99,0.7)",
              }}
            >
              <span className="display text-[15px] font-semibold text-[#2a1a08]">
                Live the season again
              </span>
            </button>
            <span className="text-[11px] text-parchment/35">
              Every ending is reachable in one run. Spend the slots differently.
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
