import type { CharKey, GameState } from "@/game/types";
import { NODES } from "@/game/content";
import { nextScene } from "@/game/scenes";
import mapTown from "@/assets/map-town.jpg";

const GRADES = [
  { name: "Morning", tint: "rgba(96,146,196,0.18)", warm: "rgba(255,236,200,0.05)" },
  { name: "Afternoon", tint: "rgba(255,206,132,0.12)", warm: "rgba(255,244,214,0.07)" },
  { name: "Evening", tint: "rgba(226,132,58,0.2)", warm: "rgba(255,196,120,0.09)" },
  { name: "Night", tint: "rgba(26,36,84,0.36)", warm: "rgba(120,150,220,0.08)" },
];

const MOTES = [
  { x: 22, y: 30, s: 3, d: 0 },
  { x: 38, y: 18, s: 2, d: 1.4 },
  { x: 55, y: 38, s: 2.5, d: 2.6 },
  { x: 71, y: 24, s: 2, d: 0.8 },
  { x: 84, y: 52, s: 3, d: 3.4 },
  { x: 12, y: 62, s: 2, d: 2 },
  { x: 46, y: 74, s: 2.5, d: 4.2 },
  { x: 63, y: 82, s: 2, d: 1.1 },
];

export default function MapLayer({
  state,
  onSelect,
}: {
  state: GameState;
  onSelect: (id: string) => void;
}) {
  const used = state.slotsToday - state.slots;
  const grade = GRADES[Math.min(GRADES.length - 1, used)];

  return (
    <div className="relative min-w-0 flex-1 overflow-hidden bg-[#0b0908]">
      {/* painted backdrop — fixed camera, never moves */}
      <img
        src={mapTown}
        alt="A painted view of the town of Ashgrove at golden hour"
        className="absolute inset-0 h-full w-full object-cover"
        draggable={false}
      />

      {/* time-of-day grade */}
      <div
        className="pointer-events-none absolute inset-0 transition-colors duration-1000"
        style={{ background: grade.tint, mixBlendMode: "soft-light" }}
      />
      <div
        className="pointer-events-none absolute inset-0 transition-colors duration-1000"
        style={{ background: grade.warm, mixBlendMode: "overlay" }}
      />
      {/* vignette + edge falloff so the UI reads */}
      <div
        className="pointer-events-none absolute inset-0"
        style={{
          background:
            "radial-gradient(120% 90% at 50% 42%, transparent 30%, rgba(10,8,7,0.55) 78%, rgba(8,6,5,0.86) 100%)",
        }}
      />
      <div
        className="pointer-events-none absolute inset-x-0 bottom-0 h-1/2"
        style={{ background: "linear-gradient(to top, rgba(9,7,6,0.9), transparent)" }}
      />

      {/* drifting motes */}
      {MOTES.map((m, i) => (
        <span
          key={i}
          className="anim-drift pointer-events-none absolute rounded-full bg-parchment/45"
          style={{
            left: `${m.x}%`,
            top: `${m.y}%`,
            width: m.s,
            height: m.s,
            animationDelay: `${m.d}s`,
            filter: "blur(0.4px)",
          }}
        />
      ))}

      {/* corner caption */}
      <div className="pointer-events-none absolute left-5 top-4 z-10 select-none">
        <div className="display text-[13px] tracking-wide text-parchment/70">Ashgrove</div>
        <div className="text-[9px] uppercase tracking-wider-xs text-parchment/35">
          {grade.name} · fixed view
        </div>
      </div>

      {/* idle prompt */}
      {!state.selected && (
        <div className="pointer-events-none absolute inset-x-0 top-[38%] z-10 flex flex-col items-center gap-1.5 px-8 text-center">
          <div
            className="anim-fade display rounded-full px-4 py-1.5 text-[13px] text-parchment/80"
            style={{
              background: "rgba(12,9,8,0.62)",
              boxShadow: "inset 0 0 0 1px rgba(243,231,211,0.14)",
              backdropFilter: "blur(8px)",
            }}
          >
            {state.slots > 0
              ? "Click a place to spend a slot"
              : "The day is spent — end it from the sidebar"}
          </div>
          <div className="text-[9.5px] uppercase tracking-wider-xs text-parchment/30">
            {state.slots > 0 ? "eight places · three slots" : "dawn returns fifty energy"}
          </div>
        </div>
      )}

      {/* map nodes */}
      {NODES.map((n) => {
        const selected = state.selected === n.id;
        const charScene = n.actions.some((a) => {
          if (!a.scene) return false;
          const key = a.scene as CharKey;
          return !!nextScene(key, state.affection[key], state.seenScenes);
        });
        const dim = state.slots <= 0;

        return (
          <button
            key={n.id}
            type="button"
            onClick={() => onSelect(n.id)}
            aria-pressed={selected}
            className="group absolute z-10 -translate-x-1/2 -translate-y-1/2 focus:outline-none"
            style={{ left: `${n.x}%`, top: `${n.y}%` }}
          >
            {/* halo */}
            <span
              className={`anim-halo pointer-events-none absolute left-1/2 top-1/2 h-16 w-16 -translate-x-1/2 -translate-y-1/2 rounded-full ${
                selected ? "opacity-100" : "opacity-0 group-hover:opacity-100"
              }`}
              style={{ background: `radial-gradient(circle, ${n.tint}55, transparent 68%)` }}
            />
            <span className="relative flex flex-col items-center">
              <span
                className={`grid h-10 w-10 place-items-center rounded-full text-[15px] transition-all duration-300 group-hover:scale-110 ${
                  dim ? "opacity-55" : "opacity-100"
                } ${selected ? "scale-110" : ""}`}
                style={{
                  background: selected
                    ? `linear-gradient(140deg, ${n.tint}, ${n.tint}bb)`
                    : "linear-gradient(140deg, rgba(20,16,14,0.9), rgba(20,16,14,0.68))",
                  color: selected ? "#1a120a" : n.tint,
                  boxShadow: selected
                    ? `0 0 22px ${n.tint}88, inset 0 0 0 1px ${n.tint}`
                    : "0 6px 18px -6px rgba(0,0,0,0.8), inset 0 0 0 1px rgba(243,231,211,0.18)",
                }}
              >
                {n.glyph}
              </span>

              {/* label plate */}
              <span
                className={`mt-1.5 whitespace-nowrap rounded-md px-2 py-[3px] text-[10.5px] transition-all duration-300 ${
                  selected ? "opacity-100" : "opacity-80 group-hover:opacity-100"
                }`}
                style={{
                  background: selected ? `${n.tint}f0` : "rgba(14,11,10,0.82)",
                  color: selected ? "#1a120a" : "rgba(243,231,211,0.9)",
                  boxShadow: "0 4px 14px -6px rgba(0,0,0,0.9)",
                  backdropFilter: "blur(6px)",
                }}
              >
                {n.name}
              </span>

              {/* new conversation badge */}
              {charScene && !selected && (
                <span
                  className="absolute -right-1.5 -top-1.5 grid h-4 w-4 place-items-center rounded-full text-[9px]"
                  style={{ background: "#d98a9c", color: "#2a1216", boxShadow: "0 0 10px #d98a9caa" }}
                >
                  ♥
                </span>
              )}
            </span>
          </button>
        );
      })}
    </div>
  );
}
