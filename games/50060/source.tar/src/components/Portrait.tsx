import type { CharKey } from "@/game/types";

interface Palette {
  bg: [string, string];
  halo: string;
  skin: string;
  shade: string;
  hair: string;
  hairShade: string;
  coat: string;
  coatShade: string;
  inner: string;
}

const PALETTES: Record<CharKey, Palette> = {
  mira: {
    bg: ["#2f5254", "#17292b"],
    halo: "#4b7d7b",
    skin: "#c99a72",
    shade: "#ab7d57",
    hair: "#33251f",
    hairShade: "#221813",
    coat: "#3a3f47",
    coatShade: "#2a2e35",
    inner: "#efe3cd",
  },
  kade: {
    bg: ["#8f4c25", "#4e2712"],
    halo: "#b8703a",
    skin: "#7d4c2e",
    shade: "#653a22",
    hair: "#1c1715",
    hairShade: "#100d0c",
    coat: "#767a80",
    coatShade: "#5c6066",
    inner: "#e8ddc8",
  },
  juno: {
    bg: ["#b98a3c", "#7d5a22"],
    halo: "#d8a95c",
    skin: "#f0d3bb",
    shade: "#dcb894",
    hair: "#d8c39a",
    hairShade: "#bda679",
    coat: "#c9a24a",
    coatShade: "#a9853a",
    inner: "#f2ead8",
  },
};

function Eyes({ p, closed = false }: { p: Palette; closed?: boolean }) {
  if (closed) {
    return (
      <g stroke="#2a1f1a" strokeWidth={2.6} fill="none" strokeLinecap="round">
        <path d="M75 110 q7 5 14 0" />
        <path d="M111 110 q7 5 14 0" />
      </g>
    );
  }
  return (
    <g>
      <ellipse cx={82} cy={110} rx={5.4} ry={6.6} fill="#2a1f1a" />
      <ellipse cx={118} cy={110} rx={5.4} ry={6.6} fill="#2a1f1a" />
      <circle cx={83.8} cy={107.4} r={1.8} fill="#fff" opacity={0.85} />
      <circle cx={119.8} cy={107.4} r={1.8} fill="#fff" opacity={0.85} />
      <path
        d="M74 100 q8 -5 16 -1"
        stroke={p.hair}
        strokeWidth={3.2}
        fill="none"
        strokeLinecap="round"
      />
      <path
        d="M110 99 q8 -4 16 1"
        stroke={p.hair}
        strokeWidth={3.2}
        fill="none"
        strokeLinecap="round"
      />
    </g>
  );
}

function Base({ p, children }: { p: Palette; children: React.ReactNode }) {
  return (
    <>
      <circle cx={100} cy={108} r={78} fill={p.halo} opacity={0.35} />
      <circle cx={100} cy={108} r={58} fill={p.halo} opacity={0.22} />
      {/* shoulders */}
      <path d="M14 260 C14 202 56 180 100 180 C144 180 186 202 186 260 Z" fill={p.coat} />
      <path d="M14 260 C14 202 56 180 100 180 L100 260 Z" fill={p.coatShade} opacity={0.45} />
      {/* neck */}
      <path d="M85 146 h30 v36 h-30 z" fill={p.shade} />
      <path d="M85 146 h30 v14 q-15 10 -30 0 z" fill={p.shade} />
      {/* head */}
      <ellipse cx={100} cy={106} rx={43} ry={49} fill={p.skin} />
      <path d="M57 106 a43 49 0 0 0 86 0 z" fill={p.shade} opacity={0.18} />
      <ellipse cx={57} cy={114} rx={7} ry={10} fill={p.skin} />
      <ellipse cx={143} cy={114} rx={7} ry={10} fill={p.skin} />
      {children}
    </>
  );
}

export default function Portrait({
  char,
  className = "",
}: {
  char: CharKey;
  className?: string;
}) {
  const p = PALETTES[char];
  const id = `pg-${char}`;

  return (
    <svg
      viewBox="0 0 200 260"
      className={className}
      role="img"
      aria-label={`Portrait of ${char}`}
      preserveAspectRatio="xMidYMid slice"
    >
      <defs>
        <linearGradient id={id} x1="0" y1="0" x2="0.4" y2="1">
          <stop offset="0%" stopColor={p.bg[0]} />
          <stop offset="100%" stopColor={p.bg[1]} />
        </linearGradient>
        <filter id={`${id}-grain`}>
          <feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves="3" result="n" />
          <feColorMatrix in="n" type="saturate" values="0" />
        </filter>
      </defs>

      <rect width={200} height={260} fill={`url(#${id})`} />

      <Base p={p}>
        {char === "mira" && (
          <>
            {/* hair back + bun */}
            <path
              d="M56 100 C54 62 74 44 100 44 C126 44 146 62 144 100 C138 78 122 66 100 66 C78 66 62 78 56 100 Z"
              fill={p.hair}
            />
            <circle cx={100} cy={44} r={21} fill={p.hair} />
            <circle cx={100} cy={44} r={21} fill={p.hairShade} opacity={0.35} />
            <path d="M56 100 C54 62 74 44 100 44 C126 44 146 62 144 100 C138 78 122 66 100 66 C78 66 62 78 56 100 Z" fill={p.hairShade} opacity={0.2} />
            {/* collar + cardigan */}
            <path d="M100 180 L74 200 L100 232 L126 200 Z" fill={p.inner} />
            <path d="M100 180 L74 200 L100 232 Z" fill={p.shade} opacity={0.12} />
            <path d="M74 200 L44 260 L100 260 Z" fill={p.coatShade} />
            <path d="M126 200 L156 260 L100 260 Z" fill={p.coat} />
            {/* glasses */}
            <Eyes p={p} />
            <g fill="none" stroke="#e0cba6" strokeWidth={2.6} opacity={0.95}>
              <circle cx={82} cy={110} r={15} />
              <circle cx={118} cy={110} r={15} />
              <path d="M97 110 h6" />
              <path d="M67 108 L57 112" />
              <path d="M133 108 L143 112" />
            </g>
            <ellipse cx={70} cy={126} rx={9} ry={4.5} fill="#c9707a" opacity={0.22} />
            <ellipse cx={130} cy={126} rx={9} ry={4.5} fill="#c9707a" opacity={0.22} />
            <path d="M100 116 q4 7 -1 9" stroke={p.shade} strokeWidth={2.4} fill="none" strokeLinecap="round" />
            <path d="M92 134 q8 6 16 -1" stroke="#9a5a52" strokeWidth={2.8} fill="none" strokeLinecap="round" />
          </>
        )}

        {char === "kade" && (
          <>
            {/* tank top straps */}
            <path d="M70 186 L58 260 L100 260 Z" fill={p.coatShade} />
            <path d="M130 186 L142 260 L100 260 Z" fill={p.coat} />
            <path d="M74 190 q26 22 52 0 l-10 70 h-32 z" fill={p.inner} opacity={0.9} />
            {/* hair */}
            <path
              d="M55 104 C52 60 74 40 100 40 C128 40 148 60 145 104 C140 74 124 60 100 60 C76 60 60 74 55 104 Z"
              fill={p.hair}
            />
            <path d="M55 104 C52 60 74 40 100 40 C128 40 148 60 145 104 C140 74 124 60 100 60 C76 60 60 74 55 104 Z" fill={p.hairShade} opacity={0.25} />
            <Eyes p={p} />
            {/* scar */}
            <path d="M124 92 l7 -4" stroke="#c98a72" strokeWidth={2.4} strokeLinecap="round" />
            <path d="M100 116 q5 8 -2 10" stroke={p.shade} strokeWidth={2.6} fill="none" strokeLinecap="round" />
            {/* grin */}
            <path d="M86 130 q14 18 28 0 q-14 8 -28 0 z" fill="#5c2a26" />
            <path d="M88 131 q12 5 24 0 l0 4 q-12 5 -24 0 z" fill="#f6efe2" />
            <ellipse cx={70} cy={124} rx={10} ry={5} fill="#c9707a" opacity={0.2} />
            <ellipse cx={130} cy={124} rx={10} ry={5} fill="#c9707a" opacity={0.2} />
            {/* towel over shoulder */}
            <path d="M138 190 q26 8 30 70 l-22 0 q-4 -40 -14 -56 z" fill={p.inner} opacity={0.85} />
          </>
        )}

        {char === "juno" && (
          <>
            {/* cardigan + striped shirt */}
            <path d="M100 180 L72 202 L100 240 L128 202 Z" fill={p.inner} />
            <path d="M84 200 h32 v8 h-32 z" fill="#8d9aa3" opacity={0.5} />
            <path d="M82 216 h36 v8 h-36 z" fill="#8d9aa3" opacity={0.5} />
            <path d="M72 202 L40 260 L100 260 Z" fill={p.coatShade} />
            <path d="M128 202 L160 260 L100 260 Z" fill={p.coat} />
            {/* wavy hair */}
            <path
              d="M52 116 C46 62 72 38 100 38 C130 38 154 62 148 116 C144 96 140 84 132 76 C120 88 80 88 68 76 C60 84 56 96 52 116 Z"
              fill={p.hair}
            />
            <path d="M52 116 C46 62 72 38 100 38 C130 38 154 62 148 116 C144 96 140 84 132 76 C120 88 80 88 68 76 C60 84 56 96 52 116 Z" fill={p.hairShade} opacity={0.2} />
            <path d="M50 112 C44 150 48 176 58 190 C50 160 52 134 58 116 Z" fill={p.hair} />
            <path d="M150 112 C156 150 152 176 142 190 C150 160 148 134 142 116 Z" fill={p.hair} />
            {/* green streak */}
            <path d="M118 44 C132 52 140 68 142 84 C136 70 128 58 116 50 Z" fill="#7fae86" opacity={0.9} />
            <Eyes p={p} />
            <path d="M100 116 q4 7 -1 9" stroke={p.shade} strokeWidth={2.4} fill="none" strokeLinecap="round" />
            <path d="M90 132 q12 8 22 -2" stroke="#a4564f" strokeWidth={2.8} fill="none" strokeLinecap="round" />
            <ellipse cx={70} cy={124} rx={10} ry={5} fill="#d98a86" opacity={0.26} />
            <ellipse cx={130} cy={124} rx={10} ry={5} fill="#d98a86" opacity={0.26} />
            {/* freckles */}
            <g fill="#c98a72" opacity={0.55}>
              <circle cx={78} cy={122} r={1.3} />
              <circle cx={86} cy={126} r={1.1} />
              <circle cx={114} cy={126} r={1.1} />
              <circle cx={122} cy={122} r={1.3} />
            </g>
            {/* earrings */}
            <circle cx={57} cy={128} r={3.4} fill="#e6ac63" />
            <circle cx={143} cy={128} r={2.6} fill="#74b3a6" />
          </>
        )}
      </Base>

      <rect width={200} height={260} filter={`url(#${id}-grain)`} opacity={0.13} style={{ mixBlendMode: "overlay" }} />
    </svg>
  );
}
