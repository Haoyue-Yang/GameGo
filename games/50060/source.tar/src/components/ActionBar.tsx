import type { ActionDef, GameState } from "@/game/types";
import { NODE_MAP, SKILL_MAP, CHAR_MAP } from "@/game/content";
import { availability } from "@/game/engine";

function Chip({
  children,
  color,
}: {
  children: React.ReactNode;
  color: string;
}) {
  return (
    <span
      className="rounded-full px-1.5 py-[1px] text-[10px] font-medium leading-[15px]"
      style={{ background: `${color}1f`, color, boxShadow: `inset 0 0 0 1px ${color}40` }}
    >
      {children}
    </span>
  );
}

function ActionCard({
  a,
  state,
  onRun,
}: {
  a: ActionDef;
  state: GameState;
  onRun: (id: string) => void;
}) {
  const avail = availability(state, a);
  const disabled = !avail.ok;

  return (
    <button
      type="button"
      disabled={disabled}
      onClick={() => onRun(a.id)}
      className={`group relative flex flex-col items-start gap-1.5 rounded-xl p-2.5 text-left transition-all duration-200 ${
        disabled
          ? "cursor-not-allowed opacity-45"
          : "hover:-translate-y-[2px] focus-visible:-translate-y-[2px] focus-visible:outline-none"
      }`}
      style={{
        background: disabled
          ? "rgba(243,231,211,0.03)"
          : "linear-gradient(160deg, rgba(243,231,211,0.075), rgba(243,231,211,0.025))",
        boxShadow: disabled
          ? "inset 0 0 0 1px rgba(243,231,211,0.07)"
          : "inset 0 0 0 1px rgba(243,231,211,0.13), 0 10px 24px -16px rgba(0,0,0,0.9)",
      }}
    >
      <div className="flex w-full items-start justify-between gap-2">
        <span className="display text-[13.5px] leading-snug text-parchment/95">{a.label}</span>
        {!disabled && (
          <span className="mt-[3px] shrink-0 text-[10px] text-brass opacity-0 transition-opacity duration-200 group-hover:opacity-100 group-focus-visible:opacity-100">
            spend →
          </span>
        )}
      </div>
      <p className="text-[11px] leading-snug text-parchment/45">{a.desc}</p>
      <div className="mt-0.5 flex flex-wrap items-center gap-1">
        {a.energy < 0 && <Chip color="#74b3a6">❈ {a.energy}</Chip>}
        {a.energy > 0 && <Chip color="#74b3a6">❈ +{a.energy}</Chip>}
        {a.money < 0 && <Chip color="#e6ac63">◈ {a.money}</Chip>}
        {a.money > 0 && <Chip color="#e6ac63">◈ +{a.money}</Chip>}
        {a.extraSlot && <Chip color="#8d9aa3">+1 slot</Chip>}
        {a.buyGift && <Chip color="#d98a9c">✿ +1 gift</Chip>}
        {a.spendGift && <Chip color="#d98a9c">✿ −1 gift</Chip>}
        {Object.entries(a.skills ?? {}).map(([k, v]) => (
          <Chip key={k} color={SKILL_MAP[k as keyof typeof SKILL_MAP].color}>
            {SKILL_MAP[k as keyof typeof SKILL_MAP].name} +{v}
          </Chip>
        ))}
        {Object.entries(a.affection ?? {})
          .filter(([, v]) => (v ?? 0) > 0)
          .map(([k, v]) => (
            <Chip key={k} color={CHAR_MAP[k as keyof typeof CHAR_MAP].accent}>
              ♥ {CHAR_MAP[k as keyof typeof CHAR_MAP].name} +{v}
            </Chip>
          ))}
        {a.scene && <Chip color="#e6ac63">dialogue</Chip>}
      </div>
      {disabled && (
        <span className="absolute inset-x-3 bottom-2 text-[10px] uppercase tracking-wider-xs text-clay/80">
          {avail.why}
        </span>
      )}
    </button>
  );
}

export default function ActionBar({
  state,
  onRun,
  onClose,
}: {
  state: GameState;
  onRun: (id: string) => void;
  onClose: () => void;
}) {
  const node = state.selected ? NODE_MAP[state.selected] : null;
  if (!node) return null;

  return (
    <div className="anim-slide panel grain pointer-events-auto absolute inset-x-0 bottom-0 z-20 border-x-0 border-b-0 px-5 pb-5 pt-4">
      <div className="mb-2.5 flex items-center justify-between gap-4">
        <div className="min-w-0">
          <div className="flex items-center gap-2">
            <span
              className="grid h-6 w-6 shrink-0 place-items-center rounded-full text-[11px]"
              style={{ background: `${node.tint}22`, color: node.tint, boxShadow: `inset 0 0 0 1px ${node.tint}55` }}
              aria-hidden
            >
              {node.glyph}
            </span>
            <h2 className="display text-[18px] leading-none text-parchment/95">{node.name}</h2>
            <span className="truncate text-[10.5px] uppercase tracking-wider-xs text-parchment/35">
              {node.sub}
            </span>
          </div>
          <p className="mt-1 truncate text-[11px] italic text-parchment/40">{node.blurb}</p>
        </div>
        <button
          type="button"
          onClick={onClose}
          className="shrink-0 rounded-lg border border-parchment/12 px-3 py-1.5 text-[10.5px] uppercase tracking-wider-xs text-parchment/55 transition-colors hover:border-parchment/28 hover:text-parchment/85"
        >
          Close
        </button>
      </div>

      <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-3 lg:grid-cols-4">
        {node.actions.map((a) => (
          <ActionCard key={a.id} a={a} state={state} onRun={onRun} />
        ))}
      </div>
    </div>
  );
}
