import type { GameState } from "@/game/types";
import { BASE_SLOTS, MAX_DAY, MAX_ENERGY, slotLabel } from "@/game/engine";

function Meter({
  value,
  max,
  color,
  label,
  glyph,
}: {
  value: number;
  max: number;
  color: string;
  label: string;
  glyph: string;
}) {
  const pct = Math.max(0, Math.min(100, (value / max) * 100));
  const low = pct <= 25;
  return (
    <div className="flex items-center gap-2.5">
      <span
        className="grid h-7 w-7 place-items-center rounded-full text-[13px]"
        style={{ background: `${color}22`, color, boxShadow: `inset 0 0 0 1px ${color}44` }}
        aria-hidden
      >
        {glyph}
      </span>
      <div className="min-w-[104px]">
        <div className="mb-1 flex items-baseline justify-between gap-2">
          <span className="text-[9.5px] uppercase tracking-wider-xs text-parchment/45">{label}</span>
          <span
            className={`display text-[13px] leading-none ${low ? "text-clay" : "text-parchment/85"}`}
          >
            {value}
          </span>
        </div>
        <div className="h-[5px] overflow-hidden rounded-full bg-parchment/10">
          <div
            className="h-full rounded-full transition-[width] duration-500 ease-out"
            style={{
              width: `${pct}%`,
              background: `linear-gradient(90deg, ${color}88, ${color})`,
              boxShadow: `0 0 10px ${color}66`,
            }}
          />
        </div>
      </div>
    </div>
  );
}

export default function TopBar({ state }: { state: GameState }) {
  const used = state.slotsToday - state.slots;
  const label = slotLabel(state.slots, state.slotsToday);

  return (
    <header className="panel grain relative z-30 flex h-[62px] shrink-0 items-center gap-5 border-x-0 border-t-0 px-5">
      <div className="flex items-center gap-3">
        <span className="display text-lg text-brass" aria-hidden>
          ✧
        </span>
        <div className="leading-tight">
          <div className="display text-[15px] font-medium text-parchment/95">
            Twenty-Eight Days in Ashgrove
          </div>
          <div className="text-[9.5px] uppercase tracking-wider-xs text-parchment/40">
            Day {state.day} of {MAX_DAY}
          </div>
        </div>
      </div>

      <div className="hairline mx-1 hidden h-8 w-px sm:block" />

      <div className="flex items-center gap-3">
        <div className="flex items-center gap-1.5" aria-label={`${state.slots} slots remaining`}>
          {Array.from({ length: state.slotsToday }).map((_, i) => {
            const spent = i < used;
            return (
              <span
                key={i}
                className={`grid h-[19px] w-[19px] rotate-45 place-items-center rounded-[4px] transition-all duration-300 ${
                  spent ? "bg-parchment/10" : ""
                }`}
                style={
                  spent
                    ? undefined
                    : {
                        background: "linear-gradient(135deg,#e6ac63,#c98a45)",
                        boxShadow: "0 0 12px rgba(230,172,99,0.55)",
                      }
                }
              />
            );
          })}
        </div>
        <div className="leading-tight">
          <div className="display text-[13px] text-parchment/85">
            {state.slots > 0 ? label : "The day is spent"}
          </div>
          <div className="text-[9.5px] uppercase tracking-wider-xs text-parchment/40">
            {state.slots} of {state.slotsToday} slots left
            {state.slotsToday > BASE_SLOTS ? " · slept in" : ""}
          </div>
        </div>
      </div>

      <div className="ml-auto flex items-center gap-5">
        <Meter value={state.energy} max={MAX_ENERGY} color="#74b3a6" label="Energy" glyph="❈" />
        <div className="flex items-center gap-2.5">
          <span
            className="grid h-7 w-7 place-items-center rounded-full text-[13px]"
            style={{ background: "#e6ac6322", color: "#e6ac63", boxShadow: "inset 0 0 0 1px #e6ac6344" }}
            aria-hidden
          >
            ◈
          </span>
          <div className="leading-tight">
            <div className="text-[9.5px] uppercase tracking-wider-xs text-parchment/45">Money</div>
            <div className="display text-[13px] text-parchment/85">{state.money}</div>
          </div>
        </div>
        <div className="hidden items-center gap-2.5 md:flex">
          <span
            className="grid h-7 w-7 place-items-center rounded-full text-[13px]"
            style={{ background: "#d98a9c22", color: "#d98a9c", boxShadow: "inset 0 0 0 1px #d98a9c44" }}
            aria-hidden
          >
            ✿
          </span>
          <div className="leading-tight">
            <div className="text-[9.5px] uppercase tracking-wider-xs text-parchment/45">Gifts</div>
            <div className="display text-[13px] text-parchment/85">{state.gifts}</div>
          </div>
        </div>
      </div>
    </header>
  );
}
