import type { Scene } from "./types";

export const SCENES: Scene[] = [
  /* ------------------------------------------------------------------ MIRA */
  {
    id: "m1",
    char: "mira",
    title: "The Ledger of Small Things",
    minAffection: 0,
    lines: [
      { who: "narr", text: "The library smells like dust and old glue. Somewhere behind the stacks, a chair creaks." },
      { who: "mira", text: "You're in the wrong aisle. The wrong aisle is where the maps are. I'm filing the ones nobody asked for." },
      { who: "mira", text: "Mira Solane. Head archivist, which is a fancy way of saying I keep other people's paper in order." },
    ],
    prompt: "She waits. One eyebrow, slightly raised.",
    options: [
      {
        label: "\"What are you shelving?\"",
        gain: 9,
        reply:
          "\"Three hundred letters from 1911 to a woman who never wrote back.\" A pause. \"It's the only collection I've never finished.\"",
      },
      {
        label: "Offer to help. Say nothing.",
        gain: 6,
        reply:
          "\"...You're quiet.\" She shelves a book. \"That's either a personality or a threat. I'll allow it.\"",
      },
      {
        label: "\"How was your day?\"",
        gain: 3,
        reply: "\"Fine. Everyone asks that.\" She turns a book over. \"Nobody asks about the letters.\"",
      },
    ],
  },
  {
    id: "m2",
    char: "mira",
    title: "Marginalia",
    minAffection: 20,
    lines: [
      { who: "narr", text: "She's at the long table with a book open face-down and a pencil in her hand." },
      { who: "mira", text: "Don't look. It's not — fine. Look." },
      { who: "mira", text: "I write in the margins. Eleven years of it. Someone will find it one day and decide I'm mad." },
      { who: "mira", text: "It's the only place I get to say something that isn't a catalogue number." },
    ],
    prompt: "The pencil hovers over the page.",
    options: [
      {
        label: "Read one note aloud.",
        gain: 11,
        reply:
          "\"'She was right about the weather.' — 1998.\" Mira goes very still. \"You read it out loud.\" \"I read it out loud.\"",
      },
      {
        label: "\"The notes are beautiful.\"",
        gain: 7,
        reply: "\"They're handwriting. It's handwriting, not a poem.\" She looks at you. \"It's a poem.\"",
      },
      {
        label: "\"Teach me.\"",
        gain: 10,
        reply:
          "\"Teach you to write in margins?\" She almost smiles. \"I'll teach you to write in margins. Carefully. There are rules.\"",
      },
    ],
  },
  {
    id: "m3",
    char: "mira",
    title: "The Unfiled Hour",
    minAffection: 45,
    lines: [
      { who: "narr", text: "Closing time. The lamps go amber, one by one, like someone counting down." },
      { who: "mira", text: "I've been here eleven years. I know every shelf by the sound it makes when it moves." },
      { who: "mira", text: "And after? After the archive closes for good — and it will — I have nothing filed for myself." },
      { who: "mira", text: "I'm not asking for a plan. I'm telling you I don't have one." },
    ],
    prompt: "The last lamp clicks off.",
    options: [
      {
        label: "\"Then let's make one. Badly.\"",
        gain: 13,
        reply:
          "\"Badly is a start.\" She laughs — a real one, surprised out of her. \"Badly is a start.\"",
      },
      {
        label: "\"The archive needs you.\"",
        gain: 4,
        reply: "\"It needs someone.\" She says it kindly, which is somehow worse.",
      },
      {
        label: "\"I'd like to be part of it.\"",
        gain: 12,
        reply:
          "She looks at you for a long moment. \"Part of what?\" \"The part after.\" A breath. \"All right. All right.\"",
      },
    ],
  },
  {
    id: "m4",
    char: "mira",
    title: "Index of Us",
    minAffection: 70,
    lines: [
      { who: "narr", text: "The roof above the library, after hours. She brought a thermos and a card index." },
      { who: "mira", text: "I made a card for you." },
      { who: "mira", text: "It's the last one. I've been building it for a week. I don't know what to write on it." },
      { who: "mira", text: "So. What do I write?" },
    ],
    prompt: "The card is blank. The city is very quiet.",
    options: [
      {
        label: "Ask her to come with you.",
        gain: 14,
        reply:
          "\"With me, where?\" \"Anywhere that isn't filed.\" She writes: Solane, M. — in transit.",
      },
      {
        label: "Give her your key.",
        gain: 16,
        reply:
          "She turns it over twice. \"This is a serious thing.\" \"I know.\" She writes: Solane, M. — home, most evenings.",
      },
      {
        label: "Say nothing. Stay.",
        gain: 9,
        reply:
          "You sit. She sits. The thermos goes cold. She writes, very slowly: Solane, M. — present.",
      },
    ],
  },

  /* ------------------------------------------------------------------ KADE */
  {
    id: "k1",
    char: "kade",
    title: "Counters",
    minAffection: 0,
    lines: [
      { who: "narr", text: "The gym is empty but for the sound of a bag being hit. Rhythm. Then more rhythm." },
      { who: "kade", text: "Hey! You're early. Or I'm late. Depends who's counting." },
      { who: "kade", text: "Kade Rook. I box. I also, apparently, work here." },
    ],
    prompt: "He wipes his face with the towel.",
    options: [
      {
        label: "\"Spar with me.\"",
        gain: 9,
        reply:
          "\"You?\" He grins. \"Yeah, okay.\" He throws the first jab so soft it's basically a handshake.",
      },
      {
        label: "Hand him water.",
        gain: 6,
        reply:
          "\"You brought water.\" \"It's water.\" \"It's water,\" he repeats, like it's a foreign language. He drinks all of it.",
      },
      {
        label: "\"You're good at this.\"",
        gain: 4,
        reply:
          "\"Everyone says that.\" He says it too fast. Then, quieter: \"Most people mean it. You do.\"",
      },
    ],
  },
  {
    id: "k2",
    char: "kade",
    title: "The Long Walk Home",
    minAffection: 20,
    lines: [
      { who: "narr", text: "He's on the bench outside, boots off, not talking about boxing for once." },
      { who: "kade", text: "My sister's in the city. Pays rent, sends money, doesn't call." },
      { who: "kade", text: "I'm fine about it. I'm — mostly fine." },
      { who: "kade", text: "It's just that everyone here thinks I'm the guy who hits things. And then I can't tell anyone anything." },
    ],
    prompt: "He doesn't look at you.",
    options: [
      {
        label: "Listen. Don't fix it.",
        gain: 11,
        reply:
          "You don't say anything for a while. Eventually: \"Thanks for not making it a speech.\" \"It's not a speech.\" \"No. It's just you.\"",
      },
      {
        label: "\"Let me help her.\"",
        gain: 8,
        reply: "\"What would you even do?\" \"I'd call her.\" He laughs, disbelieving. \"You'd call her.\" \"I'd call her.\"",
      },
      {
        label: "Change the subject.",
        gain: 2,
        reply: "He goes back to boxing talk. You both pretend it worked.",
      },
    ],
  },
  {
    id: "k3",
    char: "kade",
    title: "Knockout",
    minAffection: 45,
    lines: [
      { who: "narr", text: "He's limping. He's been limping for three days and pretending it's nothing." },
      { who: "kade", text: "It's nothing. It's a nothing. I've had worse." },
      { who: "kade", text: "If I stop, I'm just — a guy who used to be something." },
    ],
    prompt: "He's not looking at you. His hands are shaking.",
    options: [
      {
        label: "Make him rest.",
        gain: 13,
        reply:
          "You take the towel out of his hands. \"Sit down.\" \"I'm not —\" \"Sit down, Kade.\" He sits. He cries a little, and he's furious about it, and you stay.",
      },
      {
        label: "\"It's fine.\"",
        gain: 2,
        reply: "\"It's fine,\" you say. He nods. He goes back to the bag. You both know it isn't.",
      },
      {
        label: "Sit with him.",
        gain: 12,
        reply:
          "You sit on the gym floor with him. Neither of you says anything for twenty minutes. \"...Okay,\" he says finally. \"Okay.\"",
      },
    ],
  },
  {
    id: "k4",
    char: "kade",
    title: "No More Rounds",
    minAffection: 70,
    lines: [
      { who: "narr", text: "Late. The lights are off except the one over the ring." },
      { who: "kade", text: "I think I'm done. With the fighting." },
      { who: "kade", text: "Not with everything. Just — the rounds. The twelve of them." },
      { who: "kade", text: "I don't know what I am after that." },
    ],
    prompt: "He's waiting for you to tell him what he is.",
    options: [
      {
        label: "\"Fight for something else.\"",
        gain: 14,
        reply: "\"Like what?\" \"Like staying.\" He thinks about it. \"That's a long fight.\" \"It is.\"",
      },
      {
        label: "\"Stay.\"",
        gain: 16,
        reply: "\"Stay where?\" \"Here. With me. Not on the ring.\" He nods slowly. \"Yeah. Okay. Yeah.\"",
      },
      {
        label: "\"Whatever you need.\"",
        gain: 8,
        reply: "\"That's kind of you.\" He's grateful and a little disappointed, and you both let it pass.",
      },
    ],
  },

  /* ------------------------------------------------------------------ JUNO */
  {
    id: "j1",
    char: "juno",
    title: "Two Cups, One Order",
    minAffection: 0,
    lines: [
      { who: "narr", text: "The cafe is closed. There's a guitar on the counter and two cups, and only one order." },
      { who: "juno", text: "You're the new regular. I've decided that. It's a big decision." },
      { who: "juno", text: "Juno. I make coffee and I make noise. Usually at the same time." },
    ],
    prompt: "They slide a cup toward you.",
    options: [
      {
        label: "\"Whatever you're making.\"",
        gain: 10,
        reply:
          "\"That's cheating,\" they say, delighted. \"That's the best answer. Nobody ever asks me for the usual.\"",
      },
      {
        label: "\"The usual.\"",
        gain: 5,
        reply: "\"The usual.\" They make it perfectly. It's very good and slightly sad.",
      },
      {
        label: "\"What's the guitar called?\"",
        gain: 8,
        reply:
          "\"It's a bad guitar. It's my bad guitar.\" They strum one chord, badly, on purpose.",
      },
    ],
  },
  {
    id: "j2",
    char: "juno",
    title: "Busking, Bad Weather",
    minAffection: 20,
    lines: [
      { who: "narr", text: "Rain. They're at the corner with the case open and no umbrella." },
      { who: "juno", text: "Don't tell me to go inside. I've been told to go inside my whole life." },
      { who: "juno", text: "I'm playing for four people and a pigeon. The pigeon is the best one." },
    ],
    prompt: "The rain is getting worse.",
    options: [
      {
        label: "Go out with them.",
        gain: 12,
        reply:
          "You stand in the rain and listen. By the third song the pigeon has left and you're both soaked and laughing.",
      },
      {
        label: "\"Stay dry.\"",
        gain: 5,
        reply: "\"Yeah. Okay.\" They go inside. You hear them not playing for an hour.",
      },
      {
        label: "Buy them a new string.",
        gain: 11,
        reply:
          "\"You bought me a string.\" \"It was the E string.\" \"It was the E string,\" they repeat, and they cry in the way people pretend is rain.",
      },
    ],
  },
  {
    id: "j3",
    char: "juno",
    title: "The Map They Won't Draw",
    minAffection: 45,
    lines: [
      { who: "narr", text: "There's a train ticket in their pocket. They've had it for a month." },
      { who: "juno", text: "There's a place. I can't tell you where. If I tell you where, it stops being a place." },
      { who: "juno", text: "I'm not leaving you. I just don't do plans. Plans are how people lose." },
    ],
    prompt: "The ticket is visible. It's been visible for a month.",
    options: [
      {
        label: "\"No plans. Just tonight.\"",
        gain: 13,
        reply:
          "\"Tonight,\" they say. \"Yeah. Tonight's good.\" They put the ticket back in their pocket — not away.",
      },
      {
        label: "\"Let's make a plan.\"",
        gain: 3,
        reply: "\"No.\" They say it gently, which is worse. \"I'm sorry. No.\"",
      },
      {
        label: "\"I'll wait for you.\"",
        gain: 14,
        reply:
          "They look at you like you've said something impossible. \"You'd wait?\" \"I'd wait.\" \"...Okay. Okay.\"",
      },
    ],
  },
  {
    id: "j4",
    char: "juno",
    title: "Last Train",
    minAffection: 70,
    lines: [
      { who: "narr", text: "The last train is in twenty minutes. They're at the station with the case." },
      { who: "juno", text: "It's just one show. One town. I'll be back." },
      { who: "juno", text: "I've said that before. I know I've said that before." },
    ],
    prompt: "The platform is empty. The train is coming.",
    options: [
      {
        label: "\"Come with me.\"",
        gain: 15,
        reply:
          "\"You don't even know where I'm going.\" \"I know where you are.\" They put the case down. They stay.",
      },
      {
        label: "\"Go. I'll find you.\"",
        gain: 8,
        reply: "They go. You find them. It takes longer than either of you expected.",
      },
      {
        label: "\"Stay.\"",
        gain: 17,
        reply:
          "\"Stay.\" You say it once. They look at the train, then at you. They stay.",
      },
    ],
  },
];

export const SCENE_MAP: Record<string, Scene> = SCENES.reduce(
  (acc, s) => ({ ...acc, [s.id]: s }),
  {} as Record<string, Scene>,
);

/** Returns the next unseen scene for a character, or null if they're exhausted. */
export function nextScene(char: string, affection: number, seen: string[]): Scene | null {
  const pool = SCENES.filter((s) => s.char === char && !seen.includes(s.id) && affection >= s.minAffection);
  if (pool.length === 0) return null;
  return pool[0];
}
