export type SkillKey = "intellect" | "fitness" | "charm" | "craft";
export type CharKey = "mira" | "kade" | "juno";
export type Phase = "title" | "map" | "dialogue" | "ending";
export type ActionKind = "work" | "train" | "social" | "rest" | "shop";

export interface Character {
  key: CharKey;
  name: string;
  full: string;
  role: string;
  accent: string;
  soft: string;
  node: string;
  likes: string;
}

export interface SkillDef {
  key: SkillKey;
  name: string;
  glyph: string;
  color: string;
  note: string;
}

export interface ActionDef {
  id: string;
  label: string;
  desc: string;
  kind: ActionKind;
  /** negative = cost, positive = gain */
  energy: number;
  money: number;
  skills?: Partial<Record<SkillKey, number>>;
  affection?: Partial<Record<CharKey, number>>;
  /** consumes one gift token */
  spendGift?: boolean;
  /** grants one gift token */
  buyGift?: boolean;
  /** grants an extra slot for today */
  extraSlot?: boolean;
  scene?: string;
  oncePerDay?: boolean;
  maxUses?: number;
  requires?: (s: GameState) => boolean;
  lockedText?: string;
}

export interface NodeDef {
  id: string;
  name: string;
  sub: string;
  glyph: string;
  x: number;
  y: number;
  tint: string;
  blurb: string;
  actions: ActionDef[];
}

export interface SceneLine {
  who?: CharKey | "you" | "narr";
  text: string;
}

export interface SceneOption {
  label: string;
  gain: number;
  reply: string;
}

export interface Scene {
  id: string;
  char: CharKey;
  title: string;
  minAffection: number;
  lines: SceneLine[];
  prompt: string;
  options: SceneOption[];
}

export interface Toast {
  id: number;
  text: string;
  tone: "gain" | "cost" | "love" | "warn";
}

export interface LogEntry {
  day: number;
  text: string;
}

export interface DialogueState {
  sceneId: string;
  char: CharKey;
  line: number;
  stage: "lines" | "choice" | "reply";
  reply?: string;
  gain?: number;
}

export interface GameState {
  phase: Phase;
  day: number;
  slots: number;
  slotsToday: number;
  energy: number;
  money: number;
  gifts: number;
  skills: Record<SkillKey, number>;
  affection: Record<CharKey, number>;
  usedToday: string[];
  usedTotal: Record<string, number>;
  seenScenes: string[];
  selected: string | null;
  dialogue: DialogueState | null;
  log: LogEntry[];
  toasts: Toast[];
  endingId: string | null;
  dawn: boolean;
}
