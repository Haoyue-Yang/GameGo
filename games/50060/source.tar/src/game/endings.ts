import type { GameState } from "./types";
import { CHARACTERS, CHAR_MAP } from "./content";

export const THRESHOLDS = {
  romanceTop: 62,
  romanceTotal: 105,
  masteryTotal: 200,
  masteryPeak: 68,
  wealthMoney: 1500,
  wealthCraft: 50,
};

export interface EndingDef {
  id: string;
  title: string;
  tagline: string;
  priority: number;
  accent: string;
  body: string[];
  test: (s: GameState) => boolean;
  checks: (s: GameState) => { label: string; value: string; met: boolean }[];
}

export const totalSkills = (s: GameState) =>
  s.skills.intellect + s.skills.fitness + s.skills.charm + s.skills.craft;

export const totalAffection = (s: GameState) =>
  s.affection.mira + s.affection.kade + s.affection.juno;

export const peakSkill = (s: GameState) =>
  Math.max(s.skills.intellect, s.skills.fitness, s.skills.charm, s.skills.craft);

export const peakAffection = (s: GameState) =>
  Math.max(s.affection.mira, s.affection.kade, s.affection.juno);

export const closestChar = (s: GameState) =>
  CHARACTERS.reduce((a, b) => (s.affection[b.key] > s.affection[a.key] ? b : a));

export const ENDINGS: EndingDef[] = [
  {
    id: "constellation",
    title: "The Constellation",
    tagline: "Two people, one sky.",
    priority: 1,
    accent: "#d98a9c",
    test: (s) => peakAffection(s) >= THRESHOLDS.romanceTop && totalAffection(s) >= THRESHOLDS.romanceTotal,
    body: [
      "Day twenty-eight ends the way it started: the town lit up in amber, and someone waiting for you at the bottom of the stairs.",
      "You didn't become a version of yourself. You became a version of somebody's.",
      "Mira's card is on the mantel. Kade's towel is on the hook. Juno's bad guitar is in the corner — still bad, still yours.",
      "The days were never the point. The company was.",
    ],
    checks: (s) => {
      const c = closestChar(s);
      return [
        {
          label: `${c.full} — affection`,
          value: `${s.affection[c.key]} / ${THRESHOLDS.romanceTop}`,
          met: s.affection[c.key] >= THRESHOLDS.romanceTop,
        },
        {
          label: "Affection with all three",
          value: `${totalAffection(s)} / ${THRESHOLDS.romanceTotal}`,
          met: totalAffection(s) >= THRESHOLDS.romanceTotal,
        },
      ];
    },
  },
  {
    id: "cartographer",
    title: "The Cartographer",
    tagline: "You mapped yourself.",
    priority: 2,
    accent: "#e6ac63",
    test: (s) => totalSkills(s) >= THRESHOLDS.masteryTotal && peakSkill(s) >= THRESHOLDS.masteryPeak,
    body: [
      "Twenty-eight days ago you were a shape on a page you couldn't read.",
      "Now you know the weight of a thing before you lift it. You know which room to walk into. You know what you're for.",
      "It cost you the evenings and the easy ones. You'd do it again — badly, and again.",
      "Somewhere in the margins, in your own handwriting, someone has written: finished.",
    ],
    checks: (s) => [
      {
        label: "Skills combined",
        value: `${totalSkills(s)} / ${THRESHOLDS.masteryTotal}`,
        met: totalSkills(s) >= THRESHOLDS.masteryTotal,
      },
      {
        label: "Highest single skill",
        value: `${peakSkill(s)} / ${THRESHOLDS.masteryPeak}`,
        met: peakSkill(s) >= THRESHOLDS.masteryPeak,
      },
    ],
  },
  {
    id: "ledger",
    title: "The Ledger",
    tagline: "The numbers went up.",
    priority: 3,
    accent: "#74b3a6",
    test: (s) => s.money >= THRESHOLDS.wealthMoney && s.skills.craft >= THRESHOLDS.wealthCraft,
    body: [
      "The workshop has your name on the door now. Small brass letters. You paid for them yourself.",
      "You can afford the flat with the window. You can afford the tonic, the gift, the long walk.",
      "You are not lonely in the way you were. You are busy, which is a different kind of company.",
      "The ledger balances. That was the whole game.",
    ],
    checks: (s) => [
      {
        label: "Money on hand",
        value: `${s.money} / ${THRESHOLDS.wealthMoney}`,
        met: s.money >= THRESHOLDS.wealthMoney,
      },
      {
        label: "Craft",
        value: `${s.skills.craft} / ${THRESHOLDS.wealthCraft}`,
        met: s.skills.craft >= THRESHOLDS.wealthCraft,
      },
    ],
  },
  {
    id: "grey",
    title: "The Grey Season",
    tagline: "The days were spent on nothing.",
    priority: 4,
    accent: "#8d9aa3",
    test: () => true,
    body: [
      "Twenty-eight days. Eighty-four slots. You spent them on the wrong things, which is the only kind of wrong thing there is.",
      "The library is still there. The gym is still there. The cafe still smells like burnt sugar.",
      "Nobody is waiting at the bottom of the stairs. You never asked anyone to wait.",
      "But the season is over, and seasons do end, and the next one starts whether you're ready or not.",
    ],
    checks: (s) => [
      {
        label: "Skills combined",
        value: `${totalSkills(s)} / ${THRESHOLDS.masteryTotal}`,
        met: totalSkills(s) >= THRESHOLDS.masteryTotal,
      },
      {
        label: "Affection with all three",
        value: `${totalAffection(s)} / ${THRESHOLDS.romanceTotal}`,
        met: totalAffection(s) >= THRESHOLDS.romanceTotal,
      },
      {
        label: "Money on hand",
        value: `${s.money} / ${THRESHOLDS.wealthMoney}`,
        met: s.money >= THRESHOLDS.wealthMoney,
      },
    ],
  },
];

export function resolveEnding(s: GameState): EndingDef {
  const ranked = [...ENDINGS].sort((a, b) => a.priority - b.priority);
  return ranked.find((e) => e.test(s)) ?? ENDINGS[ENDINGS.length - 1];
}

/** Live read-out of how close each ending is. */
export function prognosis(s: GameState) {
  const top = closestChar(s);
  return [
    {
      id: "constellation",
      title: "The Constellation",
      accent: "#d98a9c",
      met: ENDINGS[0].test(s),
      progress: Math.min(
        1,
        Math.max(
          s.affection[top.key] / THRESHOLDS.romanceTop,
          totalAffection(s) / THRESHOLDS.romanceTotal,
        ),
      ),
      hint: `${top.full} ${s.affection[top.key]}/${THRESHOLDS.romanceTop} · all three ${totalAffection(s)}/${THRESHOLDS.romanceTotal}`,
    },
    {
      id: "cartographer",
      title: "The Cartographer",
      accent: "#e6ac63",
      met: ENDINGS[1].test(s),
      progress: Math.min(
        1,
        Math.max(totalSkills(s) / THRESHOLDS.masteryTotal, peakSkill(s) / THRESHOLDS.masteryPeak),
      ),
      hint: `skills ${totalSkills(s)}/${THRESHOLDS.masteryTotal} · peak ${peakSkill(s)}/${THRESHOLDS.masteryPeak}`,
    },
    {
      id: "ledger",
      title: "The Ledger",
      accent: "#74b3a6",
      met: ENDINGS[2].test(s),
      progress: Math.min(
        1,
        Math.max(s.money / THRESHOLDS.wealthMoney, s.skills.craft / THRESHOLDS.wealthCraft),
      ),
      hint: `money ${s.money}/${THRESHOLDS.wealthMoney} · craft ${s.skills.craft}/${THRESHOLDS.wealthCraft}`,
    },
  ];
}

export const CHAR_NAME = (k: keyof typeof CHAR_MAP) => CHAR_MAP[k].name;
