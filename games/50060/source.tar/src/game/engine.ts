import type { ActionDef, CharKey, GameState, SkillKey, Toast } from "./types";
import { NODE_MAP, SKILL_MAP, CHAR_MAP } from "./content";
import { nextScene } from "./scenes";
import { resolveEnding } from "./endings";

export const MAX_DAY = 28;
export const BASE_SLOTS = 3;
export const MAX_SLOTS = 4;
export const MAX_ENERGY = 100;
export const DAWN_ENERGY = 50;
export const START_MONEY = 120;

export const SLOT_LABELS = ["Morning", "Afternoon", "Evening", "Late night"];

let toastSeq = 0;

export function initialState(): GameState {
  return {
    phase: "title",
    day: 1,
    slots: BASE_SLOTS,
    slotsToday: BASE_SLOTS,
    energy: MAX_ENERGY,
    money: START_MONEY,
    gifts: 0,
    skills: { intellect: 0, fitness: 0, charm: 0, craft: 0 },
    affection: { mira: 0, kade: 0, juno: 0 },
    usedToday: [],
    usedTotal: {},
    seenScenes: [],
    selected: null,
    dialogue: null,
    log: [
      { day: 1, text: "You arrive in Ashgrove with a suitcase, a train ticket stub, and twenty-eight days." },
    ],
    toasts: [],
    endingId: null,
    dawn: false,
  };
}

export type GameAction =
  | { type: "start" }
  | { type: "select"; id: string | null }
  | { type: "run"; actionId: string }
  | { type: "advance" }
  | { type: "choose"; index: number }
  | { type: "closeDialogue" }
  | { type: "endDay" }
  | { type: "dismissToast"; id: number }
  | { type: "restart" };

const clamp = (n: number, lo: number, hi: number) => Math.max(lo, Math.min(hi, n));

/** Soft taper so the last points of a skill are earned, not bought. */
function skillGain(base: number, current: number) {
  if (current < 80) return base;
  return Math.max(1, Math.round(base * (1 - (current - 80) / 40)));
}

export function findAction(state: GameState, actionId: string): ActionDef | null {
  if (!state.selected) return null;
  const node = NODE_MAP[state.selected];
  if (!node) return null;
  return node.actions.find((a) => a.id === actionId) ?? null;
}

export function availability(state: GameState, a: ActionDef): { ok: boolean; why?: string } {
  if (state.phase !== "map") return { ok: false, why: "—" };
  if (state.slots <= 0) return { ok: false, why: "No slots left today" };
  if (a.oncePerDay && state.usedToday.includes(a.id)) return { ok: false, why: "Already done today" };
  if (a.maxUses && (state.usedTotal[a.id] ?? 0) >= a.maxUses) return { ok: false, why: "Sold out" };
  if (a.energy < 0 && state.energy + a.energy < 0) return { ok: false, why: "Too tired" };
  if (a.money < 0 && state.money + a.money < 0) return { ok: false, why: "Not enough money" };
  if (a.spendGift && state.gifts <= 0) return { ok: false, why: "No gift to give" };
  if (a.requires && !a.requires(state)) return { ok: false, why: a.lockedText ?? "Locked" };
  return { ok: true };
}

function pushToasts(items: Omit<Toast, "id">[]) {
  return items.map((t) => ({ ...t, id: ++toastSeq }));
}

function describeRun(a: ActionDef, state: GameState): string {
  return `${a.label} — ${NODE_MAP[state.selected ?? ""]?.name ?? "Ashgrove"}`;
}

export function reducer(state: GameState, action: GameAction): GameState {
  switch (action.type) {
    case "start":
      return { ...state, phase: "map", dawn: true };

    case "restart":
      return { ...initialState(), phase: "map", dawn: true };

    case "select":
      return { ...state, selected: action.id };

    case "dismissToast":
      return { ...state, toasts: state.toasts.filter((t) => t.id !== action.id) };

    case "run": {
      const a = findAction(state, action.actionId);
      if (!a) return state;
      const avail = availability(state, a);
      if (!avail.ok) return state;

      const toasts: Omit<Toast, "id">[] = [];

      let energy = clamp(state.energy + a.energy, 0, MAX_ENERGY);
      let money = Math.max(0, state.money + a.money);
      let gifts = state.gifts;
      let slots = state.slots - 1;
      let slotsToday = state.slotsToday;

      if (a.extraSlot) {
        slotsToday = Math.min(MAX_SLOTS, slotsToday + 1);
        slots += 1;
        toasts.push({ text: "Slept in — one extra slot", tone: "gain" });
      }

      const skills = { ...state.skills };
      for (const [k, v] of Object.entries(a.skills ?? {})) {
        const key = k as SkillKey;
        const applied = skillGain(v ?? 0, skills[key]);
        skills[key] = clamp(skills[key] + applied, 0, 100);
        toasts.push({ text: `${SKILL_MAP[key].name} +${applied}`, tone: "gain" });
      }

      const affection = { ...state.affection };
      for (const [k, v] of Object.entries(a.affection ?? {})) {
        const key = k as CharKey;
        const delta = v ?? 0;
        if (delta === 0) continue;
        affection[key] = clamp(affection[key] + delta, 0, 100);
        toasts.push({ text: `${CHAR_MAP[key].name} +${delta}`, tone: "love" });
      }

      if (a.energy < 0) toasts.push({ text: `Energy ${a.energy}`, tone: "cost" });
      else if (a.energy > 0) toasts.push({ text: `Energy +${a.energy}`, tone: "gain" });
      if (a.money > 0) toasts.push({ text: `Money +${a.money}`, tone: "gain" });
      if (a.money < 0) toasts.push({ text: `Money ${a.money}`, tone: "cost" });

      if (a.buyGift) {
        gifts += 1;
        toasts.push({ text: "Gift token +1", tone: "gain" });
      }
      if (a.spendGift) {
        gifts -= 1;
        toasts.push({ text: "Gift token −1", tone: "cost" });
      }

      const usedTotal = { ...state.usedTotal, [a.id]: (state.usedTotal[a.id] ?? 0) + 1 };
      const log = [
        ...state.log,
        { day: state.day, text: describeRun(a, state) },
      ];

      // Dialogue scenes
      if (a.scene) {
        const scene = nextScene(a.scene, affection[a.scene as CharKey], state.seenScenes);
        if (scene) {
          return {
            ...state,
            energy,
            money,
            gifts,
            slots,
            slotsToday,
            skills,
            affection,
            usedToday: [...state.usedToday, a.id],
            usedTotal,
            log,
            toasts: [...state.toasts, ...pushToasts(toasts)],
            phase: "dialogue",
            selected: null,
            dialogue: { sceneId: scene.id, char: scene.char, line: 0, stage: "lines" },
          };
        }
        toasts.push({ text: "Nothing new to say today", tone: "warn" });
      }

      return {
        ...state,
        energy,
        money,
        gifts,
        slots,
        slotsToday,
        skills,
        affection,
        usedToday: [...state.usedToday, a.id],
        usedTotal,
        log,
        toasts: [...state.toasts, ...pushToasts(toasts)],
      };
    }

    case "advance": {
      const d = state.dialogue;
      if (!d) return state;
      const scene = nextScene(d.char, state.affection[d.char], state.seenScenes);
      if (!scene) return state;
      if (d.stage === "lines") {
        if (d.line < scene.lines.length - 1) return { ...state, dialogue: { ...d, line: d.line + 1 } };
        return { ...state, dialogue: { ...d, stage: "choice" } };
      }
      return state;
    }

    case "choose": {
      const d = state.dialogue;
      if (!d) return state;
      const scene = nextScene(d.char, state.affection[d.char], state.seenScenes);
      if (!scene) return state;
      const opt = scene.options[action.index];
      if (!opt) return state;

      const affection = { ...state.affection };
      affection[d.char] = clamp(affection[d.char] + opt.gain, 0, 100);

      const toasts = pushToasts([
        { text: `${CHAR_MAP[d.char].name} +${opt.gain}`, tone: "love" as const },
      ]);

      return {
        ...state,
        affection,
        seenScenes: [...state.seenScenes, scene.id],
        toasts: [...state.toasts, ...toasts],
        dialogue: { ...d, stage: "reply", reply: opt.reply, gain: opt.gain },
      };
    }

    case "closeDialogue":
      return { ...state, phase: "map", dialogue: null };

    case "endDay": {
      if (state.day >= MAX_DAY) {
        const ending = resolveEnding(state);
        return { ...state, phase: "ending", endingId: ending.id, selected: null, dialogue: null };
      }
      const energy = clamp(state.energy + DAWN_ENERGY, 0, MAX_ENERGY);
      const day = state.day + 1;
      return {
        ...state,
        phase: "map",
        day,
        energy,
        slots: BASE_SLOTS,
        slotsToday: BASE_SLOTS,
        usedToday: [],
        selected: null,
        dialogue: null,
        dawn: true,
        log: [...state.log, { day, text: `Day ${day} — dawn. Energy restored to ${energy}.` }],
      };
    }

    default:
      return state;
  }
}

export const slotLabel = (slotsLeft: number, slotsToday: number) => {
  const used = slotsToday - slotsLeft;
  return SLOT_LABELS[Math.min(SLOT_LABELS.length - 1, used)];
};
