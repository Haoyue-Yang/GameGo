import { useEffect, useReducer, useRef, useState } from "react";
import TopBar from "@/components/TopBar";
import Sidebar from "@/components/Sidebar";
import MapLayer from "@/components/MapLayer";
import ActionBar from "@/components/ActionBar";
import DialogueBox from "@/components/DialogueBox";
import { TitleScreen, EndingScreen } from "@/components/Screens";
import { DawnVeil, Journal, Toasts } from "@/components/Overlays";
import { initialState, reducer } from "@/game/engine";
import { CHARACTERS, SKILLS } from "@/game/content";

export default function App() {
  const [state, dispatch] = useReducer(reducer, undefined, initialState);
  const [journal, setJournal] = useState(false);
  const [veil, setVeil] = useState(false);
  const [veilDay, setVeilDay] = useState(1);
  const seenDay = useRef(1);

  /* dawn transition whenever the day rolls over */
  useEffect(() => {
    if (state.phase !== "map") return;
    if (seenDay.current === state.day) return;
    seenDay.current = state.day;
    setVeilDay(state.day);
    setVeil(true);
    const t = window.setTimeout(() => setVeil(false), 1500);
    return () => window.clearTimeout(t);
  }, [state.day, state.phase]);

  /* keyboard: escape closes panels, 1-3 pick dialogue options */
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        if (journal) setJournal(false);
        else if (state.selected) dispatch({ type: "select", id: null });
        return;
      }
      if (state.phase === "dialogue" && state.dialogue?.stage === "choice") {
        const n = Number(e.key);
        if (n >= 1 && n <= 3) dispatch({ type: "choose", index: n - 1 });
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [journal, state.phase, state.selected, state.dialogue]);

  if (state.phase === "title") {
    return (
      <div className="h-screen w-screen overflow-hidden bg-[#0b0908]">
        <TitleScreen onStart={() => dispatch({ type: "start" })} />
      </div>
    );
  }

  if (state.phase === "ending") {
    return (
      <div className="h-screen w-screen overflow-hidden bg-[#0b0908]">
        <EndingScreen
          state={state}
          onRestart={() => {
            seenDay.current = 1;
            dispatch({ type: "restart" });
          }}
        />
      </div>
    );
  }

  return (
    <div className="flex h-screen w-screen flex-col overflow-hidden bg-[#0b0908]">
      <TopBar state={state} />

      {/* compact stats for narrow viewports */}
      <div className="panel grain flex shrink-0 items-center gap-3 overflow-x-auto border-x-0 border-t-0 px-4 py-2 lg:hidden">
        {SKILLS.map((s) => (
          <span key={s.key} className="flex shrink-0 items-center gap-1.5 text-[11px]">
            <span style={{ color: s.color }} aria-hidden>
              {s.glyph}
            </span>
            <span className="text-parchment/45">{s.name}</span>
            <span className="display" style={{ color: s.color }}>
              {state.skills[s.key]}
            </span>
          </span>
        ))}
        {CHARACTERS.map((c) => (
          <span key={c.key} className="flex shrink-0 items-center gap-1.5 text-[11px]">
            <span style={{ color: c.accent }} aria-hidden>
              ♥
            </span>
            <span className="text-parchment/45">{c.name}</span>
            <span className="display" style={{ color: c.accent }}>
              {state.affection[c.key]}
            </span>
          </span>
        ))}
      </div>

      <div className="flex min-h-0 flex-1">
        <div className="hidden lg:flex">
          <Sidebar
            state={state}
            onEndDay={() => dispatch({ type: "endDay" })}
            onOpenLog={() => setJournal(true)}
          />
        </div>

        <main className="relative flex min-w-0 flex-1 flex-col">
          <MapLayer state={state} onSelect={(id) => dispatch({ type: "select", id })} />

          {state.phase === "map" && (
            <ActionBar
              state={state}
              onRun={(id) => dispatch({ type: "run", actionId: id })}
              onClose={() => dispatch({ type: "select", id: null })}
            />
          )}

          {state.phase === "dialogue" && state.dialogue && (
            <DialogueBox
              state={state}
              onAdvance={() => dispatch({ type: "advance" })}
              onChoose={(i) => dispatch({ type: "choose", index: i })}
              onClose={() => dispatch({ type: "closeDialogue" })}
            />
          )}

          <Toasts toasts={state.toasts} onDone={(id) => dispatch({ type: "dismissToast", id })} />

          <DawnVeil show={veil} day={veilDay} />

          {journal && <Journal state={state} onClose={() => setJournal(false)} />}

          {/* mobile end-day */}
          {!state.selected && (
          <button
            type="button"
            onClick={() => dispatch({ type: "endDay" })}
            className="absolute bottom-4 right-4 z-30 rounded-xl px-4 py-3 lg:hidden"
            style={{
              background: "linear-gradient(135deg,#e6ac63,#c07f38)",
              boxShadow: "0 12px 30px -14px rgba(230,172,99,0.8)",
            }}
          >
            <span className="display text-[13px] font-semibold text-[#2a1a08]">End day</span>
          </button>
          )}
        </main>
      </div>
    </div>
  );
}
