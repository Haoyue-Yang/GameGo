import * as THREE from "three";
import {
  box, cone, CelSkin, cyl, glowMaterial, inkOutline, mergeParts, sph, type StageCtx,
} from "./cel";
import { BOSSES, type BossKind, type EnemyKind, type RealmDef } from "../game/data";

export interface ActorVisual {
  group: THREE.Group;
  skin: CelSkin;
  body: THREE.Mesh;
  accent: THREE.Mesh;
  weapon: THREE.Object3D | null;
  cape: THREE.Object3D | null;
  height: number;
  glow: THREE.Object3D[];
}

type P = [number, number, number];

// ---------------------------------------------------------------------------
// CHAMPION
// ---------------------------------------------------------------------------

export function buildChampion(ctx: StageCtx, accent: number): ActorVisual {
  const skin = new CelSkin(ctx);
  const group = new THREE.Group();

  const bodyMat = skin.make({ color: 0x22334f, shade: 0.24, rim: 0x9fd8ff, rimPower: 2.0, outline: 0.035 });
  const plateMat = skin.make({ color: 0x3d5a80, shade: 0.3, rim: 0xd6f2ff, rimPower: 1.7, outline: 0.03 });
  const trimMat = skin.make({
    color: 0x0e1622, shade: 0.2, emissive: accent, emissiveStrength: 1.15,
    rim: accent, rimPower: 2.2, outline: 0.02,
  });

  const body = new THREE.Mesh(
    mergeParts([
      // legs
      { g: box(0.3, 0.72, 0.34), p: [-0.19, 0.36, 0] as P },
      { g: box(0.3, 0.72, 0.34), p: [0.19, 0.36, 0] as P },
      // boots
      { g: box(0.36, 0.2, 0.5), p: [-0.19, 0.1, 0.05] as P },
      { g: box(0.36, 0.2, 0.5), p: [0.19, 0.1, 0.05] as P },
      // hips + torso
      { g: box(0.62, 0.26, 0.42), p: [0, 0.85, 0] as P },
      { g: box(0.68, 0.62, 0.44), p: [0, 1.26, 0] as P },
      { g: box(0.56, 0.2, 0.4), p: [0, 1.62, 0] as P },
      // arms
      { g: box(0.2, 0.6, 0.22), p: [-0.46, 1.28, 0] as P },
      { g: box(0.2, 0.6, 0.22), p: [0.46, 1.28, 0] as P },
      // head
      { g: box(0.34, 0.34, 0.36), p: [0, 1.86, 0] as P },
      { g: cone(0.26, 0.3, 4), p: [0, 2.12, 0] as P },
    ]),
    bodyMat
  );
  inkOutline(body, 0.038);
  group.add(body);

  const plate = new THREE.Mesh(
    mergeParts([
      { g: box(0.3, 0.26, 0.3), p: [-0.5, 1.58, 0] as P },
      { g: box(0.3, 0.26, 0.3), p: [0.5, 1.58, 0] as P },
      { g: box(0.74, 0.18, 0.48), p: [0, 1.5, 0] as P },
      { g: box(0.4, 0.12, 0.4), p: [0, 0.86, 0] as P },
    ]),
    plateMat
  );
  inkOutline(plate, 0.03);
  group.add(plate);

  const trim = new THREE.Mesh(
    mergeParts([
      { g: box(0.26, 0.06, 0.06), p: [0, 1.88, 0.19] as P },
      { g: box(0.1, 0.34, 0.06), p: [0, 1.28, 0.23] as P },
      { g: box(0.06, 0.06, 0.3), p: [0, 1.06, 0] as P },
    ]),
    trimMat
  );
  group.add(trim);

  // cape
  const cape = new THREE.Group();
  const capeMesh = new THREE.Mesh(
    mergeParts([
      { g: box(0.66, 0.5, 0.08), p: [0, -0.25, 0] as P },
      { g: box(0.56, 0.5, 0.08), p: [0, -0.75, -0.02] as P },
      { g: box(0.44, 0.4, 0.08), p: [0, -1.18, -0.04] as P },
    ]),
    skin.make({ color: 0x8c1f36, shade: 0.22, rim: 0xff8fa8, rimPower: 2.6, outline: 0.03 })
  );
  inkOutline(capeMesh, 0.03);
  cape.add(capeMesh);
  cape.position.set(0, 1.6, -0.24);
  group.add(cape);

  // sword
  const weapon = new THREE.Group();
  const blade = new THREE.Mesh(
    mergeParts([
      { g: box(0.12, 1.5, 0.05), p: [0, 0.85, 0] as P },
      { g: cone(0.09, 0.28, 4), p: [0, 1.72, 0] as P },
      { g: box(0.34, 0.08, 0.1), p: [0, 0.1, 0] as P },
      { g: cyl(0.05, 0.05, 0.3, 6), p: [0, -0.08, 0] as P },
    ]),
    skin.make({
      color: 0xd8ecff, shade: 0.42, rim: 0xffffff, rimPower: 1.4,
      emissive: accent, emissiveStrength: 0.35, outline: 0.022,
    })
  );
  inkOutline(blade, 0.026);
  weapon.add(blade);
  const edge = new THREE.Mesh(box(0.035, 1.5, 0.07), glowMaterial(accent, 0.55));
  edge.position.set(0, 0.85, 0);
  weapon.add(edge);
  weapon.position.set(0.52, 1.3, 0.1);
  weapon.rotation.z = -0.25;
  group.add(weapon);

  // ground glow
  const glow: THREE.Object3D[] = [];
  const aura = new THREE.Mesh(new THREE.RingGeometry(0.5, 1.0, 32), glowMaterial(accent, 0.28));
  aura.rotation.x = -Math.PI / 2;
  aura.position.y = 0.03;
  group.add(aura);
  glow.push(aura);

  return { group, skin, body, accent: trim, weapon, cape, height: 2.25, glow };
}

// ---------------------------------------------------------------------------
// ENEMIES
// ---------------------------------------------------------------------------

const ENEMY_BODY = 0x241d2c;

export function buildEnemy(ctx: StageCtx, kind: EnemyKind, def: RealmDef): ActorVisual {
  const skin = new CelSkin(ctx);
  const group = new THREE.Group();
  const acc = def.accent;
  const acc2 = def.accent2;

  // pale steel rim keeps every silhouette readable against all three saturated realms
  const bodyMat = skin.make({
    color: kind === "brute" ? 0x2b2233 : ENEMY_BODY,
    shade: 0.2,
    rim: 0xa9c8e6,
    rimPower: 2.6,
    outline: 0.032,
  });
  const accentMat = skin.make({
    color: 0x0b0a10, shade: 0.15, emissive: acc, emissiveStrength: 1.35,
    rim: acc, rimPower: 2.0, outline: 0.018,
  });

  let body: THREE.Mesh;
  let accent: THREE.Mesh;
  let weapon: THREE.Object3D | null = null;
  let cape: THREE.Object3D | null = null;
  let height = 1.8;

  if (kind === "grunt") {
    body = new THREE.Mesh(
      mergeParts([
        { g: box(0.24, 0.5, 0.26), p: [-0.16, 0.25, 0] as P },
        { g: box(0.24, 0.5, 0.26), p: [0.16, 0.25, 0] as P },
        { g: box(0.5, 0.56, 0.36), p: [0, 0.78, 0.04] as P },
        { g: box(0.2, 0.46, 0.2), p: [-0.36, 0.82, 0.02] as P },
        { g: box(0.2, 0.46, 0.2), p: [0.36, 0.82, 0.02] as P },
        { g: box(0.3, 0.28, 0.3), p: [0, 1.16, 0.06] as P },
        { g: box(0.16, 0.1, 0.16), p: [-0.24, 1.06, 0.06] as P },
        { g: box(0.16, 0.1, 0.16), p: [0.24, 1.06, 0.06] as P },
      ]),
      bodyMat
    );
    accent = new THREE.Mesh(
      mergeParts([
        { g: box(0.22, 0.05, 0.05), p: [0, 1.18, 0.22] as P },
        { g: box(0.3, 0.06, 0.06), p: [0, 0.9, 0.19] as P },
      ]),
      accentMat
    );
    weapon = new THREE.Group();
    const claw = new THREE.Mesh(
      mergeParts([
        { g: box(0.09, 0.62, 0.05), p: [0, 0.3, 0] as P },
        { g: cone(0.08, 0.2, 4), p: [0, 0.72, 0] as P },
      ]),
      skin.make({ color: 0x8f9aa8, shade: 0.3, rim: acc, rimPower: 2.0, outline: 0.02 })
    );
    inkOutline(claw, 0.024);
    weapon.add(claw);
    weapon.position.set(0.42, 0.9, 0.1);
    weapon.rotation.z = -0.3;
    group.add(weapon);
    height = 1.4;
  } else if (kind === "stalker") {
    body = new THREE.Mesh(
      mergeParts([
        { g: box(0.16, 0.78, 0.18), p: [-0.14, 0.39, 0] as P },
        { g: box(0.16, 0.78, 0.18), p: [0.14, 0.39, 0] as P },
        { g: box(0.36, 0.44, 0.26), p: [0, 0.98, 0.12] as P },
        { g: box(0.14, 0.5, 0.14), p: [-0.26, 1.0, 0.1] as P },
        { g: box(0.14, 0.5, 0.14), p: [0.26, 1.0, 0.1] as P },
        { g: cone(0.16, 0.34, 4), p: [0, 1.32, 0.2] as P },
        { g: box(0.08, 0.5, 0.08), p: [0, 1.0, -0.16] as P },
      ]),
      bodyMat
    );
    accent = new THREE.Mesh(
      mergeParts([
        { g: box(0.05, 0.05, 0.1), p: [-0.07, 1.34, 0.32] as P },
        { g: box(0.05, 0.05, 0.1), p: [0.07, 1.34, 0.32] as P },
        { g: box(0.1, 0.24, 0.05), p: [0, 1.02, 0.24] as P },
      ]),
      accentMat
    );
    weapon = new THREE.Group();
    const blade = new THREE.Mesh(
      mergeParts([
        { g: cone(0.06, 0.5, 4), p: [0, 0.25, 0] as P },
        { g: cone(0.05, 0.36, 4), p: [0.14, 0.18, 0] as P },
      ]),
      skin.make({ color: 0xa8b6c6, shade: 0.3, rim: acc, rimPower: 2.0, outline: 0.018 })
    );
    inkOutline(blade, 0.02);
    weapon.add(blade);
    weapon.position.set(0.3, 1.0, 0.2);
    weapon.rotation.z = -0.5;
    group.add(weapon);
    height = 1.5;
  } else if (kind === "brute") {
    body = new THREE.Mesh(
      mergeParts([
        { g: box(0.42, 0.6, 0.44), p: [-0.28, 0.3, 0] as P },
        { g: box(0.42, 0.6, 0.44), p: [0.28, 0.3, 0] as P },
        { g: box(0.98, 0.8, 0.6), p: [0, 1.0, 0] as P },
        { g: box(1.3, 0.3, 0.7), p: [0, 1.44, 0] as P },
        { g: box(0.3, 0.72, 0.32), p: [-0.72, 1.14, 0] as P },
        { g: box(0.3, 0.72, 0.32), p: [0.72, 1.14, 0] as P },
        { g: box(0.34, 0.26, 0.34), p: [0, 1.66, 0.06] as P },
      ]),
      bodyMat
    );
    accent = new THREE.Mesh(
      mergeParts([
        { g: box(0.24, 0.06, 0.06), p: [0, 1.68, 0.2] as P },
        { g: box(0.5, 0.08, 0.08), p: [0, 1.3, 0.31] as P },
        { g: box(0.1, 0.3, 0.08), p: [-0.3, 1.44, 0.36] as P },
        { g: box(0.1, 0.3, 0.08), p: [0.3, 1.44, 0.36] as P },
      ]),
      accentMat
    );
    weapon = new THREE.Group();
    const maul = new THREE.Mesh(
      mergeParts([
        { g: cyl(0.09, 0.09, 1.1, 6), p: [0, 0.55, 0] as P },
        { g: box(0.44, 0.44, 0.44), p: [0, 1.2, 0] as P },
      ]),
      skin.make({ color: 0x54465c, shade: 0.28, rim: acc, rimPower: 2.2, outline: 0.028 })
    );
    inkOutline(maul, 0.032);
    weapon.add(maul);
    weapon.position.set(0.82, 1.1, 0.1);
    weapon.rotation.z = -0.2;
    group.add(weapon);
    height = 1.9;
  } else {
    // caster — floating robed chanter
    body = new THREE.Mesh(
      mergeParts([
        { g: cone(0.42, 1.05, 8), p: [0, 0.52, 0] as P },
        { g: box(0.44, 0.4, 0.34), p: [0, 1.16, 0] as P },
        { g: box(0.2, 0.44, 0.2), p: [-0.32, 1.2, 0] as P },
        { g: box(0.2, 0.44, 0.2), p: [0.32, 1.2, 0] as P },
        { g: box(0.28, 0.3, 0.28), p: [0, 1.52, 0] as P },
        { g: cone(0.24, 0.36, 6), p: [0, 1.78, 0] as P },
      ]),
      bodyMat
    );
    accent = new THREE.Mesh(
      mergeParts([
        { g: box(0.2, 0.06, 0.06), p: [0, 1.54, 0.16] as P },
        { g: box(0.3, 0.05, 0.05), p: [0, 1.0, 0.18] as P },
      ]),
      accentMat
    );
    const orb = new THREE.Mesh(sph(0.17, 12), glowMaterial(acc2, 0.95));
    orb.position.set(0.38, 1.34, 0.24);
    group.add(orb);
    const halo = new THREE.Mesh(new THREE.RingGeometry(0.5, 0.62, 24), glowMaterial(acc, 0.4));
    halo.rotation.x = -Math.PI / 2;
    halo.position.y = 0.04;
    group.add(halo);
    height = 1.9;
  }

  inkOutline(body, 0.036);
  group.add(body);
  group.add(accent);

  return { group, skin, body, accent, weapon, cape, height, glow: [] };
}

// ---------------------------------------------------------------------------
// BOSSES — 2.5x stat bosses with their own silhouettes
// ---------------------------------------------------------------------------

export function buildBoss(ctx: StageCtx, kind: BossKind, def: RealmDef): ActorVisual {
  const skin = new CelSkin(ctx);
  const group = new THREE.Group();
  const acc = def.accent;
  const acc2 = def.accent2;
  const glow: THREE.Object3D[] = [];

  const shellMat = skin.make({ color: 0x1d1a26, shade: 0.18, rim: 0xbcd6f2, rimPower: 2.2, outline: 0.04 });
  const plateMat = skin.make({ color: 0x3a3348, shade: 0.26, rim: acc2, rimPower: 1.8, outline: 0.035 });
  const coreMat = skin.make({
    color: 0x0a0810, shade: 0.1, emissive: acc, emissiveStrength: 1.6,
    rim: acc, rimPower: 1.6, outline: 0.02,
  });

  let body: THREE.Mesh;
  let accent: THREE.Mesh;
  let weapon: THREE.Object3D | null = null;
  let height = 4.2;

  if (kind === "warden") {
    body = new THREE.Mesh(
      mergeParts([
        { g: box(0.6, 1.0, 0.66), p: [-0.42, 0.5, 0] as P },
        { g: box(0.6, 1.0, 0.66), p: [0.42, 0.5, 0] as P },
        { g: box(1.5, 1.3, 0.95), p: [0, 1.65, 0] as P },
        { g: box(2.2, 0.45, 1.1), p: [0, 2.42, 0] as P },
        { g: box(0.44, 1.1, 0.46), p: [-1.06, 1.7, 0] as P },
        { g: box(0.44, 1.1, 0.46), p: [1.06, 1.7, 0] as P },
        { g: box(0.5, 0.44, 0.5), p: [0, 2.78, 0.08] as P },
      ]),
      shellMat
    );
    accent = new THREE.Mesh(
      mergeParts([
        { g: box(0.42, 0.09, 0.09), p: [0, 2.8, 0.26] as P },
        { g: box(0.9, 0.12, 0.1), p: [0, 2.0, 0.5] as P },
        { g: box(0.14, 0.5, 0.1), p: [-0.5, 2.42, 0.56] as P },
        { g: box(0.14, 0.5, 0.1), p: [0.5, 2.42, 0.56] as P },
      ]),
      coreMat
    );
    const pauldrons = new THREE.Mesh(
      mergeParts([
        { g: box(0.7, 0.5, 0.9), p: [-1.1, 2.5, 0] as P },
        { g: box(0.7, 0.5, 0.9), p: [1.1, 2.5, 0] as P },
      ]),
      plateMat
    );
    inkOutline(pauldrons, 0.04);
    group.add(pauldrons);
    weapon = new THREE.Group();
    const greatsword = new THREE.Mesh(
      mergeParts([
        { g: box(0.2, 2.6, 0.08), p: [0, 1.3, 0] as P },
        { g: cone(0.16, 0.5, 4), p: [0, 2.85, 0] as P },
        { g: box(0.7, 0.14, 0.16), p: [0, 0.14, 0] as P },
      ]),
      skin.make({ color: 0xc9d8e8, shade: 0.36, rim: acc, rimPower: 1.5, outline: 0.03 })
    );
    inkOutline(greatsword, 0.036);
    weapon.add(greatsword);
    const edge = new THREE.Mesh(box(0.05, 2.6, 0.11), glowMaterial(acc, 0.5));
    edge.position.set(0, 1.3, 0);
    weapon.add(edge);
    weapon.position.set(1.2, 1.7, 0.2);
    weapon.rotation.z = -0.3;
    group.add(weapon);
    height = 3.4;
  } else if (kind === "overseer") {
    body = new THREE.Mesh(
      mergeParts([
        { g: sph(1.0, 16), p: [0, 2.1, 0] as P },
        { g: cone(0.7, 1.5, 8), p: [0, 0.75, 0] as P },
        { g: box(0.3, 1.0, 0.3), p: [-1.1, 2.2, 0] as P },
        { g: box(0.3, 1.0, 0.3), p: [1.1, 2.2, 0] as P },
        { g: box(0.24, 1.4, 0.24), p: [-0.8, 3.2, 0] as P },
        { g: box(0.24, 1.4, 0.24), p: [0.8, 3.2, 0] as P },
      ]),
      shellMat
    );
    accent = new THREE.Mesh(
      mergeParts([
        { g: sph(0.42, 14), p: [0, 2.15, 0.72] as P },
        { g: box(0.5, 0.08, 0.08), p: [0, 3.9, 0] as P },
      ]),
      coreMat
    );
    const ring1 = new THREE.Mesh(new THREE.TorusGeometry(1.7, 0.1, 6, 40), plateMat);
    ring1.position.set(0, 2.1, 0);
    inkOutline(ring1, 0.03);
    group.add(ring1);
    const ring2 = new THREE.Mesh(new THREE.TorusGeometry(2.2, 0.07, 6, 44), plateMat);
    ring2.position.set(0, 2.1, 0);
    ring2.rotation.x = Math.PI / 2.4;
    inkOutline(ring2, 0.03);
    group.add(ring2);
    const eye = new THREE.Mesh(sph(0.3, 12), glowMaterial(acc2, 1.0));
    eye.position.set(0, 2.15, 0.95);
    group.add(eye);
    glow.push(ring1, ring2, eye);
    weapon = ring1;
    height = 4.4;
  } else {
    body = new THREE.Mesh(
      mergeParts([
        { g: sph(1.35, 16), p: [0, 1.5, 0] as P },
        { g: cyl(0.5, 0.9, 1.4, 8), p: [0, 0.55, 0] as P },
        { g: box(0.34, 1.5, 0.34), p: [-1.2, 1.9, 0.2] as P },
        { g: box(0.34, 1.5, 0.34), p: [1.2, 1.9, 0.2] as P },
        { g: box(0.28, 1.1, 0.28), p: [-0.9, 3.0, -0.2] as P },
        { g: box(0.28, 1.1, 0.28), p: [0.9, 3.0, -0.2] as P },
      ]),
      shellMat
    );
    accent = new THREE.Mesh(
      mergeParts([
        { g: sph(0.34, 12), p: [-1.3, 2.75, 0.2] as P },
        { g: sph(0.34, 12), p: [1.3, 2.75, 0.2] as P },
        { g: sph(0.26, 12), p: [-0.9, 3.6, -0.2] as P },
        { g: sph(0.26, 12), p: [0.9, 3.6, -0.2] as P },
      ]),
      coreMat
    );
    const cap = new THREE.Mesh(sph(1.9, 18), plateMat);
    cap.position.set(0, 2.5, 0);
    cap.scale.set(1, 0.42, 1);
    inkOutline(cap, 0.045);
    group.add(cap);
    const under = new THREE.Mesh(sph(1.85, 18), glowMaterial(acc, 0.5));
    under.position.set(0, 2.4, 0);
    under.scale.set(1, 0.4, 1);
    group.add(under);
    glow.push(under);
    height = 4.6;
  }

  inkOutline(body, 0.048);
  group.add(body);
  group.add(accent);

  const bossGlow = new THREE.Mesh(new THREE.RingGeometry(1.2, 2.6, 40), glowMaterial(acc, 0.3));
  bossGlow.rotation.x = -Math.PI / 2;
  bossGlow.position.y = 0.04;
  group.add(bossGlow);
  glow.push(bossGlow);

  return { group, skin, body, accent, weapon, cape: null, height, glow };
}

export const bossName = (kind: BossKind) => BOSSES[kind].name;
