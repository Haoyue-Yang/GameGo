import * as THREE from "three";
import {
  box, cone, cyl, glowMaterial, mergeParts, sph, torus, type StageCtx,
} from "./cel";
import type { RealmDef, RealmId } from "../game/data";

export interface Stage {
  group: THREE.Group;
  ctx: StageCtx;
  floorMat: THREE.ShaderMaterial;
  hide: THREE.Object3D[];
  portals: THREE.Mesh[];
  update: (t: number, dt: number) => void;
}

// ---------------------------------------------------------------------------
// Glossy reflective floor
// ---------------------------------------------------------------------------

export function makeFloor(ctx: StageCtx, base: number, line: number, accent: number) {
  const geo = new THREE.PlaneGeometry(190, 130, 1, 1);
  geo.rotateX(-Math.PI / 2);
  const mat = new THREE.ShaderMaterial({
    uniforms: {
      uRefl: { value: null },
      uBase: { value: new THREE.Color(base) },
      uLine: { value: new THREE.Color(line) },
      uAccent: { value: new THREE.Color(accent) },
      uFog: { value: new THREE.Color(ctx.fog) },
      uTime: { value: 0 },
      uFogNear: { value: ctx.fogNear },
      uFogFar: { value: ctx.fogFar },
      uReflTex: { value: 0.9 },
    },
    vertexShader: /* glsl */ `
      varying vec3 vW;
      varying vec4 vClip;
      void main() {
        vec4 wp = modelMatrix * vec4(position, 1.0);
        vW = wp.xyz;
        vec4 mv = viewMatrix * wp;
        vClip = projectionMatrix * mv;
        gl_Position = vClip;
      }
    `,
    fragmentShader: /* glsl */ `
      uniform sampler2D uRefl;
      uniform vec3 uBase, uLine, uAccent, uFog;
      uniform float uTime, uFogNear, uFogFar, uReflTex;
      varying vec3 vW;
      varying vec4 vClip;
      void main() {
        vec2 suv = (vClip.xy / vClip.w) * 0.5 + 0.5;
        suv.x = 1.0 - suv.x;
        vec3 refl = texture2D(uRefl, suv).rgb
                  + texture2D(uRefl, suv + vec2(0.005, 0.0)).rgb
                  + texture2D(uRefl, suv - vec2(0.005, 0.0)).rgb
                  + texture2D(uRefl, suv + vec2(0.0, 0.007)).rgb
                  + texture2D(uRefl, suv - vec2(0.0, 0.007)).rgb;
        refl *= 0.2;
        float dist = length(vW.xz - cameraPosition.xz);
        float fogF = smoothstep(uFogNear, uFogFar, dist);
        vec3 col = uBase;
        col = mix(col, refl * uReflTex, 0.9 * (1.0 - fogF * 0.7));
        float gx = abs(fract(vW.x * 0.5) - 0.5);
        float gz = abs(fract(vW.z * 0.5) - 0.5);
        float g = smoothstep(0.055, 0.0, min(gx, gz));
        col += uLine * g * 0.26 * (1.0 - fogF * 0.55);
        float lane = smoothstep(3.6, 0.0, abs(vW.z));
        col += uAccent * lane * 0.05;
        vec3 V = normalize(cameraPosition - vW);
        float fres = pow(1.0 - clamp(V.y, 0.0, 1.0), 4.0);
        col += uAccent * fres * 0.11;
        float sweep = exp(-pow((vW.x - sin(uTime * 0.13) * 24.0) * 0.15, 2.0));
        col += uAccent * sweep * 0.05 * (1.0 - fogF);
        col = mix(col, uFog, fogF);
        gl_FragColor = vec4(col, 1.0);
      }
    `,
  });
  const mesh = new THREE.Mesh(geo, mat);
  mesh.position.set(0, 0, -30);
  mesh.receiveShadow = false;
  return { mesh, mat };
}

// ---------------------------------------------------------------------------
// helpers
// ---------------------------------------------------------------------------

function flat(color: number) {
  return new THREE.MeshBasicMaterial({ color, fog: true });
}

function sil(geo: THREE.BufferGeometry, color: number) {
  return new THREE.Mesh(geo, flat(color));
}

function makeParticles(
  count: number,
  color: number,
  spread: { x: number; y: number; z: number },
  center: THREE.Vector3,
  speed: number,
  size: number
) {
  const pos = new Float32Array(count * 3);
  const seed = new Float32Array(count);
  for (let i = 0; i < count; i++) {
    pos[i * 3] = center.x + (Math.random() - 0.5) * spread.x;
    pos[i * 3 + 1] = center.y + Math.random() * spread.y;
    pos[i * 3 + 2] = center.z + (Math.random() - 0.5) * spread.z;
    seed[i] = Math.random();
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute("position", new THREE.BufferAttribute(pos, 3));
  geo.setAttribute("aSeed", new THREE.BufferAttribute(seed, 1));
  const mat = new THREE.ShaderMaterial({
    uniforms: {
      uColor: { value: new THREE.Color(color) },
      uTime: { value: 0 },
      uSize: { value: size },
      uSpeed: { value: speed },
      uH: { value: spread.y },
    },
    vertexShader: /* glsl */ `
      attribute float aSeed;
      uniform float uTime, uSize, uSpeed, uH;
      varying float vA;
      void main() {
        vec3 p = position;
        p.y = mod(p.y + uTime * uSpeed * (0.4 + aSeed), uH);
        p.x += sin(uTime * 0.5 + aSeed * 30.0) * 0.6;
        vec4 mv = viewMatrix * vec4(p, 1.0);
        vA = 0.35 + 0.65 * aSeed;
        gl_PointSize = uSize * (1.0 + aSeed) * (14.0 / max(-mv.z, 0.1));
        gl_Position = projectionMatrix * mv;
      }
    `,
    fragmentShader: /* glsl */ `
      uniform vec3 uColor;
      varying float vA;
      void main() {
        vec2 d = gl_PointCoord - 0.5;
        float r = length(d);
        if (r > 0.5) discard;
        float a = smoothstep(0.5, 0.05, r) * vA;
        gl_FragColor = vec4(uColor, a);
      }
    `,
    transparent: true,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
  });
  const pts = new THREE.Points(geo, mat);
  pts.frustumCulled = false;
  return { pts, mat };
}

function glowRing(r: number, t: number, color: number, opacity = 0.9) {
  const m = new THREE.Mesh(torus(r, t, 40), glowMaterial(color, opacity));
  m.rotation.x = Math.PI / 2;
  return m;
}

// ---------------------------------------------------------------------------
// HUB — cool blue staging room
// ---------------------------------------------------------------------------

export function buildHub(): Stage {
  const ctx: StageCtx = {
    fog: 0x0a1524,
    fogNear: 14,
    fogFar: 58,
    light: new THREE.Vector3(0.35, 0.9, 0.45).normalize(),
  };
  const group = new THREE.Group();
  const hide: THREE.Object3D[] = [];
  const portals: THREE.Mesh[] = [];
  const tints: THREE.Mesh[] = [];

  const { mesh: floor, mat: floorMat } = makeFloor(ctx, 0x0a1420, 0x3f7fbf, 0x4de3ff);
  group.add(floor);
  hide.push(floor);

  // back wall with glowing seams
  const wall = new THREE.Group();
  const wallParts = [
    { g: box(64, 26, 1.2), p: [0, 13, -19] as [number, number, number] },
  ];
  wall.add(sil(mergeParts(wallParts), 0x0d1a2a));
  for (let i = -5; i <= 5; i++) {
    const seam = new THREE.Mesh(box(0.14, 22, 0.2), glowMaterial(0x4de3ff, 0.5));
    seam.position.set(i * 5.4, 11, -18.3);
    wall.add(seam);
  }
  for (let i = 0; i < 3; i++) {
    const h = new THREE.Mesh(box(58, 0.1, 0.2), glowMaterial(0x4de3ff, 0.35));
    h.position.set(0, 4 + i * 6, -18.3);
    wall.add(h);
  }
  group.add(wall);

  // ceiling trusses
  for (let i = 0; i < 5; i++) {
    const truss = new THREE.Mesh(box(50, 0.5, 0.5), flat(0x14243a));
    truss.position.set(0, 15.5, -14 + i * 4);
    group.add(truss);
    for (let k = -3; k <= 3; k++) {
      const lamp = new THREE.Mesh(box(2.6, 0.3, 0.9), glowMaterial(0xbfe9ff, 0.55));
      lamp.position.set(k * 6.5, 15.1, -14 + i * 4);
      group.add(lamp);
    }
  }

  // side pillars
  for (const sx of [-1, 1]) {
    for (let i = 0; i < 3; i++) {
      const p = new THREE.Mesh(
        mergeParts([
          { g: box(1.5, 17, 1.5), p: [0, 8.5, 0] as [number, number, number] },
          { g: box(2.1, 0.6, 2.1), p: [0, 0.3, 0] as [number, number, number] },
          { g: box(2.1, 0.6, 2.1), p: [0, 17, 0] as [number, number, number] },
        ]),
        flat(0x16283e)
      );
      p.position.set(sx * (10.5 + i * 0.6), 0, -6 - i * 5);
      group.add(p);
    }
  }

  // pedestal
  const ped = new THREE.Mesh(
    mergeParts([
      { g: cyl(2.0, 2.4, 0.5, 12), p: [0, 0.25, 0] as [number, number, number] },
      { g: cyl(1.5, 1.8, 0.35, 12), p: [0, 0.62, 0] as [number, number, number] },
    ]),
    flat(0x1b3350)
  );
  ped.position.set(0, 0, 1.2);
  group.add(ped);
  const pedRing = glowRing(2.1, 0.05, 0x4de3ff, 0.85);
  pedRing.position.set(0, 0.9, 1.2);
  group.add(pedRing);

  // realm portals
  const realmList: RealmId[] = ["colosseum", "conduit", "wastes"];
  const portalColors = [0xffb347, 0xff3ec8, 0x9dff5a];
  realmList.forEach((id, i) => {
    const x = (i - 1) * 9.2;
    const col = portalColors[i];
    const g = new THREE.Group();
    const frame = new THREE.Mesh(
      mergeParts([
        { g: box(1.1, 8.4, 1.1), p: [-3.1, 4.2, 0] as [number, number, number] },
        { g: box(1.1, 8.4, 1.1), p: [3.1, 4.2, 0] as [number, number, number] },
        { g: box(7.3, 1.2, 1.1), p: [0, 8.4, 0] as [number, number, number] },
        { g: box(7.3, 0.5, 1.6), p: [0, 0.25, 0] as [number, number, number] },
      ]),
      flat(0x152840)
    );
    g.add(frame);
    const veil = new THREE.Mesh(
      new THREE.PlaneGeometry(5.2, 7.8),
      new THREE.ShaderMaterial({
        uniforms: {
          uColor: { value: new THREE.Color(col) },
          uTime: { value: 0 },
          uLocked: { value: 0 },
        },
        vertexShader: `varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }`,
        fragmentShader: /* glsl */ `
          uniform vec3 uColor; uniform float uTime; uniform float uLocked;
          varying vec2 vUv;
          void main() {
            float d = distance(vUv, vec2(0.5, 0.5));
            float rings = sin(d * 26.0 - uTime * 2.4) * 0.5 + 0.5;
            float a = smoothstep(0.62, 0.05, d) * (0.35 + rings * 0.55);
            vec3 c = mix(uColor, vec3(0.12, 0.16, 0.22), uLocked);
            gl_FragColor = vec4(c, a * (1.0 - uLocked * 0.7));
          }
        `,
        transparent: true,
        depthWrite: false,
        blending: THREE.AdditiveBlending,
      })
    );
    veil.position.set(0, 4.2, -0.1);
    g.add(veil);
    const halo = glowRing(3.6, 0.06, col, 0.7);
    halo.rotation.x = 0;
    halo.position.set(0, 4.2, -0.3);
    g.add(halo);
    const hit = new THREE.Mesh(new THREE.PlaneGeometry(6.4, 8.2), new THREE.MeshBasicMaterial({ visible: false }));
    hit.position.set(0, 4.2, 0.2);
    hit.userData.realm = id;
    hit.userData.veil = veil.material;
    g.add(hit);
    portals.push(hit);
    g.position.set(x, 0, -13.5);
    group.add(g);
    tints.push(veil as unknown as THREE.Mesh, halo as unknown as THREE.Mesh);
  });

  // foreground framing
  const fg = new THREE.Group();
  for (const sx of [-1, 1]) {
    const col = new THREE.Mesh(
      mergeParts([
        { g: box(1.7, 9, 1.7), p: [0, 4.5, 0] as [number, number, number] },
        { g: box(2.4, 0.5, 2.4), p: [0, 8.9, 0] as [number, number, number] },
      ]),
      flat(0x05090f)
    );
    col.position.set(sx * 5.6, 0, 6.4);
    fg.add(col);
    const rail = new THREE.Mesh(box(14, 0.35, 0.5), flat(0x05090f));
    rail.position.set(sx * 4, 2.2, 7.4);
    fg.add(rail);
  }
  group.add(fg);
  hide.push(fg);

  const dust = makeParticles(220, 0x9fd8ff, { x: 34, y: 14, z: 26 }, new THREE.Vector3(0, 0, -6), 0.5, 1.6);
  group.add(dust.pts);

  return {
    group,
    ctx,
    floorMat,
    hide,
    portals,
    update: (t) => {
      floorMat.uniforms.uTime.value = t;
      dust.mat.uniforms.uTime.value = t;
      for (const m of tints) {
        const mm = m.material as THREE.ShaderMaterial;
        if (mm.uniforms?.uTime) mm.uniforms.uTime.value = t;
      }
    },
  };
}

export function setPortalLocked(portals: THREE.Mesh[], unlocked: RealmId[]) {
  for (const p of portals) {
    const mat = p.userData.veil as THREE.ShaderMaterial | undefined;
    if (mat?.uniforms?.uLocked) {
      mat.uniforms.uLocked.value = unlocked.includes(p.userData.realm as RealmId) ? 0 : 1;
    }
  }
}

// ---------------------------------------------------------------------------
// REALMS
// ---------------------------------------------------------------------------

export function buildRealm(def: RealmDef): Stage {
  const ctx: StageCtx = {
    fog: def.fog,
    fogNear: def.fogNear,
    fogFar: def.fogFar,
    light: new THREE.Vector3(0.3, 0.92, 0.4).normalize(),
  };
  const group = new THREE.Group();
  const hide: THREE.Object3D[] = [];
  const anim: ((t: number, dt: number) => void)[] = [];

  const { mesh: floor, mat: floorMat } = makeFloor(ctx, def.floor, def.floorLine, def.accent);
  group.add(floor);
  hide.push(floor);

  if (def.id === "colosseum") buildColosseum(group, def, hide, anim);
  else if (def.id === "conduit") buildConduit(group, def, hide, anim);
  else buildWastes(group, def, hide, anim);

  return {
    group,
    ctx,
    floorMat,
    hide,
    portals: [],
    update: (t, dt) => {
      floorMat.uniforms.uTime.value = t;
      for (const f of anim) f(t, dt);
    },
  };
}

// --- steel colosseum -------------------------------------------------------
function buildColosseum(
  g: THREE.Group, def: RealmDef, hide: THREE.Object3D[], anim: ((t: number, dt: number) => void)[]
) {
  const dark = 0x101a26;
  const mid = 0x16232f;
  const deep = 0x0b131c;

  // far tier — silhouetted crowd
  for (let i = 0; i < 3; i++) {
    const z = -30 - i * 8;
    const tier = new THREE.Mesh(box(90, 12 + i * 3, 2), flat(i === 0 ? deep : 0x080e15));
    tier.position.set(0, 6 + i * 1.5, z);
    g.add(tier);
    for (let k = -14; k <= 14; k++) {
      const h = 1.2 + Math.random() * 1.4;
      const c = new THREE.Mesh(box(0.8, h, 0.8), flat(0x060b11));
      c.position.set(k * 2.6 + Math.random(), 12 + i * 1.5, z + 1.4);
      g.add(c);
    }
  }

  // arch ring
  for (let i = -4; i <= 4; i++) {
    const x = i * 6.2;
    const arch = new THREE.Mesh(
      mergeParts([
        { g: box(1.5, 12, 1.5), p: [-2.2, 6, 0] as [number, number, number] },
        { g: box(1.5, 12, 1.5), p: [2.2, 6, 0] as [number, number, number] },
        { g: box(6.6, 1.6, 1.5), p: [0, 12.6, 0] as [number, number, number] },
      ]),
      flat(mid)
    );
    arch.position.set(x, 0, -15);
    g.add(arch);
    const glow = new THREE.Mesh(box(3.2, 0.12, 0.2), glowMaterial(def.accent, 0.5));
    glow.position.set(x, 11.7, -14.1);
    g.add(glow);
  }

  // mid pillars + banners
  for (const sx of [-1, 1]) {
    for (let i = 0; i < 2; i++) {
      const p = new THREE.Mesh(
        mergeParts([
          { g: cyl(0.85, 1.1, 14, 8), p: [0, 7, 0] as [number, number, number] },
          { g: box(2.4, 0.7, 2.4), p: [0, 0.35, 0] as [number, number, number] },
          { g: box(2.6, 0.8, 2.6), p: [0, 14, 0] as [number, number, number] },
        ]),
        flat(dark)
      );
      p.position.set(sx * (9.4 + i * 1.4), 0, -7 - i * 4);
      g.add(p);
    }
    const banner = new THREE.Mesh(
      mergeParts([
        { g: box(2.2, 7, 0.12), p: [0, 0, 0] as [number, number, number] },
        { g: cone(1.1, 1.6, 4), p: [0, -4.2, 0] as [number, number, number] },
      ]),
      flat(0x2a1420)
    );
    banner.position.set(sx * 6.6, 10.5, -11);
    g.add(banner);
    const trim = new THREE.Mesh(box(2.2, 0.16, 0.2), glowMaterial(def.accent, 0.6));
    trim.position.set(sx * 6.6, 13.9, -10.9);
    g.add(trim);
  }

  // floodlights
  for (const sx of [-1, 1]) {
    for (let i = 0; i < 2; i++) {
      const x = sx * (7 + i * 4);
      const mast = new THREE.Mesh(cyl(0.22, 0.3, 15, 6), flat(0x1a2634));
      mast.position.set(x, 7.5, -9 - i * 3);
      g.add(mast);
      const head = new THREE.Mesh(box(1.6, 0.9, 1.0), flat(0x22313f));
      head.position.set(x, 15.2, -9 - i * 3);
      g.add(head);
      const beam = new THREE.Mesh(cone(3.4, 15, 12), glowMaterial(def.accent2, 0.07));
      beam.position.set(x * 0.72, 8.2, -6.5 - i * 2);
      beam.rotation.z = sx * 0.22;
      g.add(beam);
      anim.push((t) => {
        (beam.material as THREE.ShaderMaterial).uniforms.uOpacity.value = 0.055 + Math.sin(t * 1.4 + i) * 0.018;
      });
    }
  }

  // foreground framing
  const fg = new THREE.Group();
  for (const sx of [-1, 1]) {
    const col = new THREE.Mesh(
      mergeParts([
        { g: box(2.0, 11, 2.0), p: [0, 5.5, 0] as [number, number, number] },
        { g: box(2.8, 0.7, 2.8), p: [0, 10.8, 0] as [number, number, number] },
      ]),
      flat(0x04070c)
    );
    col.position.set(sx * 6.2, 0, 6.2);
    fg.add(col);
    const rail = new THREE.Mesh(box(16, 0.5, 0.6), flat(0x04070c));
    rail.position.set(sx * 4.5, 2.6, 7.6);
    fg.add(rail);
    const rope = new THREE.Mesh(box(16, 0.12, 0.12), flat(0x0a121a));
    rope.position.set(sx * 4.5, 3.4, 7.6);
    fg.add(rope);
  }
  g.add(fg);
  hide.push(fg);

  const dust = makeParticles(260, 0xffd9a0, { x: 40, y: 16, z: 30 }, new THREE.Vector3(0, 0, -6), 0.35, 1.5);
  g.add(dust.pts);
  anim.push((t) => { dust.mat.uniforms.uTime.value = t; });
}

// --- magenta conduit -------------------------------------------------------
function buildConduit(
  g: THREE.Group, def: RealmDef, hide: THREE.Object3D[], anim: ((t: number, dt: number) => void)[]
) {
  const dark = 0x140a1e;
  const deep = 0x0a0512;

  // far data towers
  for (let i = 0; i < 26; i++) {
    const x = -44 + i * 3.5 + Math.random() * 1.5;
    const h = 8 + Math.random() * 22;
    const z = -26 - Math.random() * 22;
    const t = new THREE.Mesh(box(2.2 + Math.random() * 1.6, h, 2.2), flat(deep));
    t.position.set(x, h / 2, z);
    g.add(t);
    const strip = new THREE.Mesh(box(0.16, h * 0.7, 0.16), glowMaterial(def.accent, 0.55));
    strip.position.set(x + 1.2, h * 0.5, z + 1.2);
    g.add(strip);
  }

  // cable bundles
  for (let i = -6; i <= 6; i++) {
    const x = i * 3.6;
    const bundle = new THREE.Mesh(cyl(0.34, 0.34, 26, 6), flat(dark));
    bundle.position.set(x, 13, -17);
    g.add(bundle);
    const core = new THREE.Mesh(cyl(0.12, 0.12, 26, 6), glowMaterial(def.accent2, 0.5));
    core.position.set(x, 13, -16.7);
    g.add(core);
    anim.push((t) => {
      (core.material as THREE.ShaderMaterial).uniforms.uOpacity.value =
        0.25 + 0.45 * Math.max(0, Math.sin(t * 2.2 - i * 0.5));
    });
  }

  // overhead pipe arcs
  for (let i = 0; i < 3; i++) {
    const arc = new THREE.Mesh(new THREE.TorusGeometry(11 + i * 2.5, 0.42, 6, 28, Math.PI), flat(0x1b0f28));
    arc.position.set(0, 0, -9 - i * 5);
    g.add(arc);
    const neon = new THREE.Mesh(new THREE.TorusGeometry(11 + i * 2.5, 0.1, 6, 28, Math.PI), glowMaterial(def.accent, 0.6));
    neon.position.set(0, 0, -8.6 - i * 5);
    g.add(neon);
  }

  // side conduits
  for (const sx of [-1, 1]) {
    for (let i = 0; i < 3; i++) {
      const p = new THREE.Mesh(
        mergeParts([
          { g: box(1.8, 18, 1.8), p: [0, 9, 0] as [number, number, number] },
          { g: box(2.6, 0.6, 2.6), p: [0, 18, 0] as [number, number, number] },
        ]),
        flat(dark)
      );
      p.position.set(sx * (9.6 + i * 1.2), 0, -6 - i * 4.5);
      g.add(p);
      const strip = new THREE.Mesh(box(0.16, 15, 0.16), glowMaterial(def.accent, 0.7));
      strip.position.set(sx * (9.6 + i * 1.2) - sx * 0.95, 9, -6 - i * 4.5 + 0.95);
      g.add(strip);
    }
  }

  // floating shards
  for (let i = 0; i < 14; i++) {
    const s = new THREE.Mesh(
      new THREE.OctahedronGeometry(0.3 + Math.random() * 0.5, 0),
      glowMaterial(def.accent2, 0.5)
    );
    const bx = (Math.random() - 0.5) * 22;
    const by = 3 + Math.random() * 10;
    const bz = -6 - Math.random() * 12;
    s.position.set(bx, by, bz);
    g.add(s);
    anim.push((t) => {
      s.position.y = by + Math.sin(t * 0.7 + i) * 0.7;
      s.rotation.y = t * 0.6 + i;
      s.rotation.x = t * 0.3;
    });
  }

  const fg = new THREE.Group();
  for (const sx of [-1, 1]) {
    const cable = new THREE.Mesh(cyl(0.5, 0.5, 14, 6), flat(0x03030a));
    cable.position.set(sx * 6.4, 7, 6.4);
    cable.rotation.z = sx * 0.16;
    fg.add(cable);
    const bracket = new THREE.Mesh(box(1.6, 0.4, 1.6), flat(0x03030a));
    bracket.position.set(sx * 6.0, 5.4, 6.4);
    fg.add(bracket);
  }
  const beam = new THREE.Mesh(box(30, 0.7, 0.7), flat(0x03030a));
  beam.position.set(0, 9.6, 7.6);
  fg.add(beam);
  g.add(fg);
  hide.push(fg);

  const sparks = makeParticles(300, 0xff8ce0, { x: 40, y: 18, z: 30 }, new THREE.Vector3(0, 0, -6), 1.6, 1.7);
  g.add(sparks.pts);
  anim.push((t) => { sparks.mat.uniforms.uTime.value = t; });
}

// --- spore-lit wastes ------------------------------------------------------
function buildWastes(
  g: THREE.Group, def: RealmDef, hide: THREE.Object3D[], anim: ((t: number, dt: number) => void)[]
) {
  const dark = 0x0c1a14;
  const deep = 0x060f0b;

  // far treeline
  for (let i = 0; i < 30; i++) {
    const x = -46 + i * 3.2 + Math.random() * 2;
    const z = -24 - Math.random() * 24;
    const h = 7 + Math.random() * 20;
    const t = new THREE.Mesh(cyl(0.3, 0.55, h, 5), flat(deep));
    t.position.set(x, h / 2, z);
    t.rotation.z = (Math.random() - 0.5) * 0.2;
    g.add(t);
  }

  // giant glowing mushrooms
  const caps: THREE.Mesh[] = [];
  for (let i = 0; i < 12; i++) {
    const sx = i % 2 === 0 ? -1 : 1;
    const x = sx * (7 + Math.random() * 14);
    const z = -8 - Math.random() * 20;
    const h = 4 + Math.random() * 9;
    const r = 1.6 + Math.random() * 2.6;
    const stalk = new THREE.Mesh(cyl(0.45, 0.8, h, 7), flat(dark));
    stalk.position.set(x, h / 2, z);
    g.add(stalk);
    const cap = new THREE.Mesh(sph(r, 14), flat(0x123024));
    cap.position.set(x, h, z);
    cap.scale.set(1, 0.55, 1);
    g.add(cap);
    const under = new THREE.Mesh(sph(r * 0.98, 14), glowMaterial(def.accent, 0.45));
    under.position.set(x, h - 0.15, z);
    under.scale.set(1, 0.5, 1);
    g.add(under);
    caps.push(under);
    anim.push((t) => {
      (under.material as THREE.ShaderMaterial).uniforms.uOpacity.value =
        0.3 + 0.25 * Math.sin(t * 0.9 + i * 1.3);
    });
  }

  // broken obelisks
  for (const sx of [-1, 1]) {
    for (let i = 0; i < 3; i++) {
      const h = 6 + Math.random() * 8;
      const ob = new THREE.Mesh(
        mergeParts([
          { g: box(1.5, h, 1.5), p: [0, h / 2, 0] as [number, number, number] },
          { g: cone(1.1, 2.2, 4), p: [0, h + 1.1, 0] as [number, number, number] },
        ]),
        flat(dark)
      );
      ob.position.set(sx * (8.6 + i * 1.6), 0, -6 - i * 5);
      ob.rotation.z = sx * (0.03 + i * 0.02);
      g.add(ob);
      const vein = new THREE.Mesh(box(0.14, h * 0.8, 0.14), glowMaterial(def.accent2, 0.6));
      vein.position.set(sx * (8.6 + i * 1.6) - sx * 0.78, h * 0.5, -6 - i * 5 + 0.78);
      g.add(vein);
    }
  }

  // hanging vines
  for (let i = 0; i < 16; i++) {
    const x = -20 + i * 2.6;
    const len = 4 + Math.random() * 8;
    const v = new THREE.Mesh(cyl(0.08, 0.14, len, 5), flat(0x0a1a12));
    v.position.set(x, 18 - len / 2, -12 - Math.random() * 8);
    g.add(v);
    const tip = new THREE.Mesh(sph(0.22, 8), glowMaterial(def.accent, 0.6));
    tip.position.set(x, 18 - len, -12 - Math.random() * 8);
    g.add(tip);
  }

  const fg = new THREE.Group();
  for (const sx of [-1, 1]) {
    for (let i = 0; i < 3; i++) {
      const frond = new THREE.Mesh(
        mergeParts([
          { g: box(0.3, 9, 0.3), p: [0, 4.5, 0] as [number, number, number] },
          { g: box(3.2, 0.22, 0.22), p: [sx * 1.4, 7.4, 0] as [number, number, number] },
          { g: box(2.6, 0.22, 0.22), p: [sx * 1.1, 5.6, 0] as [number, number, number] },
        ]),
        flat(0x020604)
      );
      frond.position.set(sx * (5.4 + i * 0.9), 0, 6.0 + i * 0.6);
      frond.rotation.z = sx * 0.1;
      fg.add(frond);
    }
  }
  g.add(fg);
  hide.push(fg);

  const spores = makeParticles(340, 0xc8ff8a, { x: 42, y: 16, z: 30 }, new THREE.Vector3(0, 0, -6), 0.55, 2.1);
  g.add(spores.pts);
  anim.push((t) => { spores.mat.uniforms.uTime.value = t; });
}
