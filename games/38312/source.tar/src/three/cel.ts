import * as THREE from "three";

// Cel art wants authored colours to pass through untouched.
THREE.ColorManagement.enabled = false;

/** Minimal position+normal geometry merge (all inputs must be non-indexed). */
function mergeGeos(geos: THREE.BufferGeometry[]): THREE.BufferGeometry {
  let total = 0;
  for (const g of geos) total += g.getAttribute("position").count;
  const pos = new Float32Array(total * 3);
  const nor = new Float32Array(total * 3);
  let o = 0;
  for (const g of geos) {
    const p = g.getAttribute("position") as THREE.BufferAttribute;
    const n = g.getAttribute("normal") as THREE.BufferAttribute;
    pos.set(p.array as Float32Array, o * 3);
    nor.set(n.array as Float32Array, o * 3);
    o += p.count;
  }
  const out = new THREE.BufferGeometry();
  out.setAttribute("position", new THREE.BufferAttribute(pos, 3));
  out.setAttribute("normal", new THREE.BufferAttribute(nor, 3));
  out.computeBoundingSphere();
  return out;
}

export interface StageCtx {
  fog: number;
  fogNear: number;
  fogFar: number;
  light: THREE.Vector3;
}

const CEL_VERT = /* glsl */ `
varying vec3 vN;
varying vec3 vW;
varying float vD;
void main() {
  vec4 wp = modelMatrix * vec4(position, 1.0);
  vW = wp.xyz;
  vN = normalize(mat3(modelMatrix) * normal);
  vec4 mv = viewMatrix * wp;
  vD = -mv.z;
  gl_Position = projectionMatrix * mv;
}
`;

const CEL_FRAG = /* glsl */ `
uniform vec3 uColor;
uniform vec3 uShade;
uniform vec3 uRim;
uniform vec3 uEmis;
uniform vec3 uFog;
uniform vec3 uLight;
uniform float uBands;
uniform float uRimPow;
uniform float uFlash;
uniform float uFogNear;
uniform float uFogFar;
uniform float uTime;
uniform float uOpacity;
varying vec3 vN;
varying vec3 vW;
varying float vD;

void main() {
  vec3 N = normalize(vN);
  float ndl = dot(N, normalize(uLight));
  float t = smoothstep(-0.14, 0.18, ndl);
  float b = floor(t * uBands + 0.5) / max(uBands - 1.0, 0.001);
  vec3 col = mix(uShade, uColor, clamp(b, 0.0, 1.0));
  col += uColor * 0.12 * max(N.y, 0.0);
  vec3 V = normalize(cameraPosition - vW);
  float rim = pow(1.0 - clamp(dot(N, V), 0.0, 1.0), uRimPow);
  col += uRim * rim;
  col += uEmis * (0.82 + 0.18 * sin(uTime * 2.6 + vW.y * 2.2));
  col = mix(col, vec3(1.0, 0.95, 0.98), uFlash);
  float f = smoothstep(uFogNear, uFogFar, vD);
  col = mix(col, uFog, f);
  gl_FragColor = vec4(col, uOpacity);
}
`;

const OUT_VERT = /* glsl */ `
uniform float uThick;
varying float vD;
void main() {
  vec3 p = position + normal * uThick;
  vec4 mv = modelViewMatrix * vec4(p, 1.0);
  vD = -mv.z;
  gl_Position = projectionMatrix * mv;
}
`;

const OUT_FRAG = /* glsl */ `
uniform vec3 uInk;
uniform vec3 uFog;
uniform float uFogNear;
uniform float uFogFar;
varying float vD;
void main() {
  float f = smoothstep(uFogNear, uFogFar, vD);
  gl_FragColor = vec4(mix(uInk, uFog, f), 1.0);
}
`;

export interface CelOpts {
  color: number;
  shade?: number;
  rim?: number;
  rimPower?: number;
  emissive?: number;
  emissiveStrength?: number;
  bands?: number;
  outline?: number;
  transparent?: boolean;
  opacity?: number;
  ink?: number;
}

const c = new THREE.Color();

function shadeOf(hex: number, mul = 0.3): THREE.Color {
  c.setHex(hex);
  return c.clone().multiplyScalar(mul);
}

/**
 * A bundle of cel materials that share a stage's fog + light so they can be
 * flashed / re-tinted in one call.
 */
export class CelSkin {
  readonly mats: THREE.ShaderMaterial[] = [];

  constructor(public ctx: StageCtx) {}

  make(o: CelOpts): THREE.ShaderMaterial {
    const mat = new THREE.ShaderMaterial({
      vertexShader: CEL_VERT,
      fragmentShader: CEL_FRAG,
      uniforms: {
        uColor: { value: new THREE.Color(o.color) },
        uShade: { value: shadeOf(o.color, o.shade ?? 0.28) },
        uRim: { value: new THREE.Color(o.rim ?? 0x000000) },
        uEmis: { value: new THREE.Color(o.emissive ?? 0x000000).multiplyScalar(o.emissiveStrength ?? 1) },
        uFog: { value: new THREE.Color(this.ctx.fog) },
        uLight: { value: this.ctx.light.clone() },
        uBands: { value: o.bands ?? 3 },
        uRimPow: { value: o.rimPower ?? 2.4 },
        uFlash: { value: 0 },
        uFogNear: { value: this.ctx.fogNear },
        uFogFar: { value: this.ctx.fogFar },
        uTime: { value: 0 },
        uOpacity: { value: o.opacity ?? 1 },
      },
      transparent: !!o.transparent,
      depthWrite: !(o.transparent && (o.opacity ?? 1) < 1),
    });
    this.mats.push(mat);
    return mat;
  }

  setFlash(v: number) {
    for (const m of this.mats) m.uniforms.uFlash.value = v;
  }

  setOpacity(v: number) {
    for (const m of this.mats) m.uniforms.uOpacity.value = v;
  }

  setTime(t: number) {
    for (const m of this.mats) m.uniforms.uTime.value = t;
  }

  dispose() {
    for (const m of this.mats) m.dispose();
    this.mats.length = 0;
  }
}

const outlineCache = new Map<string, THREE.ShaderMaterial>();

export function outlineMaterial(thickness: number, ink = 0x04060b): THREE.ShaderMaterial {
  const key = `${thickness.toFixed(3)}|${ink}`;
  let m = outlineCache.get(key);
  if (!m) {
    m = new THREE.ShaderMaterial({
      vertexShader: OUT_VERT,
      fragmentShader: OUT_FRAG,
      uniforms: {
        uThick: { value: thickness },
        uInk: { value: new THREE.Color(ink) },
        uFog: { value: new THREE.Color(0x141d29) },
        uFogNear: { value: 16 },
        uFogFar: { value: 62 },
      },
      side: THREE.BackSide,
    });
    outlineCache.set(key, m);
  }
  return m;
}

export function setOutlineFog(color: number, near: number, far: number) {
  for (const m of outlineCache.values()) {
    (m.uniforms.uFog.value as THREE.Color).setHex(color);
    m.uniforms.uFogNear.value = near;
    m.uniforms.uFogFar.value = far;
  }
}

/** Attach an inverted-hull ink outline to a mesh. */
export function inkOutline(mesh: THREE.Mesh, thickness: number, ink = 0x04060b) {
  const o = new THREE.Mesh(mesh.geometry, outlineMaterial(thickness, ink));
  o.frustumCulled = false;
  o.renderOrder = -1;
  mesh.add(o);
  return o;
}

// ---------------------------------------------------------------------------
// Geometry assembly
// ---------------------------------------------------------------------------

export interface PartSpec {
  g: THREE.BufferGeometry;
  p?: [number, number, number];
  r?: [number, number, number];
  s?: [number, number, number];
}

export function mergeParts(parts: PartSpec[]): THREE.BufferGeometry {
  const geos = parts.map((ps) => {
    const g = ps.g.clone();
    const m = new THREE.Matrix4();
    const q = new THREE.Quaternion();
    const r = ps.r ?? [0, 0, 0];
    const p = ps.p ?? [0, 0, 0];
    const s = ps.s ?? [1, 1, 1];
    q.setFromEuler(new THREE.Euler(r[0], r[1], r[2]));
    m.compose(new THREE.Vector3(p[0], p[1], p[2]), q, new THREE.Vector3(s[0], s[1], s[2]));
    g.applyMatrix4(m);
    const flat2 = g.index ? g.toNonIndexed() : g;
    if (flat2 !== g) g.dispose();
    flat2.deleteAttribute("uv");
    return flat2;
  });
  const merged = mergeGeos(geos);
  geos.forEach((g) => g.dispose());
  return merged;
}

export const box = (w: number, h: number, d: number) => new THREE.BoxGeometry(w, h, d);
export const cyl = (rt: number, rb: number, h: number, seg = 10) =>
  new THREE.CylinderGeometry(rt, rb, h, seg);
export const cone = (r: number, h: number, seg = 10) => new THREE.ConeGeometry(r, h, seg);
export const sph = (r: number, seg = 12) => new THREE.SphereGeometry(r, seg, Math.max(6, seg / 2));
export const torus = (r: number, t: number, seg = 24) => new THREE.TorusGeometry(r, t, 6, seg);

/**
 * Additive glow material for VFX, projectiles and light shafts.
 */
export function glowMaterial(color: number, opacity = 1, fog: number = 0x141d29) {
  return new THREE.ShaderMaterial({
    uniforms: {
      uColor: { value: new THREE.Color(color) },
      uOpacity: { value: opacity },
      uFog: { value: new THREE.Color(fog) },
      uFogNear: { value: 16 },
      uFogFar: { value: 62 },
    },
    vertexShader: /* glsl */ `
      varying float vD;
      varying vec3 vW;
      void main() {
        vec4 wp = modelMatrix * vec4(position, 1.0);
        vW = wp.xyz;
        vec4 mv = viewMatrix * wp;
        vD = -mv.z;
        gl_Position = projectionMatrix * mv;
      }
    `,
    fragmentShader: /* glsl */ `
      uniform vec3 uColor; uniform vec3 uFog;
      uniform float uOpacity; uniform float uFogNear; uniform float uFogFar;
      varying float vD; varying vec3 vW;
      void main() {
        float f = smoothstep(uFogNear, uFogFar, vD);
        vec3 col = mix(uColor, uFog, f);
        gl_FragColor = vec4(col, uOpacity);
      }
    `,
    transparent: true,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
    side: THREE.DoubleSide,
  });
}
