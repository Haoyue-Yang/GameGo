import * as THREE from "three";
import { glowMaterial } from "./cel";

type Kind = "ring" | "sphere" | "arc" | "shard" | "beam";

interface Fx {
  obj: THREE.Mesh;
  mat: THREE.ShaderMaterial;
  kind: Kind;
  t: number;
  life: number;
  r0: number;
  r1: number;
  vel: THREE.Vector3;
  spin: THREE.Vector3;
  base: number;
  active: boolean;
}

const RING = new THREE.RingGeometry(0.86, 1, 48);
const SPH = new THREE.SphereGeometry(1, 14, 10);
const ARC = new THREE.RingGeometry(0.45, 1, 24, 1, -0.9, 1.8);
const SHARD = new THREE.BoxGeometry(0.16, 0.16, 0.16);
const BEAM = new THREE.CylinderGeometry(0.1, 0.1, 1, 8, 1, true);
BEAM.translate(0, 0.5, 0);
BEAM.rotateX(Math.PI / 2);

export class Vfx {
  readonly group = new THREE.Group();
  private pool: Fx[] = [];

  constructor() {
    this.group.frustumCulled = false;
  }

  private acquire(kind: Kind, color: number, fog: number): Fx {
    let fx = this.pool.find((f) => !f.active && f.kind === kind);
    if (!fx) {
      const geo = kind === "ring" ? RING : kind === "sphere" ? SPH : kind === "arc" ? ARC : kind === "shard" ? SHARD : BEAM;
      const mat = glowMaterial(color, 1, fog);
      const obj = new THREE.Mesh(geo, mat);
      obj.frustumCulled = false;
      this.group.add(obj);
      fx = {
        obj, mat, kind, t: 0, life: 1, r0: 1, r1: 1,
        vel: new THREE.Vector3(), spin: new THREE.Vector3(), base: 1, active: false,
      };
      this.pool.push(fx);
    }
    (fx.mat.uniforms.uColor.value as THREE.Color).setHex(color);
    (fx.mat.uniforms.uFog.value as THREE.Color).setHex(fog);
    fx.active = true;
    fx.t = 0;
    fx.obj.visible = true;
    return fx;
  }

  ring(x: number, y: number, z: number, color: number, r0: number, r1: number, life: number, fog: number, flat = true) {
    const fx = this.acquire("ring", color, fog);
    fx.obj.position.set(x, y, z);
    fx.obj.rotation.set(flat ? -Math.PI / 2 : 0, 0, 0);
    fx.r0 = r0;
    fx.r1 = r1;
    fx.life = life;
    fx.base = 0.95;
    fx.obj.scale.setScalar(r0);
    return fx;
  }

  sphere(x: number, y: number, z: number, color: number, r0: number, r1: number, life: number, fog: number) {
    const fx = this.acquire("sphere", color, fog);
    fx.obj.position.set(x, y, z);
    fx.obj.rotation.set(0, 0, 0);
    fx.r0 = r0;
    fx.r1 = r1;
    fx.life = life;
    fx.base = 0.8;
    fx.obj.scale.setScalar(r0);
    return fx;
  }

  arc(x: number, y: number, z: number, color: number, r0: number, r1: number, life: number, fog: number, faceZ = true) {
    const fx = this.acquire("arc", color, fog);
    fx.obj.position.set(x, y, z);
    fx.obj.rotation.set(faceZ ? 0 : -Math.PI / 2, 0, 0);
    fx.r0 = r0;
    fx.r1 = r1;
    fx.life = life;
    fx.base = 1.0;
    fx.obj.scale.setScalar(r0);
    return fx;
  }

  burst(x: number, y: number, z: number, color: number, count: number, speed: number, life: number, fog: number) {
    for (let i = 0; i < count; i++) {
      const fx = this.acquire("shard", color, fog);
      fx.obj.position.set(x, y, z);
      const a = Math.random() * Math.PI * 2;
      const up = 0.3 + Math.random() * 1.1;
      fx.vel.set(Math.cos(a) * speed * (0.4 + Math.random()), up * speed, Math.sin(a) * speed * 0.5);
      fx.spin.set(Math.random() * 8 - 4, Math.random() * 8 - 4, Math.random() * 8 - 4);
      fx.life = life * (0.6 + Math.random() * 0.7);
      fx.base = 0.9;
      fx.obj.scale.setScalar(0.5 + Math.random() * 0.9);
    }
  }

  beam(x: number, y: number, z: number, dir: number, len: number, color: number, life: number, fog: number, width = 0.34) {
    const fx = this.acquire("beam", color, fog);
    fx.obj.position.set(x, y, z);
    fx.obj.rotation.set(0, 0, 0);
    fx.obj.scale.set(width, width, len);
    fx.obj.rotation.z = dir > 0 ? 0 : Math.PI;
    fx.life = life;
    fx.base = 1.0;
    fx.r0 = width;
    fx.r1 = width;
    return fx;
  }

  update(dt: number) {
    for (const fx of this.pool) {
      if (!fx.active) continue;
      fx.t += dt;
      const k = fx.t / fx.life;
      if (k >= 1) {
        fx.active = false;
        fx.obj.visible = false;
        continue;
      }
      const e = 1 - Math.pow(1 - k, 2.4);
      if (fx.kind === "shard") {
        fx.vel.y -= 14 * dt;
        fx.obj.position.addScaledVector(fx.vel, dt);
        fx.obj.rotation.x += fx.spin.x * dt;
        fx.obj.rotation.y += fx.spin.y * dt;
        fx.obj.rotation.z += fx.spin.z * dt;
        fx.mat.uniforms.uOpacity.value = fx.base * (1 - k);
      } else if (fx.kind === "beam") {
        fx.obj.scale.x = fx.r0 * (1 - k * 0.7);
        fx.obj.scale.y = fx.r0 * (1 - k * 0.7);
        fx.mat.uniforms.uOpacity.value = fx.base * (1 - k * k);
      } else {
        const r = fx.r0 + (fx.r1 - fx.r0) * e;
        fx.obj.scale.setScalar(r);
        fx.mat.uniforms.uOpacity.value = fx.base * (1 - k) * (1 - k);
      }
    }
  }
}

// ---------------------------------------------------------------------------
// Health bar billboard
// ---------------------------------------------------------------------------

export function makeHealthBar() {
  const geo = new THREE.PlaneGeometry(1, 1);
  const mat = new THREE.ShaderMaterial({
    uniforms: {
      uFill: { value: 1 },
      uColor: { value: new THREE.Color(0xff5a6e) },
      uBg: { value: new THREE.Color(0x0a0d14) },
    },
    vertexShader: `varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }`,
    fragmentShader: /* glsl */ `
      uniform float uFill; uniform vec3 uColor; uniform vec3 uBg;
      varying vec2 vUv;
      void main() {
        vec3 c = mix(uBg, uColor, step(vUv.x, uFill));
        float b = min(min(vUv.x, 1.0 - vUv.x) * 60.0, min(vUv.y, 1.0 - vUv.y) * 12.0);
        c = mix(vec3(0.015, 0.02, 0.03), c, smoothstep(0.0, 1.0, b));
        gl_FragColor = vec4(c, 1.0);
      }
    `,
    transparent: false,
    depthWrite: false,
  });
  const mesh = new THREE.Mesh(geo, mat);
  mesh.renderOrder = 20;
  mesh.frustumCulled = false;
  return { mesh, mat };
}
