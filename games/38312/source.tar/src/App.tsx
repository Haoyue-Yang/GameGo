import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Engine, type EngineEvent, type HudSnapshot } from "./game/engine";
import {
  addXp, applyAscension, computeStats, equipItem, freshProgress, loadProgress, saveProgress, sellItem,
  unequipItem, type Progress,
} from "./game/progress";
import { PRESTIGE_XP_BONUS, REALMS, realmById, xpForLevel, type Item, type RealmId, type Slot, type StatPointKey } from "./game/data";
import { skillMaxLevel } from "./game/progress";
import Hud from "./ui/Hud";
import Hub from "./ui/Hub";
import { ClearOverlay, DeathOverlay, LevelUpFlash, LootToasts, type Toast } from "./ui/Overlays";

const EMPTY_HUD: HudSnapshot = {
  phase: "hub", hp: 100, maxHp: 100, energy: 100, maxEnergy: 100,
  wave: 0, waves: 4, enemies: 0, boss: null, skills: [], speed: 1,
  realm: null, kills: 0, dps: 0, banner: null, bannerSub: null, runTime: 0,
};

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const floatRef = useRef<HTMLDivElement | null>(null);
  const engineRef = useRef<Engine | null>(null);

  const [progress, setProgress] = useState<Progress>(() => loadProgress());
  const progressRef = useRef(progress);
  const [hud, setHud] = useState<HudSnapshot>(EMPTY_HUD);
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [levelFlash, setLevelFlash] = useState<number | null>(null);
  const [summary, setSummary] = useState({ kills: 0, wave: 0, xp: 0, levels: 0 });
  const [ready, setReady] = useState(false);

  const toastId = useRef(0);
  const xpRun = useRef(0);
  const levelsRun = useRef(0);
  const hudRef = useRef(hud);
  hudRef.current = hud;

  const stats = useMemo(() => computeStats(progress), [progress]);

  const commit = useCallback((next: Progress) => {
    progressRef.current = next;
    setProgress(next);
    saveProgress(next);
  }, []);

  const handleEvent = useCallback(
    (e: EngineEvent) => {
      if (e.type === "kill") {
        xpRun.current += e.xp;
        const { next, levels } = addXp(progressRef.current, e.xp);
        commit({ ...next, totalKills: next.totalKills + 1 });
        if (levels > 0) {
          levelsRun.current += levels;
          setLevelFlash(next.level);
          window.setTimeout(() => setLevelFlash(null), 1500);
        }
      } else if (e.type === "loot") {
        const p = progressRef.current;
        commit({ ...p, inventory: [...p.inventory, e.item] });
        const id = ++toastId.current;
        setToasts((t) => [...t.slice(-4), { id, item: e.item }]);
        window.setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 4200);
      } else if (e.type === "clear") {
        const p = progressRef.current;
        const idx = REALMS.findIndex((r) => r.id === e.realm);
        const nextId = REALMS[idx + 1]?.id;
        const unlocked = nextId && !p.unlocked.includes(nextId) ? [...p.unlocked, nextId] : p.unlocked;
        const cleared = p.cleared.includes(e.realm) ? p.cleared : [...p.cleared, e.realm];
        commit({
          ...p,
          unlocked,
          cleared,
          bestWave: { ...p.bestWave, [e.realm]: Math.max(p.bestWave[e.realm] ?? 0, e.wave) },
        });
        setSummary({ kills: e.kills, wave: e.wave, xp: xpRun.current, levels: levelsRun.current });
      } else if (e.type === "death") {
        const p = progressRef.current;
        const id = hudRef.current.realm ?? "colosseum";
        commit({
          ...p,
          bestWave: { ...p.bestWave, [id]: Math.max(p.bestWave[id] ?? 0, hudRef.current.wave) },
        });
      }
    },
    [commit]
  );

  // ---- engine boot ---------------------------------------------------------
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const eng = new Engine(canvas, progressRef.current, computeStats(progressRef.current));
    engineRef.current = eng;
    eng.onHud = setHud;
    eng.onEvent = handleEvent;
    eng.setFloaterLayer(floatRef.current);
    eng.enterHub();
    eng.start();
    setReady(true);
    return () => {
      eng.dispose();
      engineRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // ---- push progress into the engine -------------------------------------
  useEffect(() => {
    engineRef.current?.setProgress(progress, stats);
  }, [progress, stats]);

  useEffect(() => {
    engineRef.current?.setSpeed(hud.speed);
  }, [hud.speed]);

  // ---- actions -----------------------------------------------------------
  const enterRealm = (id: RealmId) => {
    xpRun.current = 0;
    levelsRun.current = 0;
    engineRef.current?.enterRealm(id);
  };

  const toHub = () => {
    xpRun.current = 0;
    levelsRun.current = 0;
    engineRef.current?.enterHub();
  };

  const setSpeed = (n: number) => engineRef.current?.setSpeed(n);

  const onMove = (dir: number, down: boolean) => {
    const k = dir < 0 ? "a" : "d";
    window.dispatchEvent(new KeyboardEvent(down ? "keydown" : "keyup", { key: k }));
  };

  const spendStat = (k: StatPointKey) => {
    const p = progressRef.current;
    if (p.statPoints <= 0) return;
    commit({ ...p, statPoints: p.statPoints - 1, points: { ...p.points, [k]: p.points[k] + 1 } });
  };

  const spendSkill = (id: number) => {
    const p = progressRef.current;
    if (p.skillPoints <= 0) return;
    const lvl = p.skillLevels[id - 1];
    if (lvl >= skillMaxLevel) return;
    const skillLevels = p.skillLevels.slice();
    skillLevels[id - 1] = lvl + 1;
    commit({ ...p, skillPoints: p.skillPoints - 1, skillLevels });
  };

  const doEquip = (item: Item) => commit(equipItem(progressRef.current, item));
  const doUnequip = (slot: Slot) => commit(unequipItem(progressRef.current, slot));
  const doSell = (uid: string) => commit(sellItem(progressRef.current, uid));

  const doAscend = () => {
    const next = applyAscension(progressRef.current);
    commit(next);
    toHub();
  };

  const doWipe = () => {
    commit(freshProgress());
    toHub();
  };

  const realm = hud.realm ? realmById(hud.realm) : null;

  return (
    <div className="relative h-full w-full overflow-hidden bg-[#05070c]">
      <canvas ref={canvasRef} className="absolute inset-0 block h-full w-full" />
      <div ref={floatRef} className="floater-layer" />

      {/* vignette + film grain framing */}
      <div
        className="pointer-events-none absolute inset-0"
        style={{
          background:
            "radial-gradient(ellipse at 50% 46%, transparent 42%, rgba(0,0,0,0.55) 100%)",
        }}
      />
      <div
        className="pointer-events-none absolute inset-0 opacity-[0.07] mix-blend-overlay"
        style={{
          backgroundImage:
            "repeating-linear-gradient(0deg, rgba(255,255,255,0.6) 0px, rgba(255,255,255,0.6) 1px, transparent 1px, transparent 3px)",
        }}
      />

      {!ready && (
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="font-display text-[12px] tracking-[0.4em] text-cyan-200/60 pulse">
            FORGING THE ARENA…
          </div>
        </div>
      )}

      {hud.phase === "hub" && (
        <Hub
          progress={progress}
          stats={stats}
          onEquip={doEquip}
          onUnequip={doUnequip}
          onSell={doSell}
          onSpendStat={spendStat}
          onSpendSkill={spendSkill}
          onEnter={enterRealm}
          onAscend={doAscend}
          onWipe={doWipe}
        />
      )}

      {hud.phase !== "hub" && (
        <Hud
          hud={hud}
          realm={realm}
          level={progress.level}
          xp={progress.xp}
          xpNeed={xpForLevel(progress.level)}
          onSpeed={setSpeed}
          onExit={toHub}
          onMove={onMove}
        />
      )}

      <LootToasts toasts={toasts} />

      {levelFlash !== null && <LevelUpFlash level={levelFlash} />}

      {hud.phase === "dead" && (
        <DeathOverlay
          realm={realm}
          kills={hud.kills}
          wave={hud.wave}
          onReturn={toHub}
        />
      )}

      {hud.phase === "clear" && (
        <ClearOverlay
          realm={realm}
          kills={summary.kills}
          wave={summary.wave}
          levels={summary.levels}
          xpGained={summary.xp}
          onReturn={toHub}
          onReplay={() => realm && enterRealm(realm.id)}
        />
      )}

      {hud.phase === "hub" && progress.ascensions > 0 && (
        <div className="pointer-events-none absolute right-4 top-4 panel clip-corner px-3 py-2 text-right">
          <div className="font-display text-[9px] tracking-[0.24em] text-white/40">ASCENSION BONUS</div>
          <div className="font-display text-[15px] font-bold text-amber-300">
            x{(1 + progress.ascensions * PRESTIGE_XP_BONUS).toFixed(2)} XP
          </div>
          <div className="font-display text-[9px] tracking-[0.14em] text-white/35">
            {progress.ascensions} ASCENSION{progress.ascensions > 1 ? "S" : ""}
          </div>
        </div>
      )}
    </div>
  );
}
