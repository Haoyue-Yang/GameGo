import type { HudSnapshot } from "../game/engine";
import type { RealmDef } from "../game/data";

const SPEEDS = [1, 3, 5, 12];

function Bar({
  value, max, color, glow, height = 14, label, sub,
}: {
  value: number; max: number; color: string; glow: string; height?: number;
  label?: string; sub?: string;
}) {
  const pct = max > 0 ? Math.max(0, Math.min(100, (value / max) * 100)) : 0;
  return (
    <div className="bar-shell clip-corner scan" style={{ height, boxShadow: `inset 0 0 12px rgba(0,0,0,0.8)` }}>
      <div className="bar-ghost" style={{ width: `${pct}%` }} />
      <div
        className="bar-fill"
        style={{
          width: `${pct}%`,
          background: `linear-gradient(90deg, ${color}55, ${color})`,
          boxShadow: `0 0 14px ${glow}`,
        }}
      />
      {label && (
        <div className="absolute inset-0 flex items-center justify-between px-2 font-display text-[10px] tracking-[0.18em] text-white/90">
          <span>{label}</span>
          <span className="tabular-nums">{sub}</span>
        </div>
      )}
    </div>
  );
}

export default function Hud({
  hud, realm, level, xp, xpNeed, onSpeed, onExit, onMove,
}: {
  hud: HudSnapshot;
  realm: RealmDef | null;
  level: number;
  xp: number;
  xpNeed: number;
  onSpeed: (n: number) => void;
  onExit: () => void;
  onMove: (dir: number, down: boolean) => void;
}) {
  const accent = realm?.css ?? "#4de3ff";
  const accent2 = realm?.css2 ?? "#8fe9ff";

  return (
    <div className="pointer-events-none absolute inset-0 select-none">
      {/* top left — vitals */}
      <div className="absolute left-4 top-4 w-[300px] panel clip-corner p-3 rise">
        <div className="mb-2 flex items-center gap-3">
          <div
            className="flex h-11 w-11 shrink-0 items-center justify-center border font-display text-lg font-bold"
            style={{ borderColor: accent, color: accent, background: "rgba(4,10,18,0.9)", boxShadow: `0 0 16px ${accent}44` }}
          >
            {level}
          </div>
          <div className="min-w-0 flex-1">
            <div className="font-display text-[11px] tracking-[0.28em] text-white/50">CHAMPION</div>
            <div className="mt-1">
              <Bar value={hud.hp} max={hud.maxHp} color="#ff4d63" glow="rgba(255,77,99,0.5)" height={16}
                label="HP" sub={`${hud.hp} / ${hud.maxHp}`} />
            </div>
            <div className="mt-1">
              <Bar value={hud.energy} max={hud.maxEnergy} color="#3fd8ff" glow="rgba(63,216,255,0.5)" height={11}
                label="ENERGY" sub={`${hud.energy}`} />
            </div>
          </div>
        </div>
        <div className="mt-2">
          <Bar value={xp} max={xpNeed} color="#c9a2ff" glow="rgba(201,162,255,0.45)" height={7} />
        </div>
      </div>

      {/* top center — realm + wave */}
      <div className="absolute left-1/2 top-4 -translate-x-1/2 text-center">
        <div className="panel clip-corner px-6 py-2 rise">
          <div className="font-display text-[11px] tracking-[0.4em]" style={{ color: accent }}>
            {realm?.name ?? "SANCTUM"}
          </div>
          <div className="mt-1 flex items-center justify-center gap-4 font-display text-[11px] tracking-[0.2em] text-white/60">
            <span>
              WAVE <span className="text-white">{Math.max(1, hud.wave)}</span>/{hud.waves}
            </span>
            <span className="h-3 w-px bg-white/20" />
            <span>
              HOSTILES <span className="text-white tabular-nums">{hud.enemies}</span>
            </span>
            <span className="h-3 w-px bg-white/20" />
            <span>
              KILLS <span className="text-white tabular-nums">{hud.kills}</span>
            </span>
          </div>
        </div>
      </div>

      {/* top right — speed + readouts */}
      <div className="absolute right-4 top-4 flex flex-col items-end gap-2">
        <div className="panel clip-corner p-2 rise">
          <div className="mb-1.5 text-center font-display text-[9px] tracking-[0.3em] text-white/45">TIME SCALE</div>
          <div className="pointer-events-auto flex gap-1">
            {SPEEDS.map((s) => (
              <button
                key={s}
                onClick={() => onSpeed(s)}
                className="btn clip-corner px-3 py-1.5 text-[12px] font-bold"
                style={
                  hud.speed === s
                    ? { borderColor: accent, color: "#04121a", background: `linear-gradient(180deg,${accent},${accent}aa)`, boxShadow: `0 0 16px ${accent}77` }
                    : undefined
                }
              >
                x{s}
              </button>
            ))}
          </div>
        </div>
        <div className="panel-flat clip-corner px-3 py-1.5 text-right font-display text-[10px] tracking-[0.16em] text-white/55">
          <div>
            DPS <span className="text-white tabular-nums">{hud.dps}</span>
          </div>
          <div>
            TIME <span className="text-white tabular-nums">{hud.runTime.toFixed(1)}s</span>
          </div>
        </div>
        <button onClick={onExit} className="btn clip-corner pointer-events-auto px-3 py-1.5 text-[10px]">
          Abandon Run
        </button>
      </div>

      {/* boss bar */}
      {hud.boss && (
        <div className="absolute bottom-[136px] left-1/2 w-[min(620px,80vw)] -translate-x-1/2 rise">
          <div className="mb-1 flex items-end justify-between font-display">
            <span className="text-[15px] font-bold tracking-[0.24em]" style={{ color: accent, textShadow: `0 0 14px ${accent}` }}>
              {hud.boss.name}
            </span>
            <span className="text-[10px] tracking-[0.2em] text-white/45">{hud.boss.title}</span>
          </div>
          <Bar value={hud.boss.hp} max={hud.boss.maxHp} color="#ff2f9e" glow="rgba(255,47,158,0.6)" height={18}
            label="BOSS" sub={`${Math.ceil(hud.boss.hp)} / ${Math.round(hud.boss.maxHp)}`} />
        </div>
      )}

      {/* skill bar */}
      <div className="absolute bottom-4 left-1/2 -translate-x-1/2">
        <div className="flex items-end gap-2">
          <button
            className="btn clip-corner pointer-events-auto h-[74px] w-[58px] flex-col gap-0.5 text-[10px]"
            onPointerDown={(e) => { e.preventDefault(); onMove(-1, true); }}
            onPointerUp={() => onMove(-1, false)}
            onPointerLeave={() => onMove(-1, false)}
            aria-label="Move left"
          >
            <span className="text-xl leading-none">◀</span>
            <span>A</span>
          </button>
          <div className="flex gap-2">
            {hud.skills.map((s) => {
              const cdPct = s.cdMax > 0 ? (s.cd / s.cdMax) * 100 : 0;
              const locked = !s.unlocked;
              return (
                <div
                  key={s.id}
                  className="panel clip-corner relative h-[74px] w-[74px] overflow-hidden"
                  style={{
                    borderColor: locked ? "rgba(255,255,255,0.1)" : s.ready ? `#${s.color.toString(16).padStart(6, "0")}` : "rgba(255,255,255,0.16)",
                    boxShadow: !locked && s.ready ? `0 0 18px #${s.color.toString(16).padStart(6, "0")}55` : undefined,
                    opacity: locked ? 0.4 : 1,
                  }}
                  title={`${s.name} — ${s.cost} energy, ${s.cdMax}s cooldown`}
                >
                  <div className="absolute inset-0 scan opacity-60" />
                  <div className="relative flex h-full flex-col items-center justify-center gap-0.5">
                    <div
                      className="keycap flex h-5 w-5 items-center justify-center text-[11px] font-bold"
                      style={{ color: locked ? "#8899aa" : `#${s.color.toString(16).padStart(6, "0")}` }}
                    >
                      {s.key}
                    </div>
                    <div className="px-1 text-center font-display text-[8.5px] leading-tight tracking-[0.08em] text-white/80">
                      {s.name}
                    </div>
                    <div className="font-display text-[8px] tracking-[0.1em]" style={{ color: "#5fd8ff" }}>
                      {s.cost} EN
                    </div>
                    {s.level > 1 && (
                      <div className="absolute right-1 top-1 font-display text-[8px] text-white/50">L{s.level}</div>
                    )}
                  </div>
                  {cdPct > 0 && (
                    <>
                      <div className="absolute inset-x-0 bottom-0 bg-black/72" style={{ height: `${cdPct}%` }} />
                      <div className="absolute inset-0 flex items-center justify-center font-display text-lg font-bold text-white/85 tabular-nums">
                        {s.cd.toFixed(1)}
                      </div>
                    </>
                  )}
                  {locked && (
                    <div className="absolute inset-0 flex items-center justify-center font-display text-[9px] tracking-[0.2em] text-white/60">
                      LOCKED
                    </div>
                  )}
                </div>
              );
            })}
          </div>
          <button
            className="btn clip-corner pointer-events-auto h-[74px] w-[58px] flex-col gap-0.5 text-[10px]"
            onPointerDown={(e) => { e.preventDefault(); onMove(1, true); }}
            onPointerUp={() => onMove(1, false)}
            onPointerLeave={() => onMove(1, false)}
            aria-label="Move right"
          >
            <span className="text-xl leading-none">▶</span>
            <span>D</span>
          </button>
        </div>
      </div>

      {/* banner */}
      {hud.banner && (
        <div className="absolute left-1/2 top-[26%] -translate-x-1/2 text-center rise">
          <div
            className="font-display text-[44px] font-bold leading-none tracking-[0.16em]"
            style={{ color: accent2, textShadow: `0 0 30px ${accent2}, 0 4px 0 #000` }}
          >
            {hud.banner}
          </div>
          {hud.bannerSub && (
            <div className="mt-2 font-display text-[12px] tracking-[0.4em] text-white/60">{hud.bannerSub}</div>
          )}
        </div>
      )}

      {/* controls hint */}
      <div className="absolute bottom-4 left-4 panel-flat clip-corner px-3 py-2 font-display text-[9.5px] leading-relaxed tracking-[0.14em] text-white/45">
        <div><span className="text-white/80">A / D</span> SLIDE ALONG THE PLANE</div>
        <div><span className="text-white/80">1 – 6</span> CAST ACTIVES</div>
        <div><span className="text-white/80">X1 · X3 · X5 · X12</span> TIME SCALE</div>
      </div>
    </div>
  );
}
