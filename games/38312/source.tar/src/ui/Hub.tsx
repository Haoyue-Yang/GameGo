import { useMemo, useState } from "react";
import {
  PRESTIGE_REQ_LEVEL, RARITY, RARITY_ORDER, SKILLS, SLOT_INFO, SLOTS, STAT_INFO, STAT_LABEL,
  REALMS, itemPower, xpForLevel, type Item, type RealmId, type Slot, type StatPointKey,
} from "../game/data";
import { ascensionGain, canAscend, skillMaxLevel, xpMultiplier, type Progress } from "../game/progress";
import type { Stats } from "../game/data";

type Tab = "loadout" | "stats" | "skills" | "realms" | "ascend";

const TABS: { id: Tab; label: string }[] = [
  { id: "loadout", label: "Loadout" },
  { id: "stats", label: "Attributes" },
  { id: "skills", label: "Skills" },
  { id: "realms", label: "Realms" },
  { id: "ascend", label: "Ascend" },
];

function ItemCard({
  item, onEquip, onSell, compact,
}: { item: Item; onEquip?: () => void; onSell?: () => void; compact?: boolean }) {
  const r = RARITY[item.rarity];
  return (
    <div
      className="panel-flat clip-corner p-2.5"
      style={{ borderColor: `${r.color}66`, boxShadow: `inset 0 0 22px ${r.glow}` }}
    >
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          <div className="truncate font-display text-[12px] font-semibold" style={{ color: r.color }}>
            {item.name}
          </div>
          <div className="font-display text-[9px] tracking-[0.18em] text-white/40">
            {r.name.toUpperCase()} · {SLOT_INFO[item.slot].name.toUpperCase()} · ILVL {item.ilvl}
          </div>
        </div>
        <div className="shrink-0 text-right">
          <div className="font-display text-[9px] tracking-[0.16em] text-white/35">PWR</div>
          <div className="font-display text-[13px] font-bold text-white">{itemPower(item)}</div>
        </div>
      </div>
      {!compact && (
        <div className="mt-2 space-y-0.5">
          {item.affixes.map((a, i) => (
            <div key={i} className="flex justify-between font-display text-[10px] tracking-[0.08em]">
              <span className="text-white/50">{STAT_LABEL[a.stat]}</span>
              <span className="text-emerald-300 tabular-nums">+{a.value}</span>
            </div>
          ))}
        </div>
      )}
      {(onEquip || onSell) && (
        <div className="mt-2 flex gap-1.5">
          {onEquip && (
            <button onClick={onEquip} className="btn btn-primary clip-corner flex-1 px-2 py-1 text-[9px]">
              Equip
            </button>
          )}
          {onSell && (
            <button onClick={onSell} className="btn clip-corner px-2 py-1 text-[9px]">
              Discard
            </button>
          )}
        </div>
      )}
    </div>
  );
}

export default function Hub({
  progress, stats, onEquip, onUnequip, onSell, onSpendStat, onSpendSkill, onEnter, onAscend, onWipe,
}: {
  progress: Progress;
  stats: Stats;
  onEquip: (i: Item) => void;
  onUnequip: (s: Slot) => void;
  onSell: (uid: string) => void;
  onSpendStat: (k: StatPointKey) => void;
  onSpendSkill: (id: number) => void;
  onEnter: (id: RealmId) => void;
  onAscend: () => void;
  onWipe: () => void;
}) {
  const [tab, setTab] = useState<Tab>("realms");
  const [sort, setSort] = useState<"power" | "rarity">("power");
  const need = xpForLevel(progress.level);

  const inv = useMemo(() => {
    const arr = progress.inventory.slice();
    arr.sort((a, b) =>
      sort === "power" ? itemPower(b) - itemPower(a) : RARITY_ORDER.indexOf(b.rarity) - RARITY_ORDER.indexOf(a.rarity)
    );
    return arr;
  }, [progress.inventory, sort]);

  return (
    <div className="pointer-events-none absolute inset-0">
      {/* title */}
      <div className="absolute left-1/2 top-5 -translate-x-1/2 text-center">
        <div
          className="font-display text-[30px] font-bold leading-none tracking-[0.34em] text-white"
          style={{ textShadow: "0 0 26px rgba(77,227,255,0.65), 0 3px 0 #000" }}
        >
          INKFALL
        </div>
        <div className="mt-1 font-display text-[10px] tracking-[0.42em] text-cyan-200/50">
          WAVE-ARENA ACTION RPG
        </div>
      </div>

      {/* left column — identity + stats */}
      <div className="pointer-events-auto absolute left-4 top-[92px] w-[300px] panel clip-corner p-3">
        <div className="flex items-center gap-3">
          <div className="flex h-14 w-14 items-center justify-center border border-cyan-300/50 bg-black/60 font-display text-2xl font-bold text-cyan-200">
            {progress.level}
          </div>
          <div className="flex-1">
            <div className="font-display text-[10px] tracking-[0.28em] text-white/45">LEVEL</div>
            <div className="mt-1 bar-shell clip-corner h-2.5">
              <div
                className="bar-fill"
                style={{
                  width: `${Math.min(100, (progress.xp / need) * 100)}%`,
                  background: "linear-gradient(90deg,#7c5cff,#c9a2ff)",
                  boxShadow: "0 0 12px rgba(201,162,255,0.6)",
                }}
              />
            </div>
            <div className="mt-1 font-display text-[9.5px] tracking-[0.14em] text-white/40 tabular-nums">
              {progress.xp} / {need} XP · x{xpMultiplier(progress).toFixed(2)} MULT
            </div>
          </div>
        </div>

        <div className="mt-3 grid grid-cols-2 gap-1.5">
          {[
            ["HP", Math.round(stats.maxHp)],
            ["DMG", stats.dmg.toFixed(1)],
            ["ATK SPD", `${stats.atkSpeed.toFixed(2)}/s`],
            ["ENERGY", Math.round(stats.maxEnergy)],
            ["REGEN", `${stats.regen.toFixed(1)}/s`],
            ["ARMOUR", stats.armor],
            ["CRIT", `${Math.round(stats.crit * 100)}%`],
            ["CRIT DMG", `${Math.round(stats.critDmg * 100)}%`],
          ].map(([k, v]) => (
            <div key={k as string} className="panel-flat clip-corner flex items-center justify-between px-2 py-1">
              <span className="font-display text-[9px] tracking-[0.14em] text-white/40">{k}</span>
              <span className="font-display text-[11px] font-semibold text-white tabular-nums">{v}</span>
            </div>
          ))}
        </div>

        <div className="mt-3 flex justify-between font-display text-[9.5px] tracking-[0.14em] text-white/40">
          <span>TOTAL KILLS {progress.totalKills}</span>
          <span>ASCENSIONS {progress.ascensions}</span>
        </div>
      </div>

      {/* tabs */}
      <div className="pointer-events-auto absolute left-1/2 top-[92px] flex -translate-x-1/2 gap-1">
        {TABS.map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className="btn clip-corner px-4 py-2 text-[10px]"
            style={
              tab === t.id
                ? { borderColor: "#4de3ff", color: "#04121a", background: "linear-gradient(180deg,#4de3ff,#2aa8d8)" }
                : undefined
            }
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* content */}
      <div className="pointer-events-auto absolute bottom-4 left-1/2 w-[min(1080px,94vw)] -translate-x-1/2">
        <div className="panel clip-corner max-h-[46vh] overflow-hidden p-3">
          {tab === "realms" && (
            <div className="grid grid-cols-3 gap-3">
              {REALMS.map((r) => {
                const unlocked = progress.unlocked.includes(r.id);
                const cleared = progress.cleared.includes(r.id);
                return (
                  <div
                    key={r.id}
                    className="panel-flat clip-corner relative overflow-hidden p-3"
                    style={{ borderColor: `${r.css}55`, boxShadow: `inset 0 0 40px ${r.css}22` }}
                  >
                    <div
                      className="absolute inset-x-0 top-0 h-[3px]"
                      style={{ background: `linear-gradient(90deg,transparent,${r.css},transparent)` }}
                    />
                    <div className="font-display text-[9px] tracking-[0.3em]" style={{ color: r.css }}>
                      {r.sub}
                    </div>
                    <div className="font-display text-[17px] font-bold tracking-[0.1em] text-white">{r.name}</div>
                    <p className="mt-1.5 h-10 text-[11px] leading-snug text-white/50">{r.blurb}</p>
                    <div className="mt-2 grid grid-cols-3 gap-1 font-display text-[9px] tracking-[0.1em] text-white/45">
                      <div>WAVES <span className="text-white">{r.waves}</span></div>
                      <div>ILVL <span className="text-white">{r.ilvl}</span></div>
                      <div>XP <span className="text-white">{r.xp}</span></div>
                    </div>
                    <div className="mt-1 font-display text-[9px] tracking-[0.14em] text-white/35">
                      BEST WAVE {progress.bestWave[r.id] ?? 0}
                      {cleared && <span style={{ color: r.css }}> · CLEARED</span>}
                    </div>
                    <button
                      disabled={!unlocked}
                      onClick={() => onEnter(r.id)}
                      className="btn btn-primary clip-corner mt-3 w-full py-2 text-[11px]"
                    >
                      {unlocked ? "Enter Realm" : "Locked"}
                    </button>
                  </div>
                );
              })}
            </div>
          )}

          {tab === "loadout" && (
            <div className="flex max-h-[40vh] gap-3 overflow-hidden">
              <div className="w-[300px] shrink-0">
                <div className="mb-2 font-display text-[10px] tracking-[0.28em] text-white/45">EQUIPPED</div>
                <div className="space-y-1.5">
                  {SLOTS.map((s) => {
                    const it = progress.equipped[s];
                    return (
                      <div key={s} className="flex gap-2">
                        <div className="panel-flat clip-corner flex h-full w-[112px] shrink-0 items-center gap-2 px-2 py-1.5">
                          <span className="text-[15px]">{SLOT_INFO[s].icon}</span>
                          <div className="min-w-0">
                            <div className="font-display text-[9px] tracking-[0.16em] text-white/40">
                              {SLOT_INFO[s].name.toUpperCase()}
                            </div>
                            {it ? (
                              <button
                                onClick={() => onUnequip(s)}
                                className="truncate font-display text-[10.5px] hover:underline"
                                style={{ color: RARITY[it.rarity].color }}
                                title="Unequip"
                              >
                                {it.name}
                              </button>
                            ) : (
                              <span className="font-display text-[10px] text-white/25">— empty —</span>
                            )}
                          </div>
                        </div>
                        {it && (
                          <div className="flex-1">
                            {it.affixes.map((a, i) => (
                              <div key={i} className="flex justify-between font-display text-[10px]">
                                <span className="text-white/40">{STAT_LABEL[a.stat]}</span>
                                <span className="text-emerald-300 tabular-nums">+{a.value}</span>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
              <div className="min-w-0 flex-1">
                <div className="mb-2 flex items-center justify-between">
                  <div className="font-display text-[10px] tracking-[0.28em] text-white/45">
                    VAULT · {progress.inventory.length}
                  </div>
                  <div className="flex gap-1">
                    {(["power", "rarity"] as const).map((k) => (
                      <button
                        key={k}
                        onClick={() => setSort(k)}
                        className="btn clip-corner px-2 py-1 text-[9px]"
                        style={sort === k ? { borderColor: "#4de3ff", color: "#4de3ff" } : undefined}
                      >
                        {k}
                      </button>
                    ))}
                  </div>
                </div>
                <div className="grid max-h-[34vh] grid-cols-3 gap-2 overflow-y-auto pr-1">
                  {inv.length === 0 && (
                    <div className="col-span-3 py-8 text-center font-display text-[11px] tracking-[0.2em] text-white/25">
                      NO GEAR YET — CLEAR WAVES TO LOOT
                    </div>
                  )}
                  {inv.map((it) => (
                    <ItemCard key={it.uid} item={it} onEquip={() => onEquip(it)} onSell={() => onSell(it.uid)} />
                  ))}
                </div>
              </div>
            </div>
          )}

          {tab === "stats" && (
            <div>
              <div className="mb-3 flex items-center justify-between">
                <div className="font-display text-[10px] tracking-[0.28em] text-white/45">
                  ATTRIBUTE POINTS
                </div>
                <div className="font-display text-[13px] font-bold text-cyan-200">
                  {progress.statPoints} AVAILABLE
                </div>
              </div>
              <div className="grid grid-cols-4 gap-2">
                {(Object.keys(STAT_INFO) as StatPointKey[]).map((k) => (
                  <div key={k} className="panel-flat clip-corner p-3 text-center">
                    <div className="font-display text-[12px] font-bold tracking-[0.1em]" style={{ color: STAT_INFO[k].color }}>
                      {STAT_INFO[k].name.toUpperCase()}
                    </div>
                    <div className="mt-1 font-display text-2xl font-bold text-white tabular-nums">
                      {progress.points[k]}
                    </div>
                    <div className="mt-1 text-[10px] leading-tight text-white/45">{STAT_INFO[k].desc}</div>
                    <button
                      disabled={progress.statPoints <= 0}
                      onClick={() => onSpendStat(k)}
                      className="btn btn-primary clip-corner mt-2 w-full py-1.5 text-[10px]"
                    >
                      Invest
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {tab === "skills" && (
            <div>
              <div className="mb-3 flex items-center justify-between">
                <div className="font-display text-[10px] tracking-[0.28em] text-white/45">SKILL POINTS</div>
                <div className="font-display text-[13px] font-bold text-cyan-200">
                  {progress.skillPoints} AVAILABLE
                </div>
              </div>
              <div className="grid grid-cols-3 gap-2">
                {SKILLS.map((s) => {
                  const lvl = progress.skillLevels[s.id - 1];
                  const locked = progress.level < s.unlockLevel;
                  return (
                    <div
                      key={s.id}
                      className="panel-flat clip-corner p-2.5"
                      style={{ borderColor: lvl > 0 ? `#${s.color.toString(16).padStart(6, "0")}77` : undefined }}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <div
                            className="keycap flex h-6 w-6 items-center justify-center text-[12px] font-bold"
                            style={{ color: `#${s.color.toString(16).padStart(6, "0")}` }}
                          >
                            {s.key}
                          </div>
                          <div className="font-display text-[12px] font-bold text-white">{s.name}</div>
                        </div>
                        <div className="font-display text-[10px] text-white/50">
                          {lvl > 0 ? `L${lvl}` : locked ? `LV${s.unlockLevel}` : "—"}
                        </div>
                      </div>
                      <p className="mt-1.5 h-10 text-[10px] leading-snug text-white/45">{s.desc}</p>
                      <div className="mt-1 flex justify-between font-display text-[9px] tracking-[0.1em] text-white/40">
                        <span style={{ color: "#5fd8ff" }}>{s.cost} EN</span>
                        <span>{s.cd}s CD</span>
                        <span>{Math.round(s.power * 100)}% PWR</span>
                      </div>
                      <button
                        disabled={progress.skillPoints <= 0 || lvl >= skillMaxLevel || locked}
                        onClick={() => onSpendSkill(s.id)}
                        className="btn btn-primary clip-corner mt-2 w-full py-1.5 text-[10px]"
                      >
                        {lvl === 0 ? (locked ? `Unlocks at LV ${s.unlockLevel}` : "Unlock") : lvl >= skillMaxLevel ? "Maxed" : "Upgrade"}
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {tab === "ascend" && (
            <div className="grid grid-cols-2 gap-4">
              <div>
                <div className="font-display text-[16px] font-bold tracking-[0.16em] text-white">ASCENSION</div>
                <p className="mt-2 text-[12px] leading-relaxed text-white/55">
                  Ascend to dissolve this run's progression — level, attributes, skills and every piece of gear — and
                  bank a <span className="text-cyan-200">permanent stacking XP multiplier</span>. Realms stay unlocked,
                  and the multiplier compounds forever.
                </p>
                <div className="mt-3 space-y-1.5 font-display text-[11px] tracking-[0.1em]">
                  <div className="flex justify-between panel-flat clip-corner px-3 py-1.5">
                    <span className="text-white/45">CURRENT MULTIPLIER</span>
                    <span className="text-white">x{xpMultiplier(progress).toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between panel-flat clip-corner px-3 py-1.5">
                    <span className="text-white/45">ASCENSIONS BANKED</span>
                    <span className="text-white">{progress.ascensions}</span>
                  </div>
                  <div className="flex justify-between panel-flat clip-corner px-3 py-1.5">
                    <span className="text-white/45">REQUIREMENT</span>
                    <span className={canAscend(progress) ? "text-emerald-300" : "text-rose-300"}>
                      LEVEL {PRESTIGE_REQ_LEVEL}
                    </span>
                  </div>
                  <div className="flex justify-between panel-flat clip-corner px-3 py-1.5">
                    <span className="text-white/45">GAIN ON ASCEND</span>
                    <span className="text-cyan-200">+{ascensionGain(progress)} ascension{ascensionGain(progress) > 1 ? "s" : ""}</span>
                  </div>
                </div>
              </div>
              <div className="flex flex-col items-center justify-center gap-3">
                <button
                  disabled={!canAscend(progress)}
                  onClick={onAscend}
                  className="btn btn-danger clip-corner w-full py-3 text-[13px] font-bold"
                >
                  {canAscend(progress) ? "Ascend" : `Reach Level ${PRESTIGE_REQ_LEVEL} to Ascend`}
                </button>
                <button onClick={onWipe} className="btn clip-corner w-full py-2 text-[10px]">
                  Wipe Save
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      <div className="absolute bottom-1 left-1/2 -translate-x-1/2 font-display text-[9px] tracking-[0.3em] text-white/20">
        CLICK A PORTAL OR USE THE REALMS TAB
      </div>
    </div>
  );
}
