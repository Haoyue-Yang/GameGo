import { RARITY, type Item, type RealmDef } from "../game/data";

export interface Toast {
  id: number;
  item: Item;
}

export function LootToasts({ toasts }: { toasts: Toast[] }) {
  return (
    <div className="pointer-events-none absolute right-4 top-[132px] flex w-[260px] flex-col gap-2">
      {toasts.map((t) => {
        const r = RARITY[t.item.rarity];
        return (
          <div
            key={t.id}
            className="toast panel clip-corner px-3 py-2"
            style={{ borderColor: `${r.color}88`, boxShadow: `0 0 22px ${r.glow}, inset 0 0 18px ${r.glow}` }}
          >
            <div className="font-display text-[9px] tracking-[0.26em]" style={{ color: r.color }}>
              {r.name.toUpperCase()} DROP
            </div>
            <div className="truncate font-display text-[12px] font-semibold text-white">{t.item.name}</div>
            <div className="mt-0.5 flex flex-wrap gap-x-2 font-display text-[9.5px] text-emerald-300">
              {t.item.affixes.map((a, i) => (
                <span key={i}>+{a.value} {a.stat}</span>
              ))}
            </div>
          </div>
        );
      })}
    </div>
  );
}

export function DeathOverlay({
  realm, kills, wave, onReturn,
}: { realm: RealmDef | null; kills: number; wave: number; onReturn: () => void }) {
  return (
    <div className="pointer-events-auto absolute inset-0 flex items-center justify-center bg-black/72 backdrop-blur-sm">
      <div className="panel clip-corner w-[min(460px,90vw)] p-7 text-center rise">
        <div
          className="font-display text-[40px] font-bold leading-none tracking-[0.2em] text-rose-400"
          style={{ textShadow: "0 0 30px rgba(255,60,90,0.7), 0 4px 0 #000" }}
        >
          YOU FELL
        </div>
        <p className="mt-3 text-[12px] leading-relaxed text-white/55">
          The ink runs out. Your progress, gear and unlocked realms are untouched — the sanctum always takes you back.
        </p>
        <div className="mt-4 grid grid-cols-2 gap-2">
          <div className="panel-flat clip-corner px-3 py-2">
            <div className="font-display text-[9px] tracking-[0.2em] text-white/40">REALM</div>
            <div className="font-display text-[12px] text-white">{realm?.name ?? "—"}</div>
          </div>
          <div className="panel-flat clip-corner px-3 py-2">
            <div className="font-display text-[9px] tracking-[0.2em] text-white/40">REACHED</div>
            <div className="font-display text-[12px] text-white">WAVE {wave} · {kills} KILLS</div>
          </div>
        </div>
        <button onClick={onReturn} className="btn btn-primary clip-corner mt-5 w-full py-3 text-[13px] font-bold">
          Return to Sanctum
        </button>
      </div>
    </div>
  );
}

export function ClearOverlay({
  realm, kills, wave, levels, xpGained, onReturn, onReplay,
}: {
  realm: RealmDef | null; kills: number; wave: number; levels: number; xpGained: number;
  onReturn: () => void; onReplay: () => void;
}) {
  return (
    <div className="pointer-events-auto absolute inset-0 flex items-center justify-center bg-black/70 backdrop-blur-sm">
      <div
        className="panel clip-corner w-[min(520px,92vw)] p-7 text-center rise"
        style={{ borderColor: `${realm?.css ?? "#4de3ff"}88`, boxShadow: `0 0 60px ${realm?.css ?? "#4de3ff"}44` }}
      >
        <div
          className="font-display text-[34px] font-bold leading-none tracking-[0.18em] text-white"
          style={{ textShadow: `0 0 30px ${realm?.css ?? "#4de3ff"}, 0 4px 0 #000` }}
        >
          REALM CLEARED
        </div>
        <div className="mt-2 font-display text-[11px] tracking-[0.34em]" style={{ color: realm?.css }}>
          {realm?.name}
        </div>
        <div className="mt-5 grid grid-cols-3 gap-2">
          {[
            ["KILLS", `${kills}`],
            ["WAVES", `${wave}`],
            ["XP BANKED", `${xpGained}`],
          ].map(([k, v]) => (
            <div key={k} className="panel-flat clip-corner px-2 py-2">
              <div className="font-display text-[9px] tracking-[0.2em] text-white/40">{k}</div>
              <div className="font-display text-[18px] font-bold text-white tabular-nums">{v}</div>
            </div>
          ))}
        </div>
        {levels > 0 && (
          <div className="mt-3 font-display text-[12px] tracking-[0.2em] text-amber-300 pulse">
            LEVEL UP x{levels} — {levels * 3} ATTRIBUTE · {levels * 2} SKILL POINTS
          </div>
        )}
        <div className="mt-5 flex gap-2">
          <button onClick={onReplay} className="btn clip-corner flex-1 py-3 text-[12px]">
            Run It Again
          </button>
          <button onClick={onReturn} className="btn btn-primary clip-corner flex-1 py-3 text-[12px] font-bold">
            Back to Sanctum
          </button>
        </div>
      </div>
    </div>
  );
}

export function LevelUpFlash({ level }: { level: number }) {
  return (
    <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
      <div className="shock absolute h-40 w-40 rounded-full border-2 border-amber-300/70" />
      <div
        className="font-display text-[52px] font-bold tracking-[0.14em] text-amber-300"
        style={{ textShadow: "0 0 34px rgba(255,190,80,0.9), 0 4px 0 #000" }}
      >
        LEVEL {level}
      </div>
    </div>
  );
}
