import * as THREE from "three";
import { glowMaterial, setOutlineFog, type StageCtx } from "../three/cel";
import { buildChampion, buildBoss, buildEnemy, type ActorVisual } from "../three/actors";
import { buildHub, buildRealm, setPortalLocked, type Stage } from "../three/stage";
import { Vfx, makeHealthBar } from "../three/vfx";
import {
  BOSSES, BOSS_MULT, ENEMIES, REALMS, SKILLS, realmById, rollItem,
  type EnemyKind, type Item, type RealmDef, type RealmId,
} from "../game/data";
import { skillDamageMul, skillUnlocked, type Progress, type Stats } from "../game/progress";

export type Phase = "hub" | "run" | "dead" | "clear";

export interface SkillHud {
  id: number; name: string; key: string; cd: number; cdMax: number;
  cost: number; ready: boolean; unlocked: boolean; level: number; color: number;
}

export interface HudSnapshot {
  phase: Phase;
  hp: number; maxHp: number;
  energy: number; maxEnergy: number;
  wave: number; waves: number;
  enemies: number;
  boss: { name: string; title: string; hp: number; maxHp: number } | null;
  skills: SkillHud[];
  speed: number;
  realm: RealmId | null;
  kills: number;
  dps: number;
  banner: string | null;
  bannerSub: string | null;
  runTime: number;
}

export type EngineEvent =
  | { type: "kill"; xp: number }
  | { type: "loot"; item: Item }
  | { type: "death" }
  | { type: "clear"; realm: RealmId; wave: number; kills: number }
  | { type: "wave"; wave: number; waves: number };

// ---- fixed camera pose (never orbits, pans, zooms or follows) ----
const CAM_POS = new THREE.Vector3(0, 4.5, 12);
const CAM_TARGET = new THREE.Vector3(0, 2.2, 0);
const CAM_FOV = 42;

const LANE_MIN = -8.2;
const LANE_MAX = 8.2;
const SPAWN_X = 13.5;

interface Champion {
  vis: ActorVisual;
  x: number; z: number;
  facing: number;
  hp: number; energy: number;
  atkTimer: number;
  swingT: number; swingDur: number; swingHit: boolean;
  cds: number[];
  invuln: number;
  hurtT: number;
  dashT: number; dashFrom: number; dashTo: number;
  bob: number;
  moving: number;
  groupY: number;
}

interface Enemy {
  vis: ActorVisual;
  kind: EnemyKind | "boss";
  name: string; title: string;
  x: number; z: number;
  hp: number; maxHp: number;
  dmg: number; speed: number;
  range: number; windup: number; recover: number;
  radius: number; scale: number; xp: number; ranged: boolean;
  state: "walk" | "wind" | "recover" | "dead";
  timer: number;
  facing: number;
  flash: number;
  deathT: number;
  isBoss: boolean;
  attackIdx: number;
  stagger: number;
  bob: number;
  bar: { mesh: THREE.Mesh; mat: THREE.ShaderMaterial };
  height: number;
}

interface Proj {
  mesh: THREE.Mesh;
  x: number; y: number; z: number;
  vx: number; life: number;
  dmg: number; hostile: boolean; radius: number;
}

export class Engine {
  private renderer: THREE.WebGLRenderer;
  private scene = new THREE.Scene();
  private camera: THREE.PerspectiveCamera;
  private reflCam: THREE.PerspectiveCamera;
  private reflRT: THREE.WebGLRenderTarget;
  private sky: THREE.Mesh;
  private skyMat: THREE.ShaderMaterial;

  private hub: Stage;
  private realms = new Map<RealmId, Stage>();
  private stage: Stage;

  private vfx = new Vfx();
  private champion!: Champion;
  private enemies: Enemy[] = [];
  private projectiles: Proj[] = [];
  private floaters: HTMLDivElement | null = null;

  private keys = new Set<string>();
  private raycaster = new THREE.Raycaster();
  private pointer = new THREE.Vector2();

  private stats: Stats;
  private progress: Progress;
  private skillLevels: number[] = [1, 0, 0, 0, 0, 0];

  phase: Phase = "hub";
  speed = 1;
  private realmDef: RealmDef = REALMS[0];
  private wave = 0;
  private waveTimer = 0;
  private spawnQueue: { kind: EnemyKind; side: number; z: number }[] = [];
  private spawnTimer = 0;
  private boss: Enemy | null = null;
  private kills = 0;
  private runTime = 0;
  private banner: string | null = null;
  private bannerSub: string | null = null;
  private bannerT = 0;
  private dmgLog: { t: number; v: number }[] = [];
  private time = 0;
  private shake = 0;
  private shakeVec = new THREE.Vector3();
  private raf = 0;
  private last = 0;
  private hudAccum = 0;
  private running = false;
  private disposed = false;

  onHud: (s: HudSnapshot) => void = () => {};
  onEvent: (e: EngineEvent) => void = () => {};

  constructor(
    private canvas: HTMLCanvasElement,
    progress: Progress,
    stats: Stats
  ) {
    this.progress = progress;
    this.stats = stats;
    this.skillLevels = progress.skillLevels.slice();

    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: "high-performance" });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.setClearColor(0x05070c, 1);
    this.renderer.toneMapping = THREE.NoToneMapping;
    this.renderer.outputColorSpace = THREE.LinearSRGBColorSpace;

    this.camera = new THREE.PerspectiveCamera(CAM_FOV, 1, 0.1, 260);
    this.camera.position.copy(CAM_POS);
    this.camera.lookAt(CAM_TARGET);

    this.reflCam = new THREE.PerspectiveCamera(CAM_FOV, 1, 0.1, 260);

    this.reflRT = new THREE.WebGLRenderTarget(1024, 512, {
      minFilter: THREE.LinearFilter,
      magFilter: THREE.LinearFilter,
      depthBuffer: true,
    });

    this.skyMat = new THREE.ShaderMaterial({
      uniforms: {
        uTop: { value: new THREE.Color(0x0a1524) },
        uBottom: { value: new THREE.Color(0x123048) },
        uAccent: { value: new THREE.Color(0x4de3ff) },
      },
      vertexShader: `varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }`,
      fragmentShader: /* glsl */ `
        uniform vec3 uTop, uBottom, uAccent;
        varying vec2 vUv;
        void main() {
          float t = clamp(vUv.y, 0.0, 1.0);
          vec3 c = mix(uBottom, uTop, pow(t, 0.75));
          c += uAccent * exp(-pow((t - 0.14) * 6.5, 2.0)) * 0.30;
          gl_FragColor = vec4(c, 1.0);
        }
      `,
      depthWrite: false,
    });
    this.sky = new THREE.Mesh(new THREE.PlaneGeometry(420, 300), this.skyMat);
    this.sky.position.set(0, 62, -104);
    this.scene.add(this.sky);

    this.scene.add(this.vfx.group);

    this.hub = buildHub();
    this.scene.add(this.hub.group);
    this.stage = this.hub;

    this.spawnChampion(this.hub.ctx);
    this.champion.x = 0;
    this.champion.z = 1.2;
    this.champion.groupY = 0.8;

    this.applyStageLook();
    this.resize();
  }

  // -------------------------------------------------------------------------
  // lifecycle
  // -------------------------------------------------------------------------

  start() {
    if (this.running) return;
    this.running = true;
    this.resize();
    this.last = performance.now();
    window.addEventListener("keydown", this.onKeyDown);
    window.addEventListener("keyup", this.onKeyUp);
    window.addEventListener("resize", this.resize);
    window.addEventListener("blur", this.onBlur);
    this.canvas.addEventListener("pointerdown", this.onPointerDown);
    this.loop();
  }

  dispose() {
    this.disposed = true;
    this.running = false;
    cancelAnimationFrame(this.raf);
    window.removeEventListener("keydown", this.onKeyDown);
    window.removeEventListener("keyup", this.onKeyUp);
    window.removeEventListener("resize", this.resize);
    window.removeEventListener("blur", this.onBlur);
    this.canvas.removeEventListener("pointerdown", this.onPointerDown);
    this.renderer.dispose();
  }

  private onBlur = () => this.keys.clear();

  private onKeyDown = (e: KeyboardEvent) => {
    const k = e.key.toLowerCase();
    if (["a", "d", "arrowleft", "arrowright", " ", "1", "2", "3", "4", "5", "6"].includes(k)) e.preventDefault();
    this.keys.add(k);
    const n = parseInt(k, 10);
    if (n >= 1 && n <= 6) this.cast(n);
  };

  private onKeyUp = (e: KeyboardEvent) => this.keys.delete(e.key.toLowerCase());

  private onPointerDown = (e: PointerEvent) => {
    if (this.phase !== "hub") return;
    const r = this.canvas.getBoundingClientRect();
    this.pointer.set(((e.clientX - r.left) / r.width) * 2 - 1, -((e.clientY - r.top) / r.height) * 2 + 1);
    this.raycaster.setFromCamera(this.pointer, this.camera);
    const hits = this.raycaster.intersectObjects(this.hub.portals, false);
    if (hits.length) {
      const id = hits[0].object.userData.realm as RealmId;
      if (this.progress.unlocked.includes(id)) this.enterRealm(id);
    }
  };

  resize = () => {
    const w = this.canvas.clientWidth || window.innerWidth;
    const h = this.canvas.clientHeight || window.innerHeight;
    this.renderer.setSize(w, h, false);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.reflCam.aspect = w / h;
    this.reflCam.updateProjectionMatrix();
    const pr = Math.min(window.devicePixelRatio, 2);
    this.reflRT.setSize(Math.max(256, Math.floor(w * 0.5 * pr)), Math.max(128, Math.floor(h * 0.5 * pr)));
  };

  // -------------------------------------------------------------------------
  // public API
  // -------------------------------------------------------------------------

  setProgress(progress: Progress, stats: Stats) {
    this.progress = progress;
    this.stats = stats;
    this.skillLevels = progress.skillLevels.slice();
    if (this.phase === "hub") {
      this.champion.hp = stats.maxHp;
      this.champion.energy = stats.maxEnergy;
      setPortalLocked(this.hub.portals, progress.unlocked);
    }
  }

  setSpeed(s: number) {
    this.speed = s;
  }

  setFloaterLayer(el: HTMLDivElement | null) {
    this.floaters = el;
  }

  enterHub() {
    this.clearRun();
    this.stage = this.hub;
    this.phase = "hub";
    this.champion.x = 0;
    this.champion.z = 1.2;
    this.champion.groupY = 0.8;
    this.champion.hp = this.stats.maxHp;
    this.champion.energy = this.stats.maxEnergy;
    this.champion.cds = [0, 0, 0, 0, 0, 0];
    this.spawnChampion(this.hub.ctx);
    setPortalLocked(this.hub.portals, this.progress.unlocked);
    this.applyStageLook();
    this.setBanner("SANCTUM", "Choose a realm");
  }

  enterRealm(id: RealmId) {
    const def = realmById(id);
    let st = this.realms.get(id);
    if (!st) {
      st = buildRealm(def);
      this.realms.set(id, st);
      this.scene.add(st.group);
    }
    this.clearRun();
    this.stage = st;
    this.realmDef = def;
    this.phase = "run";
    this.wave = 0;
    this.kills = 0;
    this.runTime = 0;
    this.waveTimer = 1.4;
    this.spawnQueue = [];
    this.boss = null;
    this.champion.x = 0;
    this.champion.z = 0;
    this.champion.groupY = 0;
    this.champion.hp = this.stats.maxHp;
    this.champion.energy = this.stats.maxEnergy;
    this.champion.cds = [0, 0, 0, 0, 0, 0];
    this.champion.invuln = 0.8;
    this.spawnChampion(st.ctx);
    this.applyStageLook();
    this.setBanner(def.name, def.sub);
  }

  private clearRun() {
    for (const e of this.enemies) this.disposeEnemy(e);
    this.enemies.length = 0;
    for (const p of this.projectiles) this.scene.remove(p.mesh);
    this.projectiles.length = 0;
    this.boss = null;
  }

  private applyStageLook() {
    const ctx = this.stage.ctx;
    setOutlineFog(ctx.fog, ctx.fogNear, ctx.fogFar);
    (this.skyMat.uniforms.uBottom.value as THREE.Color).setHex(ctx.fog);
    (this.skyMat.uniforms.uTop.value as THREE.Color)
      .setHex(this.stage === this.hub ? 0x0a1524 : this.realmDef.sky)
      .multiplyScalar(0.85);
    (this.skyMat.uniforms.uAccent.value as THREE.Color).setHex(this.stage === this.hub ? 0x4de3ff : this.realmDef.accent);
    this.renderer.setClearColor(ctx.fog, 1);
    this.scene.fog = new THREE.Fog(ctx.fog, ctx.fogNear, ctx.fogFar);
    this.stage.floorMat.uniforms.uRefl.value = this.reflRT.texture;
  }

  // -------------------------------------------------------------------------
  // champion
  // -------------------------------------------------------------------------

  private spawnChampion(ctx: StageCtx) {
    if (this.champion) {
      this.scene.remove(this.champion.vis.group);
      this.champion.vis.skin.dispose();
    }
    const vis = buildChampion(ctx, this.stage === this.hub ? 0x4de3ff : this.realmDef.accent2);
    this.scene.add(vis.group);
    const keep = this.champion
      ? { x: this.champion.x, z: this.champion.z, hp: this.champion.hp, energy: this.champion.energy, g: this.champion.groupY }
      : { x: 0, z: 0, hp: this.stats.maxHp, energy: this.stats.maxEnergy, g: 0 };
    this.champion = {
      vis, x: keep.x, z: keep.z, facing: 1, hp: keep.hp, energy: keep.energy,
      atkTimer: 0, swingT: 0, swingDur: 0.34, swingHit: false,
      cds: this.champion?.cds ?? [0, 0, 0, 0, 0, 0],
      invuln: 0, hurtT: 0, dashT: 0, dashFrom: 0, dashTo: 0, bob: 0, moving: 0, groupY: keep.g,
    };
  }

  // -------------------------------------------------------------------------
  // combat
  // -------------------------------------------------------------------------

  private nearestEnemy(x = this.champion.x, z = this.champion.z, maxD = 99) {
    let best: Enemy | null = null;
    let bd = maxD * maxD;
    for (const e of this.enemies) {
      if (e.state === "dead") continue;
      const d = (e.x - x) ** 2 + (e.z - z) ** 2 * 0.55;
      if (d < bd) { bd = d; best = e; }
    }
    return best;
  }

  private rollDamage(base: number) {
    const crit = Math.random() < this.stats.crit;
    const v = base * (crit ? this.stats.critDmg : 1) * (0.92 + Math.random() * 0.16);
    return { v: Math.max(1, Math.round(v)), crit };
  }

  private hitEnemy(e: Enemy, base: number, fxColor: number, big = false) {
    if (e.state === "dead") return;
    const { v, crit } = this.rollDamage(base);
    e.hp -= v;
    e.flash = 1;
    this.dmgLog.push({ t: this.time, v });
    this.floater(e.x, e.height * e.scale + 0.35, e.z, `${v}`, crit ? "#ffe066" : "#ffffff", crit ? 1.5 : 1);
    const y = e.height * e.scale * 0.55;
    this.vfx.sphere(e.x, y, e.z, fxColor, 0.2, big ? 1.5 : 0.85, 0.22, this.stage.ctx.fog);
    this.vfx.burst(e.x, y, e.z, fxColor, big ? 8 : 4, big ? 5 : 3.4, 0.5, this.stage.ctx.fog);
    if (e.hp <= 0) this.killEnemy(e);
  }

  private killEnemy(e: Enemy) {
    e.state = "dead";
    e.deathT = 0.55;
    e.hp = 0;
    this.kills += 1;
    const y = e.height * e.scale * 0.5;
    this.vfx.sphere(e.x, y, e.z, this.realmDef.accent, 0.4, e.isBoss ? 6 : 2.2, e.isBoss ? 0.7 : 0.35, this.stage.ctx.fog);
    this.vfx.burst(e.x, y, e.z, this.realmDef.accent, e.isBoss ? 40 : 12, e.isBoss ? 9 : 5, 0.9, this.stage.ctx.fog);
    this.vfx.ring(e.x, 0.05, e.z, this.realmDef.accent2, 0.5, e.isBoss ? 12 : 4, 0.6, this.stage.ctx.fog);
    this.onEvent({ type: "kill", xp: Math.round(e.xp) });
    if (e.isBoss) {
      this.shake = Math.max(this.shake, 0.9);
      this.dropLoot(2);
      this.finishRun();
    } else if (Math.random() < 0.16) {
      this.dropLoot(1);
    }
  }

  private dropLoot(n: number) {
    for (let i = 0; i < n; i++) {
      const item = rollItem(this.realmDef.ilvl + Math.floor(this.progress.level / 3));
      this.onEvent({ type: "loot", item });
    }
  }

  private finishRun() {
    this.phase = "clear";
    this.setBanner("REALM CLEARED", this.realmDef.name);
    this.onEvent({ type: "clear", realm: this.realmDef.id, wave: this.wave, kills: this.kills });
  }

  private hurtChampion(raw: number) {
    const c = this.champion;
    if (c.invuln > 0 || this.phase !== "run") return;
    const dmg = Math.max(1, Math.round(raw * (100 / (100 + this.stats.armor))));
    c.hp -= dmg;
    c.hurtT = 0.28;
    c.invuln = 0.22;
    this.shake = Math.min(1.2, this.shake + 0.32 + dmg * 0.004);
    this.floater(c.x, 2.6, c.z, `-${dmg}`, "#ff6b7d", 1.25);
    this.vfx.sphere(c.x, 1.2, c.z, 0xff5a6e, 0.3, 1.5, 0.24, this.stage.ctx.fog);
    if (c.hp <= 0) {
      c.hp = 0;
      this.phase = "dead";
      this.shake = 1.4;
      this.vfx.sphere(c.x, 1.2, c.z, 0xffffff, 0.5, 5, 0.7, this.stage.ctx.fog);
      this.vfx.burst(c.x, 1.2, c.z, 0xff5a6e, 26, 7, 1.1, this.stage.ctx.fog);
      this.setBanner("YOU FELL", "Progress preserved");
      this.onEvent({ type: "death" });
    }
  }

  private cast(id: number) {
    if (this.phase !== "run") return;
    const c = this.champion;
    const def = SKILLS[id - 1];
    if (!def) return;
    if (!skillUnlocked(this.progress, id)) return;
    if (c.cds[id - 1] > 0) return;
    if (c.energy < def.cost) {
      this.floater(c.x, 2.9, c.z, "NO ENERGY", "#7fd8ff", 0.95);
      return;
    }
    c.energy -= def.cost;
    c.cds[id - 1] = def.cd;
    const lvl = this.skillLevels[id - 1];
    const mult = skillDamageMul(lvl);
    const base = this.stats.dmg * def.power * mult;
    const col = def.color;
    const target = this.nearestEnemy();
    if (target) c.facing = Math.sign(target.x - c.x) || c.facing;

    switch (def.kind) {
      case "cleave": {
        c.swingT = 0.3;
        c.swingDur = 0.3;
        c.swingHit = false;
        this.vfx.arc(c.x + c.facing * 1.1, 1.25, c.z, col, 1.2, 3.4, 0.26, this.stage.ctx.fog);
        this.vfx.arc(c.x + c.facing * 1.1, 1.25, c.z, 0xffffff, 0.9, 2.8, 0.18, this.stage.ctx.fog);
        for (const e of this.enemies) {
          if (e.state === "dead") continue;
          const dx = (e.x - c.x) * c.facing;
          if (dx > -0.8 && dx < 3.6 && Math.abs(e.z - c.z) < 2.4) {
            this.hitEnemy(e, base, col);
            e.stagger = Math.max(e.stagger, 0.22);
          }
        }
        break;
      }
      case "lance": {
        const dir = c.facing;
        this.vfx.beam(c.x + dir * 0.6, 1.25, c.z, dir, 26, col, 0.34, this.stage.ctx.fog, 0.5);
        this.vfx.sphere(c.x + dir * 0.8, 1.25, c.z, 0xffffff, 0.2, 1.2, 0.2, this.stage.ctx.fog);
        for (const e of this.enemies) {
          if (e.state === "dead") continue;
          const dx = (e.x - c.x) * dir;
          if (dx > 0 && dx < 26 && Math.abs(e.z - c.z) < 1.5) this.hitEnemy(e, base, col, true);
        }
        break;
      }
      case "quake": {
        this.shake = Math.max(this.shake, 0.55);
        this.vfx.ring(c.x, 0.06, c.z, col, 0.6, 7.5, 0.5, this.stage.ctx.fog);
        this.vfx.ring(c.x, 0.06, c.z, 0xffffff, 0.4, 5, 0.35, this.stage.ctx.fog);
        this.vfx.burst(c.x, 0.2, c.z, col, 22, 6, 0.8, this.stage.ctx.fog);
        for (const e of this.enemies) {
          if (e.state === "dead") continue;
          const d = Math.hypot(e.x - c.x, (e.z - c.z) * 1.4);
          if (d < 6.2) {
            this.hitEnemy(e, base * (1 - d / 9), col, true);
            e.stagger = Math.max(e.stagger, 0.55);
          }
        }
        break;
      }
      case "dash": {
        const t = target ?? this.enemies.find((e) => e.state !== "dead");
        const to = t ? t.x : c.x + c.facing * 5;
        c.dashFrom = c.x;
        c.dashTo = THREE.MathUtils.clamp(to, LANE_MIN, LANE_MAX);
        c.dashT = 0.2;
        c.invuln = Math.max(c.invuln, 0.34);
        const dir = Math.sign(c.dashTo - c.dashFrom) || c.facing;
        c.facing = dir;
        for (let i = 0; i < 7; i++) {
          this.vfx.sphere(
            THREE.MathUtils.lerp(c.dashFrom, c.dashTo, i / 7), 1.1, c.z, col, 0.55, 0.05, 0.3, this.stage.ctx.fog
          );
        }
        for (const e of this.enemies) {
          if (e.state === "dead") continue;
          if ((e.x - c.dashFrom) * dir > -0.6 && (e.x - c.dashFrom) * dir < Math.abs(c.dashTo - c.dashFrom) + 1.2) {
            this.hitEnemy(e, base, col);
            e.stagger = Math.max(e.stagger, 0.3);
          }
        }
        break;
      }
      case "nova": {
        this.shake = Math.max(this.shake, 0.7);
        this.vfx.ring(c.x, 0.06, c.z, col, 0.5, 11, 0.55, this.stage.ctx.fog);
        this.vfx.ring(c.x, 1.1, c.z, 0xffffff, 0.4, 8, 0.4, this.stage.ctx.fog, false);
        this.vfx.sphere(c.x, 1.1, c.z, col, 0.5, 7, 0.45, this.stage.ctx.fog);
        this.vfx.burst(c.x, 1.1, c.z, col, 30, 8, 0.9, this.stage.ctx.fog);
        for (const e of this.enemies) {
          if (e.state === "dead") continue;
          const d = Math.hypot(e.x - c.x, (e.z - c.z) * 1.3);
          if (d < 9) {
            this.hitEnemy(e, base * (1 - d / 13), col, true);
            e.stagger = Math.max(e.stagger, 0.7);
          }
        }
        break;
      }
      case "overdrive": {
        this.shake = Math.max(this.shake, 1.1);
        for (let i = 0; i < 5; i++) {
          this.vfx.ring(c.x, 0.06, c.z, col, 0.5 + i, 16 + i * 3, 0.7 + i * 0.1, this.stage.ctx.fog);
        }
        this.vfx.sphere(c.x, 1.2, c.z, 0xffffff, 0.6, 14, 0.6, this.stage.ctx.fog);
        this.vfx.burst(c.x, 1.2, c.z, col, 46, 11, 1.2, this.stage.ctx.fog);
        for (const e of this.enemies) {
          if (e.state === "dead") continue;
          this.hitEnemy(e, base, col, true);
          e.stagger = Math.max(e.stagger, 1.0);
        }
        c.hp = Math.min(this.stats.maxHp, c.hp + this.stats.maxHp * 0.22);
        this.floater(c.x, 3.1, c.z, "INKFALL", "#ffffff", 1.9);
        break;
      }
    }
  }

  // -------------------------------------------------------------------------
  // enemies
  // -------------------------------------------------------------------------

  private spawnEnemy(kind: EnemyKind, side: number, z: number) {
    const def = ENEMIES[kind];
    const vis = buildEnemy(this.stage.ctx, kind, this.realmDef);
    const hp = this.realmDef.hp * def.hp;
    const bar = makeHealthBar();
    bar.mesh.scale.set(1.15, 0.11, 1);
    this.scene.add(bar.mesh);
    const e: Enemy = {
      vis, kind, name: def.name, title: "",
      x: side * SPAWN_X, z,
      hp, maxHp: hp,
      dmg: this.realmDef.dmg * def.dmg,
      speed: def.speed, range: def.range, windup: def.windup, recover: def.recover,
      radius: def.radius, scale: def.scale, xp: this.realmDef.xp * def.xp,
      ranged: !!def.ranged,
      state: "walk", timer: 0, facing: -side, flash: 0, deathT: 0,
      isBoss: false, attackIdx: 0, stagger: 0, bob: Math.random() * 6,
      bar, height: vis.height,
    };
    vis.group.scale.setScalar(def.scale);
    this.scene.add(vis.group);
    this.enemies.push(e);
  }

  private spawnBoss() {
    const def = this.realmDef;
    const b = BOSSES[def.boss];
    const vis = buildBoss(this.stage.ctx, def.boss, def);
    const hp = def.hp * b.hp * BOSS_MULT;
    const bar = makeHealthBar();
    bar.mesh.scale.set(2.4, 0.16, 1);
    this.scene.add(bar.mesh);
    const e: Enemy = {
      vis, kind: "boss", name: b.name, title: b.title,
      x: SPAWN_X * 0.8, z: 0,
      hp, maxHp: hp,
      dmg: def.dmg * b.dmg * BOSS_MULT,
      speed: 1.9, range: 3.4, windup: 0.85, recover: 1.1,
      radius: 1.8, scale: 1.55, xp: def.xp * 14,
      ranged: false,
      state: "walk", timer: 0, facing: -1, flash: 0, deathT: 0,
      isBoss: true, attackIdx: 0, stagger: 0, bob: 0,
      bar, height: vis.height,
    };
    vis.group.scale.setScalar(e.scale);
    this.scene.add(vis.group);
    this.enemies.push(e);
    this.boss = e;
    this.setBanner(b.name, b.title);
    this.shake = Math.max(this.shake, 0.8);
    this.vfx.ring(e.x, 0.06, e.z, def.accent, 1, 14, 0.9, this.stage.ctx.fog);
  }

  private disposeEnemy(e: Enemy) {
    this.scene.remove(e.vis.group);
    e.vis.skin.dispose();
    this.scene.remove(e.bar.mesh);
    e.bar.mat.dispose();
  }

  private fireProjectile(x: number, y: number, z: number, dir: number, dmg: number, speed: number, color: number) {
    const mesh = new THREE.Mesh(new THREE.SphereGeometry(0.22, 10, 8), glowMaterial(color, 1, this.stage.ctx.fog));
    mesh.position.set(x, y, z);
    this.scene.add(mesh);
    this.projectiles.push({ mesh, x, y, z, vx: dir * speed, life: 3, dmg, hostile: true, radius: 0.5 });
  }

  // -------------------------------------------------------------------------
  // waves
  // -------------------------------------------------------------------------

  private startWave(n: number) {
    this.wave = n;
    const def = this.realmDef;
    const tier = REALMS.findIndex((r) => r.id === def.id);
    const count = 3 + n + tier * 2;
    for (let i = 0; i < count; i++) {
      const kind = def.roster[(i + n) % def.roster.length];
      this.spawnQueue.push({
        kind,
        side: i % 2 === 0 ? -1 : 1,
        z: (Math.random() - 0.5) * 3.2,
      });
    }
    this.spawnTimer = 0;
    this.setBanner(`WAVE ${n} / ${def.waves}`, `${count} hostiles`);
    this.onEvent({ type: "wave", wave: n, waves: def.waves });
  }

  private updateWaves(dt: number) {
    const def = this.realmDef;
    if (this.spawnQueue.length) {
      this.spawnTimer -= dt;
      if (this.spawnTimer <= 0) {
        const s = this.spawnQueue.shift()!;
        this.spawnEnemy(s.kind, s.side, s.z);
        this.spawnTimer = 0.22;
      }
      return;
    }
    const alive = this.enemies.some((e) => e.state !== "dead");
    if (alive) return;
    this.waveTimer -= dt;
    if (this.waveTimer > 0) return;
    if (this.wave < def.waves) {
      this.waveTimer = 2.4;
      this.startWave(this.wave + 1);
      if (this.wave > 1) this.dropLoot(1);
    } else {
      this.waveTimer = 3;
      this.spawnBoss();
    }
  }

  // -------------------------------------------------------------------------
  // simulation
  // -------------------------------------------------------------------------

  private simStep(dt: number) {
    const c = this.champion;
    const st = this.stats;

    // movement
    let dir = 0;
    if (this.keys.has("a") || this.keys.has("arrowleft")) dir -= 1;
    if (this.keys.has("d") || this.keys.has("arrowright")) dir += 1;
    c.moving = dir;
    if (c.dashT > 0) {
      c.dashT -= dt;
      const k = 1 - Math.max(0, c.dashT) / 0.2;
      c.x = THREE.MathUtils.lerp(c.dashFrom, c.dashTo, k);
    } else {
      c.x = THREE.MathUtils.clamp(c.x + dir * st.move * dt, LANE_MIN, LANE_MAX);
    }

    // energy + cooldowns
    c.energy = Math.min(st.maxEnergy, c.energy + st.regen * dt);
    for (let i = 0; i < 6; i++) if (c.cds[i] > 0) c.cds[i] = Math.max(0, c.cds[i] - dt);
    if (c.invuln > 0) c.invuln -= dt;
    if (c.hurtT > 0) c.hurtT -= dt;

    // auto attack
    const target = this.nearestEnemy();
    if (target) c.facing = Math.sign(target.x - c.x) || c.facing;
    if (c.swingT > 0) {
      c.swingT -= dt;
      if (!c.swingHit && c.swingT <= c.swingDur * 0.45) {
        c.swingHit = true;
        const reach = 2.5;
        let hitAny = false;
        for (const e of this.enemies) {
          if (e.state === "dead") continue;
          const dx = (e.x - c.x) * c.facing;
          if (dx > -0.9 && dx < reach + e.radius && Math.abs(e.z - c.z) < 2.0) {
            this.hitEnemy(e, st.dmg, 0xdff2ff);
            hitAny = true;
          }
        }
        if (hitAny) {
          this.vfx.arc(c.x + c.facing * 1.0, 1.2, c.z, 0xbfe9ff, 0.8, 2.2, 0.16, this.stage.ctx.fog);
          this.shake = Math.max(this.shake, 0.06);
        }
      }
    } else {
      c.atkTimer -= dt;
      if (c.atkTimer <= 0 && target) {
        const d = Math.hypot(target.x - c.x, (target.z - c.z) * 1.3);
        if (d < 3.0) {
          c.atkTimer = 1 / st.atkSpeed;
          c.swingT = c.swingDur;
          c.swingHit = false;
        }
      }
      if (c.atkTimer < 0) c.atkTimer = 0;
    }

    // enemies
    for (const e of this.enemies) {
      if (e.state === "dead") {
        e.deathT -= dt;
        continue;
      }
      if (e.flash > 0) e.flash = Math.max(0, e.flash - dt * 4.5);
      if (e.stagger > 0) {
        e.stagger -= dt;
        continue;
      }
      const dx = c.x - e.x;
      const dist = Math.abs(dx);
      e.facing = Math.sign(dx) || e.facing;
      if (e.isBoss) this.bossAI(e, dt, dist);
      else if (e.state === "walk") {
        if (dist > e.range) {
          e.x += Math.sign(dx) * e.speed * dt;
        } else {
          e.state = "wind";
          e.timer = e.windup;
        }
      } else if (e.state === "wind") {
        e.timer -= dt;
        if (e.timer <= 0) {
          if (e.ranged) {
            this.fireProjectile(e.x + e.facing * 0.6, 1.3, e.z, e.facing, e.dmg, 9, this.realmDef.accent2);
          } else if (dist < e.range + 0.7 && Math.abs(c.z - e.z) < 2.2) {
            this.hurtChampion(e.dmg);
            this.vfx.arc(e.x + e.facing * 0.8, 1.0, e.z, this.realmDef.accent, 0.6, 1.8, 0.2, this.stage.ctx.fog);
          }
          e.state = "recover";
          e.timer = e.recover;
        }
      } else if (e.state === "recover") {
        e.timer -= dt;
        if (e.timer <= 0) e.state = "walk";
      }
    }

    // projectiles
    for (let i = this.projectiles.length - 1; i >= 0; i--) {
      const p = this.projectiles[i];
      p.x += p.vx * dt;
      p.life -= dt;
      p.mesh.position.set(p.x, p.y, p.z);
      if (p.hostile) {
        if (Math.abs(p.x - c.x) < 0.75 && Math.abs(p.z - c.z) < 1.4) {
          this.hurtChampion(p.dmg);
          this.vfx.sphere(p.x, p.y, p.z, this.realmDef.accent2, 0.2, 1.4, 0.25, this.stage.ctx.fog);
          p.life = 0;
        }
      }
      if (p.life <= 0 || Math.abs(p.x) > 20) {
        this.scene.remove(p.mesh);
        (p.mesh.material as THREE.Material).dispose();
        p.mesh.geometry.dispose();
        this.projectiles.splice(i, 1);
      }
    }

    // reap dead
    for (let i = this.enemies.length - 1; i >= 0; i--) {
      const e = this.enemies[i];
      if (e.state === "dead" && e.deathT <= 0) {
        this.disposeEnemy(e);
        if (this.boss === e) this.boss = null;
        this.enemies.splice(i, 1);
      }
    }

    this.updateWaves(dt);
    this.runTime += dt;
  }

  private bossAI(e: Enemy, dt: number, dist: number) {
    if (e.state === "walk") {
      if (dist > e.range) e.x += Math.sign(this.champion.x - e.x) * e.speed * dt;
      else {
        e.state = "wind";
        e.timer = e.windup;
        const kind = e.attackIdx % 4;
        if (kind === 0) this.vfx.ring(e.x, 0.05, e.z, this.realmDef.accent, 1, 6.5, e.windup, this.stage.ctx.fog);
        else if (kind === 1) this.vfx.ring(e.x, 0.05, e.z, this.realmDef.accent2, 1, 11, e.windup, this.stage.ctx.fog);
        else if (kind === 3) this.vfx.ring(e.x, 1.4, e.z, this.realmDef.accent, 0.5, 3, e.windup, this.stage.ctx.fog, false);
      }
    } else if (e.state === "wind") {
      e.timer -= dt;
      if (e.timer <= 0) {
        const kind = e.attackIdx % 4;
        const c = this.champion;
        if (kind === 0) {
          // slam
          this.shake = Math.max(this.shake, 0.6);
          this.vfx.ring(e.x, 0.06, e.z, this.realmDef.accent, 0.8, 7, 0.45, this.stage.ctx.fog);
          this.vfx.burst(e.x, 0.3, e.z, this.realmDef.accent, 20, 6, 0.8, this.stage.ctx.fog);
          if (Math.hypot(c.x - e.x, (c.z - e.z) * 1.4) < 6.5) this.hurtChampion(e.dmg);
        } else if (kind === 1) {
          // lane sweep
          this.vfx.beam(e.x, 1.2, e.z, e.facing, 20, this.realmDef.accent2, 0.3, this.stage.ctx.fog, 0.8);
          if (Math.abs(c.x - e.x) < 10 && Math.abs(c.z - e.z) < 2.0) this.hurtChampion(e.dmg * 0.8);
        } else if (kind === 2) {
          // summon
          for (let i = 0; i < 3; i++) {
            const kind2 = this.realmDef.roster[i % this.realmDef.roster.length];
            this.spawnEnemy(kind2, i % 2 === 0 ? -1 : 1, (i - 1) * 1.2);
            this.vfx.ring(this.champion.x + (i - 1) * 3, 0.05, (i - 1) * 1.2, this.realmDef.accent, 0.5, 3, 0.5, this.stage.ctx.fog);
          }
        } else {
          // volley
          for (let i = -2; i <= 2; i++) {
            const p = new THREE.Mesh(new THREE.SphereGeometry(0.3, 10, 8), glowMaterial(this.realmDef.accent, 1, this.stage.ctx.fog));
            p.position.set(e.x + e.facing * 1.2, 1.6, e.z + i * 0.5);
            this.scene.add(p);
            this.projectiles.push({
              mesh: p, x: e.x + e.facing * 1.2, y: 1.6, z: e.z + i * 0.5,
              vx: e.facing * 8.5, life: 3, dmg: e.dmg * 0.55, hostile: true, radius: 0.6,
            });
          }
        }
        e.attackIdx += 1;
        e.state = "recover";
        e.timer = e.recover;
      }
    } else if (e.state === "recover") {
      e.timer -= dt;
      if (e.timer <= 0) e.state = "walk";
    }
  }

  // -------------------------------------------------------------------------
  // visuals
  // -------------------------------------------------------------------------

  private updateVisuals(dtReal: number) {
    const c = this.champion;
    const g = c.vis.group;
    g.position.set(c.x, c.groupY, c.z);
    const swingK = c.swingT > 0 ? 1 - c.swingT / c.swingDur : 0;
    const swingEase = c.swingT > 0 ? Math.sin(Math.min(1, swingK) * Math.PI) : 0;
    g.rotation.y = c.facing * (Math.PI / 2 - 0.44);
    g.rotation.z = -c.facing * swingEase * 0.16;
    const bobAmp = c.moving !== 0 ? 0.075 : 0.03;
    c.bob += dtReal * (c.moving !== 0 ? 11 : 3.2);
    g.position.y = c.groupY + Math.abs(Math.sin(c.bob)) * bobAmp;
    if (c.vis.weapon) {
      c.vis.weapon.rotation.z = -0.25 - swingEase * 2.5;
      c.vis.weapon.rotation.x = -swingEase * 0.5;
    }
    if (c.vis.cape) {
      c.vis.cape.rotation.x = -0.12 - Math.abs(c.moving) * 0.22 - swingEase * 0.1;
      c.vis.cape.rotation.z = Math.sin(this.time * 2.4) * 0.08 - c.moving * 0.14;
    }
    c.vis.skin.setFlash(Math.max(c.hurtT * 3, 0));
    c.vis.skin.setTime(this.time);
    for (const gl of c.vis.glow) {
      const m = (gl as THREE.Mesh).material as THREE.ShaderMaterial;
      if (m.uniforms?.uOpacity) {
        m.uniforms.uOpacity.value = 0.18 + 0.12 * Math.sin(this.time * 3) + (c.invuln > 0 ? 0.4 : 0);
      }
    }

    for (const e of this.enemies) {
      if (e.state === "dead" && this.phase !== "run") e.deathT -= dtReal;
      const eg = e.vis.group;
      const s = e.scale;
      eg.position.set(e.x, 0, e.z);
      eg.rotation.y = e.facing * (Math.PI / 2 - 0.4);
      e.bob += dtReal * (e.state === "walk" ? 9 : 2);
      const dying = e.state === "dead";
      const k = dying ? Math.max(0, e.deathT / 0.55) : 1;
      eg.scale.setScalar(s * k);
      eg.position.y = dying ? (1 - k) * 0.4 : Math.abs(Math.sin(e.bob)) * 0.06 * (e.state === "walk" ? 1 : 0.2);
      eg.rotation.z = e.state === "wind" ? -e.facing * 0.22 : e.stagger > 0 ? e.facing * 0.3 : 0;
      eg.rotation.x = e.state === "wind" ? -0.16 : 0;
      e.vis.skin.setFlash(e.flash * 0.9);
      e.vis.skin.setTime(this.time);
      e.vis.skin.setOpacity(dying ? k : 1);
      if (e.vis.weapon) e.vis.weapon.rotation.z = (e.kind === "brute" ? -0.2 : -0.3) - (e.state === "wind" ? 1.5 : 0);
      for (const gl of e.vis.glow) {
        const m = (gl as THREE.Mesh).material as THREE.ShaderMaterial;
        if (m.uniforms?.uTime) m.uniforms.uTime.value = this.time;
        if (m.uniforms?.uOpacity) m.uniforms.uOpacity.value = 0.5 + 0.3 * Math.sin(this.time * 2 + e.x);
      }
      if (e.kind === "boss" && e.vis.weapon) {
        e.vis.weapon.rotation.z = this.time * 0.6;
        e.vis.weapon.rotation.y = this.time * 0.4;
      }
      // health bar
      const show = !dying && (e.hp < e.maxHp || e.isBoss);
      e.bar.mesh.visible = show;
      if (show) {
        e.bar.mesh.position.set(e.x, e.height * s + 0.42, e.z + 0.05);
        e.bar.mat.uniforms.uFill.value = Math.max(0, e.hp / e.maxHp);
        (e.bar.mat.uniforms.uColor.value as THREE.Color).setHex(e.isBoss ? 0xff3ec8 : 0xff5a6e);
      }
    }

    // camera: fixed pose + decaying hit shake only
    if (this.shake > 0.0008) {
      this.shake *= Math.pow(0.0009, dtReal);
      const a = this.shake;
      this.shakeVec.set(
        (Math.random() - 0.5) * a * 0.9,
        (Math.random() - 0.5) * a * 0.7,
        (Math.random() - 0.5) * a * 0.4
      );
      this.camera.position.copy(CAM_POS).add(this.shakeVec);
      this.camera.lookAt(CAM_TARGET.x + this.shakeVec.x * 0.3, CAM_TARGET.y + this.shakeVec.y * 0.3, CAM_TARGET.z);
    } else if (this.shake !== 0) {
      this.shake = 0;
      this.camera.position.copy(CAM_POS);
      this.camera.lookAt(CAM_TARGET);
    }
  }

  // -------------------------------------------------------------------------
  // floating combat text
  // -------------------------------------------------------------------------

  private floater(x: number, y: number, z: number, text: string, color: string, scale: number) {
    if (!this.floaters || this.floaters.childElementCount > 26) return;
    const v = new THREE.Vector3(x, y, z).project(this.camera);
    const w = this.canvas.clientWidth;
    const h = this.canvas.clientHeight;
    const el = document.createElement("div");
    el.className = "floater";
    el.textContent = text;
    el.style.left = `${(v.x * 0.5 + 0.5) * w}px`;
    el.style.top = `${(-v.y * 0.5 + 0.5) * h}px`;
    el.style.color = color;
    el.style.fontSize = `${Math.round(15 * scale)}px`;
    this.floaters.appendChild(el);
    setTimeout(() => el.remove(), 1000);
  }

  private setBanner(text: string, sub: string | null) {
    this.banner = text;
    this.bannerSub = sub;
    this.bannerT = 2.4;
  }

  // -------------------------------------------------------------------------
  // main loop
  // -------------------------------------------------------------------------

  private loop = () => {
    if (this.disposed) return;
    this.raf = requestAnimationFrame(this.loop);
    const now = performance.now();
    let dtReal = (now - this.last) / 1000;
    this.last = now;
    if (dtReal > 0.1) dtReal = 0.1;
    this.time += dtReal;

    this.stage.update(this.time, dtReal);

    if (this.phase === "run") {
      const dtGame = dtReal * this.speed;
      let left = dtGame;
      let guard = 0;
      while (left > 0.0001 && guard++ < 40) {
        const step = Math.min(left, 1 / 60);
        this.simStep(step);
        left -= step;
        if (this.phase !== "run") break;
      }
    }

    this.updateVisuals(dtReal);
    this.vfx.update(dtReal * this.speed);

    // dps window
    const cutoff = this.time - 3;
    while (this.dmgLog.length && this.dmgLog[0].t < cutoff) this.dmgLog.shift();

    if (this.bannerT > 0) {
      this.bannerT -= dtReal;
      if (this.bannerT <= 0) { this.banner = null; this.bannerSub = null; }
    }

    this.render();

    this.hudAccum += dtReal;
    if (this.hudAccum > 0.05) {
      this.hudAccum = 0;
      this.onHud(this.snapshot());
    }
  };

  private render() {
    // planar reflection pass (mirrored camera, flipped up → sample with x flipped)
    for (const o of this.stage.hide) o.visible = false;
    this.reflCam.position.set(0, -CAM_POS.y, CAM_POS.z);
    this.reflCam.up.set(0, -1, 0);
    this.reflCam.lookAt(CAM_TARGET.x, -CAM_TARGET.y, CAM_TARGET.z);
    this.reflCam.updateMatrixWorld();
    this.renderer.setRenderTarget(this.reflRT);
    this.renderer.clear();
    this.renderer.render(this.scene, this.reflCam);
    this.renderer.setRenderTarget(null);
    for (const o of this.stage.hide) o.visible = true;
    this.renderer.render(this.scene, this.camera);
  }

  private snapshot(): HudSnapshot {
    const c = this.champion;
    const dps = this.dmgLog.reduce((s, d) => s + d.v, 0) / 3;
    return {
      phase: this.phase,
      hp: Math.max(0, Math.round(c.hp)),
      maxHp: Math.round(this.stats.maxHp),
      energy: Math.round(c.energy),
      maxEnergy: Math.round(this.stats.maxEnergy),
      wave: this.wave,
      waves: this.realmDef.waves,
      enemies: this.enemies.filter((e) => e.state !== "dead").length + this.spawnQueue.length,
      boss: this.boss
        ? { name: this.boss.name, title: this.boss.title, hp: Math.max(0, this.boss.hp), maxHp: this.boss.maxHp }
        : null,
      skills: SKILLS.map((s, i) => ({
        id: s.id, name: s.name, key: s.key, cd: c.cds[i], cdMax: s.cd, cost: s.cost,
        ready: c.cds[i] <= 0 && c.energy >= s.cost,
        unlocked: skillUnlocked(this.progress, s.id),
        level: this.skillLevels[i],
        color: s.color,
      })),
      speed: this.speed,
      realm: this.phase === "hub" ? null : this.realmDef.id,
      kills: this.kills,
      dps: Math.round(dps),
      banner: this.banner,
      bannerSub: this.bannerSub,
      runTime: this.runTime,
    };
  }
}
