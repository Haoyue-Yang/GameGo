import {
  PRESTIGE_REQ_LEVEL,
  PRESTIGE_XP_BONUS,
  SLOTS,
  SKILLS,
  type Item,
  type RealmId,
  type Slot,
  type StatKey,
  type StatPointKey,
  type Stats,
  xpForLevel,
} from "./data";

export interface Progress {
  level: number;
  xp: number;
  statPoints: number;
  skillPoints: number;
  points: Record<StatPointKey, number>;
  skillLevels: number[]; // index 0..5 → skill id 1..6
  equipped: Partial<Record<Slot, Item>>;
  inventory: Item[];
  unlocked: RealmId[];
  cleared: RealmId[];
  ascensions: number;
  totalKills: number;
  bestWave: Record<string, number>;
  lastRun: { realm: RealmId; wave: number; kills: number } | null;
}

export const freshProgress = (): Progress => ({
  level: 1,
  xp: 0,
  statPoints: 3,
  skillPoints: 1,
  points: { vitality: 0, power: 0, focus: 0, alacrity: 0 },
  skillLevels: [1, 0, 0, 0, 0, 0],
  equipped: {},
  inventory: [],
  unlocked: ["colosseum"],
  cleared: [],
  ascensions: 0,
  totalKills: 0,
  bestWave: {},
  lastRun: null,
});

const SAVE_KEY = "inkfall.save.v1";

export function loadProgress(): Progress {
  try {
    const raw = localStorage.getItem(SAVE_KEY);
    if (!raw) return freshProgress();
    const p = JSON.parse(raw) as Progress;
    const base = freshProgress();
    return {
      ...base,
      ...p,
      points: { ...base.points, ...(p.points ?? {}) },
      skillLevels: Array.isArray(p.skillLevels) && p.skillLevels.length === 6 ? p.skillLevels : base.skillLevels,
      equipped: p.equipped ?? {},
      inventory: Array.isArray(p.inventory) ? p.inventory : [],
      unlocked: Array.isArray(p.unlocked) && p.unlocked.length ? p.unlocked : base.unlocked,
      cleared: Array.isArray(p.cleared) ? p.cleared : [],
      bestWave: p.bestWave ?? {},
    };
  } catch {
    return freshProgress();
  }
}

export function saveProgress(p: Progress) {
  try {
    localStorage.setItem(SAVE_KEY, JSON.stringify(p));
  } catch {
    /* storage unavailable — session-only progress */
  }
}

// ---------------------------------------------------------------------------
// Derived stats
// ---------------------------------------------------------------------------

export function gearBonus(p: Progress): Record<StatKey, number> {
  const out: Record<StatKey, number> = {
    hp: 0, dmg: 0, energy: 0, regen: 0, haste: 0, armor: 0, crit: 0, critDmg: 0, move: 0,
  };
  for (const slot of SLOTS) {
    const it = p.equipped[slot];
    if (!it) continue;
    for (const a of it.affixes) out[a.stat] += a.value;
  }
  return out;
}

export function computeStats(p: Progress): Stats {
  const g = gearBonus(p);
  const lv = p.level;
  const maxHp = Math.round(120 + lv * 16 + p.points.vitality * 16 + g.hp);
  const dmg = Math.round((11 + lv * 2.4 + p.points.power * 3.5 + g.dmg) * 10) / 10;
  const maxEnergy = Math.round(100 + lv * 5 + p.points.focus * 14 + g.energy);
  const regen = Math.round((5.5 + p.points.focus * 1.3 + g.regen) * 10) / 10;
  const haste = Math.min(0.75, p.points.alacrity * 0.03 + g.haste / 100);
  const move = 7.2 + p.points.alacrity * 0.12 + g.move;
  const armor = Math.round(2 + p.points.vitality * 2 + g.armor);
  const crit = Math.min(0.75, 0.05 + g.crit / 100);
  const critDmg = 1.5 + g.critDmg / 100;
  return {
    maxHp, dmg, maxEnergy, regen, haste, armor, crit, critDmg, move,
    atkSpeed: 1.55 * (1 + haste),
  };
}

export const xpMultiplier = (p: Progress) => 1 + p.ascensions * PRESTIGE_XP_BONUS;

export const skillUnlocked = (p: Progress, id: number) => {
  const def = SKILLS[id - 1];
  return p.skillLevels[id - 1] > 0 && p.level >= def.unlockLevel;
};

export const skillMaxLevel = 5;

export function skillDamageMul(level: number) {
  return 1 + (level - 1) * 0.28;
}

export function canAscend(p: Progress) {
  return p.level >= PRESTIGE_REQ_LEVEL;
}

export function ascensionGain(p: Progress) {
  return Math.max(1, Math.floor((p.level - PRESTIGE_REQ_LEVEL + 1) / 2));
}

export function applyAscension(p: Progress): Progress {
  const gain = ascensionGain(p);
  const next = freshProgress();
  next.ascensions = p.ascensions + gain;
  next.unlocked = p.unlocked;
  next.cleared = p.cleared;
  next.totalKills = p.totalKills;
  next.bestWave = p.bestWave;
  return next;
}

export function addXp(p: Progress, raw: number): { next: Progress; levels: number } {
  let level = p.level;
  let xp = p.xp + Math.max(0, Math.round(raw * xpMultiplier(p)));
  let gained = 0;
  while (xp >= xpForLevel(level)) {
    xp -= xpForLevel(level);
    level += 1;
    gained += 1;
  }
  const next: Progress = {
    ...p,
    level,
    xp,
    statPoints: p.statPoints + gained * 3,
    skillPoints: p.skillPoints + gained * 2,
  };
  return { next, levels: gained };
}

export function equipItem(p: Progress, item: Item): Progress {
  const equipped = { ...p.equipped, [item.slot]: item };
  const prev = p.equipped[item.slot];
  const inventory = p.inventory.filter((i) => i.uid !== item.uid);
  if (prev) inventory.push(prev);
  return { ...p, equipped, inventory };
}

export function unequipItem(p: Progress, slot: Slot): Progress {
  const item = p.equipped[slot];
  if (!item) return p;
  const equipped = { ...p.equipped };
  delete equipped[slot];
  return { ...p, equipped, inventory: [...p.inventory, item] };
}

export function sellItem(p: Progress, uid: string): Progress {
  return { ...p, inventory: p.inventory.filter((i) => i.uid !== uid) };
}
