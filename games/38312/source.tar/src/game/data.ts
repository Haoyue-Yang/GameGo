// ---------------------------------------------------------------------------
// INKFALL — core data tables: realms, skills, gear, affixes, enemy archetypes
// ---------------------------------------------------------------------------

export type RealmId = "colosseum" | "conduit" | "wastes";
export type Slot = "weapon" | "armor" | "helm" | "boots" | "relic";
export type Rarity = "common" | "uncommon" | "rare" | "epic" | "legendary";
export type StatKey =
  | "hp"
  | "dmg"
  | "energy"
  | "regen"
  | "haste"
  | "armor"
  | "crit"
  | "critDmg"
  | "move";
export type StatPointKey = "vitality" | "power" | "focus" | "alacrity";

export interface RealmDef {
  id: RealmId;
  name: string;
  sub: string;
  blurb: string;
  /** per-realm coloured fog */
  fog: number;
  fogNear: number;
  fogFar: number;
  /** stage palette */
  floor: number;
  floorLine: number;
  accent: number;
  accent2: number;
  sky: number;
  /** gameplay */
  waves: number;
  hp: number;
  dmg: number;
  xp: number;
  ilvl: number;
  roster: EnemyKind[];
  boss: BossKind;
  /** css colour used by the UI chrome */
  css: string;
  css2: string;
}

export type EnemyKind = "grunt" | "brute" | "caster" | "stalker";
export type BossKind = "warden" | "overseer" | "bloom";

export const REALMS: RealmDef[] = [
  {
    id: "colosseum",
    name: "STEEL COLOSSEUM",
    sub: "Realm I",
    blurb:
      "A rusted arena of cold iron. Floodlights, banners and the smell of old blood.",
    fog: 0x141d29,
    fogNear: 16,
    fogFar: 62,
    floor: 0x0e141c,
    floorLine: 0x4e7ba6,
    accent: 0xffb347,
    accent2: 0x63b8ff,
    sky: 0x1b2634,
    waves: 4,
    hp: 34,
    dmg: 7,
    xp: 12,
    ilvl: 1,
    roster: ["grunt", "grunt", "stalker", "brute"],
    boss: "warden",
    css: "#ffb347",
    css2: "#63b8ff",
  },
  {
    id: "conduit",
    name: "MAGENTA CONDUIT",
    sub: "Realm II",
    blurb:
      "A dead signal highway. Live cables bleed magenta light into a black void.",
    fog: 0x170a20,
    fogNear: 14,
    fogFar: 54,
    floor: 0x120818,
    floorLine: 0xff3ec8,
    accent: 0xff3ec8,
    accent2: 0x3ce6ff,
    sky: 0x24102e,
    waves: 5,
    hp: 62,
    dmg: 12,
    xp: 26,
    ilvl: 2,
    roster: ["stalker", "caster", "grunt", "brute", "caster"],
    boss: "overseer",
    css: "#ff3ec8",
    css2: "#3ce6ff",
  },
  {
    id: "wastes",
    name: "SPORE-LIT WASTES",
    sub: "Realm III",
    blurb:
      "Rot and bloom. Every cap glows, every breath is a hundred small lungs.",
    fog: 0x0a1a14,
    fogNear: 12,
    fogFar: 48,
    floor: 0x0a1512,
    floorLine: 0x86ff9e,
    accent: 0x9dff5a,
    accent2: 0x35e6c0,
    sky: 0x0f2620,
    waves: 6,
    hp: 108,
    dmg: 19,
    xp: 48,
    ilvl: 3,
    roster: ["brute", "caster", "stalker", "grunt", "caster", "brute"],
    boss: "bloom",
    css: "#9dff5a",
    css2: "#35e6c0",
  },
];

export const realmById = (id: RealmId): RealmDef =>
  REALMS.find((r) => r.id === id) ?? REALMS[0];

// ---------------------------------------------------------------------------
// Skills — 1..6, energy gated, on cooldown
// ---------------------------------------------------------------------------

export type SkillKind = "cleave" | "lance" | "quake" | "dash" | "nova" | "overdrive";

export interface SkillDef {
  id: number;
  name: string;
  key: string;
  kind: SkillKind;
  cost: number;
  cd: number;
  power: number;
  unlockLevel: number;
  desc: string;
  color: number;
}

export const SKILLS: SkillDef[] = [
  {
    id: 1,
    name: "Rift Cleave",
    key: "1",
    kind: "cleave",
    cost: 18,
    cd: 3.2,
    power: 1.9,
    unlockLevel: 1,
    desc: "Wide arc slash in front of the champion. Hits everything in the lane.",
    color: 0x8fe9ff,
  },
  {
    id: 2,
    name: "Void Lance",
    key: "2",
    kind: "lance",
    cost: 26,
    cd: 5.0,
    power: 2.6,
    unlockLevel: 2,
    desc: "Fires a piercing bolt down the lane. Passes through every body it touches.",
    color: 0x7d8bff,
  },
  {
    id: 3,
    name: "Fault Quake",
    key: "3",
    kind: "quake",
    cost: 38,
    cd: 7.5,
    power: 3.2,
    unlockLevel: 4,
    desc: "Slam the floor for a shockwave that staggers and shreds nearby foes.",
    color: 0xffb347,
  },
  {
    id: 4,
    name: "Phase Rush",
    key: "4",
    kind: "dash",
    cost: 22,
    cd: 6.0,
    power: 2.2,
    unlockLevel: 6,
    desc: "Blink through the nearest foe, damaging everything crossed. Brief invulnerability.",
    color: 0x9dff5a,
  },
  {
    id: 5,
    name: "Hollow Nova",
    key: "5",
    kind: "nova",
    cost: 52,
    cd: 11.0,
    power: 3.8,
    unlockLevel: 9,
    desc: "Detonate stored energy in a ring around you. Large radius, heavy damage.",
    color: 0xff3ec8,
  },
  {
    id: 6,
    name: "INKFALL",
    key: "6",
    kind: "overdrive",
    cost: 85,
    cd: 20.0,
    power: 6.5,
    unlockLevel: 13,
    desc: "Ultimate. Ink floods the whole lane, then heals you for 22% of max HP.",
    color: 0xffffff,
  },
];

// ---------------------------------------------------------------------------
// Stats
// ---------------------------------------------------------------------------

export interface Stats {
  maxHp: number;
  dmg: number;
  maxEnergy: number;
  regen: number;
  haste: number;
  armor: number;
  crit: number;
  critDmg: number;
  move: number;
  atkSpeed: number;
}

export const STAT_INFO: Record<StatPointKey, { name: string; desc: string; color: string }> = {
  vitality: {
    name: "Vitality",
    desc: "+16 max HP, +2 armour",
    color: "#ff6b7d",
  },
  power: {
    name: "Power",
    desc: "+3.5 damage",
    color: "#ffb347",
  },
  focus: {
    name: "Focus",
    desc: "+14 max energy, +1.3 regen",
    color: "#4de3ff",
  },
  alacrity: {
    name: "Alacrity",
    desc: "+3% attack speed, +0.12 move",
    color: "#9dff5a",
  },
};

export const STAT_LABEL: Record<StatKey, string> = {
  hp: "Max HP",
  dmg: "Damage",
  energy: "Max Energy",
  regen: "Energy Regen",
  haste: "Haste",
  armor: "Armour",
  crit: "Crit Chance",
  critDmg: "Crit Damage",
  move: "Move Speed",
};

// ---------------------------------------------------------------------------
// Gear
// ---------------------------------------------------------------------------

export const RARITY: Record<
  Rarity,
  { name: string; color: string; glow: string; affixes: number; mult: number; weight: number }
> = {
  common: { name: "Common", color: "#b9c6d6", glow: "rgba(185,198,214,0.35)", affixes: 1, mult: 1, weight: 46 },
  uncommon: { name: "Uncommon", color: "#7dff9b", glow: "rgba(125,255,155,0.4)", affixes: 2, mult: 1.25, weight: 27 },
  rare: { name: "Rare", color: "#59b6ff", glow: "rgba(89,182,255,0.45)", affixes: 3, mult: 1.6, weight: 16 },
  epic: { name: "Epic", color: "#c07bff", glow: "rgba(192,123,255,0.5)", affixes: 4, mult: 2.05, weight: 8 },
  legendary: { name: "Legendary", color: "#ffb347", glow: "rgba(255,179,71,0.55)", affixes: 5, mult: 2.7, weight: 3 },
};

export const RARITY_ORDER: Rarity[] = ["common", "uncommon", "rare", "epic", "legendary"];

export const SLOT_INFO: Record<Slot, { name: string; icon: string }> = {
  weapon: { name: "Weapon", icon: "⚔" },
  armor: { name: "Armour", icon: "🛡" },
  helm: { name: "Helm", icon: "⛑" },
  boots: { name: "Boots", icon: "🥾" },
  relic: { name: "Relic", icon: "◈" },
};

export const SLOTS: Slot[] = ["weapon", "armor", "helm", "boots", "relic"];

export interface Affix {
  stat: StatKey;
  value: number;
}

export interface Item {
  uid: string;
  slot: Slot;
  name: string;
  rarity: Rarity;
  ilvl: number;
  affixes: Affix[];
}

const AFFIX_POOL: { stat: StatKey; min: number; max: number; scale: number; pct?: boolean }[] = [
  { stat: "hp", min: 8, max: 22, scale: 1.0 },
  { stat: "dmg", min: 1.4, max: 4.2, scale: 1.0 },
  { stat: "energy", min: 6, max: 18, scale: 1.0 },
  { stat: "regen", min: 0.7, max: 2.4, scale: 1.0 },
  { stat: "haste", min: 1.5, max: 4.5, scale: 0.85, pct: true },
  { stat: "armor", min: 3, max: 11, scale: 1.0 },
  { stat: "crit", min: 1.0, max: 3.4, scale: 0.8, pct: true },
  { stat: "critDmg", min: 5, max: 16, scale: 0.9, pct: true },
  { stat: "move", min: 0.05, max: 0.18, scale: 0.6 },
];

const PREFIX = [
  "Riven", "Hollow", "Gilded", "Ashen", "Cobalt", "Umbral", "Severed", "Screaming",
  "Drowned", "Fulgurite", "Vantablack", "Ninefold", "Hushed", "Cinder", "Pale",
];
const SUFFIX = [
  "of the Colossus", "of Static", "of Bloom", "of the Long Night", "of Nine Deaths",
  "of Ink", "of the Quiet", "of Spilled Light", "of the Last Wave", "of Rust",
];
const BASE: Record<Slot, string[]> = {
  weapon: ["Cleaver", "Glaive", "Reaver", "Edge", "Halberd", "Nail"],
  armor: ["Carapace", "Plating", "Weave", "Harness", "Bulwark"],
  helm: ["Visor", "Crown", "Hood", "Mask", "Coronet"],
  boots: ["Striders", "Greaves", "Treads", "Sabatons", "Runners"],
  relic: ["Sigil", "Core", "Lantern", "Talisman", "Shard"],
};

let uidCounter = 0;
export const nextUid = () => `i${Date.now().toString(36)}${(uidCounter++).toString(36)}`;

export function rollItem(ilvl: number, luck = 0): Item {
  const slot = SLOTS[Math.floor(Math.random() * SLOTS.length)];
  const rarity = rollRarity(ilvl, luck);
  const r = RARITY[rarity];
  const affixes: Affix[] = [];
  const used = new Set<StatKey>();
  const count = r.affixes;
  for (let i = 0; i < count; i++) {
    const pool = AFFIX_POOL.filter((a) => !used.has(a.stat));
    const pick = pool[Math.floor(Math.random() * pool.length)];
    if (!pick) break;
    used.add(pick.stat);
    const t = 0.35 + Math.random() * 0.65;
    const raw = (pick.min + (pick.max - pick.min) * t) * (0.7 + ilvl * 0.42) * r.mult;
    affixes.push({ stat: pick.stat, value: pick.pct ? Math.round(raw * 10) / 10 : Math.round(raw) });
  }
  const name =
    Math.random() < 0.55
      ? `${PREFIX[Math.floor(Math.random() * PREFIX.length)]} ${BASE[slot][Math.floor(Math.random() * BASE[slot].length)]}`
      : `${BASE[slot][Math.floor(Math.random() * BASE[slot].length)]} ${SUFFIX[Math.floor(Math.random() * SUFFIX.length)]}`;
  return { uid: nextUid(), slot, name, rarity, ilvl, affixes };
}

function rollRarity(ilvl: number, luck: number): Rarity {
  const weights = RARITY_ORDER.map((k) => {
    const base = RARITY[k].weight;
    const tier = RARITY_ORDER.indexOf(k);
    const bump = 1 + (ilvl - 1) * 0.16 * tier + luck * tier;
    return base * bump;
  });
  const total = weights.reduce((a, b) => a + b, 0);
  let roll = Math.random() * total;
  for (let i = 0; i < weights.length; i++) {
    roll -= weights[i];
    if (roll <= 0) return RARITY_ORDER[i];
  }
  return "common";
}

export function itemScore(it: Item): number {
  return it.affixes.reduce((s, a) => s + a.value * (a.stat === "hp" ? 0.5 : a.stat === "dmg" ? 3 : 1), 0);
}

export function itemPower(it: Item): number {
  return Math.round(
    it.affixes.reduce((s, a) => {
      switch (a.stat) {
        case "hp": return s + a.value * 0.55;
        case "dmg": return s + a.value * 3.2;
        case "energy": return s + a.value * 0.4;
        case "regen": return s + a.value * 2.4;
        case "haste": return s + a.value * 1.6;
        case "armor": return s + a.value * 0.9;
        case "crit": return s + a.value * 2.2;
        case "critDmg": return s + a.value * 0.7;
        default: return s + a.value * 12;
      }
    }, 0)
  );
}

// ---------------------------------------------------------------------------
// Enemy archetypes
// ---------------------------------------------------------------------------

export interface EnemyDef {
  kind: EnemyKind;
  name: string;
  hp: number;
  dmg: number;
  speed: number;
  range: number;
  windup: number;
  recover: number;
  radius: number;
  scale: number;
  xp: number;
  ranged?: boolean;
}

export const ENEMIES: Record<EnemyKind, EnemyDef> = {
  grunt: {
    kind: "grunt", name: "Husk", hp: 1.0, dmg: 1.0, speed: 2.5, range: 1.7,
    windup: 0.34, recover: 0.5, radius: 0.55, scale: 1.0, xp: 1.0,
  },
  stalker: {
    kind: "stalker", name: "Stalker", hp: 0.7, dmg: 0.8, speed: 4.1, range: 1.5,
    windup: 0.2, recover: 0.34, radius: 0.5, scale: 0.92, xp: 1.15,
  },
  brute: {
    kind: "brute", name: "Brute", hp: 2.5, dmg: 1.9, speed: 1.7, range: 2.1,
    windup: 0.62, recover: 0.95, radius: 0.95, scale: 1.42, xp: 2.2,
  },
  caster: {
    kind: "caster", name: "Chanter", hp: 0.85, dmg: 1.25, speed: 1.9, range: 8.5,
    windup: 0.7, recover: 1.2, radius: 0.55, scale: 1.05, xp: 1.6, ranged: true,
  },
};

export const BOSSES: Record<BossKind, { name: string; title: string; hp: number; dmg: number }> = {
  warden: { name: "IRON WARDEN", title: "Keeper of the Colosseum", hp: 18, dmg: 1.8 },
  overseer: { name: "THE OVERSEER", title: "Signal That Learned To Want", hp: 25, dmg: 2.0 },
  bloom: { name: "THE BLOOM", title: "Mother of the Wastes", hp: 33, dmg: 2.2 },
};

/** boss stat multiplier — the spec's 2.5x boss */
export const BOSS_MULT = 2.5;

// ---------------------------------------------------------------------------
// XP curve
// ---------------------------------------------------------------------------

export const xpForLevel = (level: number) => Math.round(48 * Math.pow(level, 1.42));

export const PRESTIGE_XP_BONUS = 0.25; // +25% per ascension, stacking
export const PRESTIGE_REQ_LEVEL = 12;
