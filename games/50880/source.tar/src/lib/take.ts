export type TakeEvent = {
  t: number; // ms from take start
  code: string; // physical key code, or "SPACE"
  midis: number[];
  on: boolean;
};

export type Take = {
  id: string;
  name: string;
  duration: number;
  events: TakeEvent[];
};

export const formatTime = (ms: number) => {
  const total = Math.max(0, ms);
  const s = Math.floor(total / 1000);
  const cs = Math.floor((total % 1000) / 10);
  return `${String(Math.floor(s / 60)).padStart(2, "0")}:${String(s % 60).padStart(2, "0")}.${String(cs).padStart(2, "0")}`;
};
