/**
 * Physical keyboard layout -> pitch table.
 * Rows are ordered low (bottom row of the keyboard) to high (number row),
 * so the physical keyboard reads like a 4-row piano.
 */

import {
  buildLadder,
  chordPcs,
  getChord,
  getScale,
  isChordTone,
  type ChordDef,
  type ScaleDef,
} from "./theory";

export type KeySlot = { code: string; label: string; row: number };

const row = (codes: [string, string][], rowIndex: number): KeySlot[] =>
  codes.map(([code, label]) => ({ code, label, row: rowIndex }));

/** Row 0 = bottom row (lowest pitches) ... Row 3 = number row (highest). */
export const KEY_ROWS: KeySlot[][] = [
  row(
    [
      ["KeyZ", "Z"],
      ["KeyX", "X"],
      ["KeyC", "C"],
      ["KeyV", "V"],
      ["KeyB", "B"],
      ["KeyN", "N"],
      ["KeyM", "M"],
      ["Comma", ","],
      ["Period", "."],
      ["Slash", "/"],
    ],
    0,
  ),
  row(
    [
      ["KeyA", "A"],
      ["KeyS", "S"],
      ["KeyD", "D"],
      ["KeyF", "F"],
      ["KeyG", "G"],
      ["KeyH", "H"],
      ["KeyJ", "J"],
      ["KeyK", "K"],
      ["KeyL", "L"],
      ["Semicolon", ";"],
      ["Quote", "'"],
    ],
    1,
  ),
  row(
    [
      ["KeyQ", "Q"],
      ["KeyW", "W"],
      ["KeyE", "E"],
      ["KeyR", "R"],
      ["KeyT", "T"],
      ["KeyY", "Y"],
      ["KeyU", "U"],
      ["KeyI", "I"],
      ["KeyO", "O"],
      ["KeyP", "P"],
      ["BracketLeft", "["],
      ["BracketRight", "]"],
    ],
    2,
  ),
  row(
    [
      ["Digit1", "1"],
      ["Digit2", "2"],
      ["Digit3", "3"],
      ["Digit4", "4"],
      ["Digit5", "5"],
      ["Digit6", "6"],
      ["Digit7", "7"],
      ["Digit8", "8"],
      ["Digit9", "9"],
      ["Digit0", "0"],
      ["Minus", "-"],
      ["Equal", "="],
    ],
    3,
  ),
];

/** All note-producing keys, ascending in pitch. */
export const NOTE_KEYS: KeySlot[] = KEY_ROWS.flat();

export const SPECIALS: Record<string, { label: string; action: string }> = {
  Space: { label: "SPACE", action: "chord" },
  ShiftLeft: { label: "L-SHIFT", action: "sustain" },
  ShiftRight: { label: "R-SHIFT", action: "sustain" },
  Enter: { label: "ENTER", action: "chord" },
  ArrowUp: { label: "↑", action: "octaveUp" },
  ArrowDown: { label: "↓", action: "octaveDown" },
  Backquote: { label: "`", action: "echo" },
  Backslash: { label: "\\", action: "chordMode" },
};

export type TableEntry = {
  code: string;
  label: string;
  row: number;
  midi: number;
  chordTone: boolean;
};

export type PitchTable = {
  entries: TableEntry[];
  byCode: Record<string, TableEntry>;
  low: number;
  high: number;
  chordPcs: Set<number>;
  scale: ScaleDef;
  chord: ChordDef;
};

export function buildPitchTable(
  rootPc: number,
  scaleId: string,
  chordId: string,
  octave: number,
  strict: boolean,
): PitchTable {
  const scale = getScale(scaleId);
  const chord = getChord(chordId);
  const count = NOTE_KEYS.length;
  const low = 36 + 12 * octave;
  const high = low + 54;
  const ladder = buildLadder(rootPc, scale, chord, count, low, high, strict);
  const cps = chordPcs(rootPc, chord);

  const entries: TableEntry[] = NOTE_KEYS.map((slot, i) => ({
    ...slot,
    midi: ladder[i] ?? low + i,
    chordTone: isChordTone(ladder[i] ?? low + i, rootPc, chord),
  }));

  const byCode: Record<string, TableEntry> = {};
  for (const e of entries) byCode[e.code] = e;

  return {
    entries,
    byCode,
    low,
    high,
    chordPcs: cps,
    scale,
    chord,
  };
}

/** Chord voicing for the SPACE / ENTER "stab" key. */
export function stabVoicing(table: PitchTable, octave: number): number[] {
  const base = 48 + 12 * octave;
  const ivs = table.chord.intervals;
  return ivs.map((iv, i) => {
    let m = base + iv;
    while (m < base + 12) m += 12;
    if (i > 0 && m > base + 24) m -= 12;
    return m;
  });
}
