/**
 * Music theory core: scales, chord qualities and the "consonant ladder"
 * generator that turns a tonality + chord into an ordered list of pitches.
 */

export const NOTE_NAMES = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"] as const;
export const WHITE_PCS = [0, 2, 4, 5, 7, 9, 11];
export const BLACK_PCS = [1, 3, 6, 8, 10];

export const mod = (n: number, m: number) => ((n % m) + m) % m;

export function midiToName(midi: number): string {
  return `${NOTE_NAMES[mod(midi, 12)]}${Math.floor(midi / 12) - 1}`;
}

export function midiToFreq(midi: number): number {
  return 440 * Math.pow(2, (midi - 69) / 12);
}

export const isBlack = (midi: number) => BLACK_PCS.includes(mod(midi, 12));

/** Diatonic index: useful for placing notes on a staff. */
export function diatonicIndex(midi: number): number {
  const pc = mod(midi, 12);
  const letter = Math.floor(pc / 2); // C,D,E,F,G,A,B
  const sharp = pc % 2 === 1;
  return Math.floor(midi / 12) * 7 + letter + (sharp ? 1 : 0);
}

export type ScaleDef = { id: string; name: string; steps: number[] };

export const SCALES: ScaleDef[] = [
  { id: "major", name: "Major", steps: [0, 2, 4, 5, 7, 9, 11] },
  { id: "minor", name: "Natural minor", steps: [0, 2, 3, 5, 7, 8, 10] },
  { id: "dorian", name: "Dorian", steps: [0, 2, 3, 5, 7, 9, 10] },
  { id: "phrygian", name: "Phrygian", steps: [0, 1, 3, 5, 7, 8, 10] },
  { id: "lydian", name: "Lydian", steps: [0, 2, 4, 6, 7, 9, 11] },
  { id: "mixolydian", name: "Mixolydian", steps: [0, 2, 4, 5, 7, 9, 10] },
  { id: "harmonicMinor", name: "Harmonic minor", steps: [0, 2, 3, 5, 7, 8, 11] },
  { id: "locrian", name: "Locrian", steps: [0, 1, 3, 5, 6, 8, 10] },
  { id: "pentMajor", name: "Major pentatonic", steps: [0, 2, 4, 7, 9] },
  { id: "pentMinor", name: "Minor pentatonic", steps: [0, 3, 5, 7, 10] },
  { id: "blues", name: "Blues", steps: [0, 3, 5, 6, 7, 10] },
  { id: "wholeTone", name: "Whole tone", steps: [0, 2, 4, 6, 8, 10] },
  { id: "chromatic", name: "Chromatic", steps: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11] },
];

export type ChordDef = { id: string; name: string; short: string; intervals: number[] };

export const CHORDS: ChordDef[] = [
  { id: "maj", name: "Major", short: "maj", intervals: [0, 4, 7] },
  { id: "min", name: "Minor", short: "min", intervals: [0, 3, 7] },
  { id: "sus2", name: "Sus 2", short: "sus2", intervals: [0, 2, 7] },
  { id: "sus4", name: "Sus 4", short: "sus4", intervals: [0, 5, 7] },
  { id: "add9", name: "Add 9", short: "add9", intervals: [0, 4, 7, 14] },
  { id: "six", name: "Sixth", short: "6", intervals: [0, 4, 7, 9] },
  { id: "dom7", name: "Dominant 7", short: "7", intervals: [0, 4, 7, 10] },
  { id: "maj7", name: "Major 7", short: "maj7", intervals: [0, 4, 7, 11] },
  { id: "min7", name: "Minor 7", short: "min7", intervals: [0, 3, 7, 10] },
  { id: "min7b5", name: "Minor 7♭5", short: "m7♭5", intervals: [0, 3, 6, 10] },
  { id: "dom7sus4", name: "7 Sus 4", short: "7sus4", intervals: [0, 5, 7, 10] },
  { id: "nine", name: "Ninth", short: "9", intervals: [0, 4, 7, 10, 14] },
  { id: "min9", name: "Minor 9", short: "m9", intervals: [0, 3, 7, 10, 14] },
  { id: "eleven", name: "Eleventh", short: "11", intervals: [0, 4, 7, 10, 14, 17] },
  { id: "thirteen", name: "Thirteenth", short: "13", intervals: [0, 4, 7, 10, 14, 21] },
  { id: "dim", name: "Diminished", short: "dim", intervals: [0, 3, 6] },
  { id: "aug", name: "Augmented", short: "aug", intervals: [0, 4, 8] },
  { id: "power", name: "Power", short: "5", intervals: [0, 7] },
];

export const getScale = (id: string): ScaleDef => SCALES.find((s) => s.id === id) ?? SCALES[0];
export const getChord = (id: string): ChordDef => CHORDS.find((c) => c.id === id) ?? CHORDS[0];

/** Pitch classes of the chord, relative to a root pitch class. */
export function chordPcs(rootPc: number, chord: ChordDef): Set<number> {
  const set = new Set<number>();
  for (const i of chord.intervals) set.add(mod(rootPc + i, 12));
  return set;
}

/**
 * Scale tones that never clash with the chord.
 * A tone is rejected when it forms a tritone (6 semitones) against a chord tone
 * that the chord itself does not already contain.
 */
export function consonantPcs(rootPc: number, scale: ScaleDef, chord: ChordDef, strict: boolean): Set<number> {
  const cps = chordPcs(rootPc, chord);
  const out = new Set<number>();
  for (const s of scale.steps) {
    const pc = mod(rootPc + s, 12);
    if (!strict) {
      out.add(pc);
      continue;
    }
    let clash = false;
    for (const c of cps) {
      const iv = mod(pc - c, 12);
      if (iv === 6) clash = true;
    }
    if (!clash) out.add(pc);
  }
  return out;
}

/**
 * Build an ascending ladder of `count` pitches inside [low, high].
 * Chord tones are favoured inside each bin so the resulting key map is
 * always consonant and always highlights the harmony.
 */
export function buildLadder(
  rootPc: number,
  scale: ScaleDef,
  chord: ChordDef,
  count: number,
  low: number,
  high: number,
  strict: boolean,
): number[] {
  const cps = chordPcs(rootPc, chord);
  const allowed = consonantPcs(rootPc, scale, chord, strict);
  const ok = (pc: number) => cps.has(pc) || allowed.has(pc);

  // Collect every consonant pitch in range. Chord tones are listed twice so
  // they show up roughly twice as often in the final map.
  const candidates: number[] = [];
  for (let midi = low; midi <= high; midi++) {
    const pc = mod(midi, 12);
    if (!ok(pc)) continue;
    candidates.push(midi);
    if (cps.has(pc)) candidates.push(midi);
  }

  if (candidates.length === 0) return Array.from({ length: count }, (_, i) => low + i);

  // Spread the keys evenly across the candidates: the result is always
  // non-decreasing, so the physical keyboard reads low-to-high left-to-right.
  const out: number[] = [];
  for (let i = 0; i < count; i++) {
    const idx = Math.min(candidates.length - 1, Math.floor((i * candidates.length) / count));
    out.push(candidates[idx]);
  }
  return out;
}

/** A playable voicing of a chord around a given root midi. */
export function chordVoicing(rootMidi: number, chord: ChordDef): number[] {
  const midis: number[] = [];
  for (const iv of chord.intervals) {
    let m = rootMidi + iv;
    while (m < rootMidi + 12) m += 12;
    midis.push(m);
  }
  return midis;
}

/** Which chord tones are present in a given midi (for highlighting). */
export function isChordTone(midi: number, rootPc: number, chord: ChordDef): boolean {
  return chordPcs(rootPc, chord).has(mod(midi, 12));
}
