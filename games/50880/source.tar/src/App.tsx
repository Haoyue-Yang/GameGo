import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import PianoStrip from "./components/PianoStrip";
import Staff, { type StaffNote } from "./components/Staff";
import KeyMap from "./components/KeyMap";
import { ChordPanel, TonalityPanel, VoicePanel } from "./components/Controls";
import { EchoPanel, RecorderPanel } from "./components/Studio";
import { Panel } from "./components/ui";
import { AudioEngine, getTimbre, type EchoSettings, type TimbreId } from "./audio/engine";
import { buildPitchTable, SPECIALS, stabVoicing } from "./lib/mapping";
import { chordVoicing, midiToName, mod } from "./lib/theory";
import type { Take, TakeEvent } from "./lib/take";

const MAX_STAFF = 34;

export default function App() {
  const engineRef = useRef<AudioEngine>(undefined as unknown as AudioEngine);
  if (!engineRef.current) engineRef.current = new AudioEngine();

  const [ready, setReady] = useState(false);
  const [rootPc, setRootPc] = useState(0);
  const [scaleId, setScaleId] = useState("major");
  const [chordId, setChordId] = useState("maj7");
  const [octave, setOctave] = useState(0);
  const [strict, setStrict] = useState(true);
  const [timbre, setTimbre] = useState<TimbreId>("glass");
  const [volume, setVolume] = useState(0.7);
  const [reverb, setReverb] = useState(0.3);
  const [chordMode, setChordMode] = useState(false);
  const [sustain, setSustain] = useState(false);
  const [echo, setEcho] = useState<EchoSettings>({
    on: true,
    delay: 400,
    repeats: 3,
    depth: 0.5,
    transpose: 7,
  });

  const [active, setActive] = useState<Record<string, number[]>>({});
  const [takeActive, setTakeActive] = useState<Record<string, number[]>>({});
  const [notes, setNotes] = useState<StaffNote[]>([]);
  const [memory, setMemory] = useState<number[]>([]);
  const [takes, setTakes] = useState<Take[]>([]);
  const [recording, setRecording] = useState(false);
  const [elapsed, setElapsed] = useState(0);
  const [playingIds, setPlayingIds] = useState<string[]>([]);

  const table = useMemo(() => buildPitchTable(rootPc, scaleId, chordId, octave, strict), [rootPc, scaleId, chordId, octave, strict]);

  const noteIdRef = useRef(0);
  const tableRef = useRef(table);
  tableRef.current = table;
  const takesRef = useRef(takes);
  takesRef.current = takes;
  const activeRef = useRef<Record<string, number[]>>({});
  activeRef.current = active;
  const recRef = useRef<{ start: number; events: TakeEvent[] } | null>(null);
  const playRef = useRef<{ id: string; startedAt: number; idx: number }[]>([]);
  const heldRef = useRef<Set<string>>(new Set());
  const sustainRef = useRef(false);
  sustainRef.current = sustain;
  const chordModeRef = useRef(false);
  chordModeRef.current = chordMode;

  const activeMidis = useMemo(() => {
    const s = new Set<number>();
    for (const midis of Object.values(active)) for (const m of midis) s.add(m);
    for (const midis of Object.values(takeActive)) for (const m of midis) s.add(m);
    return s;
  }, [active, takeActive]);

  const activeCodes = useMemo(() => new Set([...Object.keys(active), ...Object.keys(takeActive)]), [active, takeActive]);

  const ensureAudio = useCallback(async () => {
    const e = engineRef.current;
    if (e.ready) {
      if (e.ctx && e.ctx.state === "suspended") await e.ctx.resume();
      return;
    }
    await e.init();
    e.setVolume(volume);
    e.setReverb(reverb);
    e.setTimbre(getTimbre(timbre));
    e.setEcho(echo);
    setReady(true);
  }, [volume, reverb, timbre, echo]);

  useEffect(() => {
    engineRef.current.setTimbre(getTimbre(timbre));
  }, [timbre]);
  useEffect(() => {
    engineRef.current.setVolume(volume);
  }, [volume]);
  useEffect(() => {
    engineRef.current.setReverb(reverb);
  }, [reverb]);
  useEffect(() => {
    engineRef.current.setEcho(echo);
  }, [echo]);

  const pushNotes = useCallback((midis: number[], kind: StaffNote["kind"]) => {
    const cps = tableRef.current.chordPcs;
    const add: StaffNote[] = midis.map((m) => ({
      id: noteIdRef.current++,
      midi: m,
      kind,
      chordTone: cps.has(mod(m, 12)),
    }));
    setNotes((prev) => [...prev, ...add].slice(-MAX_STAFF));
  }, []);

  useEffect(() => {
    engineRef.current.onEcho = (midis) => {
      pushNotes(midis, "echo");
      setMemory((m) => [...m, midis[0]].slice(-16));
    };
  }, [pushNotes]);

  const panFor = useCallback((code: string) => {
    const entries = tableRef.current.entries;
    const idx = entries.findIndex((e) => e.code === code);
    return idx >= 0 ? (idx / Math.max(1, entries.length - 1)) * 1.1 - 0.55 : 0;
  }, []);

  const voiceOn = useCallback(
    (code: string, id: string, midis: number[], kind: StaffNote["kind"], record = true) => {
      engineRef.current.noteOn(id, midis, 1, panFor(code));
      setActive((a) => ({ ...a, [code]: midis }));
      pushNotes(midis, kind);
      if (record && recRef.current) {
        recRef.current.events.push({
          t: performance.now() - recRef.current.start,
          code,
          midis,
          on: true,
        });
      }
    },
    [pushNotes, panFor],
  );

  const voiceOff = useCallback((code: string, id: string, record = true) => {
    engineRef.current.noteOff(id);
    setActive((a) => {
      const next = { ...a };
      delete next[code];
      return next;
    });
    if (record && recRef.current) {
      recRef.current.events.push({
        t: performance.now() - recRef.current.start,
        code,
        midis: [],
        on: false,
      });
    }
  }, []);

  /** Take playback uses its own highlight map so it never steals held keys. */
  const takeOn = useCallback(
    (code: string, id: string, midis: number[]) => {
      engineRef.current.noteOn(id, midis, 1, panFor(code));
      setTakeActive((a) => ({ ...a, [code]: midis }));
      pushNotes(midis, "take");
    },
    [panFor, pushNotes],
  );

  const takeOff = useCallback((code: string, id: string) => {
    engineRef.current.noteOff(id);
    setTakeActive((a) => {
      const next = { ...a };
      delete next[code];
      return next;
    });
  }, []);

  const midisFor = useCallback((code: string) => {
    const t = tableRef.current;
    const entry = t.byCode[code];
    if (!entry) return null;
    if (chordModeRef.current) return chordVoicing(entry.midi, t.chord);
    return [entry.midi];
  }, []);

  const releaseAll = useCallback(() => {
    for (const code of Object.keys(activeRef.current)) voiceOff(code, code, false);
    heldRef.current.clear();
  }, [voiceOff]);

  /* ---------------- keyboard ---------------- */

  useEffect(() => {
    const onKeyDown = (ev: KeyboardEvent) => {
      if (ev.metaKey || ev.ctrlKey || ev.altKey) return;
      const code = ev.code;
      const special = SPECIALS[code];
      const isNote = tableRef.current.byCode[code];

      if (special || isNote) ev.preventDefault();
      if (ev.repeat) return;

      void ensureAudio();

      if (special) {
        const action = special.action;
        if (action === "sustain") {
          setSustain(true);
          setActive((a) => ({ ...a, [code]: [] }));
          return;
        }
        if (action === "chordMode") {
          setChordMode((c) => !c);
          return;
        }
        if (action === "echo") {
          setEcho((e) => ({ ...e, on: !e.on }));
          return;
        }
        if (action === "octaveUp") {
          setOctave((o) => Math.min(3, o + 1));
          return;
        }
        if (action === "octaveDown") {
          setOctave((o) => Math.max(-3, o - 1));
          return;
        }
        if (action === "chord") {
          if (activeRef.current[code]) return;
          const midis = stabVoicing(tableRef.current, octave);
          voiceOn(code, code, midis, "live");
          return;
        }
      }

      if (!isNote || activeRef.current[code]) return;
      const midis = midisFor(code);
      if (!midis) return;
      voiceOn(code, code, midis, "live");
    };

    const onKeyUp = (ev: KeyboardEvent) => {
      const code = ev.code;
      const special = SPECIALS[code];
      if (special && special.action === "sustain") {
        setSustain(false);
        setActive((a) => {
          const next = { ...a };
          delete next[code];
          return next;
        });
        for (const held of heldRef.current) voiceOff(held, held, false);
        heldRef.current.clear();
        return;
      }
      if (special) return;
      if (!tableRef.current.byCode[code]) return;
      if (sustainRef.current) {
        heldRef.current.add(code);
        return;
      }
      voiceOff(code, code, true);
    };

    const onBlur = () => {
      setSustain(false);
      heldRef.current.clear();
      releaseAll();
    };

    window.addEventListener("keydown", onKeyDown);
    window.addEventListener("keyup", onKeyUp);
    window.addEventListener("blur", onBlur);
    return () => {
      window.removeEventListener("keydown", onKeyDown);
      window.removeEventListener("keyup", onKeyUp);
      window.removeEventListener("blur", onBlur);
    };
  }, [ensureAudio, midisFor, octave, voiceOn, voiceOff, releaseAll]);

  /* ---------------- recording / playback ---------------- */

  const startTake = useCallback(() => {
    void ensureAudio();
    recRef.current = { start: performance.now(), events: [] };
    setRecording(true);
    setElapsed(0);
  }, [ensureAudio]);

  const stopTake = useCallback(() => {
    const rec = recRef.current;
    recRef.current = null;
    setRecording(false);
    if (!rec) return;
    const duration = performance.now() - rec.start;
    const events = rec.events.slice().sort((a, b) => a.t - b.t);
    setTakes((prev) => [
      ...prev,
      { id: `take-${Date.now()}`, name: `take-${prev.length + 1}`, duration, events },
    ]);
  }, []);

  const playTake = useCallback((take: Take) => {
    void ensureAudio();
    playRef.current = playRef.current.filter((p) => p.id !== take.id);
    playRef.current.push({ id: take.id, startedAt: performance.now(), idx: 0 });
    setPlayingIds(playRef.current.map((p) => p.id));
  }, [ensureAudio]);

  const stopAllTakes = useCallback(() => {
    for (const p of playRef.current) {
      for (let i = 0; i < p.idx; i++) {
        const ev = takesRef.current.find((t) => t.id === p.id)?.events[i];
        if (ev && ev.on) takeOff(ev.code, `t:${p.id}:${i}`);
      }
    }
    playRef.current = [];
    setPlayingIds([]);
  }, [takeOff]);

  useEffect(() => {
    let raf = 0;
    let lastShown = -1;
    const loop = () => {
      const now = performance.now();
      if (recRef.current) {
        const e = now - recRef.current.start;
        if (e - lastShown > 45) {
          lastShown = e;
          setElapsed(e);
        }
      }
      if (playRef.current.length) {
        let dirty = false;
        for (const p of playRef.current) {
          const take = takesRef.current.find((t) => t.id === p.id);
          if (!take) {
            dirty = true;
            continue;
          }
          const el = now - p.startedAt;
          while (p.idx < take.events.length && take.events[p.idx].t <= el) {
            const ev = take.events[p.idx];
            const vid = `t:${p.id}:${p.idx}`;
            if (ev.on) takeOn(ev.code, vid, ev.midis);
            else takeOff(ev.code, vid);
            p.idx++;
          }
          if (p.idx >= take.events.length && el > take.duration + 250) dirty = true;
        }
        if (dirty) {
          playRef.current = playRef.current.filter((p) => {
            const take = takesRef.current.find((t) => t.id === p.id);
            return !!take && p.idx < take.events.length;
          });
          setPlayingIds(playRef.current.map((p) => p.id));
        }
      }
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [takeOn, takeOff]);

  /* ---------------- derived readouts ---------------- */

  const voiceCount = Object.values(active).reduce((n, m) => n + m.length, 0);
  const tonalityLabel = `${["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"][rootPc]} ${table.scale.name.toUpperCase()} · ${table.chord.name.toUpperCase()}`;

  return (
    <div
      className="min-h-screen bg-paper p-3 md:p-5"
      onPointerUp={(e) => {
        const btn = (e.target as HTMLElement).closest("button");
        if (btn) btn.blur();
      }}
    >
      <div className="mx-auto max-w-[1500px] space-y-3">
        {/* header */}
        <header className="panel flex flex-wrap items-stretch gap-0">
          <div className="flex items-center gap-3 border-r-[3px] border-ink px-4 py-3">
            <div className="flex h-11 w-11 items-center justify-center border-[3px] border-ink bg-coral text-[22px] font-bold text-paper">
              ♪
            </div>
            <div>
              <h1 className="text-[19px] font-bold leading-none tracking-[0.16em]">TONALITY MACHINE</h1>
              <p className="mt-1 text-[10px] tracking-[0.1em] opacity-70">
                ANY KEY → CONSONANT NOTE · LIVE REMAP · STACKED VOICES
              </p>
            </div>
          </div>

          <div className="flex flex-1 flex-wrap items-center gap-2 px-4 py-3">
            <Readout label="TONALITY" value={tonalityLabel} accent="var(--color-mustard)" />
            <Readout label="VOICES" value={String(voiceCount)} accent="var(--color-coral)" />
            <Readout label="RANGE" value={`${midiToName(table.low)} – ${midiToName(table.high)}`} />
            <Readout label="TAKES" value={String(takes.length)} accent="var(--color-plum)" />
          </div>

          <div className="flex items-center gap-2 border-l-[3px] border-ink px-3 py-3">
            {!ready ? (
              <button
                type="button"
                onClick={() => void ensureAudio()}
                className="btn-flat bg-coral px-3 py-2 text-[11px] text-paper"
              >
                ▶ START AUDIO
              </button>
            ) : (
              <button
                type="button"
                onClick={() => {
                  stopAllTakes();
                  engineRef.current.stopAll();
                  setActive({});
                  setTakeActive({});
                  heldRef.current.clear();
                  setSustain(false);
                }}
                className="btn-flat px-3 py-2 text-[11px]"
              >
                ■ MUTE ALL
              </button>
            )}
          </div>
        </header>

        <div className="grid grid-cols-12 gap-3">
          <TonalityPanel
            className="col-span-12 lg:col-span-3"
            rootPc={rootPc}
            setRootPc={setRootPc}
            scaleId={scaleId}
            setScaleId={setScaleId}
            octave={octave}
            setOctave={setOctave}
            strict={strict}
            setStrict={setStrict}
          />
          <ChordPanel
            className="col-span-12 lg:col-span-3"
            chordId={chordId}
            setChordId={setChordId}
            chordMode={chordMode}
            setChordMode={setChordMode}
            table={table}
          />
          <div className="col-span-12 grid grid-cols-1 gap-3 sm:grid-cols-2 lg:col-span-6">
            <VoicePanel
              timbre={timbre}
              setTimbre={setTimbre}
              volume={volume}
              setVolume={setVolume}
              reverb={reverb}
              setReverb={setReverb}
            />
            <EchoPanel
              echo={echo}
              setEcho={setEcho}
              pending={engineRef.current.echoPending}
              memory={memory}
              onClearEcho={() => engineRef.current.clearEcho()}
            />
          </div>

          <Panel
            className="col-span-12"
            title="STAFF"
            accent="var(--color-ink)"
            right={
              <span className="flex items-center gap-2 text-[9px] font-bold">
                <Legend color="var(--color-ink)" text="LIVE" />
                <Legend color="var(--color-coral)" text="CHORD TONE" />
                <Legend color="var(--color-teal)" text="ECHO" />
                <Legend color="var(--color-plum)" text="TAKE" />
              </span>
            }
          >
            {notes.length === 0 ? (
              <p className="py-10 text-center text-[11px] tracking-[0.14em] opacity-60">
                PRESS ANY KEY TO WRITE A NOTE
              </p>
            ) : (
              <Staff notes={notes} />
            )}
          </Panel>

          <Panel
            className="col-span-12 lg:col-span-8"
            title="KEY → PITCH TABLE"
            accent="var(--color-teal)"
            right={
              <span className="border-2 border-ink px-1.5 text-[9px] font-bold" style={{ background: "var(--color-paper)" }}>
                {table.entries.length} KEYS · {table.chordPcs.size} CHORD TONES
              </span>
            }
          >
            <KeyMap table={table} activeCodes={activeCodes} activeMidis={activeMidis} chordMode={chordMode} />
          </Panel>

          <div className="col-span-12 lg:col-span-4">
            <RecorderPanel
              takes={takes}
              recording={recording}
              elapsed={elapsed}
              playingIds={playingIds}
              onStart={startTake}
              onStop={stopTake}
              onPlay={playTake}
              onStopAll={stopAllTakes}
              onDelete={(id) => {
                stopAllTakes();
                setTakes((prev) => prev.filter((t) => t.id !== id));
              }}
              onClear={() => {
                stopAllTakes();
                setTakes([]);
              }}
            />
          </div>

          <Panel
            className="col-span-12"
            title="PIANO STRIP"
            accent="var(--color-coral)"
            right={
              <span className="border-2 border-ink px-1.5 text-[9px] font-bold" style={{ background: "var(--color-paper)" }}>
                {sustain ? "SUSTAIN ON" : "SUSTAIN OFF"}
              </span>
            }
          >
            <PianoStrip table={table} activeMidis={activeMidis} activeCodes={activeCodes} />
          </Panel>
        </div>

        <footer className="panel flex flex-wrap items-center gap-x-4 gap-y-1 px-3 py-2 text-[9px] tracking-[0.1em]">
          <span className="font-bold">HOTKEYS</span>
          <span>SPACE / ENTER — CHORD STAB</span>
          <span>L-SHIFT — SUSTAIN PEDAL</span>
          <span>\ — CHORD MODE</span>
          <span>` — ECHO</span>
          <span>↑ / ↓ — OCTAVE</span>
          <span className="ml-auto opacity-60">
            HOLD SEVERAL KEYS TO STACK VOICES · {takes.length} TAKE{takes.length === 1 ? "" : "S"} BANKED
          </span>
        </footer>
      </div>
    </div>
  );
}

function Readout({ label, value, accent }: { label: string; value: string; accent?: string }) {
  return (
    <div className="border-2 border-ink px-2 py-1">
      <p className="text-[8px] font-bold tracking-[0.16em] opacity-60">{label}</p>
      <p className="text-[11px] font-bold leading-tight" style={{ color: accent ?? "var(--color-ink)" }}>
        {value}
      </p>
    </div>
  );
}

function Legend({ color, text }: { color: string; text: string }) {
  return (
    <span className="flex items-center gap-1">
      <span className="block h-2.5 w-2.5 border border-ink" style={{ background: color }} />
      {text}
    </span>
  );
}
