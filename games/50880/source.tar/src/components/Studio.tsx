import type { EchoSettings } from "../audio/engine";
import type { Take } from "../lib/take";
import { formatTime } from "../lib/take";
import { midiToName } from "../lib/theory";
import { Panel, Slider } from "./ui";

export function RecorderPanel({
  takes,
  recording,
  elapsed,
  playingIds,
  onStart,
  onStop,
  onPlay,
  onStopAll,
  onDelete,
  onClear,
}: {
  takes: Take[];
  recording: boolean;
  elapsed: number;
  playingIds: string[];
  onStart: () => void;
  onStop: () => void;
  onPlay: (t: Take) => void;
  onStopAll: () => void;
  onDelete: (id: string) => void;
  onClear: () => void;
}) {
  return (
    <Panel
      title="TAKES"
      accent={recording ? "var(--color-coral)" : "var(--color-plum)"}
      right={
        <span className="border-2 border-ink px-1.5 text-[10px] font-bold tabular-nums" style={{ background: "var(--color-paper)" }}>
          {formatTime(elapsed)}
        </span>
      }
    >
      <div className="space-y-2">
        <div className="grid grid-cols-3 gap-1">
          <button
            type="button"
            className="btn-flat col-span-2 py-2 text-[11px]"
            data-on={recording}
            onClick={recording ? onStop : onStart}
          >
            {recording ? "■ STOP TAKE" : "● RECORD TAKE"}
          </button>
          <button type="button" className="btn-flat py-2 text-[11px]" onClick={onStopAll}>
            ⏹
          </button>
        </div>

        {takes.length === 0 ? (
          <p className="text-[10px] leading-snug opacity-60">
            No takes yet. Hit RECORD, play on the keyboard, then STOP to bank the take. Layer several takes for
            call-and-response.
          </p>
        ) : (
          <ul className="space-y-1">
            {takes.map((t, i) => {
              const playing = playingIds.includes(t.id);
              return (
                <li
                  key={t.id}
                  className="flex items-center gap-1 border-2 border-ink px-1.5 py-1"
                  style={{ background: playing ? "var(--color-plum)" : "var(--color-paper)" }}
                >
                  <button
                    type="button"
                    onClick={() => onPlay(t)}
                    className="btn-flat min-w-[54px] px-1 py-0.5 text-[9px]"
                    style={{
                      background: playing ? "var(--color-mustard)" : "var(--color-paper)",
                      color: "var(--color-ink)",
                    }}
                  >
                    {playing ? "■" : "▶"}
                  </button>
                  <span
                    className="flex-1 text-[10px] font-bold"
                    style={{ color: playing ? "var(--color-paper)" : "var(--color-ink)" }}
                  >
                    TAKE {String(i + 1).padStart(2, "0")}
                    <span className="ml-1 font-normal tabular-nums opacity-70">{formatTime(t.duration)}</span>
                  </span>
                  <span
                    className="text-[9px] font-bold tabular-nums"
                    style={{ color: playing ? "var(--color-paper)" : "var(--color-ink)" }}
                  >
                    {t.events.length}
                  </span>
                  <button
                    type="button"
                    onClick={() => onDelete(t.id)}
                    aria-label={`Delete take ${i + 1}`}
                    className="border-2 border-ink px-1 text-[10px] font-bold hover:bg-coral"
                    style={{ color: playing ? "var(--color-paper)" : "var(--color-ink)" }}
                  >
                    ✕
                  </button>
                </li>
              );
            })}
          </ul>
        )}

        {takes.length > 1 && (
          <button type="button" className="btn-flat w-full py-1 text-[10px]" onClick={onClear}>
            CLEAR ALL TAKES
          </button>
        )}
      </div>
    </Panel>
  );
}

export function EchoPanel({
  echo,
  setEcho,
  pending,
  memory,
  onClearEcho,
}: {
  echo: EchoSettings;
  setEcho: (e: EchoSettings) => void;
  pending: number;
  memory: number[];
  onClearEcho: () => void;
}) {
  const set = <K extends keyof EchoSettings>(k: K, v: EchoSettings[K]) => setEcho({ ...echo, [k]: v });
  return (
    <Panel
      title="MEMORY ECHO"
      accent={echo.on ? "var(--color-teal)" : "var(--color-ink)"}
      right={
        <span className="border-2 border-ink px-1.5 text-[10px] font-bold" style={{ background: "var(--color-paper)" }}>
          {pending} QUEUED
        </span>
      }
    >
      <div className="space-y-2">
        <button
          type="button"
          className="btn-flat w-full py-1.5 text-[11px]"
          data-on={echo.on}
          onClick={() => set("on", !echo.on)}
        >
          {echo.on ? "ECHO ON" : "ECHO OFF"}
        </button>

        <Slider
          label="DELAY"
          value={echo.delay}
          min={90}
          max={1400}
          step={10}
          onChange={(v) => set("delay", v)}
          display={echo.delay + "ms"}
        />
        <Slider
          label="REPEATS"
          value={echo.repeats}
          min={0}
          max={6}
          step={1}
          onChange={(v) => set("repeats", v)}
          display={String(echo.repeats)}
        />
        <Slider
          label="DEPTH"
          value={echo.depth}
          min={0.05}
          max={0.95}
          step={0.01}
          onChange={(v) => set("depth", v)}
          display={Math.round(echo.depth * 100) + "%"}
        />
        <Slider
          label="TRANSPOSE"
          value={echo.transpose}
          min={-12}
          max={12}
          step={1}
          onChange={(v) => set("transpose", v)}
          display={(echo.transpose >= 0 ? "+" : "") + echo.transpose + "st"}
        />

        <div>
          <p className="mb-1 flex items-center justify-between text-[9px] font-bold tracking-[0.14em] opacity-70">
            <span>ECHO MEMORY</span>
            <button type="button" className="btn-flat px-1.5 py-0.5 text-[8px]" onClick={onClearEcho}>
              FLUSH
            </button>
          </p>
          <div className="flex flex-wrap gap-1">
            {memory.length === 0 && <span className="text-[10px] opacity-50">— empty —</span>}
            {memory.map((m, i) => (
              <span
                key={i}
                className="border-2 border-ink px-1 py-0.5 text-[9px] font-bold"
                style={{ background: i === memory.length - 1 ? "var(--color-teal)" : "var(--color-paper-2)" }}
              >
                {midiToName(m)}
              </span>
            ))}
          </div>
        </div>
      </div>
    </Panel>
  );
}
