import type { ReactNode } from "react";

export function Panel({
  title,
  accent,
  right,
  children,
  className = "",
}: {
  title: string;
  accent?: string;
  right?: ReactNode;
  children: ReactNode;
  className?: string;
}) {
  return (
    <section className={`panel flex flex-col ${className}`}>
      <header
        className="flex flex-wrap items-center justify-between gap-2 border-b-[3px] border-ink px-3 py-1.5"
        style={{ background: accent ?? "var(--color-ink)" }}
      >
        <h2
          className="text-[11px] font-bold tracking-[0.18em]"
          style={{ color: accent ? "var(--color-ink)" : "var(--color-paper)" }}
        >
          {title}
        </h2>
        {right}
      </header>
      <div className="p-3">{children}</div>
    </section>
  );
}

export function Slider({
  label,
  value,
  min,
  max,
  step,
  onChange,
  display,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  step: number;
  onChange: (v: number) => void;
  display?: string;
}) {
  return (
    <label className="block">
      <span className="flex items-baseline justify-between text-[10px] font-bold tracking-[0.12em]">
        <span>{label}</span>
        <span className="tabular-nums opacity-70">{display ?? value}</span>
      </span>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        aria-label={label}
      />
    </label>
  );
}

export function Toggle({
  label,
  on,
  onClick,
  accent = "var(--color-ink)",
}: {
  label: string;
  on: boolean;
  onClick: () => void;
  accent?: string;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-pressed={on}
      className="btn-flat flex items-center justify-between gap-2 px-2 py-1.5 text-[10px]"
      data-on={on}
    >
      <span>{label}</span>
      <span
        className="block h-3 w-6 border-2 border-ink"
        style={{ background: on ? accent : "var(--color-paper-3)" }}
      />
    </button>
  );
}

export function Chip({
  label,
  on,
  onClick,
  accent = "var(--color-ink)",
  sub,
  title,
}: {
  label: string;
  on: boolean;
  onClick: () => void;
  accent?: string;
  sub?: string;
  title?: string;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      title={title}
      aria-pressed={on}
      className="chip px-2 py-1 text-left text-[10px] font-bold leading-tight"
      style={{ background: on ? accent : "var(--color-paper)", color: on ? "var(--color-paper)" : "var(--color-ink)" }}
    >
      <span className="block">{label}</span>
      {sub && <span className="block text-[8px] font-normal opacity-70">{sub}</span>}
    </button>
  );
}
