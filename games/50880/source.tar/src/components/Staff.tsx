import { useEffect, useRef } from "react";
import { diatonicIndex, midiToName } from "../lib/theory";

export type StaffNote = {
  id: number;
  midi: number;
  kind: "live" | "echo" | "take";
  chordTone: boolean;
};

type Props = {
  notes: StaffNote[];
};

const LINE_GAP = 12;
const TOP_Y = 48;
const MIDDLE_Y = TOP_Y + LINE_GAP * 2; // E4
const E4_DI = diatonicIndex(64);
const STEP_X = 46;
const LEFT_PAD = 74;

const yFor = (midi: number) => MIDDLE_Y - (diatonicIndex(midi) - E4_DI) * (LINE_GAP / 2);

function ledgers(y: number): number[] {
  const out: number[] = [];
  if (y < TOP_Y - LINE_GAP / 2) {
    for (let ly = TOP_Y - LINE_GAP; ly >= y - LINE_GAP / 2; ly -= LINE_GAP) out.push(ly);
  }
  if (y > TOP_Y + LINE_GAP * 4 + LINE_GAP / 2) {
    for (let ly = TOP_Y + LINE_GAP * 4 + LINE_GAP; ly <= y + LINE_GAP / 2; ly += LINE_GAP) out.push(ly);
  }
  return out;
}

const FILL: Record<StaffNote["kind"], string> = {
  live: "var(--color-ink)",
  echo: "var(--color-teal)",
  take: "var(--color-plum)",
};

export default function Staff({ notes }: Props) {
  const scroller = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scroller.current) scroller.current.scrollLeft = scroller.current.scrollWidth;
  }, [notes.length]);

  const svgW = LEFT_PAD + Math.max(1, notes.length) * STEP_X + 40;
  const svgH = 190;

  return (
    <div ref={scroller} className="scroll-thin overflow-x-auto">
      <svg width={svgW} height={svgH} viewBox={`0 0 ${svgW} ${svgH}`} role="img" aria-label="Notation staff">
        {/* clef block */}
        <g>
          <rect x={16} y={MIDDLE_Y - 26} width={34} height={52} fill="var(--color-ink)" />
          <text
            x={33}
            y={MIDDLE_Y + 11}
            textAnchor="middle"
            fontSize={26}
            fontWeight={700}
            fill="var(--color-paper)"
            fontFamily="ui-monospace, monospace"
          >
            G
          </text>
        </g>

        {/* staff lines */}
        {[0, 1, 2, 3, 4].map((i) => (
          <line
            key={i}
            x1={LEFT_PAD - 26}
            x2={svgW - 8}
            y1={TOP_Y + i * LINE_GAP}
            y2={TOP_Y + i * LINE_GAP}
            stroke="var(--color-ink)"
            strokeWidth={2}
          />
        ))}
        <line
          x1={LEFT_PAD - 26}
          x2={LEFT_PAD - 26}
          y1={TOP_Y - 8}
          y2={TOP_Y + LINE_GAP * 4 + 8}
          stroke="var(--color-ink)"
          strokeWidth={3}
        />

        {/* notes */}
        {notes.map((n, i) => {
          const x = LEFT_PAD + i * STEP_X + STEP_X / 2;
          const y = yFor(n.midi);
          const up = y > MIDDLE_Y;
          const fill = n.chordTone ? "var(--color-coral)" : FILL[n.kind];
          return (
            <g key={n.id}>
              {ledgers(y).map((ly) => (
                <line key={ly} x1={x - 11} x2={x + 11} y1={ly} y2={ly} stroke="var(--color-ink)" strokeWidth={2} />
              ))}
              <line
                x1={x + (up ? 6 : -6)}
                x2={x + (up ? 6 : -6)}
                y1={y}
                y2={y + (up ? -46 : 46)}
                stroke={fill}
                strokeWidth={2.4}
              />
              <ellipse
                cx={x}
                cy={y}
                rx={7.4}
                ry={5.4}
                fill={fill}
                transform={`rotate(-18 ${x} ${y})`}
              />
              {n.kind === "echo" && (
                <circle cx={x} cy={y} r={11} fill="none" stroke="var(--color-teal)" strokeWidth={1.6} />
              )}
              {n.kind === "take" && (
                <rect
                  x={x - 10}
                  y={y - 8}
                  width={20}
                  height={16}
                  fill="none"
                  stroke="var(--color-plum)"
                  strokeWidth={1.6}
                />
              )}
              <text
                x={x}
                y={svgH - 16}
                textAnchor="middle"
                fontSize={9}
                fontWeight={700}
                fill="var(--color-ink)"
                fontFamily="ui-monospace, monospace"
                opacity={0.75}
              >
                {midiToName(n.midi)}
              </text>
            </g>
          );
        })}

        {/* playhead */}
        {notes.length > 0 && (
          <line
            x1={svgW - 14}
            x2={svgW - 14}
            y1={TOP_Y - 14}
            y2={TOP_Y + LINE_GAP * 4 + 14}
            stroke="var(--color-coral)"
            strokeWidth={2}
            strokeDasharray="4 4"
          />
        )}

        {/* ruler */}
        <line
          x1={LEFT_PAD - 26}
          x2={svgW - 8}
          y1={svgH - 6}
          y2={svgH - 6}
          stroke="var(--color-ink)"
          strokeWidth={2}
        />
        {Array.from({ length: Math.ceil(svgW / 40) }).map((_, i) => (
          <line
            key={i}
            x1={i * 40}
            x2={i * 40}
            y1={svgH - 6}
            y2={svgH - (i % 5 === 0 ? 14 : 10)}
            stroke="var(--color-ink)"
            strokeWidth={i % 5 === 0 ? 2 : 1}
            opacity={0.6}
          />
        ))}
      </svg>
    </div>
  );
}
