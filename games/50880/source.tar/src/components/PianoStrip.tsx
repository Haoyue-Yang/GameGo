import { isBlack, midiToName, mod, NOTE_NAMES } from "../lib/theory";
import { SPECIALS, type PitchTable } from "../lib/mapping";

type Props = {
  table: PitchTable;
  activeMidis: Set<number>;
  activeCodes: Set<string>;
};

const WHITE_W = 42;
const BLACK_W = 25;
const KEY_H = 138;

export default function PianoStrip({ table, activeMidis, activeCodes }: Props) {
  const low = table.low - 2;
  const high = table.high + 2;

  const whites: number[] = [];
  const blacks: number[] = [];
  for (let m = low; m <= high; m++) (isBlack(m) ? blacks : whites).push(m);

  const labelOf = new Map<number, string>();
  for (const e of table.entries) {
    const prev = labelOf.get(e.midi);
    labelOf.set(e.midi, prev ? `${prev}/${e.label}` : e.label);
  }

  const width = whites.length * WHITE_W;

  return (
    <div className="scroll-thin overflow-x-auto">
      <div className="relative" style={{ width, height: KEY_H + 34 }}>
        {/* white keys */}
        {whites.map((m, i) => {
          const on = activeMidis.has(m);
          const label = labelOf.get(m);
          const ct = table.chordPcs.has(mod(m, 12));
          return (
            <div
              key={m}
              className="absolute top-0 flex flex-col items-center justify-end border-l-2 border-ink pb-2"
              style={{
                left: i * WHITE_W,
                width: WHITE_W,
                height: KEY_H,
                background: on ? "var(--color-coral)" : ct ? "var(--color-mustard)" : "var(--color-paper)",
                borderColor: "var(--color-ink)",
              }}
            >
              {label && (
                <span
                  className="text-[13px] font-bold leading-none"
                  style={{ color: on ? "var(--color-paper)" : "var(--color-ink)" }}
                >
                  {label}
                </span>
              )}
              <span
                className="mt-1 text-[9px] leading-none opacity-70"
                style={{ color: on ? "var(--color-paper)" : "var(--color-ink)" }}
              >
                {midiToName(m)}
              </span>
            </div>
          );
        })}

        {/* black keys */}
        {blacks.map((m) => {
          const idx = whites.filter((w) => w < m).length;
          const on = activeMidis.has(m);
          const label = labelOf.get(m);
          const ct = table.chordPcs.has(mod(m, 12));
          return (
            <div
              key={m}
              className="absolute top-0 flex items-end justify-center border-2 border-ink pb-1"
              style={{
                left: idx * WHITE_W + WHITE_W - BLACK_W / 2,
                width: BLACK_W,
                height: KEY_H * 0.62,
                background: on ? "var(--color-coral)" : ct ? "var(--color-indigo)" : "var(--color-ink)",
                zIndex: 2,
              }}
            >
              {label && (
                <span
                  className="text-[10px] font-bold leading-none"
                  style={{ color: on ? "var(--color-paper)" : "var(--color-paper)" }}
                >
                  {label}
                </span>
              )}
            </div>
          );
        })}

        {/* octave ticks */}
        <div className="absolute bottom-0 left-0 flex w-full items-center" style={{ height: 30 }}>
          {whites.map((m) => (
            <div
              key={m}
              className="flex items-center justify-center border-l border-ink/40 text-[9px] font-bold"
              style={{
                width: WHITE_W,
                height: 30,
                background: m % 12 === 0 ? "var(--color-ink)" : "transparent",
                color: m % 12 === 0 ? "var(--color-paper)" : "var(--color-ink)",
              }}
            >
              {m % 12 === 0 ? NOTE_NAMES[mod(m, 12)] + (Math.floor(m / 12) - 1) : ""}
            </div>
          ))}
        </div>

        {/* active key count ribbon */}
        <div className="pointer-events-none absolute -top-[3px] right-0 flex gap-1">
          {[...activeCodes].slice(0, 8).map((c) => (
            <span
              key={c}
              className="blip border-2 border-ink px-1 text-[10px] font-bold"
              style={{ background: "var(--color-teal)", color: "var(--color-paper)" }}
            >
              {table.byCode[c]?.label ?? SPECIALS[c]?.label ?? c}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}
