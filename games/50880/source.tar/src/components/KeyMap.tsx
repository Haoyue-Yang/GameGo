import { midiToName } from "../lib/theory";
import { KEY_ROWS, SPECIALS } from "../lib/mapping";

type Props = {
  table: import("../lib/mapping").PitchTable;
  activeCodes: Set<string>;
  activeMidis: Set<number>;
  chordMode: boolean;
};

export default function KeyMap({ table, activeCodes, activeMidis, chordMode }: Props) {
  const rows = [3, 2, 1, 0];

  return (
    <div className="scroll-thin overflow-x-auto">
      <div className="flex min-w-max flex-col gap-1.5">
      {rows.map((r) => (
        <div key={r} className="flex gap-1.5">
          {KEY_ROWS[r].map((slot) => {
            const entry = table.byCode[slot.code];
            const on = activeCodes.has(slot.code);
            const sounding = !!entry && activeMidis.has(entry.midi);
            const bg = on
              ? "var(--color-coral)"
              : sounding
                ? "var(--color-mustard)"
                : entry?.chordTone
                  ? "var(--color-paper-2)"
                  : "var(--color-paper)";
            return (
              <div
                key={slot.code}
                className="flex min-w-[38px] flex-col items-center justify-center border-2 border-ink px-1 py-1.5 leading-none"
                style={{ background: bg }}
                title={`${slot.label} → ${entry ? midiToName(entry.midi) : "—"}`}
              >
                <span
                  className="text-[12px] font-bold"
                  style={{ color: on ? "var(--color-paper)" : "var(--color-ink)" }}
                >
                  {slot.label}
                </span>
                <span
                  className="mt-1 text-[9px] font-bold opacity-80"
                  style={{ color: on ? "var(--color-paper)" : "var(--color-ink)" }}
                >
                  {entry ? midiToName(entry.midi) : "—"}
                </span>
              </div>
            );
          })}
        </div>
      ))}

      {/* specials */}
      <div className="mt-1 flex flex-wrap items-center gap-1.5">
        {Object.entries(SPECIALS).map(([code, s]) => {
          const on = activeCodes.has(code);
          return (
            <div
              key={code}
              className="flex items-center gap-1.5 border-2 border-ink px-2 py-1 text-[10px] font-bold leading-none"
              style={{
                background: on ? "var(--color-teal)" : "var(--color-paper-2)",
                color: on ? "var(--color-paper)" : "var(--color-ink)",
              }}
            >
              <span className="border border-ink px-1 py-0.5" style={{ background: "var(--color-paper)" }}>
                {s.label}
              </span>
              <span>{s.action.toUpperCase()}</span>
            </div>
          );
        })}
        <div
          className="ml-auto border-2 border-ink px-2 py-1 text-[10px] font-bold leading-none"
          style={{
            background: chordMode ? "var(--color-plum)" : "var(--color-paper-2)",
            color: chordMode ? "var(--color-paper)" : "var(--color-ink)",
          }}
        >
          {chordMode ? "CHORD MODE: ON" : "CHORD MODE: OFF"}
        </div>
      </div>
      </div>
    </div>
  );
}
