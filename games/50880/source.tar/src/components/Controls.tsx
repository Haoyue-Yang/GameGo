import { CHORDS, NOTE_NAMES, SCALES, chordVoicing, midiToName } from "../lib/theory";
import type { PitchTable } from "../lib/mapping";
import { TIMBRES, type TimbreId } from "../audio/engine";
import { Chip, Panel, Slider, Toggle } from "./ui";

const ROOT_LABELS = NOTE_NAMES.map((n, i) => ({ pc: i, label: n }));

export function TonalityPanel({
  rootPc,
  setRootPc,
  scaleId,
  setScaleId,
  octave,
  setOctave,
  strict,
  setStrict,
  className = "",
}: {
  rootPc: number;
  setRootPc: (n: number) => void;
  scaleId: string;
  setScaleId: (s: string) => void;
  octave: number;
  setOctave: (n: number) => void;
  strict: boolean;
  setStrict: (b: boolean) => void;
  className?: string;
}) {
  return (
    <Panel title="TONALITY" accent="var(--color-mustard)" className={className}>
      <div className="space-y-3">
        <div>
          <p className="mb-1 text-[9px] font-bold tracking-[0.14em] opacity-70">ROOT</p>
          <div className="grid grid-cols-6 gap-1">
            {ROOT_LABELS.map((r) => (
              <Chip
                key={r.pc}
                label={r.label}
                on={r.pc === rootPc}
                accent="var(--color-coral)"
                onClick={() => setRootPc(r.pc)}
              />
            ))}
          </div>
        </div>

        <div>
          <p className="mb-1 text-[9px] font-bold tracking-[0.14em] opacity-70">SCALE / MODE</p>
          <div className="grid grid-cols-3 gap-1">
            {SCALES.map((s) => (
              <Chip key={s.id} label={s.name} on={s.id === scaleId} onClick={() => setScaleId(s.id)} />
            ))}
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            className="btn-flat h-8 w-9 text-[14px]"
            onClick={() => setOctave(octave - 1)}
            aria-label="Octave down"
          >
            −
          </button>
          <div className="flex-1 border-2 border-ink px-2 py-1 text-center text-[11px] font-bold">
            OCTAVE {octave >= 0 ? `+${octave}` : octave}
          </div>
          <button
            type="button"
            className="btn-flat h-8 w-9 text-[14px]"
            onClick={() => setOctave(octave + 1)}
            aria-label="Octave up"
          >
            +
          </button>
        </div>

        <Toggle
          label="STRICT CONSONANCE"
          on={strict}
          onClick={() => setStrict(!strict)}
          accent="var(--color-teal)"
        />
        <p className="text-[9px] leading-snug opacity-60">
          Strict mode drops any scale tone that forms a tritone against a chord tone, so every key stays consonant.
        </p>
      </div>
    </Panel>
  );
}

export function ChordPanel({
  chordId,
  setChordId,
  chordMode,
  setChordMode,
  table,
  className = "",
}: {
  chordId: string;
  setChordId: (s: string) => void;
  chordMode: boolean;
  setChordMode: (b: boolean) => void;
  table: PitchTable;
  className?: string;
}) {
  const voicing = chordVoicing(48, table.chord);
  return (
    <Panel
      title="CHORD"
      className={className}
      accent="var(--color-indigo)"
      right={
        <span className="border-2 border-ink px-1.5 text-[10px] font-bold" style={{ background: "var(--color-paper)" }}>
          {table.chord.name}
        </span>
      }
    >
      <div className="space-y-3">
        <div className="grid grid-cols-3 gap-1">
          {CHORDS.map((c) => (
            <Chip
              key={c.id}
              label={c.name}
              sub={c.short}
              on={c.id === chordId}
              accent="var(--color-indigo)"
              onClick={() => setChordId(c.id)}
            />
          ))}
        </div>

        <div>
          <p className="mb-1 text-[9px] font-bold tracking-[0.14em] opacity-70">SPACE STAB VOICING</p>
          <div className="flex flex-wrap gap-1">
            {voicing.map((m, i) => (
              <span
                key={i}
                className="border-2 border-ink px-1.5 py-0.5 text-[10px] font-bold"
                style={{ background: "var(--color-mustard)" }}
              >
                {midiToName(m)}
              </span>
            ))}
          </div>
        </div>

        <Toggle
          label="CHORD MODE (\\)"
          on={chordMode}
          onClick={() => setChordMode(!chordMode)}
          accent="var(--color-plum)"
        />
        <p className="text-[9px] leading-snug opacity-60">
          Chord mode turns every key into a full voicing stacked on that pitch.
        </p>
      </div>
    </Panel>
  );
}

export function VoicePanel({
  timbre,
  setTimbre,
  volume,
  setVolume,
  reverb,
  setReverb,
}: {
  timbre: TimbreId;
  setTimbre: (t: TimbreId) => void;
  volume: number;
  setVolume: (n: number) => void;
  reverb: number;
  setReverb: (n: number) => void;
}) {
  return (
    <Panel title="VOICE" accent="var(--color-teal)">
      <div className="space-y-3">
        <div className="grid grid-cols-2 gap-1">
          {TIMBRES.map((t) => (
            <Chip
              key={t.id}
              label={t.name}
              sub={t.blurb}
              on={t.id === timbre}
              accent="var(--color-teal)"
              onClick={() => setTimbre(t.id)}
            />
          ))}
        </div>
        <Slider label="VOLUME" value={volume} min={0} max={1} step={0.01} onChange={setVolume} display={Math.round(volume * 100) + "%"} />
        <Slider
          label="REVERB"
          value={reverb}
          min={0}
          max={0.9}
          step={0.01}
          onChange={setReverb}
          display={Math.round(reverb * 100) + "%"}
        />
      </div>
    </Panel>
  );
}
