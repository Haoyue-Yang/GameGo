/**
 * Small polyphonic Web Audio engine: layered voices, reverb, delay,
 * and a "memory echo" scheduler that re-voices past notes.
 */

import { midiToFreq } from "../lib/theory";

export type TimbreId = "glass" | "warm" | "pluck" | "pad" | "bell";

type OscLayer = { type: OscillatorType; detune: number; gain: number };

export type TimbreDef = {
  id: TimbreId;
  name: string;
  blurb: string;
  layers: OscLayer[];
  filter: { type: BiquadFilterType; freq: number; q: number; sweep: number };
  attack: number;
  decay: number;
  sustain: number;
  release: number;
  gain: number;
};

export const TIMBRES: TimbreDef[] = [
  {
    id: "glass",
    name: "Glass",
    blurb: "bright triangle + sine",
    layers: [
      { type: "triangle", detune: 0, gain: 0.6 },
      { type: "sine", detune: 7, gain: 0.35 },
      { type: "sine", detune: -7, gain: 0.25 },
    ],
    filter: { type: "lowpass", freq: 5200, q: 0.6, sweep: 1400 },
    attack: 0.006,
    decay: 0.18,
    sustain: 0.55,
    release: 0.42,
    gain: 0.2,
  },
  {
    id: "warm",
    name: "Warm",
    blurb: "detuned saws, soft filter",
    layers: [
      { type: "sawtooth", detune: -6, gain: 0.35 },
      { type: "sawtooth", detune: 6, gain: 0.35 },
      { type: "triangle", detune: 0, gain: 0.3 },
    ],
    filter: { type: "lowpass", freq: 2400, q: 1.4, sweep: 900 },
    attack: 0.02,
    decay: 0.25,
    sustain: 0.7,
    release: 0.5,
    gain: 0.17,
  },
  {
    id: "pluck",
    name: "Pluck",
    blurb: "fast decay, marimba feel",
    layers: [
      { type: "triangle", detune: 0, gain: 0.7 },
      { type: "square", detune: 0, gain: 0.12 },
    ],
    filter: { type: "lowpass", freq: 6000, q: 0.8, sweep: 2600 },
    attack: 0.003,
    decay: 0.5,
    sustain: 0.12,
    release: 0.3,
    gain: 0.2,
  },
  {
    id: "pad",
    name: "Pad",
    blurb: "slow attack, wide detune",
    layers: [
      { type: "sawtooth", detune: -12, gain: 0.28 },
      { type: "sawtooth", detune: 12, gain: 0.28 },
      { type: "sine", detune: 0, gain: 0.3 },
    ],
    filter: { type: "lowpass", freq: 1500, q: 0.9, sweep: 500 },
    attack: 0.22,
    decay: 0.6,
    sustain: 0.85,
    release: 1.1,
    gain: 0.15,
  },
  {
    id: "bell",
    name: "Bell",
    blurb: "sine partials, long tail",
    layers: [
      { type: "sine", detune: 0, gain: 0.6 },
      { type: "sine", detune: 1200, gain: 0.22 },
      { type: "sine", detune: 1900, gain: 0.12 },
    ],
    filter: { type: "lowpass", freq: 7000, q: 0.4, sweep: 1800 },
    attack: 0.004,
    decay: 1.1,
    sustain: 0.18,
    release: 0.9,
    gain: 0.18,
  },
];

export const getTimbre = (id: TimbreId): TimbreDef => TIMBRES.find((t) => t.id === id) ?? TIMBRES[0];

type Voice = {
  midis: number[];
  out: GainNode;
  filter: BiquadFilterNode;
  oscs: OscillatorNode[];
};

export type EchoSettings = {
  on: boolean;
  delay: number;
  repeats: number;
  depth: number;
  transpose: number;
};

function makeImpulse(ctx: AudioContext, seconds: number, decay: number): AudioBuffer {
  const len = Math.max(1, Math.floor(ctx.sampleRate * seconds));
  const buf = ctx.createBuffer(2, len, ctx.sampleRate);
  for (let ch = 0; ch < 2; ch++) {
    const data = buf.getChannelData(ch);
    for (let i = 0; i < len; i++) {
      const t = i / len;
      data[i] = (Math.random() * 2 - 1) * Math.pow(1 - t, decay);
    }
  }
  return buf;
}

export class AudioEngine {
  ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private wet: GainNode | null = null;
  private convSend: GainNode | null = null;
  private voices = new Map<string, Voice>();
  private echoQueue: { midis: number[]; at: number; depth: number; transposed: number }[] = [];
  private timer: number | null = null;
  private timbre: TimbreDef = TIMBRES[0];
  private echo: EchoSettings = { on: true, delay: 380, repeats: 3, depth: 0.5, transpose: 7 };
  private voiceCount = 0;

  onEcho?: (midis: number[]) => void;

  get ready() {
    return this.ctx !== null;
  }

  async init() {
    if (this.ctx) {
      if (this.ctx.state === "suspended") await this.ctx.resume();
      return;
    }
    const Ctor: typeof AudioContext =
      window.AudioContext ??
      (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    const ctx = new Ctor();
    this.ctx = ctx;

    const comp = ctx.createDynamicsCompressor();
    comp.threshold.value = -14;
    comp.knee.value = 24;
    comp.ratio.value = 3.2;
    comp.attack.value = 0.006;
    comp.release.value = 0.22;

    this.master = ctx.createGain();
    this.master.gain.value = 0.85;
    this.master.connect(comp);
    comp.connect(ctx.destination);

    const conv = ctx.createConvolver();
    conv.buffer = makeImpulse(ctx, 2.4, 2.6);
    this.wet = ctx.createGain();
    this.wet.gain.value = 0.25;
    conv.connect(this.wet);
    this.wet.connect(this.master);

    this.convSend = ctx.createGain();
    this.convSend.gain.value = 0.3;
    this.convSend.connect(conv);

    const delay = ctx.createDelay(1.5);
    delay.delayTime.value = 0.28;
    const fb = ctx.createGain();
    fb.gain.value = 0.32;
    const damp = ctx.createBiquadFilter();
    damp.type = "lowpass";
    damp.frequency.value = 2600;
    const delayIn = ctx.createGain();
    delayIn.gain.value = 0.2;
    delayIn.connect(delay);
    delay.connect(damp);
    damp.connect(fb);
    fb.connect(delay);
    damp.connect(this.master);
    delay.connect(conv);

    this.startScheduler();
  }

  setVolume(v: number) {
    if (!this.ctx || !this.master) return;
    this.master.gain.setTargetAtTime(v, this.ctx.currentTime, 0.02);
  }

  setReverb(v: number) {
    if (!this.ctx || !this.wet) return;
    this.wet.gain.setTargetAtTime(v, this.ctx.currentTime, 0.02);
  }

  setTimbre(id: TimbreDef) {
    this.timbre = id;
  }

  setEcho(e: EchoSettings) {
    this.echo = e;
    if (!e.on) this.echoQueue.length = 0;
  }

  get voiceTotal() {
    return this.voiceCount;
  }

  get echoPending() {
    return this.echoQueue.length;
  }

  private buildVoice(midis: number[], pan: number, velocity: number): Voice {
    const ctx = this.ctx!;
    const t = ctx.currentTime;
    const def = this.timbre;

    const out = ctx.createGain();
    out.gain.value = 0;

    const filter = ctx.createBiquadFilter();
    filter.type = def.filter.type;
    filter.Q.value = def.filter.q;

    const panner = ctx.createStereoPanner();
    panner.pan.value = pan;

    filter.connect(out);
    out.connect(panner);
    panner.connect(this.master!);
    if (this.convSend) panner.connect(this.convSend);

    const oscs: OscillatorNode[] = [];
    let cutoff = def.filter.freq;
    for (const m of midis) {
      const f = midiToFreq(m);
      cutoff = Math.max(cutoff, f * 2.2 + 400);
      for (const layer of def.layers) {
        const osc = ctx.createOscillator();
        osc.type = layer.type;
        osc.frequency.value = f;
        osc.detune.value = layer.detune;
        const g = ctx.createGain();
        g.gain.value = layer.gain;
        osc.connect(g);
        g.connect(filter);
        osc.start(t);
        oscs.push(osc);
      }
    }

    filter.frequency.setValueAtTime(cutoff, t);
    filter.frequency.exponentialRampToValueAtTime(
      Math.max(320, cutoff - def.filter.sweep),
      t + Math.max(0.08, def.attack + def.decay),
    );

    const peak = def.gain * velocity;
    const sustainLevel = peak * def.sustain;
    out.gain.setValueAtTime(0.0001, t);
    out.gain.linearRampToValueAtTime(peak, t + def.attack);
    out.gain.exponentialRampToValueAtTime(Math.max(0.0002, sustainLevel), t + def.attack + def.decay);

    this.voiceCount++;
    return { midis, out, filter, oscs };
  }

  noteOn(id: string, midis: number[], velocity = 1, pan = 0) {
    if (!this.ctx || this.voices.has(id)) return;
    const voice = this.buildVoice(midis, pan, velocity);
    this.voices.set(id, voice);

    if (this.echo.on) {
      const now = performance.now();
      for (let r = 1; r <= this.echo.repeats; r++) {
        this.echoQueue.push({
          midis,
          at: now + this.echo.delay * r,
          depth: Math.pow(this.echo.depth, r),
          transposed: this.echo.transpose * r,
        });
      }
    }
  }

  noteOff(id: string) {
    if (!this.ctx) return;
    const voice = this.voices.get(id);
    if (!voice) return;
    this.release(voice, this.timbre.release);
    this.voices.delete(id);
  }

  private release(voice: Voice, release: number) {
    const ctx = this.ctx!;
    const t = ctx.currentTime;
    voice.out.gain.cancelScheduledValues(t);
    voice.out.gain.setValueAtTime(Math.max(voice.out.gain.value, 0.0002), t);
    voice.out.gain.exponentialRampToValueAtTime(0.0001, t + Math.max(0.02, release));
    const stopAt = t + Math.max(0.03, release) + 0.05;
    for (const osc of voice.oscs) {
      try {
        osc.stop(stopAt);
      } catch {
        /* already stopped */
      }
    }
    const wait = Math.max(60, (stopAt - ctx.currentTime) * 1000 + 120);
    window.setTimeout(() => {
      try {
        voice.filter.disconnect();
        voice.out.disconnect();
      } catch {
        /* already disconnected */
      }
    }, wait);
    this.voiceCount = Math.max(0, this.voiceCount - 1);
  }

  /** One-shot voice used by the memory echo. */
  oneShot(midis: number[], velocity: number, decay: number, pan = 0) {
    if (!this.ctx || !this.master) return;
    const ctx = this.ctx;
    const t = ctx.currentTime;
    const def = this.timbre;
    const out = ctx.createGain();
    out.gain.value = 0;
    const filter = ctx.createBiquadFilter();
    filter.type = "lowpass";
    filter.frequency.value = 4200;
    filter.Q.value = 0.7;
    const panner = ctx.createStereoPanner();
    panner.pan.value = pan;
    filter.connect(out);
    out.connect(panner);
    panner.connect(this.master);
    if (this.convSend) panner.connect(this.convSend);

    const oscs: OscillatorNode[] = [];
    for (const m of midis) {
      const f = midiToFreq(m);
      for (const layer of def.layers) {
        const osc = ctx.createOscillator();
        osc.type = layer.type;
        osc.frequency.value = f;
        osc.detune.value = layer.detune;
        const g = ctx.createGain();
        g.gain.value = layer.gain;
        osc.connect(g);
        g.connect(filter);
        osc.start(t);
        oscs.push(osc);
      }
    }
    const peak = def.gain * velocity;
    out.gain.setValueAtTime(0.0001, t);
    out.gain.linearRampToValueAtTime(peak, t + 0.008);
    out.gain.exponentialRampToValueAtTime(0.0002, t + 0.008 + decay);
    const stopAt = t + decay + 0.25;
    for (const osc of oscs) osc.stop(stopAt);
    window.setTimeout(() => {
      try {
        filter.disconnect();
        out.disconnect();
      } catch {
        /* already disconnected */
      }
    }, (stopAt - ctx.currentTime) * 1000 + 120);
  }

  private startScheduler() {
    if (this.timer !== null) return;
    this.timer = window.setInterval(() => {
      if (!this.ctx || !this.echo.on || this.echoQueue.length === 0) return;
      const now = performance.now();
      const due = this.echoQueue.filter((e) => e.at <= now);
      if (!due.length) return;
      this.echoQueue = this.echoQueue.filter((e) => e.at > now);
      for (const item of due) {
        const midis = item.midis.map((m) => m + item.transposed);
        this.oneShot(midis, Math.max(0.02, item.depth), 0.5 + item.depth * 0.9, item.depth * 0.6 - 0.3);
        this.onEcho?.(midis);
      }
    }, 24);
  }

  stopAll() {
    for (const id of [...this.voices.keys()]) this.noteOff(id);
    this.echoQueue.length = 0;
  }

  clearEcho() {
    this.echoQueue.length = 0;
  }
}
