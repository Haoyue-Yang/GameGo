import { useEffect, useState, type ReactNode } from 'react';
import {
  BUILDINGS,
  RESOURCES,
  RESOURCE_META,
  type BuildingType,
  type Cost,
  type Medal,
  type ResourceKind,
  type Snapshot,
} from '../game/types';
import type { Game } from '../game/engine';

const KIND_ICON: Record<string, string> = {
  gather: '⛏',
  clear: '🪓',
  repair: '🔨',
  build: '🏗',
  upgrade: '⬆',
  fire: '🔥',
};

const MEDAL_META: Record<Medal, { label: string; color: string; ring: string }> = {
  gold: { label: 'Gold Wayfarer', color: '#e8c05a', ring: '#8a6a1a' },
  silver: { label: 'Silver Wayfarer', color: '#cfd6de', ring: '#6d7681' },
  bronze: { label: 'Bronze Wayfarer', color: '#cd8a52', ring: '#7a4a22' },
  none: { label: 'Level Cleared', color: '#a8d17f', ring: '#4f7f3a' },
};

function fmt(t: number) {
  const s = Math.max(0, Math.floor(t));
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
}

function CostRow({ cost, res }: { cost: Cost; res: Record<ResourceKind, number> }) {
  const entries = RESOURCES.filter((r) => (cost[r] ?? 0) > 0);
  if (!entries.length) return <span className="text-[11px] italic opacity-60">free</span>;
  return (
    <span className="inline-flex flex-wrap gap-1.5">
      {entries.map((r) => {
        const need = cost[r]!;
        const ok = res[r] >= need;
        return (
          <span
            key={r}
            className={`inline-flex items-center gap-1 rounded-full border px-1.5 py-[1px] text-[11px] font-bold ${
              ok ? 'border-[#5a4a38]/40 bg-white/55' : 'border-[#a33]/60 bg-[#f0c0b0]/70 text-[#7a2418]'
            }`}
          >
            <span style={{ color: RESOURCE_META[r].color }}>{RESOURCE_META[r].glyph}</span>
            {need}
          </span>
        );
      })}
    </span>
  );
}

function Panel({ children, className = '' }: { children: ReactNode; className?: string }) {
  return <div className={`panel px-3 py-2.5 ${className}`}>{children}</div>;
}

/* ------------------------------------------------------------------ */
export function Hud({
  snap,
  game,
  onRestart,
  onNext,
}: {
  snap: Snapshot;
  game: Game | null;
  onRestart: () => void;
  onNext: () => void;
}) {
  const [cursor, setCursor] = useState({ x: 0, y: 0 });
  const [guide, setGuide] = useState(false);
  const [showIntro, setShowIntro] = useState(true);

  useEffect(() => {
    const h = (e: PointerEvent) => setCursor({ x: e.clientX, y: e.clientY });
    window.addEventListener('pointermove', h);
    return () => window.removeEventListener('pointermove', h);
  }, []);

  useEffect(() => {
    setShowIntro(true);
  }, [snap.levelIndex]);

  const timed = snap.timeLimit !== undefined;
  const remain = timed ? (snap.timeLimit ?? 0) - snap.elapsed : 0;
  const urgent = timed && remain < 45;
  const doneCount = snap.objectives.filter((o) => o.done).length;

  return (
    <div className="pointer-events-none absolute inset-0 select-none">
      <div className="vignette absolute inset-0" />

      {/* ---------------- top left: level + clock ---------------- */}
      <div className="pointer-events-auto absolute left-3 top-3 flex flex-col gap-2">
        <Panel className="w-[268px]">
          <div className="flex items-start justify-between gap-2">
            <div>
              <div className="font-display ink-title text-[17px] font-bold leading-tight">{snap.levelName}</div>
              <div className="text-[11px] font-semibold uppercase tracking-wider opacity-60">{snap.levelSubtitle}</div>
            </div>
            <div className="chip shrink-0 px-2 py-0.5 text-[10px] font-extrabold uppercase tracking-wide">
              {snap.biomeName}
            </div>
          </div>
          <div className="mt-2 flex items-center gap-2">
            {timed ? (
              <div
                className={`font-display flex-1 rounded-lg border-2 px-2 py-1 text-center text-[19px] font-bold tabular-nums ${
                  urgent ? 'border-[#a33]/60 bg-[#f3c3b6] text-[#7a2418] pulse' : 'border-[#5a4a38]/40 bg-white/50'
                }`}
              >
                {fmt(remain)}
              </div>
            ) : (
              <div className="font-display flex-1 rounded-lg border-2 border-[#5a4a38]/40 bg-white/50 px-2 py-1 text-center text-[19px] font-bold tabular-nums">
                {fmt(snap.elapsed)}
              </div>
            )}
            <div className="rounded-lg border-2 border-[#5a4a38]/40 bg-white/50 px-2 py-1 text-center">
              <div className="text-[9px] font-extrabold uppercase tracking-wider opacity-60">Build pts</div>
              <div className="font-display text-[17px] font-bold leading-none">{snap.points}</div>
            </div>
          </div>
        </Panel>

        <Panel className="w-[268px]">
          <div className="flex items-center justify-between">
            <div className="text-[11px] font-extrabold uppercase tracking-wider opacity-70">Objectives</div>
            <div className="text-[11px] font-bold opacity-70">
              {doneCount}/{snap.objectives.length}
            </div>
          </div>
          <div className="mt-1.5 flex flex-col gap-1.5">
            {snap.objectives.map((o) => (
              <div key={o.id} className="flex items-center gap-2">
                <div
                  className={`flex h-[17px] w-[17px] shrink-0 items-center justify-center rounded-full border-2 text-[10px] font-black ${
                    o.done ? 'border-[#3f7f3a] bg-[#8fc45a] text-white' : 'border-[#5a4a38]/45 bg-white/55'
                  }`}
                  aria-hidden
                >
                  {o.done ? '✓' : ''}
                </div>
                <div className="min-w-0 flex-1">
                  <div className={`truncate text-[12px] font-bold ${o.done ? 'line-through opacity-55' : ''}`}>
                    {o.label}
                  </div>
                  <div className="bar mt-0.5 h-[5px]">
                    <span
                      style={{
                        width: `${Math.min(100, (o.have / o.target) * 100)}%`,
                        background: o.done ? '#6faa45' : 'linear-gradient(90deg,#e0b45a,#c98a4b)',
                      }}
                    />
                  </div>
                </div>
                <div className="w-11 shrink-0 text-right text-[11px] font-bold tabular-nums opacity-70">
                  {o.have}/{o.target}
                </div>
              </div>
            ))}
          </div>
        </Panel>
      </div>

      {/* ---------------- top right: resources ---------------- */}
      <div className="pointer-events-auto absolute right-3 top-3 flex flex-col items-end gap-2">
        <Panel className="w-[318px]">
          <div className="grid grid-cols-5 gap-1.5">
            {RESOURCES.map((r) => {
              const v = Math.floor(snap.resources[r]);
              const cap = snap.caps[r];
              const full = v >= cap - 0.5;
              return (
                <div
                  key={r}
                  className="rounded-lg border-2 border-[#5a4a38]/35 bg-white/45 px-1 py-1 text-center"
                  title={`${RESOURCE_META[r].label} — cap ${cap}`}
                >
                  <div className="text-[13px] leading-none" style={{ color: RESOURCE_META[r].color }}>
                    {RESOURCE_META[r].glyph}
                  </div>
                  <div className="font-display text-[15px] font-bold leading-tight tabular-nums">{v}</div>
                  <div className="text-[9px] font-bold opacity-50">/{cap}</div>
                  {full && <div className="text-[8px] font-black text-[#a33]">FULL</div>}
                </div>
              );
            })}
          </div>
          <div className="mt-2 flex items-center justify-between text-[11px] font-bold">
            <span className={snap.starving ? 'text-[#a33]' : 'opacity-70'}>
              {snap.starving ? '⚠ Crew is starving — work slowed' : 'Crew fed'}
            </span>
            <span className={snap.foodRate >= 0 ? 'text-[#3f7f3a]' : 'text-[#a33]'}>
              food {snap.foodRate >= 0 ? '+' : ''}
              {snap.foodRate.toFixed(2)}/s
            </span>
          </div>
          <div className="mt-1.5 flex items-center gap-2 text-[10px] font-bold opacity-70">
            <span className="chip px-1.5 py-[1px]">gather ×{snap.gatherSpeed.toFixed(2)}</span>
            <span className="chip px-1.5 py-[1px]">work ×{snap.workSpeed.toFixed(2)}</span>
            <span className="chip px-1.5 py-[1px]">crew {snap.workerCount}</span>
            <button
              className="btn ml-auto px-2 py-[2px] text-[10px] font-extrabold"
              onClick={() => setGuide((g) => !g)}
              aria-expanded={guide}
            >
              {guide ? 'Hide guide' : 'Field guide'}
            </button>
          </div>
          {guide && (
            <div className="mt-2 space-y-1 border-t border-[#5a4a38]/25 pt-2 text-[11px] leading-snug">
              <p>
                <b>Click anything</b> and the nearest idle worker walks over, works, then returns.
              </p>
              <p>
                <b>Click a queued task</b> to cancel it and get the materials back. Use ▲▼ to reorder.
              </p>
              <p>
                <b>Snow bonfires</b> must be lit with wood before the ice around them can be cleared.
              </p>
              <p>
                Repairing <b>bridges and stairs</b> opens new platforms with fresh nodes and build points.
              </p>
              <p>
                <b>Housing</b> wakes more workers — the task list grows from 3 to 5.
              </p>
            </div>
          )}
        </Panel>

        {/* buildings */}
        <Panel className="w-[318px]">
          <div className="text-[11px] font-extrabold uppercase tracking-wider opacity-70">Settlement</div>
          <div className="mt-1.5 grid grid-cols-2 gap-1.5">
            {(Object.keys(BUILDINGS) as BuildingType[]).map((t) => {
              const p = snap.plots.find((x) => x.type === t);
              const lvl = p?.level ?? 0;
              return (
                <div
                  key={t}
                  className="rounded-lg border-2 border-[#5a4a38]/35 bg-white/45 px-1.5 py-1"
                  title={BUILDINGS[t].effect}
                >
                  <div className="flex items-center justify-between">
                    <span className="truncate text-[11px] font-extrabold">{BUILDINGS[t].name}</span>
                    <span className="font-display text-[12px] font-bold">{lvl ? ['0', 'I', 'II', 'III'][lvl] : '—'}</span>
                  </div>
                  <div className="text-[9px] leading-tight opacity-60">{BUILDINGS[t].effect}</div>
                </div>
              );
            })}
          </div>
        </Panel>
      </div>

      {/* ---------------- bottom left: crew ---------------- */}
      <div className="pointer-events-auto absolute bottom-3 left-3">
        <Panel className="w-[228px]">
          <div className="text-[11px] font-extrabold uppercase tracking-wider opacity-70">
            Crew · {snap.workers.filter((w) => w.state === 'idle').length} idle
          </div>
          <div className="mt-1.5 flex flex-col gap-1">
            {snap.workers.map((w) => (
              <div key={w.id} className="flex items-center gap-2">
                <span
                  className="h-3 w-3 shrink-0 rounded-full border-2 border-[#5a4a38]/50"
                  style={{ background: w.color }}
                />
                <span className="w-12 shrink-0 text-[12px] font-extrabold">{w.name}</span>
                <span className="text-[10px] font-bold uppercase tracking-wide opacity-65">{w.state}</span>
              </div>
            ))}
          </div>
        </Panel>
      </div>

      {/* ---------------- bottom centre: task queue ---------------- */}
      <div className="pointer-events-auto absolute bottom-3 left-1/2 w-[430px] -translate-x-1/2">
        <Panel>
          <div className="flex items-center justify-between">
            <div className="text-[11px] font-extrabold uppercase tracking-wider opacity-70">Work order</div>
            <div className="text-[11px] font-bold opacity-70">
              {snap.tasks.length}/{snap.taskCap} slots
            </div>
          </div>
          {snap.tasks.length === 0 ? (
            <div className="py-2 text-center text-[12px] font-semibold italic opacity-55">
              Click a node, obstacle, bonfire, route or plot to send a worker.
            </div>
          ) : (
            <div className="scroll-thin mt-1.5 max-h-[172px] space-y-1 overflow-y-auto pr-1">
              {snap.tasks.map((t, i) => (
                <div
                  key={t.id}
                  className={`rise flex items-center gap-2 rounded-lg border-2 px-2 py-1.5 ${
                    t.state === 'pending'
                      ? 'border-[#5a4a38]/30 bg-white/45'
                      : 'border-[#3f7f9a]/50 bg-[#dcecf5]/70'
                  }`}
                >
                  <div className="flex flex-col gap-0.5">
                    <button
                      className="btn px-1.5 text-[10px] leading-none"
                      onClick={() => game?.moveTask(t.id, -1)}
                      disabled={i === 0 || !!t.workerId}
                      aria-label={`Move ${t.label} up`}
                    >
                      ▲
                    </button>
                    <button
                      className="btn px-1.5 text-[10px] leading-none"
                      onClick={() => game?.moveTask(t.id, 1)}
                      disabled={i === snap.tasks.length - 1 || !!t.workerId}
                      aria-label={`Move ${t.label} down`}
                    >
                      ▼
                    </button>
                  </div>
                  <button
                    className="min-w-0 flex-1 text-left"
                    onClick={() => game?.cancelTask(t.id)}
                    title="Cancel and refund"
                  >
                    <div className="flex items-center gap-1.5">
                      <span aria-hidden>{KIND_ICON[t.kind]}</span>
                      <span className="truncate text-[12.5px] font-extrabold">{t.label}</span>
                      <span className="ml-auto shrink-0 text-[10px] font-bold uppercase tracking-wide opacity-60">
                        {t.state}
                      </span>
                    </div>
                    <div className="mt-0.5 flex items-center gap-2">
                      <CostRow cost={t.cost} res={snap.resources} />
                      <span className="truncate text-[10px] opacity-60">{t.detail}</span>
                    </div>
                    {t.progress > 0 && (
                      <div className="bar mt-1 h-[5px]">
                        <span style={{ width: `${t.progress * 100}%`, background: '#3f8fbf' }} />
                      </div>
                    )}
                  </button>
                </div>
              ))}
            </div>
          )}
        </Panel>
      </div>

      {/* ---------------- hover tooltip ---------------- */}
      {snap.hover && (
        <div
          className="panel pointer-events-none absolute z-20 max-w-[260px] px-2.5 py-2"
          style={{
            left: Math.min(cursor.x + 16, window.innerWidth - 280),
            top: Math.min(cursor.y + 16, window.innerHeight - 130),
          }}
        >
          <div className="font-display text-[13px] font-bold leading-tight">{snap.hover.label}</div>
          <div className="text-[11px] leading-snug opacity-75">{snap.hover.detail}</div>
          <div className="mt-1.5 flex items-center gap-2">
            <CostRow cost={snap.hover.cost} res={snap.resources} />
            {snap.hover.blocked && <span className="text-[11px] font-bold text-[#a33]">{snap.hover.blocked}</span>}
          </div>
        </div>
      )}

      {/* ---------------- toast ---------------- */}
      {snap.toast && (
        <div key={snap.toast.id} className="pop absolute left-1/2 top-3 -translate-x-1/2">
          <div
            className={`panel px-3.5 py-1.5 text-[13px] font-extrabold ${
              snap.toast.tone === 'good'
                ? 'text-[#2f6b2a]'
                : snap.toast.tone === 'bad'
                  ? 'text-[#8f2a1a]'
                  : 'text-[#4a3a28]'
            }`}
          >
            {snap.toast.text}
          </div>
        </div>
      )}

      {/* ---------------- overlays ---------------- */}
      {showIntro && snap.status === 'playing' && (
        <div className="pointer-events-auto absolute inset-0 flex items-center justify-center bg-[#14100c]/55 backdrop-blur-[2px]">
          <div className="panel pop w-[520px] px-6 py-5">
            <div className="text-[11px] font-extrabold uppercase tracking-[0.2em] opacity-60">
              Wayforge · {snap.levelSubtitle}
            </div>
            <h1 className="font-display ink-title mt-1 text-[30px] font-bold leading-tight">{snap.levelName}</h1>
            <div className="chip mt-2 inline-block px-2 py-0.5 text-[11px] font-extrabold uppercase tracking-wide">
              Biome · {snap.biomeName}
            </div>
            <p className="mt-3 text-[13.5px] leading-relaxed">{LEVEL_INTRO[snap.levelIndex]}</p>
            <div className="mt-3 grid grid-cols-2 gap-2 text-[11.5px]">
              <div className="rounded-lg border-2 border-[#5a4a38]/30 bg-white/45 px-2 py-1.5">
                <b>Camera</b> — fixed isometric. No orbit, pan or zoom.
              </div>
              <div className="rounded-lg border-2 border-[#5a4a38]/30 bg-white/45 px-2 py-1.5">
                <b>Controls</b> — pointer only. Click to send a worker.
              </div>
              <div className="rounded-lg border-2 border-[#5a4a38]/30 bg-white/45 px-2 py-1.5">
                <b>Crew</b> — {snap.workerCount} workers, {snap.taskCap} task slots.
              </div>
              <div className="rounded-lg border-2 border-[#5a4a38]/30 bg-white/45 px-2 py-1.5">
                <b>{timed ? 'Timed level' : 'Untimed level'}</b> —{' '}
                {timed ? `${fmt(snap.timeLimit ?? 0)} on the clock` : 'take your time, no failure'}
              </div>
            </div>
            <div className="mt-3 flex flex-wrap gap-1.5">
              {snap.objectives.map((o) => (
                <span key={o.id} className="chip px-2 py-0.5 text-[11px] font-bold">
                  {o.label}
                </span>
              ))}
            </div>
            <button
              className="btn font-display mt-4 w-full py-2 text-[15px] font-bold"
              onClick={() => {
                setShowIntro(false);
                game?.resume();
              }}
              autoFocus
            >
              Begin the reclamation
            </button>
          </div>
        </div>
      )}

      {snap.status === 'clear' && (
        <div className="pointer-events-auto absolute inset-0 flex items-center justify-center bg-[#14100c]/60 backdrop-blur-[2px]">
          <div className="panel pop w-[460px] px-6 py-5 text-center">
            <div className="text-[11px] font-extrabold uppercase tracking-[0.2em] opacity-60">Level reclaimed</div>
            <h2 className="font-display ink-title mt-1 text-[28px] font-bold leading-tight">{snap.levelName}</h2>
            <div
              className="font-display mx-auto mt-3 flex h-[104px] w-[104px] flex-col items-center justify-center rounded-full border-[6px] text-[13px] font-bold"
              style={{ borderColor: MEDAL_META[snap.medal].ring, background: MEDAL_META[snap.medal].color }}
            >
              <span className="text-[26px] leading-none">★</span>
              {MEDAL_META[snap.medal].label}
            </div>
            <div className="mt-3 flex items-center justify-center gap-4 text-[13px] font-bold">
              <span>Time · {fmt(snap.elapsed)}</span>
              <span>Build pts · {snap.points}</span>
              <span>Nodes left · {snap.nodesLeft}</span>
            </div>
            <div className="mt-4 flex gap-2">
              <button className="btn flex-1 py-2 text-[14px] font-bold" onClick={onRestart}>
                Replay level
              </button>
              <button className="btn flex-1 py-2 text-[14px] font-bold" onClick={onNext}>
                {snap.levelIndex < 2 ? 'Next frontier →' : 'Return to Chapter I'}
              </button>
            </div>
          </div>
        </div>
      )}

      {snap.status === 'failed' && (
        <div className="pointer-events-auto absolute inset-0 flex items-center justify-center bg-[#1a0f0a]/65 backdrop-blur-[2px]">
          <div className="panel pop w-[420px] px-6 py-5 text-center">
            <div className="text-[11px] font-extrabold uppercase tracking-[0.2em] opacity-60">The light went out</div>
            <h2 className="font-display ink-title mt-1 text-[26px] font-bold leading-tight">Out of time</h2>
            <p className="mt-2 text-[13px] leading-relaxed">
              {doneCount} of {snap.objectives.length} objectives met. Untimed chapters cannot fail — this one was on the
              clock.
            </p>
            <button className="btn font-display mt-4 w-full py-2 text-[15px] font-bold" onClick={onRestart}>
              Retry {snap.levelName}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

const LEVEL_INTRO = [
  'Three wayfarers woke on the old terrace. Gather, clear, and mend the routes upward before the light goes.',
  'Snow has swallowed the old roads. Bonfires must burn before the ice can be broken — and the clock is running.',
  'The last ridge. Crystal runs deep here, the spire is far, and the light will not hold forever.',
];
