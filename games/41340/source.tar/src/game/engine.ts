import * as THREE from 'three';
import {
  BASE_CAPS,
  BUILDINGS,
  CAP_STEP,
  LINK_META,
  OBSTACLE_META,
  RESOURCE_META,
  RESOURCES,
  type Cost,
  type LevelDef,
  type Medal,
  type ObjectiveView,
  type ResourceKind,
  type Snapshot,
  type TaskKind,
  type TaskView,
  type Vec3,
} from './types';
import { LEVELS } from './levels';
import { buildWorld, type World } from './world';
import { buildBuilding } from './props';

const WORKER_NAMES = ['Bram', 'Odile', 'Pell', 'Sable', 'Tarn'];
const MOVE_SPEED = 3.4;
const BASE_DUR: Record<TaskKind, number> = {
  gather: 1.15,
  clear: 2.0,
  repair: 2.4,
  build: 2.2,
  upgrade: 1.9,
  fire: 0.9,
};

interface Task {
  id: string;
  kind: TaskKind;
  targetId: string;
  label: string;
  detail: string;
  cost: Cost;
  workerId: string | null;
  state: 'pending' | 'walking' | 'working' | 'returning';
  progress: number;
  blocked: string | null;
  spent: boolean;
}

interface Worker {
  id: string;
  name: string;
  color: string;
  pos: THREE.Vector3;
  path: Vec3[];
  pathIdx: number;
  state: 'idle' | 'walking' | 'working' | 'returning';
  taskId: string | null;
  workT: number;
  workDur: number;
  facing: number;
  phase: number;
}

export class Game {
  world: World;
  level: LevelDef;
  levelIndex: number;
  status: 'playing' | 'clear' | 'failed' = 'playing';
  paused = true;
  elapsed = 0;
  medal: Medal = 'none';

  resources: Record<ResourceKind, number> = { wood: 10, food: 16, gold: 0, stone: 4, crystal: 0 };
  gathered: Record<ResourceKind, number> = { wood: 0, food: 0, gold: 0, stone: 0, crystal: 0 };
  points = 0;
  cleared = 0;
  repaired = 0;
  litFires = 0;
  reached = new Set<string>();

  tasks: Task[] = [];
  workers: Worker[] = [];
  taskSeq = 0;

  private raycaster = new THREE.Raycaster();
  private pointer = new THREE.Vector2();
  private hoverId: string | null = null;
  private hoverRing: THREE.Mesh;
  private clock = new THREE.Clock();
  private lastEmit = 0;
  private toast: Snapshot['toast'] = null;
  private toastT = 0;
  private toastSeq = 0;
  private raf = 0;
  private disposed = false;

  constructor(
    private canvas: HTMLCanvasElement,
    levelIndex: number,
    private onState: (s: Snapshot) => void,
  ) {
    this.levelIndex = levelIndex;
    this.level = LEVELS[levelIndex];
    this.world = buildWorld(this.level, canvas);
    this.world.frame(canvas.clientWidth || 1280, canvas.clientHeight || 720);

    this.hoverRing = new THREE.Mesh(
      new THREE.RingGeometry(0.7, 0.95, 28),
      new THREE.MeshBasicMaterial({ color: 0xfff0c4, transparent: true, opacity: 0.75, side: THREE.DoubleSide, depthWrite: false }),
    );
    this.hoverRing.rotation.x = -Math.PI / 2;
    this.hoverRing.visible = false;
    this.world.scene.add(this.hoverRing);

    const home = this.level.home;
    for (let i = 0; i < 5; i++) {
      const a = (i / 5) * Math.PI * 2;
      this.workers.push({
        id: `w${i}`,
        name: WORKER_NAMES[i],
        color: ['#e0603c', '#3f8fbf', '#e8b93c', '#8a63c9', '#4fae7a'][i],
        pos: new THREE.Vector3(home.x + Math.cos(a) * 1.6, home.y, home.z + Math.sin(a) * 1.6),
        path: [],
        pathIdx: 0,
        state: 'idle',
        taskId: null,
        workT: 0,
        workDur: 0,
        facing: a,
        phase: i * 1.3,
      });
    }

    canvas.addEventListener('pointerdown', this.onDown);
    canvas.addEventListener('pointermove', this.onMove);
    canvas.addEventListener('pointerleave', this.onLeave);
    this.loop();
  }

  /* ------------------------------------------------------------ *
   * Derived economy values
   * ------------------------------------------------------------ */
  levelOf(type: keyof typeof BUILDINGS) {
    let best = 0;
    for (const p of this.world.plots.values()) {
      if (p.def.type === type && p.built) best = Math.max(best, p.level);
    }
    return best;
  }

  get workerCount() {
    return Math.min(5, 3 + this.levelOf('housing'));
  }

  get caps(): Record<ResourceKind, number> {
    const w = this.levelOf('warehouse');
    const out = {} as Record<ResourceKind, number>;
    for (const r of RESOURCES) out[r] = BASE_CAPS[r] + CAP_STEP[r] * w;
    return out;
  }

  get gatherSpeed() {
    return 1 + 0.15 * this.levelOf('mill') + 0.05 * this.levelOf('well');
  }

  get workSpeed() {
    return 1 + 0.18 * this.levelOf('blacksmith');
  }

  get starving() {
    return this.resources.food <= 0.01;
  }

  get foodRate() {
    const farm = 0.14 * this.levelOf('farm');
    const drain = 0.055 * this.workerCount * (1 - 0.12 * this.levelOf('well'));
    return farm - drain;
  }

  /* ------------------------------------------------------------ *
   * Pointer input — the only control surface
   * ------------------------------------------------------------ */
  private setPointer(ev: PointerEvent) {
    const r = this.canvas.getBoundingClientRect();
    this.pointer.set(((ev.clientX - r.left) / r.width) * 2 - 1, -((ev.clientY - r.top) / r.height) * 2 + 1);
  }

  private pick(): string | null {
    this.raycaster.setFromCamera(this.pointer, this.world.camera);
    const hits = this.raycaster.intersectObjects(this.world.pickables, false);
    for (const h of hits) {
      let o: THREE.Object3D | null = h.object;
      let vis = true;
      while (o) {
        if (!o.visible) {
          vis = false;
          break;
        }
        o = o.parent;
      }
      if (!vis) continue;
      const id = h.object.userData.pickId as string | undefined;
      if (id && this.isLive(id)) return id;
    }
    return null;
  }

  private isLive(id: string) {
    if (this.world.nodes.has(id)) return this.world.nodes.get(id)!.amount > 0;
    if (this.world.obstacles.has(id)) return !this.world.obstacles.get(id)!.cleared;
    if (this.world.links.has(id)) return !this.world.links.get(id)!.repaired;
    if (this.world.fires.has(id)) return !this.world.fires.get(id)!.lit;
    if (this.world.plots.has(id)) return true;
    return false;
  }

  private onDown = (ev: PointerEvent) => {
    if (this.status !== 'playing' || this.paused) return;
    this.setPointer(ev);
    const id = this.pick();
    if (id) this.request(id);
  };

  private onMove = (ev: PointerEvent) => {
    this.setPointer(ev);
    this.hoverId = this.pick();
  };

  private onLeave = () => {
    this.hoverId = null;
  };

  /* ------------------------------------------------------------ *
   * Description / affordability
   * ------------------------------------------------------------ */
  describe(id: string) {
    const node = this.world.nodes.get(id);
    if (node) {
      const m = RESOURCE_META[node.def.kind];
      return {
        kind: 'gather' as TaskKind,
        label: `${m.label} node`,
        detail: `+${node.def.perTrip} ${m.label.toLowerCase()} · ${node.amount} left`,
        cost: {} as Cost,
        blocked: null as string | null,
      };
    }
    const ob = this.world.obstacles.get(id);
    if (ob) {
      const need = ob.def.needsFire;
      const blocked = need && !this.world.fires.get(need)!.lit ? `Needs bonfire ${need.toUpperCase()} lit` : null;
      return {
        kind: 'clear' as TaskKind,
        label: OBSTACLE_META[ob.def.kind].label,
        detail: `Clear · +${ob.def.points} build points`,
        cost: ob.def.cost,
        blocked,
      };
    }
    const fire = this.world.fires.get(id);
    if (fire) {
      return {
        kind: 'fire' as TaskKind,
        label: 'Snow bonfire',
        detail: 'Light it to break the ice around it',
        cost: fire.def.cost,
        blocked: null,
      };
    }
    const link = this.world.links.get(id);
    if (link) {
      return {
        kind: 'repair' as TaskKind,
        label: LINK_META[link.def.kind].label,
        detail: `Rebuild · +${link.def.points} build points · opens ${this.platformName(link.def.b)}`,
        cost: link.def.cost,
        blocked: null,
      };
    }
    const plot = this.world.plots.get(id);
    if (plot) {
      const spec = BUILDINGS[plot.def.type];
      if (!plot.built) {
        return {
          kind: 'build' as TaskKind,
          label: `Build ${spec.name}`,
          detail: `${spec.effect} · +${spec.points} build points`,
          cost: spec.build,
          blocked: null,
        };
      }
      const up = spec.upgrades[plot.level - 1];
      if (!up) {
        return {
          kind: 'upgrade' as TaskKind,
          label: `${spec.name} ${roman(plot.level)}`,
          detail: 'Fully upgraded',
          cost: {} as Cost,
          blocked: 'Fully upgraded',
        };
      }
      return {
        kind: 'upgrade' as TaskKind,
        label: `Upgrade ${spec.name} → ${roman(plot.level + 1)}`,
        detail: `${up.label} · ${spec.effect}`,
        cost: up.cost,
        blocked: null,
      };
    }
    return null;
  }

  private platformName(id: string) {
    return this.level.platforms.find((p) => p.id === id)?.name ?? id;
  }

  private affordable(cost: Cost) {
    return RESOURCES.every((r) => (cost[r] ?? 0) <= this.resources[r] + 1e-6);
  }

  /* ------------------------------------------------------------ *
   * Task queue
   * ------------------------------------------------------------ */
  request(id: string) {
    if (this.status !== 'playing') return;
    const d = this.describe(id);
    if (!d) return;
    if (d.blocked) {
      this.say(d.blocked, 'bad');
      return;
    }
    if ((d.kind === 'build' || d.kind === 'upgrade') && Object.keys(d.cost).length === 0) {
      this.say('Nothing left to do there', 'info');
      return;
    }
    if (this.tasks.some((t) => t.targetId === id)) {
      this.say('Already on the list', 'info');
      return;
    }
    if (this.tasks.length >= this.workerCount) {
      this.say(`Task list full (${this.workerCount}) — build housing for more`, 'bad');
      return;
    }
    if (!this.affordable(d.cost)) {
      this.say('Not enough materials', 'bad');
      return;
    }
    for (const r of RESOURCES) this.resources[r] -= d.cost[r] ?? 0;
    this.tasks.push({
      id: `t${++this.taskSeq}`,
      kind: d.kind,
      targetId: id,
      label: d.label,
      detail: d.detail,
      cost: d.cost,
      workerId: null,
      state: 'pending',
      progress: 0,
      blocked: null,
      spent: true,
    });
    this.assign();
    this.emit(true);
  }

  cancelTask(id: string) {
    const i = this.tasks.findIndex((t) => t.id === id);
    if (i < 0) return;
    const t = this.tasks[i];
    if (t.workerId) {
      const w = this.workers.find((x) => x.id === t.workerId);
      if (w) {
        w.taskId = null;
        w.workT = 0;
        this.sendHome(w);
      }
    }
    if (t.spent) for (const r of RESOURCES) this.resources[r] = Math.min(this.caps[r], this.resources[r] + (t.cost[r] ?? 0));
    t.spent = false;
    this.tasks.splice(i, 1);
    this.say(`${t.label} cancelled — materials refunded`, 'info');
    this.assign();
    this.emit(true);
  }

  moveTask(id: string, dir: -1 | 1) {
    const i = this.tasks.findIndex((t) => t.id === id);
    const j = i + dir;
    if (i < 0 || j < 0 || j >= this.tasks.length) return;
    const a = this.tasks[i];
    if (a.workerId) {
      this.say('That worker is already on the move', 'info');
      return;
    }
    this.tasks[i] = this.tasks[j];
    this.tasks[j] = a;
    this.emit(true);
  }

  private assign() {
    for (const t of this.tasks) {
      if (t.workerId) continue;
      const target = this.targetPos(t.targetId);
      if (!target) continue;
      let best: Worker | null = null;
      let bestD = Infinity;
      for (const w of this.workers) {
        if (w.id >= `w${this.workerCount}`) continue;
        if (w.state !== 'idle') continue;
        const d = w.pos.distanceToSquared(target);
        if (d < bestD) {
          bestD = d;
          best = w;
        }
      }
      if (!best) continue;
      const path = this.world.nav.findPath({ x: best.pos.x, y: best.pos.y, z: best.pos.z }, target);
      if (!path) {
        t.blocked = 'No route yet — repair a bridge or stairs';
        this.say(t.blocked, 'bad');
        continue;
      }
      t.workerId = best.id;
      t.state = 'walking';
      t.blocked = null;
      best.taskId = t.id;
      best.state = 'walking';
      best.path = path;
      best.pathIdx = 0;
    }
  }

  private targetPos(id: string): Vec3 | null {
    const n = this.world.nodes.get(id);
    if (n) return { x: n.def.x, y: n.def.y, z: n.def.z };
    const o = this.world.obstacles.get(id);
    if (o) return { x: o.def.x, y: o.def.y, z: o.def.z };
    const f = this.world.fires.get(id);
    if (f) return { x: f.def.x, y: f.def.y, z: f.def.z };
    const l = this.world.links.get(id);
    if (l) {
      const p = this.level.platforms.find((p) => p.id === l.def.a);
      if (p) return { x: l.def.aPoint.x, y: p.y, z: l.def.aPoint.z };
    }
    const p = this.world.plots.get(id);
    if (p) return { x: p.def.x, y: p.def.y, z: p.def.z };
    return null;
  }

  private sendHome(w: Worker) {
    const home = this.level.home;
    const a = (this.workers.indexOf(w) / 5) * Math.PI * 2;
    const dest = { x: home.x + Math.cos(a) * 1.6, y: home.y, z: home.z + Math.sin(a) * 1.6 };
    const path = this.world.nav.findPath({ x: w.pos.x, y: w.pos.y, z: w.pos.z }, dest);
    w.state = 'returning';
    w.path = path ?? [dest];
    w.pathIdx = 0;
  }

  /* ------------------------------------------------------------ *
   * Completion
   * ------------------------------------------------------------ */
  private complete(t: Task) {
    const w = this.workers.find((x) => x.id === t.workerId);
    switch (t.kind) {
      case 'gather': {
        const n = this.world.nodes.get(t.targetId);
        if (!n) break;
        const take = Math.min(n.amount, n.def.perTrip);
        n.amount -= take;
        const cap = this.caps[n.def.kind];
        this.resources[n.def.kind] = Math.min(cap, this.resources[n.def.kind] + take);
        this.gathered[n.def.kind] += take;
        if (n.amount <= 0) {
          n.group.visible = false;
          this.world.pickables = this.world.pickables.filter((o) => o.userData.pickId !== n.def.id);
          this.say(`${RESOURCE_META[n.def.kind].label} node exhausted`, 'info');
        }
        break;
      }
      case 'clear': {
        const o = this.world.obstacles.get(t.targetId);
        if (!o) break;
        o.cleared = true;
        o.group.visible = false;
        this.world.pickables = this.world.pickables.filter((x) => x.userData.pickId !== o.def.id);
        const c = this.world.nav.at(o.def.x, o.def.y, o.def.z);
        if (c) this.world.nav.blocked.delete(`${c.ix}|${c.iy}|${c.iz}`);
        this.points += o.def.points;
        this.cleared++;
        this.say(`${OBSTACLE_META[o.def.kind].label} cleared · +${o.def.points} pts`, 'good');
        break;
      }
      case 'repair': {
        const l = this.world.links.get(t.targetId);
        if (!l) break;
        l.repaired = true;
        l.rig.fixed.visible = true;
        l.rig.broken.visible = false;
        this.world.pickables = this.world.pickables.filter((x) => x.userData.pickId !== l.def.id);
        this.world.nav.ramp(l.def.aPoint, l.def.bPoint, l.def.id, 0.7);
        this.points += l.def.points;
        this.repaired++;
        this.say(`${LINK_META[l.def.kind].label} rebuilt · +${l.def.points} pts`, 'good');
        break;
      }
      case 'fire': {
        const f = this.world.fires.get(t.targetId);
        if (!f) break;
        f.lit = true;
        f.rig.flame.visible = true;
        this.world.pickables = this.world.pickables.filter((x) => x.userData.pickId !== f.def.id);
        this.litFires++;
        this.say('Bonfire lit — the ice around it can be broken', 'good');
        break;
      }
      case 'build': {
        const p = this.world.plots.get(t.targetId);
        if (!p) break;
        p.built = true;
        p.level = 1;
        p.marker.visible = false;
        p.mesh = buildBuilding(p.def.type, 1, this.world.pal, hash(p.def.id));
        p.mesh.position.set(p.def.x, p.def.y, p.def.z);
        p.mesh.rotation.y = p.def.rot ?? 0;
        p.mesh.traverse((o) => {
          if ((o as THREE.Mesh).isMesh) {
            o.userData.pickId = p.def.id;
            this.world.pickables.push(o);
          }
        });
        this.world.scene.add(p.mesh);
        this.points += BUILDINGS[p.def.type].points;
        this.say(`${BUILDINGS[p.def.type].name} raised · +${BUILDINGS[p.def.type].points} pts`, 'good');
        break;
      }
      case 'upgrade': {
        const p = this.world.plots.get(t.targetId);
        if (!p) break;
        const spec = BUILDINGS[p.def.type];
        const up = spec.upgrades[p.level - 1];
        if (!up) break;
        p.level++;
        if (p.mesh) {
          p.mesh.visible = false;
          this.world.scene.remove(p.mesh);
        }
        p.mesh = buildBuilding(p.def.type, p.level, this.world.pal, hash(p.def.id));
        p.mesh.position.set(p.def.x, p.def.y, p.def.z);
        p.mesh.rotation.y = p.def.rot ?? 0;
        p.mesh.traverse((o) => {
          if ((o as THREE.Mesh).isMesh) {
            o.userData.pickId = p.def.id;
            this.world.pickables.push(o);
          }
        });
        this.world.scene.add(p.mesh);
        this.points += up.points;
        this.say(`${spec.name} → ${roman(p.level)} · +${up.points} pts`, 'good');
        break;
      }
    }
    if (w) this.sendHome(w);
    this.tasks = this.tasks.filter((x) => x.id !== t.id);
    this.assign();
  }

  /* ------------------------------------------------------------ *
   * Simulation
   * ------------------------------------------------------------ */
  private updateWorkers(dt: number) {
    const speedMul = this.starving ? 0.6 : 1;
    for (const w of this.workers) {
      const rig = this.world.workers.get(w.id)!;
      rig.group.visible = w.id < `w${this.workerCount}`;
      if (!rig.group.visible) continue;

      if (w.state === 'walking' || w.state === 'returning') {
        const target = w.path[w.pathIdx];
        if (!target) {
          if (w.state === 'returning') {
            w.state = 'idle';
            this.assign();
          } else {
            const t = this.tasks.find((x) => x.id === w.taskId);
            if (t) {
              t.state = 'working';
              w.state = 'working';
              w.workT = 0;
              const dur = BASE_DUR[t.kind];
              w.workDur = t.kind === 'gather' ? dur / this.gatherSpeed : dur / this.workSpeed;
              w.workDur /= speedMul;
            }
          }
          continue;
        }
        const dx = target.x - w.pos.x;
        const dz = target.z - w.pos.z;
        const dist = Math.hypot(dx, dz);
        const step = MOVE_SPEED * speedMul * dt;
        if (dist <= step) {
          w.pos.set(target.x, target.y, target.z);
          w.pathIdx++;
        } else {
          w.pos.x += (dx / dist) * step;
          w.pos.z += (dz / dist) * step;
          w.pos.y += (target.y - w.pos.y) * Math.min(1, dt * 8);
          w.facing = Math.atan2(dx, dz);
        }
      } else if (w.state === 'working') {
        const t = this.tasks.find((x) => x.id === w.taskId);
        if (!t) {
          w.state = 'idle';
          continue;
        }
        w.workT += dt * speedMul;
        t.progress = Math.min(1, w.workT / w.workDur);
        if (w.workT >= w.workDur) {
          t.state = 'working';
          this.complete(t);
        }
      }

      rig.group.position.copy(w.pos);
      const moving = w.state === 'walking' || w.state === 'returning';
      w.phase += dt * (moving ? 11 : 2.2);
      const bob = moving ? Math.abs(Math.sin(w.phase)) * 0.09 : Math.sin(w.phase) * 0.02;
      rig.group.position.y += bob;
      rig.group.rotation.y = w.facing;
      const swing = moving ? Math.sin(w.phase) * 0.5 : 0;
      rig.legL.rotation.x = swing;
      rig.legR.rotation.x = -swing;
      rig.armL.rotation.x = -swing * 0.8;
      if (w.state === 'working') {
        const s = Math.sin(w.phase * 2.4);
        rig.armR.rotation.x = -1.1 + s * 0.7;
        rig.tool.rotation.z = -0.5 + s * 0.9;
        rig.body.rotation.x = 0.12 + s * 0.06;
      } else {
        rig.armR.rotation.x = swing * 0.8;
        rig.tool.rotation.z = -0.5;
        rig.body.rotation.x = 0;
      }
      rig.ring.visible = w.state === 'idle';
      if (rig.ring.visible) {
        const m = rig.ring.material as THREE.MeshBasicMaterial;
        m.opacity = 0.25 + Math.sin(w.phase * 1.4) * 0.12;
      }

      // platform reach tracking
      for (const p of this.level.platforms) {
        if (
          Math.abs(w.pos.x - p.x) <= p.w / 2 &&
          Math.abs(w.pos.z - p.z) <= p.d / 2 &&
          Math.abs(w.pos.y - p.y) < 0.9
        ) {
          this.reached.add(p.id);
        }
      }
    }
  }

  private objectives(): ObjectiveView[] {
    return this.level.objectives.map((o) => {
      let have = 0;
      if (o.kind === 'gather') have = this.gathered[o.resource!];
      else if (o.kind === 'clear') have = this.cleared;
      else if (o.kind === 'repair') have = this.repaired;
      else if (o.kind === 'fire') have = this.litFires;
      else if (o.kind === 'build') have = [...this.world.plots.values()].filter((p) => p.def.type === o.building && p.built).length;
      else if (o.kind === 'upgrade') have = this.levelOf(o.building!);
      else if (o.kind === 'reach') have = this.reached.has(o.platform!) ? 1 : 0;
      return { id: o.id, label: o.label, have: Math.min(have, o.target), target: o.target, done: have >= o.target };
    });
  }

  private checkEnd() {
    if (this.status !== 'playing') return;
    const objs = this.objectives();
    if (objs.every((o) => o.done)) {
      this.status = 'clear';
      const [g, s, br] = this.level.par;
      this.medal = this.elapsed <= g ? 'gold' : this.elapsed <= s ? 'silver' : this.elapsed <= br ? 'bronze' : 'none';
      this.emit(true);
      return;
    }
    if (this.level.timeLimit && this.elapsed >= this.level.timeLimit) {
      this.status = 'failed';
      this.emit(true);
    }
  }

  /* ------------------------------------------------------------ *
   * Loop
   * ------------------------------------------------------------ */
  private loop = () => {
    if (this.disposed) return;
    this.raf = requestAnimationFrame(this.loop);
    const dt = Math.min(0.05, this.clock.getDelta());
    const t = this.clock.elapsedTime;

    if (this.status === 'playing' && !this.paused) {
      this.elapsed += dt;
      const cap = this.caps.food;
      this.resources.food = Math.max(0, Math.min(cap, this.resources.food + this.foodRate * dt));
      this.updateWorkers(dt);
      this.checkEnd();
    }

    // flames
    for (const f of this.world.fires.values()) {
      if (!f.lit) continue;
      const s = 1 + Math.sin(t * 9) * 0.12 + Math.sin(t * 17.3) * 0.06;
      f.rig.flame.scale.set(s, 1 + (s - 1) * 1.6, s);
      f.rig.flame.rotation.y = t * 1.6;
      f.rig.light.intensity = 7 + Math.sin(t * 11) * 2.2;
      (f.rig.glow.material as THREE.SpriteMaterial).opacity = 0.45 + Math.sin(t * 8) * 0.1;
    }

    // mill wheel + well bucket
    for (const p of this.world.plots.values()) {
      if (!p.mesh) continue;
      const spin = p.mesh.getObjectByName('spin');
      if (spin) spin.rotation.z = t * (p.def.type === 'mill' ? 1.1 : 0);
      const bob = p.mesh.getObjectByName('bob');
      if (bob) bob.position.y = 1.5 + Math.sin(t * 1.6) * 0.18;
    }

    // weather
    if (this.world.snow) {
      const pos = this.world.snow.geometry.getAttribute('position');
      const arr = pos.array as Float32Array;
      for (let i = 0; i < arr.length; i += 3) {
        arr[i + 1] -= dt * (1.6 + (i % 7) * 0.22);
        arr[i] += Math.sin(t * 0.7 + i) * dt * 0.5;
        if (arr[i + 1] < -12) arr[i + 1] = 16;
      }
      pos.needsUpdate = true;
    } else if (this.world.motes) {
      const pos = this.world.motes.geometry.getAttribute('position');
      const arr = pos.array as Float32Array;
      for (let i = 0; i < arr.length; i += 3) {
        arr[i + 1] += dt * 0.35;
        arr[i] += Math.sin(t * 0.5 + i * 0.3) * dt * 0.4;
        if (arr[i + 1] > 16) arr[i + 1] = -8;
      }
      pos.needsUpdate = true;
    }

    // hover ring
    if (this.hoverId && this.isLive(this.hoverId)) {
      const p = this.targetPos(this.hoverId);
      if (p) {
        this.hoverRing.visible = true;
        this.hoverRing.position.set(p.x, p.y + 0.06, p.z);
        const m = this.hoverRing.material as THREE.MeshBasicMaterial;
        m.opacity = 0.5 + Math.sin(t * 5) * 0.2;
        this.hoverRing.scale.setScalar(1.1 + Math.sin(t * 5) * 0.06);
      }
    } else {
      this.hoverRing.visible = false;
    }

    this.world.renderer.render(this.world.scene, this.world.camera);

    if (this.toast) {
      this.toastT -= dt;
      if (this.toastT <= 0) this.toast = null;
    }
    if (t - this.lastEmit > 0.1) this.emit(false);
  };

  private say(text: string, tone: 'good' | 'bad' | 'info') {
    this.toast = { id: ++this.toastSeq, text, tone };
    this.toastT = 3.2;
  }

  /* ------------------------------------------------------------ *
   * Snapshot for React
   * ------------------------------------------------------------ */
  private emit(force: boolean) {
    if (!force && this.clock.elapsedTime - this.lastEmit < 0.1) return;
    this.lastEmit = this.clock.elapsedTime;
    const caps = this.caps;
    const tasks: TaskView[] = this.tasks.map((t) => ({
      id: t.id,
      kind: t.kind,
      label: t.label,
      detail: t.detail,
      cost: t.cost,
      workerId: t.workerId,
      state: t.workerId ? t.state : 'pending',
      progress: t.progress,
      blocked: t.blocked,
    }));
    const hoverId = this.hoverId;
    const hd = hoverId ? this.describe(hoverId) : null;
    this.onState({
      levelIndex: this.levelIndex,
      levelName: this.level.name,
      levelSubtitle: this.level.subtitle,
      biomeName: this.level.biome.name,
      status: this.status,
      elapsed: this.elapsed,
      timeLimit: this.level.timeLimit,
      medal: this.medal,
      resources: { ...this.resources },
      caps,
      points: this.points,
      foodRate: this.foodRate,
      workers: this.workers
        .filter((w) => w.id < `w${this.workerCount}`)
        .map((w) => ({
          id: w.id,
          name: w.name,
          color: w.color,
          state: w.state,
          taskId: w.taskId,
        })),
      workerCount: this.workerCount,
      tasks,
      taskCap: this.workerCount,
      objectives: this.objectives(),
      plots: [...this.world.plots.values()].map((p) => ({ id: p.def.id, type: p.def.type, built: p.built, level: p.level })),
      gatherSpeed: this.gatherSpeed,
      workSpeed: this.workSpeed,
      starving: this.starving,
      toast: this.toast,
      hover: hd
        ? {
            label: hd.label,
            detail: hd.detail,
            cost: hd.cost,
            affordable: this.affordable(hd.cost),
            blocked: hd.blocked,
          }
        : null,
      nodesLeft: [...this.world.nodes.values()].filter((n) => n.amount > 0).length,
    });
  }

  resume() {
    this.paused = false;
  }

  resize(w: number, h: number) {
    this.world.renderer.setSize(w, h, false);
    this.world.frame(w, h);
  }

  dispose() {
    this.disposed = true;
    cancelAnimationFrame(this.raf);
    this.canvas.removeEventListener('pointerdown', this.onDown);
    this.canvas.removeEventListener('pointermove', this.onMove);
    this.canvas.removeEventListener('pointerleave', this.onLeave);
    this.world.dispose();
  }
}

function roman(n: number) {
  return ['0', 'I', 'II', 'III'][n] ?? String(n);
}

function hash(s: string) {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return Math.abs(h) % 100000;
}

export { LEVELS };
