import * as THREE from 'three';

/* ------------------------------------------------------------------ *
 * Deterministic noise helpers
 * ------------------------------------------------------------------ */
export function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function makeCanvas(size: number) {
  const c = document.createElement('canvas');
  c.width = size;
  c.height = size;
  return c;
}

function finish(c: HTMLCanvasElement, repeat = 1) {
  const t = new THREE.CanvasTexture(c);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.colorSpace = THREE.SRGBColorSpace;
  t.repeat.set(repeat, repeat);
  t.anisotropy = 4;
  return t;
}

/* ------------------------------------------------------------------ *
 * Hand-painted procedural textures
 * ------------------------------------------------------------------ */
export function paintTexture(
  base: string,
  dark: string,
  light: string,
  seed: number,
  opts: { patches?: number; strokes?: number; speck?: number; strokeLen?: number } = {},
) {
  const size = 256;
  const c = makeCanvas(size);
  const g = c.getContext('2d')!;
  const rnd = mulberry32(seed);
  const patches = opts.patches ?? 26;
  const strokes = opts.strokes ?? 220;
  const speck = opts.speck ?? 420;
  const strokeLen = opts.strokeLen ?? 26;

  g.fillStyle = base;
  g.fillRect(0, 0, size, size);

  for (let i = 0; i < patches; i++) {
    const x = rnd() * size;
    const y = rnd() * size;
    const r = 16 + rnd() * 48;
    g.globalAlpha = 0.08 + rnd() * 0.14;
    g.fillStyle = rnd() > 0.5 ? dark : light;
    g.beginPath();
    g.ellipse(x, y, r, r * (0.45 + rnd() * 0.7), rnd() * Math.PI, 0, Math.PI * 2);
    g.fill();
  }

  g.lineCap = 'round';
  for (let i = 0; i < strokes; i++) {
    const x = rnd() * size;
    const y = rnd() * size;
    const len = 6 + rnd() * strokeLen;
    const ang = rnd() * Math.PI;
    g.globalAlpha = 0.05 + rnd() * 0.17;
    g.strokeStyle = rnd() > 0.45 ? light : dark;
    g.lineWidth = 1.4 + rnd() * 3.6;
    g.beginPath();
    g.moveTo(x, y);
    g.lineTo(x + Math.cos(ang) * len, y + Math.sin(ang) * len);
    g.stroke();
  }

  for (let i = 0; i < speck; i++) {
    g.globalAlpha = 0.04 + rnd() * 0.2;
    g.fillStyle = rnd() > 0.5 ? light : dark;
    g.fillRect(rnd() * size, rnd() * size, 1 + rnd() * 2.2, 1 + rnd() * 2.2);
  }
  g.globalAlpha = 1;
  return finish(c);
}

/** Vertical wood grain — used for logs, planks, crates. */
export function woodTexture(base: string, dark: string, light: string, seed: number) {
  const size = 256;
  const c = makeCanvas(size);
  const g = c.getContext('2d')!;
  const rnd = mulberry32(seed);
  g.fillStyle = base;
  g.fillRect(0, 0, size, size);
  for (let i = 0; i < 70; i++) {
    const x = rnd() * size;
    g.globalAlpha = 0.06 + rnd() * 0.22;
    g.strokeStyle = rnd() > 0.5 ? dark : light;
    g.lineWidth = 1 + rnd() * 5;
    g.beginPath();
    g.moveTo(x, 0);
    let cx = x;
    for (let y = 0; y <= size; y += 16) {
      cx += (rnd() - 0.5) * 5;
      g.lineTo(cx, y);
    }
    g.stroke();
  }
  for (let i = 0; i < 160; i++) {
    g.globalAlpha = 0.05 + rnd() * 0.18;
    g.fillStyle = rnd() > 0.5 ? light : dark;
    g.fillRect(rnd() * size, rnd() * size, 1 + rnd() * 3, 1 + rnd() * 1.5);
  }
  g.globalAlpha = 1;
  return finish(c);
}

export function skyTexture(top: string, bottom: string) {
  const c = makeCanvas(128);
  const g = c.getContext('2d')!;
  const grad = g.createLinearGradient(0, 0, 0, 128);
  grad.addColorStop(0, top);
  grad.addColorStop(0.62, bottom);
  grad.addColorStop(1, bottom);
  g.fillStyle = grad;
  g.fillRect(0, 0, 128, 128);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

export function glowTexture() {
  const c = makeCanvas(128);
  const g = c.getContext('2d')!;
  const grad = g.createRadialGradient(64, 64, 0, 64, 64, 64);
  grad.addColorStop(0, 'rgba(255,255,255,1)');
  grad.addColorStop(0.35, 'rgba(255,255,255,0.55)');
  grad.addColorStop(1, 'rgba(255,255,255,0)');
  g.fillStyle = grad;
  g.fillRect(0, 0, 128, 128);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

/* ------------------------------------------------------------------ *
 * Toon banding
 * ------------------------------------------------------------------ */
let gradient: THREE.DataTexture | null = null;
export function toonGradient() {
  if (gradient) return gradient;
  const steps = new Uint8Array([70, 132, 196, 255]);
  const t = new THREE.DataTexture(steps, steps.length, 1, THREE.RedFormat);
  t.minFilter = THREE.NearestFilter;
  t.magFilter = THREE.NearestFilter;
  t.generateMipmaps = false;
  t.needsUpdate = true;
  gradient = t;
  return t;
}

export interface ToonOpts {
  map?: THREE.Texture | null;
  emissive?: THREE.ColorRepresentation;
  emissiveIntensity?: number;
  flat?: boolean;
  transparent?: boolean;
  opacity?: number;
}

export function toonMat(color: THREE.ColorRepresentation, o: ToonOpts = {}) {
  const m = new THREE.MeshToonMaterial({
    color,
    map: o.map ?? null,
    gradientMap: toonGradient(),
    emissive: o.emissive ?? 0x000000,
    emissiveIntensity: o.emissiveIntensity ?? 1,
    transparent: o.transparent ?? false,
    opacity: o.opacity ?? 1,
  });
  if (o.flat) (m as unknown as { flatShading: boolean }).flatShading = true;
  return m;
}

export const INK = 0x2c2318;

/** Inverted-hull outline: the cheap, chunky hand-inked rim. */
export function outline(mesh: THREE.Mesh, scale = 1.045, color: THREE.ColorRepresentation = INK) {
  const m = new THREE.Mesh(
    mesh.geometry,
    new THREE.MeshBasicMaterial({ color, side: THREE.BackSide }),
  );
  m.scale.setScalar(scale);
  m.renderOrder = -2;
  mesh.add(m);
  return m;
}

/** Hand-drawn edge ink. */
export function edgeInk(geo: THREE.BufferGeometry, color: THREE.ColorRepresentation = INK, opacity = 0.32) {
  return new THREE.LineSegments(
    new THREE.EdgesGeometry(geo, 24),
    new THREE.LineBasicMaterial({ color, transparent: true, opacity, depthWrite: false }),
  );
}

/** Nudge vertices so boxes read as hand-drawn rather than CAD-perfect. */
export function wobble(geo: THREE.BufferGeometry, amount: number, seed: number) {
  const pos = geo.getAttribute('position');
  const rnd = mulberry32(seed);
  const seen = new Map<string, [number, number, number]>();
  for (let i = 0; i < pos.count; i++) {
    const x = pos.getX(i);
    const y = pos.getY(i);
    const z = pos.getZ(i);
    const k = `${x.toFixed(3)},${y.toFixed(3)},${z.toFixed(3)}`;
    let d = seen.get(k);
    if (!d) {
      d = [(rnd() - 0.5) * amount, (rnd() - 0.5) * amount, (rnd() - 0.5) * amount];
      seen.set(k, d);
    }
    pos.setXYZ(i, x + d[0], y + d[1], z + d[2]);
  }
  pos.needsUpdate = true;
  geo.computeVertexNormals();
  return geo;
}
