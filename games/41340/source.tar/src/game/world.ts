import * as THREE from 'three';
import type { LevelDef, NodeDef, ObstacleDef, FireDef, PlotDef, LinkDef } from './types';
import { INK, edgeInk, glowTexture, mulberry32, paintTexture, skyTexture, toonMat, wobble } from './art';
import { NavGrid } from './nav';
import {
  buildBonfire,
  buildBush,
  buildLink,
  buildNode,
  buildObstacle,
  buildPlotMarker,
  buildRock,
  buildTree,
  buildWorker,
  makePal,
  type FireRig,
  type LinkRig,
  type Pal,
  type WorkerRig,
} from './props';

export interface NodeInst {
  def: NodeDef;
  group: THREE.Group;
  amount: number;
}
export interface ObstacleInst {
  def: ObstacleDef;
  group: THREE.Group;
  cleared: boolean;
}
export interface FireInst {
  def: FireDef;
  rig: FireRig;
  lit: boolean;
}
export interface PlotInst {
  def: PlotDef;
  marker: THREE.Group;
  mesh: THREE.Group | null;
  built: boolean;
  level: number;
}
export interface LinkInst {
  def: LinkDef;
  rig: LinkRig;
  repaired: boolean;
}

export interface World {
  scene: THREE.Scene;
  camera: THREE.OrthographicCamera;
  renderer: THREE.WebGLRenderer;
  pal: Pal;
  nav: NavGrid;
  pickables: THREE.Object3D[];
  nodes: Map<string, NodeInst>;
  obstacles: Map<string, ObstacleInst>;
  fires: Map<string, FireInst>;
  plots: Map<string, PlotInst>;
  links: Map<string, LinkInst>;
  workers: Map<string, WorkerRig>;
  platforms: Map<string, THREE.Group>;
  keyLight: THREE.DirectionalLight;
  backdrop: THREE.Mesh;
  snow: THREE.Points | null;
  motes: THREE.Points | null;
  frame: (w: number, h: number) => void;
  dispose: () => void;
}

/* ------------------------------------------------------------------ *
 * Painted backdrop — guarantees the background cliff silhouette band
 * ------------------------------------------------------------------ */
function backdropTexture(top: string, bottom: string, cliff: string, cliffFar: string, leaf: string) {
  const W = 1024;
  const H = 640;
  const c = document.createElement('canvas');
  c.width = W;
  c.height = H;
  const g = c.getContext('2d')!;
  const rnd = mulberry32(1337);

  const ridge = (baseY: number, amp: number, color: string, alpha: number, teeth: number, seed: number) => {
    const r = mulberry32(seed);
    g.globalAlpha = alpha;
    g.fillStyle = color;
    g.beginPath();
    g.moveTo(0, H);
    g.lineTo(0, baseY);
    const step = W / teeth;
    for (let i = 0; i <= teeth; i++) {
      const x = i * step;
      const peak = baseY - amp * (0.35 + r() * 0.9);
      const mid = baseY - amp * (0.1 + r() * 0.35);
      g.lineTo(x - step * 0.5, mid);
      g.lineTo(x, peak);
    }
    g.lineTo(W, baseY);
    g.lineTo(W, H);
    g.closePath();
    g.fill();
    g.globalAlpha = 1;
  };

  ridge(H * 0.42, H * 0.3, cliffFar, 0.55, 7, 5);
  ridge(H * 0.55, H * 0.26, cliff, 0.75, 9, 9);
  ridge(H * 0.68, H * 0.18, cliff, 0.95, 13, 17);

  // tree line on the nearest ridge
  g.globalAlpha = 0.9;
  g.fillStyle = leaf;
  for (let i = 0; i < 90; i++) {
    const x = rnd() * W;
    const baseY = H * 0.7 + rnd() * H * 0.06;
    const h = 14 + rnd() * 34;
    const w = 7 + rnd() * 12;
    g.beginPath();
    g.moveTo(x, baseY - h);
    g.lineTo(x + w, baseY);
    g.lineTo(x - w, baseY);
    g.closePath();
    g.fill();
  }
  g.globalAlpha = 1;

  // painted haze at the horizon
  const haze = g.createLinearGradient(0, H * 0.3, 0, H * 0.75);
  haze.addColorStop(0, bottom + '00');
  haze.addColorStop(0.5, bottom + '55');
  haze.addColorStop(1, bottom + '00');
  g.fillStyle = haze;
  g.fillRect(0, H * 0.3, W, H * 0.45);

  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

/* ------------------------------------------------------------------ *
 * Platform slab
 * ------------------------------------------------------------------ */
function platformMesh(def: LevelDef['platforms'][number], pal: Pal, seed: number) {
  const g = new THREE.Group();
  const b = pal.biome;
  const topTex = def.kind === 'stone' ? pal.stone : def.kind === 'snow' ? pal.snow : pal.grass;
  const top = topTex.clone();
  top.needsUpdate = true;
  top.repeat.set(def.w / 4.5, def.d / 4.5);
  const rockTex = pal.rock.clone();
  rockTex.needsUpdate = true;
  rockTex.repeat.set(def.w / 3.5, 1.4);

  const thick = 1.6 + def.y * 0.35;
  const slab = new THREE.Mesh(
    wobble(new THREE.BoxGeometry(def.w, thick, def.d), 0.05, seed),
    toonMat(b.rock, { map: rockTex, flat: true }),
  );
  slab.position.set(def.x, def.y - thick / 2, def.z);
  slab.castShadow = true;
  slab.receiveShadow = true;
  g.add(slab);
  slab.add(edgeInk(slab.geometry, INK, 0.3));

  // support column down to the diorama base so nothing floats
  const supportTop = def.y - thick;
  const supportH = supportTop + 2;
  if (supportH > 0.2) {
    const support = new THREE.Mesh(
      wobble(new THREE.BoxGeometry(def.w * 0.74, supportH, def.d * 0.74), 0.06, seed + 9),
      toonMat(b.rock, { map: rockTex, flat: true }),
    );
    support.position.set(def.x, supportTop - supportH / 2, def.z);
    support.castShadow = true;
    support.receiveShadow = true;
    g.add(support);
    support.add(edgeInk(support.geometry, INK, 0.26));
  }

  const cap = new THREE.Mesh(
    wobble(new THREE.BoxGeometry(def.w - 0.1, 0.26, def.d - 0.1), 0.04, seed + 3),
    toonMat(0xffffff, { map: top, flat: true }),
  );
  cap.position.set(def.x, def.y - 0.13, def.z);
  cap.receiveShadow = true;
  cap.castShadow = true;
  g.add(cap);
  cap.add(edgeInk(cap.geometry, INK, 0.22));

  // hanging root / rock skirt so the slab never reads as a flat plane
  const rnd = mulberry32(seed + 11);
  for (let i = 0; i < 7; i++) {
    const s = 0.5 + rnd() * 0.9;
    const chunk = new THREE.Mesh(
      new THREE.IcosahedronGeometry(s, 0),
      toonMat(b.rock, { map: pal.rock, flat: true }),
    );
    const side = i % 4;
    const t = (rnd() - 0.5) * 0.8;
    if (side === 0) chunk.position.set(def.x + t * def.w, def.y - thick - s * 0.3, def.z + def.d / 2 - 0.2);
    else if (side === 1) chunk.position.set(def.x + t * def.w, def.y - thick - s * 0.3, def.z - def.d / 2 + 0.2);
    else if (side === 2) chunk.position.set(def.x + def.w / 2 - 0.2, def.y - thick - s * 0.3, def.z + t * def.d);
    else chunk.position.set(def.x - def.w / 2 + 0.2, def.y - thick - s * 0.3, def.z + t * def.d);
    chunk.rotation.set(rnd(), rnd(), rnd());
    chunk.castShadow = true;
    g.add(chunk);
  }
  // grass fringe on the lip
  for (let i = 0; i < 6; i++) {
    const bush = buildBush(pal, seed * 31 + i, 0.55 + rnd() * 0.5);
    const side = i % 4;
    const t = (rnd() - 0.5) * 0.85;
    if (side === 0) bush.position.set(def.x + t * def.w, def.y, def.z + def.d / 2 - 0.15);
    else if (side === 1) bush.position.set(def.x + t * def.w, def.y, def.z - def.d / 2 + 0.15);
    else if (side === 2) bush.position.set(def.x + def.w / 2 - 0.15, def.y, def.z + t * def.d);
    else bush.position.set(def.x - def.w / 2 + 0.15, def.y, def.z + t * def.d);
    g.add(bush);
  }
  return g;
}

/* ------------------------------------------------------------------ *
 * World assembly
 * ------------------------------------------------------------------ */
export function buildWorld(level: LevelDef, canvas: HTMLCanvasElement): World {
  const pal = makePal(level.biome);
  pal.glow = glowTexture();
  const b = level.biome;

  const scene = new THREE.Scene();
  scene.background = skyTexture(b.skyTop, b.skyBottom);
  scene.fog = new THREE.Fog(new THREE.Color(b.fog), b.fogNear, b.fogFar);

  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: false });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  renderer.toneMapping = THREE.NoToneMapping;
  renderer.outputColorSpace = THREE.SRGBColorSpace;

  /* ---- fixed orthographic isometric camera: 3/4 overhead, no orbit ---- */
  const camera = new THREE.OrthographicCamera(-20, 20, 20, -20, -200, 400);
  const viewDir = new THREE.Vector3(-1, -1.15, -1).normalize();
  camera.position.copy(viewDir).multiplyScalar(-80);
  camera.lookAt(0, 0, 0);
  camera.updateMatrixWorld(true);

  const nav = new NavGrid();
  const pickables: THREE.Object3D[] = [];
  const platforms = new Map<string, THREE.Group>();
  const nodes = new Map<string, NodeInst>();
  const obstacles = new Map<string, ObstacleInst>();
  const fires = new Map<string, FireInst>();
  const plots = new Map<string, PlotInst>();
  const links = new Map<string, LinkInst>();
  const workers = new Map<string, WorkerRig>();

  const root = new THREE.Group();
  scene.add(root);

  /* ---- diorama base mass ---- */
  let minX = Infinity, maxX = -Infinity, minZ = Infinity, maxZ = -Infinity, maxY = 0;
  for (const p of level.platforms) {
    minX = Math.min(minX, p.x - p.w / 2);
    maxX = Math.max(maxX, p.x + p.w / 2);
    minZ = Math.min(minZ, p.z - p.d / 2);
    maxZ = Math.max(maxZ, p.z + p.d / 2);
    maxY = Math.max(maxY, p.y);
  }
  const cx = (minX + maxX) / 2;
  const cz = (minZ + maxZ) / 2;
  const bw = maxX - minX;
  const bd = maxZ - minZ;

  const baseTex = pal.rock.clone();
  baseTex.repeat.set(bw / 5, 3);
  const base = new THREE.Mesh(
    wobble(new THREE.BoxGeometry(bw + 3, 12, bd + 3), 0.12, 77),
    toonMat(b.rock, { map: baseTex, flat: true }),
  );
  base.position.set(cx, -8, cz);
  base.receiveShadow = true;
  base.castShadow = true;
  root.add(base);
  base.add(edgeInk(base.geometry, INK, 0.35));

  const under = new THREE.Mesh(
    new THREE.ConeGeometry(Math.max(bw, bd) * 0.52, 11, 7, 1),
    toonMat(b.rock, { map: baseTex, flat: true }),
  );
  under.position.set(cx, -19.5, cz);
  under.rotation.z = Math.PI;
  under.rotation.y = 0.4;
  root.add(under);

  /* ---- platforms ---- */
  level.platforms.forEach((p, i) => {
    const g = platformMesh(p, pal, 100 + i * 17);
    root.add(g);
    platforms.set(p.id, g);
    nav.sheet(p.x - p.w / 2, p.x + p.w / 2, p.z - p.d / 2, p.z + p.d / 2, p.y, 0.5);
    // scatter decoration inside the platform, away from the centre
    const rnd = mulberry32(500 + i * 13);
    const count = 4 + Math.floor(rnd() * 3);
    for (let k = 0; k < count; k++) {
      const x = p.x + (rnd() - 0.5) * (p.w - 2.2);
      const z = p.z + (rnd() - 0.5) * (p.d - 2.2);
      if (Math.hypot(x - p.x, z - p.z) < 2.4) continue;
      const r = rnd();
      const deco = r < 0.45 ? buildTree(pal, 900 + i * 31 + k, 0.6 + rnd() * 0.5) : buildRock(pal, 950 + i * 17 + k, 0.5 + rnd() * 0.4);
      deco.position.set(x, p.y, z);
      root.add(deco);
    }
  });

  /* ---- links ---- */
  for (const l of level.links) {
    const rig = buildLink(l.kind, pal, l.aPoint, l.bPoint, l.width ?? 2.2);
    rig.group.position.set(0, 0, 0);
    rig.fixed.visible = false;
    rig.broken.visible = true;
    root.add(rig.group);
    links.set(l.id, { def: l, rig, repaired: false });
    rig.group.traverse((o) => {
      if ((o as THREE.Mesh).isMesh) {
        o.userData.pickId = l.id;
        pickables.push(o);
      }
    });
  }

  /* ---- nodes ---- */
  level.nodes.forEach((n, i) => {
    const g = buildNode(n.kind, pal, 200 + i * 7);
    g.position.set(n.x, n.y, n.z);
    root.add(g);
    nodes.set(n.id, { def: n, group: g, amount: n.amount });
    g.traverse((o) => {
      if ((o as THREE.Mesh).isMesh) {
        o.userData.pickId = n.id;
        pickables.push(o);
      }
    });
  });

  /* ---- obstacles ---- */
  level.obstacles.forEach((o, i) => {
    const g = buildObstacle(o.kind, pal, 400 + i * 11);
    g.position.set(o.x, o.y, o.z);
    root.add(g);
    obstacles.set(o.id, { def: o, group: g, cleared: false });
    g.traverse((o2) => {
      if ((o2 as THREE.Mesh).isMesh) {
        o2.userData.pickId = o.id;
        pickables.push(o2);
      }
    });
    const c = nav.at(o.x, o.y, o.z);
    if (c) nav.blocked.add(`${c.ix}|${c.iy}|${c.iz}`);
  });

  /* ---- bonfires ---- */
  for (const f of level.fires) {
    const rig = buildBonfire(pal);
    rig.group.position.set(f.x, f.y, f.z);
    root.add(rig.group);
    fires.set(f.id, { def: f, rig, lit: false });
    rig.group.traverse((o) => {
      if ((o as THREE.Mesh).isMesh) {
        o.userData.pickId = f.id;
        pickables.push(o);
      }
    });
  }

  /* ---- building plots ---- */
  for (const p of level.plots) {
    const marker = buildPlotMarker(pal);
    marker.position.set(p.x, p.y, p.z);
    marker.rotation.y = p.rot ?? 0;
    root.add(marker);
    plots.set(p.id, { def: p, marker, mesh: null, built: false, level: 0 });
    marker.traverse((o) => {
      if ((o as THREE.Mesh).isMesh) {
        o.userData.pickId = p.id;
        pickables.push(o);
      }
    });
  }

  /* ---- workers ---- */
  const workerColors = ['#e0603c', '#3f8fbf', '#e8b93c', '#8a63c9', '#4fae7a'];
  for (let i = 0; i < 5; i++) {
    const rig = buildWorker(workerColors[i], 300 + i * 13);
    rig.group.visible = i < 3;
    root.add(rig.group);
    workers.set(`w${i}`, rig);
  }

  /* ---- home pad ---- */
  const pad = new THREE.Mesh(
    new THREE.RingGeometry(0.9, 1.25, 24),
    new THREE.MeshBasicMaterial({ color: 0xf6e7c0, transparent: true, opacity: 0.4, side: THREE.DoubleSide, depthWrite: false }),
  );
  pad.rotation.x = -Math.PI / 2;
  pad.position.set(level.home.x, level.home.y + 0.04, level.home.z);
  root.add(pad);

  /* ---- lighting: only the key light warmth shifts with the biome ---- */
  const keyLight = new THREE.DirectionalLight(new THREE.Color(b.key), b.keyIntensity);
  keyLight.position.set(cx + 26, 40, cz + 18);
  keyLight.target.position.set(cx, 0, cz);
  keyLight.castShadow = true;
  keyLight.shadow.mapSize.set(2048, 2048);
  const sc = keyLight.shadow.camera;
  sc.left = -34;
  sc.right = 34;
  sc.top = 34;
  sc.bottom = -34;
  sc.near = 1;
  sc.far = 140;
  keyLight.shadow.bias = -0.0009;
  keyLight.shadow.normalBias = 0.035;
  scene.add(keyLight, keyLight.target);

  const hemi = new THREE.HemisphereLight(new THREE.Color(b.ambient), new THREE.Color(b.rock), b.ambientIntensity);
  scene.add(hemi);
  const fill = new THREE.DirectionalLight(new THREE.Color(b.ambient), 0.2);
  fill.position.set(cx - 20, 14, cz - 24);
  scene.add(fill);

  /* ---- painted backdrop (background cliff silhouette) ---- */
  const backdrop = new THREE.Mesh(
    new THREE.PlaneGeometry(1, 1),
    new THREE.MeshBasicMaterial({
      map: backdropTexture(b.skyTop, b.skyBottom, b.cliff, b.cliffFar, b.leafDark),
      transparent: true,
      depthWrite: false,
      fog: false,
    }),
  );
  backdrop.renderOrder = -10;
  scene.add(backdrop);

  /* ---- foreground occluders: dark silhouettes that crop the frame ---- */
  const fgMat = (c: THREE.ColorRepresentation) => toonMat(new THREE.Color(c).multiplyScalar(0.42), { flat: true });
  const fgSpots: [number, number, number][] = [
    [cx + bw * 0.42, cz + bd * 0.62, 1.25],
    [cx - bw * 0.16, cz + bd * 0.66, 1.45],
    [cx - bw * 0.52, cz + bd * 0.52, 1.15],
    [cx + bw * 0.66, cz + bd * 0.1, 1.3],
    [cx + bw * 0.7, cz - bd * 0.34, 1.1],
    [cx - bw * 0.62, cz + bd * 0.2, 1.0],
  ];
  fgSpots.forEach(([x, z, s], i) => {
    const cluster = new THREE.Group();
    const mound = new THREE.Mesh(new THREE.IcosahedronGeometry(2.6 * s, 1), fgMat(b.rock));
    mound.position.y = -1.4 * s;
    mound.scale.set(1.5, 0.75, 1.3);
    cluster.add(mound);
    const stem = new THREE.Mesh(new THREE.BoxGeometry(5 * s, 12, 4.5 * s), fgMat(b.rock));
    stem.position.y = -7 * s;
    cluster.add(stem);
    const t = buildTree(pal, 1500 + i * 29, 1.9 * s);
    t.position.set((i % 2 ? 0.7 : -0.6) * s, 0, 0);
    t.traverse((o) => {
      const m = o as THREE.Mesh;
      if (m.isMesh) {
        m.castShadow = false;
        m.receiveShadow = false;
        const mm = m.material as THREE.MeshToonMaterial;
        if (mm && mm.color) mm.color.multiplyScalar(0.4);
      }
    });
    cluster.add(t);
    const t2 = buildTree(pal, 1600 + i * 17, 1.35 * s);
    t2.position.set((i % 2 ? -1.7 : 1.6) * s, -0.2, 1.1 * s);
    t2.traverse((o) => {
      const m = o as THREE.Mesh;
      if (m.isMesh) {
        m.castShadow = false;
        const mm = m.material as THREE.MeshToonMaterial;
        if (mm && mm.color) mm.color.multiplyScalar(0.36);
      }
    });
    cluster.add(t2);
    const r = buildRock(pal, 1700 + i * 7, 1.1 * s);
    r.position.set(1.9 * s, -0.1, -0.9 * s);
    r.traverse((o) => {
      const m = o as THREE.Mesh;
      if (m.isMesh) {
        m.castShadow = false;
        const mm = m.material as THREE.MeshToonMaterial;
        if (mm && mm.color) mm.color.multiplyScalar(0.4);
      }
    });
    cluster.add(r);
    cluster.position.set(x, 0.4, z);
    root.add(cluster);
  });

  /* ---- weather ---- */
  let snow: THREE.Points | null = null;
  let motes: THREE.Points | null = null;
  const particleTex = paintTexture('#ffffff', '#dfe8f2', '#ffffff', 9, { patches: 4, strokes: 0, speck: 40, strokeLen: 4 });
  const makePoints = (count: number, spread: number, size: number, color: number, opacity: number) => {
    const geo = new THREE.BufferGeometry();
    const pos = new Float32Array(count * 3);
    const rnd = mulberry32(21);
    for (let i = 0; i < count; i++) {
      pos[i * 3] = cx + (rnd() - 0.5) * spread;
      pos[i * 3 + 1] = (rnd() - 0.2) * 26;
      pos[i * 3 + 2] = cz + (rnd() - 0.5) * spread;
    }
    geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    const pts = new THREE.Points(
      geo,
      new THREE.PointsMaterial({
        map: particleTex,
        color,
        size,
        transparent: true,
        opacity,
        depthWrite: false,
        sizeAttenuation: true,
        fog: false,
      }),
    );
    scene.add(pts);
    return pts;
  };
  if (b.snow) snow = makePoints(900, bw + 26, 0.34, 0xffffff, 0.85);
  else motes = makePoints(340, bw + 20, 0.22, new THREE.Color(b.skyBottom).getHex(), 0.55);

  /* ---- camera framing: fit the whole level, fixed forever ---- */
  const box = new THREE.Box3(
    new THREE.Vector3(minX - 1.5, -3, minZ - 1.5),
    new THREE.Vector3(maxX + 1.5, maxY + 5.5, maxZ + 1.5),
  );
  const frame = (w: number, h: number) => {
    const aspect = w / h;
    const inv = camera.matrixWorld.clone().invert();
    let u0 = Infinity, u1 = -Infinity, v0 = Infinity, v1 = -Infinity;
    for (let i = 0; i < 8; i++) {
      const p = new THREE.Vector3(
        i & 1 ? box.max.x : box.min.x,
        i & 2 ? box.max.y : box.min.y,
        i & 4 ? box.max.z : box.min.z,
      ).applyMatrix4(inv);
      u0 = Math.min(u0, p.x);
      u1 = Math.max(u1, p.x);
      v0 = Math.min(v0, p.y);
      v1 = Math.max(v1, p.y);
    }
    const pad = 1.1;
    const halfW = ((u1 - u0) / 2) * pad;
    const halfH = ((v1 - v0) / 2) * pad;
    let hw = halfW;
    let hh = halfH;
    if (hw / hh < aspect) hw = hh * aspect;
    else hh = hw / aspect;
    const cu = (u0 + u1) / 2;
    const cv = (v0 + v1) / 2;
    camera.left = cu - hw;
    camera.right = cu + hw;
    camera.top = cv + hh;
    camera.bottom = cv - hh;
    camera.near = -200;
    camera.far = 400;
    camera.updateProjectionMatrix();

    backdrop.quaternion.copy(camera.quaternion);
    backdrop.position.copy(camera.position).addScaledVector(viewDir, 300);
    backdrop.scale.set(hw * 2.2, hh * 2.2, 1);

    const fog = scene.fog as THREE.Fog;
    fog.near = 96;
    fog.far = 172;
  };

  const dispose = () => {
    scene.traverse((o) => {
      const m = o as THREE.Mesh;
      if (m.geometry) m.geometry.dispose();
      const mat = m.material as THREE.Material | THREE.Material[] | undefined;
      if (Array.isArray(mat)) mat.forEach((x) => x.dispose());
      else if (mat) mat.dispose();
    });
    renderer.dispose();
  };

  return {
    scene,
    camera,
    renderer,
    pal,
    nav,
    pickables,
    nodes,
    obstacles,
    fires,
    plots,
    links,
    workers,
    platforms,
    keyLight,
    backdrop,
    snow,
    motes,
    frame,
    dispose,
  };
}
