export type ResourceKind = 'wood' | 'food' | 'gold' | 'stone' | 'crystal';

export const RESOURCES: ResourceKind[] = ['wood', 'food', 'gold', 'stone', 'crystal'];

export type Cost = Partial<Record<ResourceKind, number>>;

export interface Vec3 {
  x: number;
  y: number;
  z: number;
}

export type PlatformKind = 'grass' | 'stone' | 'wood' | 'snow';

export interface PlatformDef {
  id: string;
  name: string;
  /** centre x */
  x: number;
  /** centre z */
  z: number;
  /** height of the walkable top surface */
  y: number;
  w: number;
  d: number;
  kind: PlatformKind;
}

export type LinkKind = 'bridge' | 'stairs';

export interface LinkDef {
  id: string;
  kind: LinkKind;
  a: string;
  b: string;
  aPoint: Vec3;
  bPoint: Vec3;
  cost: Cost;
  points: number;
  width?: number;
}

export interface NodeDef {
  id: string;
  kind: ResourceKind;
  x: number;
  y: number;
  z: number;
  amount: number;
  perTrip: number;
}

export type ObstacleKind = 'thicket' | 'stump' | 'rock' | 'ice' | 'bones' | 'crate';

export interface ObstacleDef {
  id: string;
  kind: ObstacleKind;
  x: number;
  y: number;
  z: number;
  cost: Cost;
  points: number;
  /** id of a bonfire that must be lit first */
  needsFire?: string;
}

export interface FireDef {
  id: string;
  x: number;
  y: number;
  z: number;
  cost: Cost;
}

export type BuildingType = 'mill' | 'farm' | 'well' | 'warehouse' | 'housing' | 'blacksmith';

export interface PlotDef {
  id: string;
  type: BuildingType;
  x: number;
  y: number;
  z: number;
  rot?: number;
}

export type ObjectiveKind = 'gather' | 'clear' | 'repair' | 'build' | 'upgrade' | 'reach' | 'fire';

export interface ObjectiveDef {
  id: string;
  kind: ObjectiveKind;
  label: string;
  target: number;
  resource?: ResourceKind;
  building?: BuildingType;
  platform?: string;
}

export interface BiomeDef {
  name: string;
  skyTop: string;
  skyBottom: string;
  fog: string;
  fogNear: number;
  fogFar: number;
  cliff: string;
  cliffFar: string;
  ground: string;
  /** key light colour — the only thing a biome shift is allowed to change besides environment colour */
  key: string;
  keyIntensity: number;
  ambient: string;
  ambientIntensity: number;
  snow: boolean;
  leaf: string;
  leafDark: string;
  trunk: string;
  rock: string;
  grass: string;
}

export interface LevelDef {
  id: string;
  name: string;
  subtitle: string;
  biome: BiomeDef;
  platforms: PlatformDef[];
  links: LinkDef[];
  nodes: NodeDef[];
  obstacles: ObstacleDef[];
  fires: FireDef[];
  plots: PlotDef[];
  objectives: ObjectiveDef[];
  /** seconds; undefined = untimed level, which cannot fail */
  timeLimit?: number;
  /** gold / silver / bronze par times in seconds */
  par: [number, number, number];
  home: Vec3;
  intro: string;
}

export interface BuildingSpec {
  name: string;
  blurb: string;
  build: Cost;
  points: number;
  upgrades: { cost: Cost; points: number; label: string }[];
  effect: string;
}

export const BUILDINGS: Record<BuildingType, BuildingSpec> = {
  mill: {
    name: 'Grain Mill',
    blurb: 'Saw blades and sharpened picks. Every worker hauls faster.',
    build: { wood: 12, stone: 6 },
    points: 2,
    upgrades: [
      { cost: { wood: 14, stone: 8 }, points: 2, label: 'Twin blades' },
      { cost: { wood: 20, stone: 12, gold: 8 }, points: 3, label: 'Stone gearing' },
    ],
    effect: '+15% gather speed per level',
  },
  farm: {
    name: 'Terrace Farm',
    blurb: 'Raised beds of hardy grain. Keeps the crew fed while you are away.',
    build: { wood: 10, food: 8 },
    points: 2,
    upgrades: [
      { cost: { wood: 12, food: 10 }, points: 2, label: 'Second terrace' },
      { cost: { wood: 16, food: 14, gold: 6 }, points: 3, label: 'Irrigation' },
    ],
    effect: '+0.14 food / sec per level',
  },
  well: {
    name: 'Deep Well',
    blurb: 'Clean water cuts hunger and speeds every swing of the axe.',
    build: { stone: 14, wood: 6 },
    points: 2,
    upgrades: [
      { cost: { stone: 16, wood: 10 }, points: 2, label: 'Stone lining' },
      { cost: { stone: 22, gold: 10 }, points: 3, label: 'Cistern' },
    ],
    effect: '-12% food drain, +5% gather speed per level',
  },
  warehouse: {
    name: 'Warehouse',
    blurb: 'Stacked crates and racks. Raises every resource cap.',
    build: { wood: 16, stone: 10 },
    points: 3,
    upgrades: [
      { cost: { wood: 20, stone: 14 }, points: 3, label: 'Upper racks' },
      { cost: { wood: 26, stone: 20, gold: 12 }, points: 4, label: 'Cold store' },
    ],
    effect: '+30 wood/stone, +20 food/gold, +10 crystal cap per level',
  },
  housing: {
    name: 'Housing',
    blurb: 'Cots and hearths. Each level wakes one more worker (pool 3, cap 5).',
    build: { wood: 18, stone: 8, food: 6 },
    points: 3,
    upgrades: [{ cost: { wood: 24, stone: 14, food: 10 }, points: 4, label: 'Second wing' }],
    effect: '+1 worker per level',
  },
  blacksmith: {
    name: 'Blacksmith',
    blurb: 'Hot iron for chisels and pick heads. Clears and repairs far quicker.',
    build: { stone: 18, gold: 10 },
    points: 4,
    upgrades: [
      { cost: { stone: 22, gold: 16 }, points: 4, label: 'Second forge' },
      { cost: { stone: 28, gold: 22, crystal: 6 }, points: 5, label: 'Crystal tempering' },
    ],
    effect: '+18% clear / repair / build speed per level',
  },
};

export const BASE_CAPS: Record<ResourceKind, number> = {
  wood: 60,
  food: 40,
  gold: 40,
  stone: 40,
  crystal: 20,
};

export const CAP_STEP: Record<ResourceKind, number> = {
  wood: 30,
  food: 20,
  gold: 20,
  stone: 30,
  crystal: 10,
};

export const RESOURCE_META: Record<ResourceKind, { label: string; color: string; glyph: string }> = {
  wood: { label: 'Wood', color: '#c98a4b', glyph: '▤' },
  food: { label: 'Food', color: '#8fc45a', glyph: '❦' },
  gold: { label: 'Gold', color: '#e8c05a', glyph: '◆' },
  stone: { label: 'Stone', color: '#a9b0bd', glyph: '⬢' },
  crystal: { label: 'Crystal', color: '#7fd8e8', glyph: '✦' },
};

export const OBSTACLE_META: Record<ObstacleKind, { label: string }> = {
  thicket: { label: 'Bramble thicket' },
  stump: { label: 'Fallen stump' },
  rock: { label: 'Boulder' },
  ice: { label: 'Ice shelf' },
  bones: { label: 'Old bones' },
  crate: { label: 'Rusted crates' },
};

export const LINK_META: Record<LinkKind, { label: string }> = {
  bridge: { label: 'Broken bridge' },
  stairs: { label: 'Collapsed stairs' },
};

export type TaskKind = 'gather' | 'clear' | 'repair' | 'build' | 'upgrade' | 'fire';

export interface TaskView {
  id: string;
  kind: TaskKind;
  label: string;
  detail: string;
  cost: Cost;
  workerId: string | null;
  state: 'pending' | 'walking' | 'working' | 'returning';
  progress: number;
  blocked: string | null;
}

export interface WorkerView {
  id: string;
  name: string;
  color: string;
  state: 'idle' | 'walking' | 'working' | 'returning';
  taskId: string | null;
}

export interface ObjectiveView {
  id: string;
  label: string;
  have: number;
  target: number;
  done: boolean;
}

export interface PlotView {
  id: string;
  type: BuildingType;
  built: boolean;
  level: number;
}

export type Medal = 'gold' | 'silver' | 'bronze' | 'none';

export interface Snapshot {
  levelIndex: number;
  levelName: string;
  levelSubtitle: string;
  biomeName: string;
  status: 'playing' | 'clear' | 'failed';
  elapsed: number;
  timeLimit?: number;
  medal: Medal;
  resources: Record<ResourceKind, number>;
  caps: Record<ResourceKind, number>;
  points: number;
  foodRate: number;
  workers: WorkerView[];
  workerCount: number;
  tasks: TaskView[];
  taskCap: number;
  objectives: ObjectiveView[];
  plots: PlotView[];
  gatherSpeed: number;
  workSpeed: number;
  starving: boolean;
  toast: { id: number; text: string; tone: 'good' | 'bad' | 'info' } | null;
  hover: { label: string; detail: string; cost: Cost; affordable: boolean; blocked: string | null } | null;
  nodesLeft: number;
}
