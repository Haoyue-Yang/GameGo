import * as THREE from 'three';
import type { BiomeDef, BuildingType, ObstacleKind, ResourceKind, Vec3 } from './types';
import { INK, edgeInk, mulberry32, paintTexture, toonMat, wobble, woodTexture } from './art';

export interface Pal {
  biome: BiomeDef;
  grass: THREE.Texture;
  stone: THREE.Texture;
  wood: THREE.Texture;
  snow: THREE.Texture;
  rock: THREE.Texture;
  cloth: THREE.Texture;
  glow: THREE.Texture;
}

export function makePal(b: BiomeDef): Pal {
  return {
    biome: b,
    grass: paintTexture(b.grass, '#4f7f45', '#a8d17f', 11, { strokes: 260, strokeLen: 30 }),
    stone: paintTexture(b.rock, '#5f6773', '#d3dae2', 23, { patches: 30, strokes: 150, strokeLen: 18 }),
    wood: woodTexture(b.trunk, '#4a2f1e', '#c39263', 31),
    snow: paintTexture(b.grass, '#b9cede', '#ffffff', 47, { patches: 18, strokes: 200, strokeLen: 22 }),
    rock: paintTexture(b.rock, '#4f5661', '#cfd6de', 59, { patches: 34, strokes: 120, strokeLen: 14 }),
    cloth: paintTexture('#c96a4b', '#8c3f2c', '#e8a06a', 71, { patches: 14, strokes: 180, strokeLen: 16 }),
    glow: null as unknown as THREE.Texture,
  };
}

const box = (w: number, h: number, d: number) => new THREE.BoxGeometry(w, h, d);
const cyl = (rt: number, rb: number, h: number, s = 8) => new THREE.CylinderGeometry(rt, rb, h, s);
const sph = (r: number, s = 10) => new THREE.SphereGeometry(r, s, Math.max(6, s - 2));
const cone = (r: number, h: number, s = 8) => new THREE.ConeGeometry(r, h, s);
const ico = (r: number, det = 0) => new THREE.IcosahedronGeometry(r, det);
const octa = (r: number, det = 0) => new THREE.OctahedronGeometry(r, det);

function mesh(
  geo: THREE.BufferGeometry,
  mat: THREE.Material,
  x = 0,
  y = 0,
  z = 0,
  ink = false,
): THREE.Mesh {
  const m = new THREE.Mesh(geo, mat);
  m.position.set(x, y, z);
  m.castShadow = true;
  m.receiveShadow = true;
  if (ink) {
    const e = edgeInk(geo, INK, 0.28);
    m.add(e);
  }
  return m;
}

/* ------------------------------------------------------------------ *
 * Scenery
 * ------------------------------------------------------------------ */
export function buildTree(pal: Pal, seed: number, scale = 1) {
  const rnd = mulberry32(seed);
  const g = new THREE.Group();
  const trunkH = (1.5 + rnd() * 1.1) * scale;
  const trunk = mesh(cyl(0.13 * scale, 0.2 * scale, trunkH, 6), toonMat(pal.biome.trunk, { map: pal.wood, flat: true }), 0, trunkH / 2, 0, true);
  g.add(trunk);
  const layers = 3;
  for (let i = 0; i < layers; i++) {
    const t = i / layers;
    const r = (0.95 - t * 0.45) * scale * (0.9 + rnd() * 0.25);
    const h = (1.25 - t * 0.28) * scale;
    const leaf = mesh(
      cone(r, h, 7),
      toonMat(i % 2 ? pal.biome.leafDark : pal.biome.leaf, { flat: true }),
      (rnd() - 0.5) * 0.12,
      trunkH * 0.72 + i * h * 0.52,
      (rnd() - 0.5) * 0.12,
      true,
    );
    leaf.rotation.y = rnd() * Math.PI;
    g.add(leaf);
    if (pal.biome.snow) {
      const cap = mesh(cone(r * 0.86, h * 0.34, 7), toonMat('#f4fbff', { flat: true }), leaf.position.x, leaf.position.y + h * 0.32, leaf.position.z);
      cap.rotation.y = leaf.rotation.y;
      g.add(cap);
    }
  }
  return g;
}

export function buildBush(pal: Pal, seed: number, scale = 1) {
  const rnd = mulberry32(seed);
  const g = new THREE.Group();
  for (let i = 0; i < 3; i++) {
    const r = (0.32 + rnd() * 0.22) * scale;
    const b = mesh(
      ico(r, 0),
      toonMat(i === 1 ? pal.biome.leafDark : pal.biome.leaf, { flat: true }),
      (rnd() - 0.5) * 0.5 * scale,
      r * 0.8,
      (rnd() - 0.5) * 0.5 * scale,
      true,
    );
    g.add(b);
  }
  return g;
}

export function buildRock(pal: Pal, seed: number, scale = 1) {
  const rnd = mulberry32(seed);
  const g = new THREE.Group();
  const n = 2 + Math.floor(rnd() * 2);
  for (let i = 0; i < n; i++) {
    const r = (0.34 + rnd() * 0.34) * scale;
    const m = mesh(
      ico(r, 0),
      toonMat(pal.biome.rock, { map: pal.rock, flat: true }),
      (rnd() - 0.5) * 0.6 * scale,
      r * 0.62,
      (rnd() - 0.5) * 0.6 * scale,
      true,
    );
    m.rotation.set(rnd(), rnd(), rnd());
    m.scale.y *= 0.78;
    g.add(m);
  }
  return g;
}

/* ------------------------------------------------------------------ *
 * Resource nodes
 * ------------------------------------------------------------------ */
export function buildNode(kind: ResourceKind, pal: Pal, seed: number) {
  const rnd = mulberry32(seed);
  const g = new THREE.Group();
  if (kind === 'wood') {
    const stump = mesh(cyl(0.42, 0.5, 0.5, 8), toonMat(pal.biome.trunk, { map: pal.wood, flat: true }), 0, 0.25, 0, true);
    g.add(stump);
    const top = mesh(cyl(0.36, 0.36, 0.06, 8), toonMat('#d9b183'), 0, 0.53, 0);
    g.add(top);
    for (let i = 0; i < 3; i++) {
      const log = mesh(cyl(0.16, 0.16, 1.05, 7), toonMat(pal.biome.trunk, { map: pal.wood, flat: true }), 0.75, 0.17 + i * 0.3, (rnd() - 0.5) * 0.5, true);
      log.rotation.z = Math.PI / 2;
      log.rotation.y = (rnd() - 0.5) * 0.5;
      g.add(log);
    }
  } else if (kind === 'food') {
    const trunk = mesh(cyl(0.12, 0.16, 0.5, 6), toonMat(pal.biome.trunk, { map: pal.wood }), 0, 0.25, 0);
    g.add(trunk);
    for (let i = 0; i < 4; i++) {
      const r = 0.3 + rnd() * 0.2;
      const b = mesh(ico(r, 0), toonMat(i % 2 ? pal.biome.leafDark : pal.biome.leaf, { flat: true }), (rnd() - 0.5) * 0.7, 0.62 + rnd() * 0.4, (rnd() - 0.5) * 0.7, true);
      g.add(b);
    }
    for (let i = 0; i < 7; i++) {
      const berry = mesh(sph(0.075, 6), toonMat('#e2564f', { emissive: '#5c1410' }), (rnd() - 0.5) * 0.9, 0.6 + rnd() * 0.55, (rnd() - 0.5) * 0.9);
      g.add(berry);
    }
  } else if (kind === 'gold') {
    const base = mesh(ico(0.62, 0), toonMat(pal.biome.rock, { map: pal.rock, flat: true }), 0, 0.42, 0, true);
    base.scale.y *= 0.85;
    g.add(base);
    for (let i = 0; i < 5; i++) {
      const n = mesh(ico(0.13 + rnd() * 0.09, 0), toonMat('#f0c34a', { emissive: '#6b4a05', flat: true }), (rnd() - 0.5) * 0.85, 0.35 + rnd() * 0.6, (rnd() - 0.5) * 0.85);
      n.rotation.set(rnd(), rnd(), rnd());
      g.add(n);
    }
  } else if (kind === 'stone') {
    for (let i = 0; i < 4; i++) {
      const r = 0.26 + rnd() * 0.3;
      const m = mesh(ico(r, 0), toonMat(i % 2 ? '#8f98a4' : pal.biome.rock, { map: pal.rock, flat: true }), (rnd() - 0.5) * 0.85, r * 0.7, (rnd() - 0.5) * 0.85, true);
      m.rotation.set(rnd(), rnd(), rnd());
      m.scale.y *= 0.8;
      g.add(m);
    }
    const shard = mesh(octa(0.2, 0), toonMat('#c3ccd6', { flat: true }), 0.1, 0.78, -0.1, true);
    g.add(shard);
  } else {
    const base = mesh(ico(0.5, 0), toonMat(pal.biome.rock, { map: pal.rock, flat: true }), 0, 0.3, 0, true);
    base.scale.y *= 0.7;
    g.add(base);
    const mat = toonMat('#8fe6f2', { emissive: '#2ea8c4', emissiveIntensity: 1.4, flat: true });
    for (let i = 0; i < 5; i++) {
      const h = 0.45 + rnd() * 0.75;
      const c = mesh(octa(0.16 + rnd() * 0.1, 0), mat, (rnd() - 0.5) * 0.6, 0.35 + h * 0.4, (rnd() - 0.5) * 0.6, true);
      c.scale.set(1, h * 1.5, 1);
      c.rotation.set((rnd() - 0.5) * 0.5, rnd() * 3, (rnd() - 0.5) * 0.5);
      g.add(c);
    }
    const glow = new THREE.Sprite(
      new THREE.SpriteMaterial({ map: pal.glow, color: 0x8fe6f2, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, opacity: 0.55 }),
    );
    glow.scale.setScalar(2.6);
    glow.position.y = 0.7;
    g.add(glow);
  }
  return g;
}

/* ------------------------------------------------------------------ *
 * Obstacles
 * ------------------------------------------------------------------ */
export function buildObstacle(kind: ObstacleKind, pal: Pal, seed: number) {
  const rnd = mulberry32(seed);
  const g = new THREE.Group();
  if (kind === 'thicket') {
    for (let i = 0; i < 6; i++) {
      const h = 0.7 + rnd() * 0.8;
      const b = mesh(
        ico(0.3 + rnd() * 0.22, 0),
        toonMat(i % 2 ? '#3f6b34' : '#578a3c', { flat: true }),
        (rnd() - 0.5) * 0.9,
        0.3 + rnd() * 0.5,
        (rnd() - 0.5) * 0.9,
        true,
      );
      b.scale.set(1, h, 1);
      g.add(b);
    }
  } else if (kind === 'stump') {
    const s = mesh(cyl(0.5, 0.62, 0.7, 8), toonMat(pal.biome.trunk, { map: pal.wood, flat: true }), 0, 0.35, 0, true);
    g.add(s);
    const fallen = mesh(cyl(0.34, 0.34, 1.9, 7), toonMat(pal.biome.trunk, { map: pal.wood, flat: true }), 1.0, 0.34, 0.2, true);
    fallen.rotation.z = Math.PI / 2;
    fallen.rotation.y = 0.4;
    g.add(fallen);
    const branch = mesh(cyl(0.1, 0.14, 0.9, 6), toonMat(pal.biome.trunk, { map: pal.wood }), -0.5, 0.75, -0.3, true);
    branch.rotation.z = -0.9;
    g.add(branch);
  } else if (kind === 'rock') {
    for (let i = 0; i < 3; i++) {
      const r = 0.55 + rnd() * 0.4;
      const m = mesh(ico(r, 0), toonMat(pal.biome.rock, { map: pal.rock, flat: true }), (rnd() - 0.5) * 0.7, r * 0.72, (rnd() - 0.5) * 0.7, true);
      m.rotation.set(rnd(), rnd(), rnd());
      m.scale.y *= 0.9;
      g.add(m);
    }
  } else if (kind === 'ice') {
    const mat = toonMat('#bfe6f5', { emissive: '#3f7f9a', emissiveIntensity: 0.35, flat: true, transparent: true, opacity: 0.92 });
    for (let i = 0; i < 5; i++) {
      const h = 0.6 + rnd() * 1.0;
      const m = mesh(octa(0.3 + rnd() * 0.2, 0), mat, (rnd() - 0.5) * 0.9, h * 0.45, (rnd() - 0.5) * 0.9, true);
      m.scale.set(1, h * 1.6, 1);
      m.rotation.set((rnd() - 0.5) * 0.4, rnd() * 3, (rnd() - 0.5) * 0.4);
      g.add(m);
    }
  } else if (kind === 'bones') {
    const bone = toonMat('#e8e2cf', { flat: true });
    for (let i = 0; i < 4; i++) {
      const b = mesh(cyl(0.09, 0.09, 0.9 + rnd() * 0.6, 6), bone, (rnd() - 0.5) * 0.8, 0.1, (rnd() - 0.5) * 0.8, true);
      b.rotation.z = Math.PI / 2;
      b.rotation.y = rnd() * Math.PI;
      g.add(b);
    }
    const skull = mesh(sph(0.26, 8), bone, 0.1, 0.26, 0.1, true);
    g.add(skull);
    const rib = mesh(torus(), bone, -0.2, 0.3, -0.1, true);
    rib.rotation.x = 1.2;
    g.add(rib);
  } else {
    const crate = toonMat('#a9764a', { map: pal.wood, flat: true });
    for (let i = 0; i < 4; i++) {
      const s = 0.55 + rnd() * 0.25;
      const c = mesh(wobble(box(s, s, s), 0.03, seed + i), crate, (rnd() - 0.5) * 0.8, s / 2 + (i > 2 ? 0.6 : 0), (rnd() - 0.5) * 0.8, true);
      c.rotation.y = rnd() * 0.8;
      g.add(c);
    }
  }
  return g;
}

function torus() {
  return new THREE.TorusGeometry(0.28, 0.05, 6, 10);
}

/* ------------------------------------------------------------------ *
 * Bonfire
 * ------------------------------------------------------------------ */
export interface FireRig {
  group: THREE.Group;
  flame: THREE.Group;
  light: THREE.PointLight;
  glow: THREE.Sprite;
}

export function buildBonfire(pal: Pal): FireRig {
  const g = new THREE.Group();
  const logMat = toonMat(pal.biome.trunk, { map: pal.wood, flat: true });
  for (let i = 0; i < 5; i++) {
    const a = (i / 5) * Math.PI * 2;
    const l = mesh(cyl(0.1, 0.13, 1.15, 6), logMat, Math.cos(a) * 0.3, 0.18, Math.sin(a) * 0.3, true);
    l.rotation.set(Math.cos(a) * 0.7, 0, Math.sin(a) * 0.7);
    g.add(l);
  }
  for (let i = 0; i < 8; i++) {
    const a = (i / 8) * Math.PI * 2;
    const r = mesh(ico(0.16, 0), toonMat(pal.biome.rock, { map: pal.rock, flat: true }), Math.cos(a) * 0.75, 0.1, Math.sin(a) * 0.75);
    r.scale.y *= 0.6;
    g.add(r);
  }
  const flame = new THREE.Group();
  flame.position.y = 0.35;
  const f1 = mesh(cone(0.34, 0.95, 7), toonMat('#ffb03a', { emissive: '#ff7a12', emissiveIntensity: 2.2, flat: true }), 0, 0.45, 0);
  const f2 = mesh(cone(0.2, 0.6, 7), toonMat('#ffe27a', { emissive: '#ffcf4a', emissiveIntensity: 2.6, flat: true }), 0, 0.62, 0);
  flame.add(f1, f2);
  flame.visible = false;
  g.add(flame);

  const light = new THREE.PointLight(0xffa03a, 0, 9, 2);
  light.position.y = 0.9;
  g.add(light);

  const glow = new THREE.Sprite(
    new THREE.SpriteMaterial({ map: pal.glow, color: 0xffb055, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, opacity: 0 }),
  );
  glow.scale.setScalar(4);
  glow.position.y = 0.8;
  g.add(glow);

  return { group: g, flame, light, glow };
}

/* ------------------------------------------------------------------ *
 * Bridges & stairs
 * ------------------------------------------------------------------ */
export interface LinkRig {
  group: THREE.Group;
  fixed: THREE.Group;
  broken: THREE.Group;
}

export function buildLink(
  kind: 'bridge' | 'stairs',
  pal: Pal,
  a: Vec3,
  b: Vec3,
  width = 2.2,
): LinkRig {
  const group = new THREE.Group();
  const fixed = new THREE.Group();
  const broken = new THREE.Group();
  const dx = b.x - a.x;
  const dz = b.z - a.z;
  const flatLen = Math.hypot(dx, dz);
  const rise = b.y - a.y;
  const len = Math.hypot(flatLen, rise);
  const ang = Math.atan2(dz, dx);
  const mid = { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2, z: (a.z + b.z) / 2 };
  const deckMat = toonMat('#a9764a', { map: pal.wood, flat: true });
  const stoneMat = toonMat(pal.biome.rock, { map: pal.stone, flat: true });

  if (kind === 'bridge') {
    const deck = mesh(wobble(box(len, 0.22, width), 0.02, 7), deckMat, 0, 0, 0, true);
    const holder = new THREE.Group();
    holder.position.set(mid.x, mid.y - 0.11, mid.z);
    holder.rotation.order = 'YXZ';
    holder.rotation.y = -ang;
    holder.rotation.x = Math.atan2(-rise, flatLen || 0.001);
    holder.add(deck);
    for (const s of [-1, 1]) {
      const rail = mesh(box(len, 0.1, 0.12), deckMat, 0, 0.42, (s * width) / 2);
      holder.add(rail);
      const posts = Math.max(2, Math.round(len / 1.6));
      for (let i = 0; i <= posts; i++) {
        const p = mesh(box(0.13, 0.55, 0.13), deckMat, -len / 2 + (i * len) / posts, 0.2, (s * width) / 2);
        holder.add(p);
      }
    }
    fixed.add(holder);
    // broken: two stubs and a gap
    for (const [t, s] of [[0.16, a], [0.84, b]] as [number, Vec3][]) {
      const stub = mesh(box(len * 0.3, 0.22, width), deckMat, 0, 0, 0, true);
      const h = new THREE.Group();
      h.position.set(a.x + dx * t, a.y + rise * t - 0.11, a.z + dz * t);
      h.rotation.y = -ang;
      h.add(stub);
      const post = mesh(box(0.16, 0.7, 0.16), deckMat, len * 0.14, 0.35, width / 2);
      h.add(post);
      broken.add(h);
      const rubble = buildRock(pal, s.x * 13 + s.z * 7, 0.5);
      rubble.position.set(s.x + dx * (t - 0.5) * 0.4, s.y, s.z + dz * (t - 0.5) * 0.4);
      broken.add(rubble);
    }
  } else {
    const steps = Math.max(3, Math.round(Math.abs(rise) / 0.34) + Math.round(flatLen / 0.9));
    for (let i = 0; i < steps; i++) {
      const t = (i + 0.5) / steps;
      const h = mesh(box(flatLen / steps + 0.16, 0.34, width), i % 2 ? deckMat : stoneMat, 0, 0, 0, true);
      h.position.set(a.x + dx * t, a.y + rise * t - 0.17, a.z + dz * t);
      h.rotation.y = -ang;
      fixed.add(h);
      if (i < Math.floor(steps * 0.35)) {
        const bh = h.clone();
        bh.position.y -= 0.1;
        bh.rotation.z = (i % 2 ? 1 : -1) * 0.06;
        broken.add(bh);
      }
    }
    for (const s of [-1, 1]) {
      const rail = mesh(box(len, 0.1, 0.1), deckMat, 0, 0, 0);
      const h = new THREE.Group();
      h.position.set(mid.x, mid.y + 0.35, mid.z);
      h.rotation.y = -ang;
      h.rotation.order = 'YXZ';
      h.rotation.x = Math.atan2(-rise, flatLen || 0.001);
      rail.position.z = (s * width) / 2;
      h.add(rail);
      fixed.add(h);
    }
    const pile = buildRock(pal, 91, 0.7);
    pile.position.set(a.x + dx * 0.55, a.y + rise * 0.55, a.z + dz * 0.55);
    broken.add(pile);
  }
  group.add(fixed, broken);
  return { group, fixed, broken };
}

/* ------------------------------------------------------------------ *
 * Buildings
 * ------------------------------------------------------------------ */
export function buildBuilding(type: BuildingType, level: number, pal: Pal, seed: number) {
  const g = new THREE.Group();
  const wall = toonMat('#e6d3ae', { map: pal.stone, flat: true });
  const wall2 = toonMat('#d8c19a', { map: pal.stone, flat: true });
  const roofMat = toonMat('#b8563c', { map: pal.cloth, flat: true });
  const woodMat = toonMat(pal.biome.trunk, { map: pal.wood, flat: true });
  const lvl = Math.max(0, level - 1);

  const base = mesh(wobble(box(2.6, 0.28, 2.6), 0.03, seed), toonMat(pal.biome.rock, { map: pal.stone, flat: true }), 0, 0.14, 0, true);
  g.add(base);

  if (type === 'mill') {
    const body = mesh(wobble(box(2.0, 1.5, 1.9), 0.03, seed + 1), wall, 0, 1.03, 0, true);
    g.add(body);
    const roof = mesh(cone(1.75, 0.95, 4), roofMat, 0, 2.2, 0, true);
    roof.rotation.y = Math.PI / 4;
    g.add(roof);
    const tower = mesh(cyl(0.5, 0.55, 1.1, 8), wall2, 1.35, 1.6, 0, true);
    g.add(tower);
    const cap = mesh(cone(0.72, 0.5, 8), roofMat, 1.35, 2.4, 0, true);
    g.add(cap);
    const wheel = new THREE.Group();
    wheel.position.set(1.35, 1.6, 0.75);
    const rim = mesh(new THREE.TorusGeometry(0.62, 0.07, 6, 12), woodMat);
    wheel.add(rim);
    for (let i = 0; i < 6; i++) {
      const spoke = mesh(box(0.09, 1.2, 0.16), woodMat, 0, 0, 0);
      spoke.rotation.z = (i / 6) * Math.PI;
      wheel.add(spoke);
    }
    wheel.name = 'spin';
    g.add(wheel);
    if (lvl > 0) {
      const extra = mesh(wobble(box(1.3, 0.9, 1.3), 0.03, seed + 5), wall2, -1.1, 0.73, 0.9, true);
      g.add(extra);
      const r2 = mesh(cone(1.05, 0.6, 4), roofMat, -1.1, 1.5, 0.9, true);
      r2.rotation.y = Math.PI / 4;
      g.add(r2);
    }
  } else if (type === 'farm') {
    for (let i = 0; i < 3; i++) {
      const bed = mesh(box(2.3, 0.3, 0.62), toonMat('#7a5230', { map: pal.wood, flat: true }), 0, 0.42, -0.85 + i * 0.85, true);
      g.add(bed);
      const cropMat = toonMat(i % 2 ? pal.biome.leaf : '#d8c15a', { flat: true });
      for (let j = 0; j < 7; j++) {
        const c = mesh(cone(0.1, 0.42, 5), cropMat, -0.95 + j * 0.32, 0.72, -0.85 + i * 0.85);
        g.add(c);
      }
    }
    const shed = mesh(wobble(box(1.1, 0.9, 1.1), 0.03, seed + 3), wall, 1.15, 0.73, 0, true);
    g.add(shed);
    const r = mesh(cone(0.95, 0.6, 4), roofMat, 1.15, 1.45, 0, true);
    r.rotation.y = Math.PI / 4;
    g.add(r);
    if (lvl > 0) {
      const fence = toonMat(pal.biome.trunk, { map: pal.wood });
      for (let i = 0; i < 8; i++) {
        const p = mesh(box(0.1, 0.6, 0.1), fence, -1.2 + i * 0.35, 0.58, 1.25);
        g.add(p);
      }
      const rail = mesh(box(2.6, 0.08, 0.08), fence, 0, 0.72, 1.25);
      g.add(rail);
    }
  } else if (type === 'well') {
    const ring = mesh(cyl(0.85, 0.95, 0.8, 10), toonMat(pal.biome.rock, { map: pal.stone, flat: true }), 0, 0.68, 0, true);
    g.add(ring);
    const water = mesh(cyl(0.72, 0.72, 0.05, 10), toonMat('#4fa8c8', { emissive: '#1d5a72', emissiveIntensity: 0.8 }), 0, 0.98, 0);
    g.add(water);
    for (const s of [-1, 1]) {
      const post = mesh(box(0.16, 1.5, 0.16), woodMat, s * 0.7, 1.6, 0, true);
      g.add(post);
    }
    const roof = mesh(cone(1.25, 0.6, 4), roofMat, 0, 2.5, 0, true);
    roof.rotation.y = Math.PI / 4;
    g.add(roof);
    const bucket = mesh(box(0.34, 0.3, 0.34), woodMat, 0, 1.5, 0, true);
    bucket.name = 'bob';
    g.add(bucket);
    if (lvl > 0) {
      const tank = mesh(cyl(0.6, 0.6, 0.9, 8), toonMat('#9fb6c4', { flat: true }), -1.2, 0.73, 0.7, true);
      g.add(tank);
    }
  } else if (type === 'warehouse') {
    const body = mesh(wobble(box(2.5, 1.35, 2.1), 0.03, seed + 2), wall, 0, 0.95, 0, true);
    g.add(body);
    const roof = mesh(box(2.75, 0.16, 2.35), roofMat, 0, 1.68, 0, true);
    roof.rotation.z = 0.16;
    g.add(roof);
    const door = mesh(box(0.9, 1.0, 0.1), woodMat, 0, 0.78, 1.06, true);
    g.add(door);
    for (let i = 0; i < 3; i++) {
      const c = mesh(box(0.5, 0.5, 0.5), toonMat('#a9764a', { map: pal.wood, flat: true }), -0.9 + i * 0.9, 0.53, 1.35, true);
      c.rotation.y = i * 0.3;
      g.add(c);
    }
    if (lvl > 0) {
      const upper = mesh(wobble(box(2.2, 0.8, 1.8), 0.03, seed + 6), wall2, 0, 2.15, 0, true);
      g.add(upper);
      const r2 = mesh(box(2.5, 0.14, 2.1), roofMat, 0, 2.62, 0, true);
      r2.rotation.z = -0.16;
      g.add(r2);
    }
  } else if (type === 'housing') {
    const body = mesh(wobble(box(2.2, 1.25, 1.9), 0.03, seed + 4), wall, 0, 0.9, 0, true);
    g.add(body);
    const roof = mesh(cone(1.85, 1.0, 4), roofMat, 0, 2.0, 0, true);
    roof.rotation.y = Math.PI / 4;
    g.add(roof);
    const chimney = mesh(box(0.3, 0.7, 0.3), toonMat('#8d7f70', { flat: true }), 0.7, 2.1, -0.4, true);
    g.add(chimney);
    const door = mesh(box(0.6, 0.85, 0.1), woodMat, 0, 0.7, 0.98, true);
    g.add(door);
    for (const s of [-1, 1]) {
      const w = mesh(box(0.5, 0.45, 0.08), toonMat('#f2d98a', { emissive: '#8a6a1a', emissiveIntensity: 0.6 }), s * 0.75, 1.1, 0.98);
      g.add(w);
    }
    if (lvl > 0) {
      const wing = mesh(wobble(box(1.4, 1.0, 1.5), 0.03, seed + 8), wall2, -1.5, 0.78, 0.2, true);
      g.add(wing);
      const r2 = mesh(cone(1.3, 0.8, 4), roofMat, -1.5, 1.6, 0.2, true);
      r2.rotation.y = Math.PI / 4;
      g.add(r2);
    }
  } else {
    const body = mesh(wobble(box(2.3, 1.4, 2.0), 0.03, seed + 7), toonMat('#b9a68f', { map: pal.stone, flat: true }), 0, 0.98, 0, true);
    g.add(body);
    const roof = mesh(box(2.6, 0.16, 2.3), toonMat('#6f5b4a', { flat: true }), 0, 1.74, 0, true);
    g.add(roof);
    const forge = mesh(box(0.9, 0.7, 0.8), toonMat('#5c4a3c', { flat: true }), 0, 0.63, 0.9, true);
    g.add(forge);
    const coals = mesh(box(0.6, 0.1, 0.5), toonMat('#ff7a2a', { emissive: '#ff5a10', emissiveIntensity: 2.2 }), 0, 0.98, 0.9);
    g.add(coals);
    const chimney = mesh(cyl(0.28, 0.36, 1.5, 8), toonMat('#8d7f70', { flat: true }), -0.8, 2.3, -0.4, true);
    g.add(chimney);
    const anvil = mesh(box(0.5, 0.3, 0.3), toonMat('#5b6068', { flat: true }), 1.3, 0.44, 0.9, true);
    g.add(anvil);
    if (lvl > 0) {
      const bell = mesh(cone(0.55, 0.8, 8), toonMat('#d9a83c', { flat: true }), 1.3, 1.3, -0.6, true);
      g.add(bell);
      const post = mesh(box(0.14, 1.1, 0.14), woodMat, 1.3, 0.83, -0.6);
      g.add(post);
    }
  }
  return g;
}

export function buildPlotMarker(pal: Pal) {
  const g = new THREE.Group();
  const mat = toonMat('#c9a86a', { map: pal.stone, flat: true, transparent: true, opacity: 0.75 });
  const slab = mesh(wobble(box(2.7, 0.16, 2.7), 0.03, 3), mat, 0, 0.08, 0, true);
  g.add(slab);
  for (const [x, z] of [[-1, -1], [1, -1], [-1, 1], [1, 1]] as [number, number][]) {
    const peg = mesh(box(0.16, 0.5, 0.16), toonMat(pal.biome.trunk, { map: pal.wood }), x * 1.15, 0.3, z * 1.15, true);
    g.add(peg);
  }
  return g;
}

/* ------------------------------------------------------------------ *
 * Workers
 * ------------------------------------------------------------------ */
export interface WorkerRig {
  group: THREE.Group;
  body: THREE.Mesh;
  armL: THREE.Mesh;
  armR: THREE.Mesh;
  legL: THREE.Mesh;
  legR: THREE.Mesh;
  tool: THREE.Mesh;
  ring: THREE.Mesh;
}

export function buildWorker(color: string, seed: number): WorkerRig {
  const rnd = mulberry32(seed);
  const g = new THREE.Group();
  const skin = toonMat('#f0c39a', { flat: true });
  const cloth = toonMat(color, { flat: true });
  const dark = toonMat('#4a3a2c', { flat: true });

  const legL = mesh(cyl(0.09, 0.09, 0.34, 6), dark, -0.11, 0.17, 0);
  const legR = mesh(cyl(0.09, 0.09, 0.34, 6), dark, 0.11, 0.17, 0);
  const body = mesh(cyl(0.2, 0.24, 0.42, 8), cloth, 0, 0.55, 0, true);
  const head = mesh(sph(0.19, 10), skin, 0, 0.92, 0, true);
  const hat = mesh(cone(0.27, 0.22, 8), toonMat('#7a4a2c', { flat: true }), 0, 1.06, 0, true);
  const brim = mesh(cyl(0.3, 0.3, 0.04, 10), toonMat('#8a5a34', { flat: true }), 0, 0.99, 0);
  const armL = mesh(cyl(0.07, 0.07, 0.36, 6), cloth, -0.26, 0.58, 0);
  const armR = mesh(cyl(0.07, 0.07, 0.36, 6), cloth, 0.26, 0.58, 0);
  const tool = mesh(box(0.09, 0.62, 0.09), toonMat('#a9764a', { map: null, flat: true }), 0.3, 0.6, 0.05);
  tool.rotation.z = -0.5;
  const headband = mesh(cyl(0.2, 0.2, 0.06, 10), toonMat('#e8e2cf', { flat: true }), 0, 0.86, 0);

  g.add(legL, legR, body, head, hat, brim, armL, armR, tool, headband);
  g.rotation.y = rnd() * Math.PI * 2;

  const ring = mesh(
    new THREE.RingGeometry(0.34, 0.46, 20),
    new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.5, side: THREE.DoubleSide, depthWrite: false }),
    0,
    0.03,
    0,
  );
  ring.rotation.x = -Math.PI / 2;
  ring.visible = false;
  g.add(ring);

  return { group: g, body, armL, armR, legL, legR, tool, ring };
}
