import type { Vec3 } from './types';

export interface NavCell {
  ix: number;
  iy: number;
  iz: number;
  x: number;
  y: number;
  z: number;
  open: boolean;
  /** link id when this cell belongs to a bridge / stair run */
  link?: string;
}

const key = (ix: number, iy: number, iz: number) => `${ix}|${iy}|${iz}`;

/**
 * Coarse 3D walkable grid. Platforms contribute flat sheets of cells at their
 * surface height; repaired bridges and stairs contribute ramps of cells that
 * bridge the height gap. A* runs over 6-neighbourhood so ramps work naturally.
 */
export class NavGrid {
  cells = new Map<string, NavCell>();
  blocked = new Set<string>();

  add(ix: number, iy: number, iz: number, open = true, link?: string) {
    const k = key(ix, iy, iz);
    const prev = this.cells.get(k);
    if (prev) {
      prev.open = prev.open || open;
      if (link) prev.link = link;
      return prev;
    }
    const c: NavCell = { ix, iy, iz, x: ix + 0.5, y: iy, z: iz + 0.5, open, link };
    this.cells.set(k, c);
    return c;
  }

  at(x: number, y: number, z: number) {
    return this.cells.get(key(Math.floor(x), Math.round(y), Math.floor(z)));
  }

  cell(ix: number, iy: number, iz: number) {
    return this.cells.get(key(ix, iy, iz));
  }

  isOpen(ix: number, iy: number, iz: number) {
    const c = this.cells.get(key(ix, iy, iz));
    return !!c && c.open && !this.blocked.has(key(ix, iy, iz));
  }

  /** Open cells inside an axis-aligned rect at a given height. */
  sheet(minX: number, maxX: number, minZ: number, maxZ: number, y: number, inset = 0.45) {
    const x0 = Math.ceil(minX + inset);
    const x1 = Math.floor(maxX - inset);
    const z0 = Math.ceil(minZ + inset);
    const z1 = Math.floor(maxZ - inset);
    const iy = Math.round(y);
    for (let ix = x0; ix <= x1; ix++) for (let iz = z0; iz <= z1; iz++) this.add(ix, iy, iz, true);
  }

  /** Ramp of cells between two world points (stairs / bridge deck). */
  ramp(a: Vec3, b: Vec3, link: string, halfWidth = 0.7) {
    const dist = Math.hypot(b.x - a.x, b.y - a.y, b.z - a.z);
    const steps = Math.max(2, Math.ceil(dist / 0.4));
    for (let i = 0; i <= steps; i++) {
      const t = i / steps;
      const x = a.x + (b.x - a.x) * t;
      const y = a.y + (b.y - a.y) * t;
      const z = a.z + (b.z - a.z) * t;
      const iy = Math.round(y);
      const ix = Math.floor(x);
      const iz = Math.floor(z);
      this.add(ix, iy, iz, true, link);
      if (halfWidth > 0.5) {
        const dx = b.x - a.x;
        const dz = b.z - a.z;
        const len = Math.hypot(dx, dz) || 1;
        const px = -dz / len;
        const pz = dx / len;
        this.add(ix + Math.round(px * halfWidth), iy, iz + Math.round(pz * halfWidth), true, link);
      }
    }
  }

  /** Nearest open cell to a world point, searching outward. */
  nearestOpen(x: number, y: number, z: number, maxR = 12): NavCell | null {
    const cx = Math.floor(x);
    const cy = Math.round(y);
    const cz = Math.floor(z);
    if (this.isOpen(cx, cy, cz)) return this.cell(cx, cy, cz)!;
    for (let r = 1; r <= maxR; r++) {
      let best: NavCell | null = null;
      let bestD = Infinity;
      for (let dx = -r; dx <= r; dx++) {
        for (let dz = -r; dz <= r; dz++) {
          for (let dy = -r; dy <= r; dy++) {
            const c = this.cell(cx + dx, cy + dy, cz + dz);
            if (!c || !c.open || this.blocked.has(key(c.ix, c.iy, c.iz))) continue;
            const d = (c.x - x) ** 2 + (c.y - y) ** 2 * 1.6 + (c.z - z) ** 2;
            if (d < bestD) {
              bestD = d;
              best = c;
            }
          }
        }
      }
      if (best) return best;
    }
    return null;
  }

  private clearLine(a: Vec3, b: Vec3) {
    const dist = Math.hypot(b.x - a.x, b.y - a.y, b.z - a.z);
    const steps = Math.max(2, Math.ceil(dist / 0.3));
    for (let i = 0; i <= steps; i++) {
      const t = i / steps;
      const x = a.x + (b.x - a.x) * t;
      const y = a.y + (b.y - a.y) * t;
      const z = a.z + (b.z - a.z) * t;
      const ix = Math.floor(x);
      const iy = Math.round(y);
      const iz = Math.floor(z);
      if (!this.isOpen(ix, iy, iz)) return false;
    }
    return true;
  }

  findPath(from: Vec3, to: Vec3): Vec3[] | null {
    const start = this.nearestOpen(from.x, from.y, from.z, 4);
    const goal = this.nearestOpen(to.x, to.y, to.z, 8);
    if (!start || !goal) return null;
    const sk = key(start.ix, start.iy, start.iz);
    const gk = key(goal.ix, goal.iy, goal.iz);
    if (sk === gk) return [{ x: goal.x, y: goal.y, z: goal.z }];

    const open: NavCell[] = [start];
    const gScore = new Map<string, number>([[sk, 0]]);
    const cameFrom = new Map<string, string>();
    const fScore = new Map<string, number>([[sk, 0]]);
    const h = (c: NavCell) =>
      Math.abs(c.ix - goal.ix) + Math.abs(c.iz - goal.iz) + Math.abs(c.iy - goal.iy) * 1.2;

    const closed = new Set<string>();
    while (open.length) {
      let bi = 0;
      for (let i = 1; i < open.length; i++) {
        if ((fScore.get(key(open[i].ix, open[i].iy, open[i].iz)) ?? Infinity) <
          (fScore.get(key(open[bi].ix, open[bi].iy, open[bi].iz)) ?? Infinity))
          bi = i;
      }
      const cur = open.splice(bi, 1)[0];
      const ck = key(cur.ix, cur.iy, cur.iz);
      if (ck === gk) break;
      closed.add(ck);
      const nb: [number, number, number][] = [
        [1, 0, 0],
        [-1, 0, 0],
        [0, 0, 1],
        [0, 0, -1],
        [0, 1, 0],
        [0, -1, 0],
      ];
      for (const [dx, dy, dz] of nb) {
        const n = this.cell(cur.ix + dx, cur.iy + dy, cur.iz + dz);
        if (!n || !n.open || this.blocked.has(key(n.ix, n.iy, n.iz))) continue;
        const nk = key(n.ix, n.iy, n.iz);
        if (closed.has(nk)) continue;
        const step = Math.abs(dy) > 0 ? 1.35 : 1;
        const tentative = (gScore.get(ck) ?? Infinity) + step;
        if (tentative < (gScore.get(nk) ?? Infinity)) {
          cameFrom.set(nk, ck);
          gScore.set(nk, tentative);
          fScore.set(nk, tentative + h(n));
          if (!open.includes(n)) open.push(n);
        }
      }
    }

    if (!cameFrom.has(gk) && sk !== gk) return null;
    const raw: Vec3[] = [];
    let k: string | undefined = gk;
    while (k) {
      const [ax, ay, az] = k.split('|').map(Number);
      const c = this.cell(ax, ay, az)!;
      raw.push({ x: c.x, y: c.y, z: c.z });
      k = cameFrom.get(k);
    }
    raw.reverse();

    // string-pull: drop waypoints we can walk straight past
    const out: Vec3[] = [];
    let i = 0;
    while (i < raw.length) {
      let j = raw.length - 1;
      for (; j > i + 1; j--) {
        if (this.clearLine(raw[i], raw[j])) break;
      }
      out.push(raw[j]);
      i = j;
    }
    return out.length ? out : [raw[raw.length - 1]];
  }
}
