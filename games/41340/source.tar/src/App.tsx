import { useCallback, useEffect, useRef, useState } from 'react';
import { Game } from './game/engine';
import { LEVELS } from './game/levels';
import type { Snapshot } from './game/types';
import { Hud } from './ui/Hud';

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const gameRef = useRef<Game | null>(null);
  const [snap, setSnap] = useState<Snapshot | null>(null);
  const [levelIndex, setLevelIndex] = useState(0);
  const [runId, setRunId] = useState(0);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    let game: Game | null = null;
    try {
      game = new Game(canvas, levelIndex, setSnap);
      gameRef.current = game;
    } catch (err) {
      console.error('Failed to start the diorama', err);
      return;
    }
    const resize = () => {
      const w = canvas.clientWidth || window.innerWidth;
      const h = canvas.clientHeight || window.innerHeight;
      game?.resize(w, h);
    };
    resize();
    const ro = new ResizeObserver(resize);
    ro.observe(canvas);
    window.addEventListener('resize', resize);
    setReady(true);
    return () => {
      ro.disconnect();
      window.removeEventListener('resize', resize);
      game?.dispose();
      gameRef.current = null;
    };
  }, [levelIndex, runId]);

  const restart = useCallback(() => {
    setSnap(null);
    setReady(false);
    setRunId((r) => r + 1);
  }, []);

  const next = useCallback(() => {
    setSnap(null);
    setReady(false);
    setLevelIndex((i) => (i + 1) % LEVELS.length);
    setRunId((r) => r + 1);
  }, []);

  const jump = useCallback((i: number) => {
    setSnap(null);
    setReady(false);
    setLevelIndex(i);
    setRunId((r) => r + 1);
  }, []);

  return (
    <div className="relative h-screen w-screen overflow-hidden bg-[#14100c]">
      <canvas
        ref={canvasRef}
        className="absolute inset-0 block h-full w-full cursor-crosshair touch-none"
        aria-label="Isometric diorama of the frontier. Click interactables to send workers."
      />

      {snap && (
        <Hud snap={snap} game={gameRef.current} onRestart={restart} onNext={next} />
      )}

      {/* chapter switcher */}
      <div className="absolute bottom-3 right-3 z-30 flex items-center gap-1.5">
        {LEVELS.map((l, i) => (
          <button
            key={l.id}
            onClick={() => jump(i)}
            className={`panel px-2.5 py-1 text-[11px] font-extrabold transition-transform hover:-translate-y-0.5 ${
              i === levelIndex ? 'ring-2 ring-[#e8c05a]' : 'opacity-70'
            }`}
            aria-current={i === levelIndex}
          >
            {i + 1} · {l.name.split(' ')[0]}
          </button>
        ))}
      </div>

      {!ready && (
        <div className="absolute inset-0 flex items-center justify-center bg-[#14100c]">
          <div className="panel px-6 py-4 text-center">
            <div className="font-display text-[20px] font-bold">Painting the diorama…</div>
            <div className="text-[12px] opacity-70">mixing toon bands and brush strokes</div>
          </div>
        </div>
      )}
    </div>
  );
}
