import GameView from './components/GameView';

export default function App() {
  return (
    <div className="flex min-h-screen w-full flex-col items-center justify-center bg-black p-3">
      <div className="flex h-[calc(100vh-1.5rem)] w-full items-center justify-center">
        <GameView />
      </div>
    </div>
  );
}
