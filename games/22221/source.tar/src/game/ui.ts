// ---------------------------------------------------------------------------
// HUD + full-screen overlays, all drawn inside the 384x216 buffer.
// ---------------------------------------------------------------------------

import { MOTIFS, PAL, VH, VW, clamp } from './core';
import { UNLOCKS } from './content';
import { drawText, drawTextC, textWidth } from './font';
import { fillDither } from './dither';
import { Game } from './state';

type C2D = CanvasRenderingContext2D;

const HEART = ['.##.##.', '#######', '#######', '.#####.', '..###..', '...#...'];

function bitmap(ctx: C2D, rows: string[], x: number, y: number, col: string) {
  ctx.fillStyle = col;
  for (let r = 0; r < rows.length; r++)
    for (let c = 0; c < rows[r].length; c++) if (rows[r][c] === '#') ctx.fillRect(x + c, y + r, 1, 1);
}

export function panel(ctx: C2D, x: number, y: number, w: number, h: number, level = 2) {
  ctx.fillStyle = PAL.black;
  ctx.fillRect(x, y, w, h);
  fillDither(ctx, 'bayer', level, x, y, w, h);
  ctx.fillStyle = PAL.white;
  ctx.fillRect(x, y, w, 1);
  ctx.fillRect(x, y + h - 1, w, 1);
  ctx.fillRect(x, y, 1, h);
  ctx.fillRect(x + w - 1, y, 1, h);
}

function frame(ctx: C2D, x: number, y: number, w: number, h: number, col: string) {
  ctx.fillStyle = col;
  ctx.fillRect(x, y, w, 1);
  ctx.fillRect(x, y + h - 1, w, 1);
  ctx.fillRect(x, y, 1, h);
  ctx.fillRect(x + w - 1, y, 1, h);
}

function shadowText(ctx: C2D, s: string, x: number, y: number, col: string, scale = 1) {
  drawText(ctx, s, x + scale, y + scale, PAL.black, scale);
  drawText(ctx, s, x, y, col, scale);
}

function shadowTextC(ctx: C2D, s: string, cx: number, y: number, col: string, scale = 1) {
  const w = textWidth(s, scale);
  shadowText(ctx, s, Math.round(cx - w / 2), y, col, scale);
}

// ---------------------------------------------------------------------------
export function drawHud(ctx: C2D, g: Game) {
  const p = g.player;
  // life
  for (let i = 0; i < p.stats.maxHp; i++) {
    const filled = i < p.hp;
    const x = 6 + i * 9;
    bitmap(ctx, HEART, x, 6, filled ? PAL.red : PAL.g2);
    if (filled) {
      ctx.fillStyle = PAL.redMid;
      ctx.fillRect(x + 1, 8, 5, 1);
    }
  }
  // dash charges
  for (let i = 0; i < p.stats.dashCharges; i++) {
    const x = 6 + i * 8;
    const ready = i < p.dashCharges;
    const col = ready ? PAL.white : PAL.g2;
    ctx.fillStyle = col;
    ctx.fillRect(x, 15, 2, 3);
    ctx.fillRect(x + 2, 14, 2, 5);
    ctx.fillRect(x + 4, 15, 2, 3);
    if (!ready && i === p.dashCharges) {
      const k = 1 - clamp(p.dashCd / p.stats.dashCd, 0, 1);
      ctx.fillStyle = PAL.g4;
      ctx.fillRect(x, 19, Math.round(6 * k), 1);
    }
  }

  // coins + motif
  const coins = String(Math.round(g.coins * p.stats.coinMult));
  drawText(ctx, coins, VW - 8 - textWidth(coins, 1), 6, PAL.white);
  drawText(ctx, 'COIN', VW - 14 - textWidth(coins, 1), 6, PAL.g4);

  const m = MOTIFS[g.motif];
  const label = `${m.name}  ROOM ${Math.min(3, g.roomIndex + 1)}/3`;
  drawText(ctx, label, VW - 8 - textWidth(label, 1), 15, PAL.g5);

  // motif ladder
  for (let i = 0; i < 4; i++) {
    const x = 6 + i * 14;
    const done = i < g.motif;
    const cur = i === g.motif;
    ctx.fillStyle = done ? PAL.white : cur ? PAL.g5 : PAL.g2;
    ctx.fillRect(x, 22, 10, 3);
    if (cur) {
      ctx.fillStyle = PAL.white;
      ctx.fillRect(x + 4, 21, 2, 5);
    }
  }

  // powerups
  const ids = Object.keys(p.powerups);
  let bx = 6;
  for (const id of ids) {
    const n = p.powerups[id];
    const ch = id.slice(0, 3).toUpperCase();
    ctx.fillStyle = PAL.black;
    ctx.fillRect(bx, VH - 12, 20, 9);
    ctx.fillStyle = PAL.g2;
    ctx.fillRect(bx, VH - 12, 20, 1);
    ctx.fillRect(bx, VH - 12, 1, 9);
    ctx.fillRect(bx + 19, VH - 12, 1, 9);
    ctx.fillRect(bx, VH - 4, 20, 1);
    drawText(ctx, ch, bx + 3, VH - 10, PAL.white, 1);
    if (n > 1) drawText(ctx, String(n), bx + 15, VH - 10, PAL.g5, 1);
    bx += 22;
  }

  // boss bar
  const boss = g.boss;
  if (boss && boss.hp > 0) {
    const bw = 200;
    const bx2 = Math.round((VW - bw) / 2);
    drawTextC(ctx, boss.boss!.name, VW / 2, 6, PAL.white, 1);
    ctx.fillStyle = PAL.black;
    ctx.fillRect(bx2, 15, bw, 5);
    ctx.fillStyle = PAL.g2;
    ctx.fillRect(bx2, 15, bw, 5);
    const frac = clamp(boss.hp / boss.maxHp, 0, 1);
    ctx.fillStyle = PAL.white;
    ctx.fillRect(bx2 + 1, 16, Math.round((bw - 2) * frac), 3);
    frame(ctx, bx2, 15, bw, 5, PAL.g5);
    for (let i = 1; i < 3; i++) {
      const gx = bx2 + Math.round((bw / 3) * i);
      ctx.fillStyle = PAL.black;
      ctx.fillRect(gx, 15, 1, 5);
    }
    drawText(ctx, `PHASE ${boss.boss!.phase}/3`, bx2 + bw + 4, 16, PAL.g4, 1);
  }

  // banner
  if (g.banner) {
    const t = g.banner.t;
    const a = clamp(t > 1.6 ? (2.8 - t) / 1.2 : t / 0.5, 0, 1);
    ctx.globalAlpha = a;
    shadowTextC(ctx, g.banner.text, VW / 2, 62, PAL.white, 2);
    shadowTextC(ctx, g.banner.sub, VW / 2, 78, PAL.g5, 1);
    ctx.globalAlpha = 1;
  }

  // enemies remaining
  if (!g.room.cleared && g.enemies.length > 0 && g.room.kind === 'combat') {
    const s = `FOES ${g.enemies.length}`;
    drawText(ctx, s, VW - 8 - textWidth(s, 1), VH - 12, PAL.g4, 1);
  }
}

// ---------------------------------------------------------------------------
function bigTitle(ctx: C2D, s: string, cx: number, y: number, scale: number) {
  const w = textWidth(s, scale);
  ctx.globalAlpha = 0.25;
  shadowText(ctx, s, Math.round(cx - w / 2) - 2, y - 2, PAL.g3, scale);
  ctx.globalAlpha = 1;
  shadowText(ctx, s, Math.round(cx - w / 2), y, PAL.white, scale);
}

export function drawTitle(ctx: C2D, g: Game) {
  ctx.fillStyle = PAL.black;
  ctx.fillRect(0, 0, VW, VH);
  // decorative dither field
  for (let y = 0; y < VH; y += 8) fillDither(ctx, 'bayer', 1 + (y % 3), 0, y, VW, 4);
  for (let i = 0; i < 4; i++) {
    const x = 40 + i * 88;
    fillDither(ctx, 'checker', 3, x, 150, 60, 40);
  }
  bigTitle(ctx, 'NULLROOM', VW / 2, 34, 5);
  shadowTextC(ctx, 'A 1-BIT DESCENT IN FOUR MOTIFS', VW / 2, 76, PAL.g5, 1);

  panel(ctx, 60, 84, 264, 62, 1);
  drawTextC(ctx, 'WASD  MOVE', 192, 91, PAL.white, 1);
  drawTextC(ctx, 'ARROWS  FIRE EIGHT-WAY', 192, 101, PAL.white, 1);
  drawTextC(ctx, 'SPACE  DASH, INVULNERABLE', 192, 111, PAL.white, 1);
  drawTextC(ctx, 'P  PAUSE      M  MUTE', 192, 121, PAL.g5, 1);
  drawTextC(ctx, 'RED MEANS IT CAN KILL YOU', 192, 131, PAL.red, 1);

  const blink = Math.floor(g.time * 2) % 2 === 0;
  if (blink) shadowTextC(ctx, 'PRESS SPACE TO DESCEND', VW / 2, 158, PAL.white, 1);
  shadowTextC(ctx, 'PRESS U FOR UNLOCKS', VW / 2, 172, PAL.g5, 1);
  drawTextC(ctx, `BANKED COIN ${g.save.bank}     RUNS ${g.save.runs}     WINS ${g.save.wins}`, VW / 2, 196, PAL.g4, 1);
}

// ---------------------------------------------------------------------------
export function drawShop(ctx: C2D, g: Game) {
  ctx.fillStyle = PAL.black;
  ctx.fillRect(0, 0, VW, VH);
  for (let y = 0; y < VH; y += 6) fillDither(ctx, 'noise', 1, 0, y, VW, 3);
  bigTitle(ctx, 'UNLOCKS', VW / 2, 8, 3);
  drawText(ctx, `BANKED COIN ${g.save.bank}`, 8, 30, PAL.white, 1);
  drawText(ctx, 'W/S SELECT   SPACE BUY   U BACK', VW - 8 - textWidth('W/S SELECT   SPACE BUY   U BACK', 1), 30, PAL.g4, 1);

  const rows = UNLOCKS.length;
  const top = 42;
  const rh = 15;
  const scroll = clamp(g.shopIdx - 1, 0, Math.max(0, rows - 11));
  for (let i = 0; i < rows; i++) {
    const u = UNLOCKS[i];
    const y = top + (i - scroll) * rh;
    if (y < 38 || y > VH - 12) continue;
    const lvl = g.save.unlocks[u.id] ?? 0;
    const max = u.costs.length;
    const sel = i === g.shopIdx;
    const cost = lvl < max ? u.costs[lvl] : 0;
    const afford = cost > 0 && g.save.bank >= cost;
    if (sel) fillDither(ctx, 'bayer', 4, 8, y - 2, VW - 16, rh);
    drawText(ctx, u.name, 14, y, sel ? PAL.white : PAL.g5, 1);
    drawText(ctx, u.desc, 130, y, sel ? PAL.g5 : PAL.g3, 1);
    for (let k = 0; k < max; k++) {
      const px0 = VW - 18 - (max - k) * 7;
      ctx.fillStyle = k < lvl ? PAL.white : PAL.g2;
      ctx.fillRect(px0, y, 5, 5);
    }
    drawText(
      ctx,
      lvl >= max ? 'MAXED' : `${cost}`,
      VW - 18 - (max + 1) * 7 - 26,
      y,
      lvl >= max ? PAL.g3 : afford ? PAL.white : PAL.g3,
      1,
    );
  }
  if (g.lastPickups > 0)
    drawTextC(ctx, `LAST RUN BANKED ${g.lastPickups} COIN`, VW / 2, VH - 10, PAL.g4, 1);
}

// ---------------------------------------------------------------------------
export function drawDraft(ctx: C2D, g: Game) {
  ctx.globalAlpha = 0.82;
  ctx.fillStyle = PAL.black;
  ctx.fillRect(0, 0, VW, VH);
  ctx.globalAlpha = 1;
  for (let y = 0; y < VH; y += 4) fillDither(ctx, 'bayer', 1, 0, y, VW, 2);
  shadowTextC(ctx, 'DRAFT A POWER-UP', VW / 2, 16, PAL.white, 2);
  shadowTextC(ctx, 'ARROWS SELECT   SPACE CONFIRM', VW / 2, 34, PAL.g5, 1);

  const n = g.draft.length;
  const cw = 108;
  const gap = 12;
  const total = n * cw + (n - 1) * gap;
  const x0 = Math.round((VW - total) / 2);
  for (let i = 0; i < n; i++) {
    const p = g.draft[i];
    const x = x0 + i * (cw + gap);
    const sel = i === g.draftIdx;
    const y = 56;
    const h = 96;
    panel(ctx, x, y, cw, h, sel ? 4 : 1);
    if (sel) frame(ctx, x - 2, y - 2, cw + 4, h + 4, PAL.white);
    // icon block
    fillDither(ctx, 'checker', sel ? 10 : 5, x + 8, y + 8, 30, 30);
    const ch = p.name[0];
    drawText(ctx, ch, x + 20, y + 18, PAL.black, 3);
    drawText(ctx, p.name, x + 46, y + 12, sel ? PAL.white : PAL.g5, 1);
    const lvl = g.player.powerups[p.id] ?? 0;
    if (lvl > 0) drawText(ctx, `RANK ${lvl}`, x + 46, y + 22, PAL.g4, 1);
    // wrapped description
    const words = p.desc.split(' ');
    let line = '';
    let ly = y + 46;
    for (const w of words) {
      const test = line ? line + ' ' + w : w;
      if (textWidth(test, 1) > cw - 16) {
        drawText(ctx, line, x + 8, ly, sel ? PAL.g5 : PAL.g3, 1);
        ly += 9;
        line = w;
      } else line = test;
    }
    if (line) drawText(ctx, line, x + 8, ly, sel ? PAL.g5 : PAL.g3, 1);
    drawText(ctx, `${p.max} RANKS MAX`, x + 8, y + h - 12, PAL.g3, 1);
  }
}

// ---------------------------------------------------------------------------
export function drawDeath(ctx: C2D, g: Game) {
  ctx.globalAlpha = 0.86;
  ctx.fillStyle = PAL.black;
  ctx.fillRect(0, 0, VW, VH);
  ctx.globalAlpha = 1;
  for (let y = 0; y < VH; y += 3) fillDither(ctx, 'noise', 2, 0, y, VW, 2);
  bigTitle(ctx, 'YOU DIED', VW / 2, 40, 4);
  const m = MOTIFS[g.motif];
  const lines = [
    `MOTIF ${g.motif + 1} OF 4  -  ${m.name}`,
    `ROOM ${Math.min(3, g.roomIndex + 1)} OF 3`,
    `FOES FELLED  ${g.kills}`,
    `TIME  ${Math.floor(g.time / 60)}:${String(Math.floor(g.time % 60)).padStart(2, '0')}`,
  ];
  lines.forEach((l, i) => shadowTextC(ctx, l, VW / 2, 78 + i * 11, PAL.g5, 1));
  shadowTextC(ctx, `${g.lastPickups} COIN BANKED`, VW / 2, 128, PAL.white, 2);
  shadowTextC(ctx, 'COIN IS THE ONLY THING THAT CARRIES OVER', VW / 2, 148, PAL.g4, 1);
  if (Math.floor(g.time * 2) % 2 === 0) shadowTextC(ctx, 'SPACE  UNLOCKS', VW / 2, 176, PAL.white, 1);
  drawTextC(ctx, `BANK ${g.save.bank}`, VW / 2, 196, PAL.g4, 1);
}

export function drawVictory(ctx: C2D, g: Game) {
  ctx.globalAlpha = 0.9;
  ctx.fillStyle = PAL.black;
  ctx.fillRect(0, 0, VW, VH);
  ctx.globalAlpha = 1;
  for (let y = 0; y < VH; y += 4) fillDither(ctx, 'bayer', 2, 0, y, VW, 3);
  bigTitle(ctx, 'THE ROOM IS QUIET', VW / 2, 30, 3);
  shadowTextC(ctx, 'ALL FOUR MOTIFS CROSSED', VW / 2, 54, PAL.g5, 1);
  const lines = [
    `FOES FELLED  ${g.kills}`,
    `TIME  ${Math.floor(g.time / 60)}:${String(Math.floor(g.time % 60)).padStart(2, '0')}`,
    `POWER-UPS  ${Object.keys(g.player.powerups).length}`,
  ];
  lines.forEach((l, i) => shadowTextC(ctx, l, VW / 2, 82 + i * 11, PAL.g5, 1));
  shadowTextC(ctx, `${g.lastPickups} COIN BANKED`, VW / 2, 130, PAL.white, 2);
  if (Math.floor(g.time * 2) % 2 === 0) shadowTextC(ctx, 'SPACE  UNLOCKS', VW / 2, 170, PAL.white, 1);
  drawTextC(ctx, `BANK ${g.save.bank}`, VW / 2, 196, PAL.g4, 1);
}

export function drawPause(ctx: C2D) {
  ctx.globalAlpha = 0.7;
  ctx.fillStyle = PAL.black;
  ctx.fillRect(0, 0, VW, VH);
  ctx.globalAlpha = 1;
  bigTitle(ctx, 'PAUSED', VW / 2, 90, 3);
  shadowTextC(ctx, 'P TO RESUME', VW / 2, 120, PAL.g5, 1);
}
