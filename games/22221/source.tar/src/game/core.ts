// ---------------------------------------------------------------------------
// CORE: resolution, palette, math, rng, shared types
// 1-bit aesthetic: white/grey dither on black. RED is reserved for hazards
// and life (player hearts, enemy projectiles, telegraphs).
// ---------------------------------------------------------------------------

export const VW = 384;
export const VH = 216;
export const TILE = 12;

export const PAL = {
  black: '#000000',
  g1: '#111111',
  g2: '#262626',
  g3: '#454545',
  g4: '#6a6a6a',
  g5: '#9a9a9a',
  white: '#ffffff',
  red: '#ff2f2f',
  redMid: '#c01c1c',
  redDark: '#6b0f0f',
};

// --- math -------------------------------------------------------------------
export const clamp = (v: number, a: number, b: number) => (v < a ? a : v > b ? b : v);
export const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
export const dist = (ax: number, ay: number, bx: number, by: number) =>
  Math.hypot(ax - bx, ay - by);
export const dist2 = (ax: number, ay: number, bx: number, by: number) => {
  const dx = ax - bx,
    dy = ay - by;
  return dx * dx + dy * dy;
};
export const TAU = Math.PI * 2;

export function angDiff(a: number, b: number) {
  let d = (b - a) % TAU;
  if (d > Math.PI) d -= TAU;
  if (d < -Math.PI) d += TAU;
  return d;
}

// --- rng --------------------------------------------------------------------
export class RNG {
  private s: number;
  constructor(seed: number) {
    this.s = seed >>> 0 || 1;
  }
  next() {
    this.s = (this.s + 0x6d2b79f5) >>> 0;
    let t = this.s;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  }
  range(a: number, b: number) {
    return a + this.next() * (b - a);
  }
  int(a: number, b: number) {
    return Math.floor(this.range(a, b + 1));
  }
  chance(p: number) {
    return this.next() < p;
  }
  pick<T>(arr: T[]): T {
    return arr[Math.floor(this.next() * arr.length) % arr.length];
  }
  shuffle<T>(arr: T[]): T[] {
    const a = arr.slice();
    for (let i = a.length - 1; i > 0; i--) {
      const j = Math.floor(this.next() * (i + 1));
      [a[i], a[j]] = [a[j], a[i]];
    }
    return a;
  }
}

// --- tiles ------------------------------------------------------------------
export const T_FLOOR = 0;
export const T_WALL = 1;
export const T_DOOR = 2; // open, passable
export const T_LOCK = 3; // closed door, solid

export interface Door {
  tx: number;
  ty: number;
  side: 'n' | 's' | 'e' | 'w';
  kind: 'entry' | 'exit';
  open: boolean;
}

export interface Room {
  w: number;
  h: number;
  tiles: Uint8Array;
  motif: number;
  kind: 'combat' | 'boss';
  doors: Door[];
  spawns: { x: number; y: number; type: string }[];
  cleared: boolean;
  bg: HTMLCanvasElement | null;
  label: string;
}

export function tileAt(r: Room, tx: number, ty: number): number {
  if (tx < 0 || ty < 0 || tx >= r.w || ty >= r.h) return T_WALL;
  return r.tiles[ty * r.w + tx];
}
export function solidAt(r: Room, tx: number, ty: number): boolean {
  const t = tileAt(r, tx, ty);
  return t === T_WALL || t === T_LOCK;
}
export function circleHitsWall(r: Room, x: number, y: number, rad: number): boolean {
  const x0 = Math.floor((x - rad) / TILE);
  const x1 = Math.floor((x + rad) / TILE);
  const y0 = Math.floor((y - rad) / TILE);
  const y1 = Math.floor((y + rad) / TILE);
  for (let ty = y0; ty <= y1; ty++)
    for (let tx = x0; tx <= x1; tx++) {
      if (!solidAt(r, tx, ty)) continue;
      const cx = clamp(x, tx * TILE, tx * TILE + TILE);
      const cy = clamp(y, ty * TILE, ty * TILE + TILE);
      if (dist2(x, y, cx, cy) < rad * rad) return true;
    }
  return false;
}

export interface Body {
  x: number;
  y: number;
  vx: number;
  vy: number;
  r: number;
}

/** Axis-separated movement with wall resolution. Returns collision flags. */
export function moveBody(r: Room, b: Body, dt: number) {
  let hitX = false,
    hitY = false;
  const nx = b.x + b.vx * dt;
  if (circleHitsWall(r, nx, b.y, b.r)) {
    hitX = true;
    b.vx = 0;
  } else b.x = nx;
  const ny = b.y + b.vy * dt;
  if (circleHitsWall(r, b.x, ny, b.r)) {
    hitY = true;
    b.vy = 0;
  } else b.y = ny;
  return { hitX, hitY };
}

// --- stats / player ---------------------------------------------------------
export interface Stats {
  maxHp: number;
  speed: number;
  fireRate: number;
  dmg: number;
  proj: number;
  spread: number;
  bulletSpeed: number;
  bulletLife: number;
  pierce: number;
  homing: number;
  ricochet: number;
  magnet: number;
  lifesteal: number;
  aura: number;
  slowBullets: number;
  dashCharges: number;
  dashCd: number;
  coinMult: number;
}

export function baseStats(): Stats {
  return {
    maxHp: 5,
    speed: 82,
    fireRate: 5.2,
    dmg: 1,
    proj: 1,
    spread: 0,
    bulletSpeed: 210,
    bulletLife: 0.85,
    pierce: 0,
    homing: 0,
    ricochet: 0,
    magnet: 34,
    lifesteal: 0,
    aura: 0,
    slowBullets: 1,
    dashCharges: 1,
    dashCd: 0.72,
    coinMult: 1,
  };
}

export interface Player {
  x: number;
  y: number;
  vx: number;
  vy: number;
  r: number;
  hp: number;
  aim: number;
  fireCd: number;
  dashCd: number;
  dashCharges: number;
  dashT: number;
  dashAng: number;
  iframe: number;
  hitFlash: number;
  anim: number;
  stats: Stats;
  powerups: Record<string, number>;
  ghosts: { x: number; y: number; a: number; t: number }[];
}

// --- projectiles ------------------------------------------------------------
export interface Bullet {
  x: number;
  y: number;
  vx: number;
  vy: number;
  r: number;
  dmg: number;
  life: number;
  friendly: boolean;
  pierce: number;
  hit: number[];
  homing: number;
  ricochet: number;
  kind: 'bolt' | 'orb' | 'shard' | 'wave';
  ang: number;
  spin: number;
}

export interface Beam {
  x: number;
  y: number;
  ang: number;
  len: number;
  w: number;
  t: number;
  dur: number;
  tele: number;
  active: boolean;
}

export interface Telegraph {
  kind: 'line' | 'ring' | 'circle' | 'wedge' | 'dots';
  t: number;
  dur: number;
  ang: number;
  len: number;
  rad: number;
  x: number;
  y: number;
  n: number;
}

export interface Enemy {
  id: number;
  type: string;
  x: number;
  y: number;
  vx: number;
  vy: number;
  r: number;
  hp: number;
  maxHp: number;
  t: number;
  state: string;
  timer: number;
  ang: number;
  spin: number;
  flash: number;
  tele: Telegraph | null;
  contact: number;
  coin: number;
  data: Record<string, number>;
  boss?: BossData;
}

export interface BossData {
  name: string;
  motif: number;
  phase: number;
  maxPhase: number;
  script: string[][];
  idx: number;
  invuln: number;
  spin: number;
  attack: string;
}

export interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  max: number;
  size: number;
  red: boolean;
  drag: number;
}

export interface Pickup {
  x: number;
  y: number;
  vx: number;
  vy: number;
  kind: 'coin' | 'heart';
  t: number;
  value: number;
}

export interface FloatText {
  x: number;
  y: number;
  t: number;
  text: string;
  red: boolean;
}

// --- powerups ---------------------------------------------------------------
export interface Powerup {
  id: string;
  name: string;
  desc: string;
  max: number;
  apply: (s: Stats) => void;
}

// --- meta unlocks -----------------------------------------------------------
export interface Unlock {
  id: string;
  name: string;
  desc: string;
  costs: number[];
  apply: (s: Stats) => void;
}

export interface SaveData {
  bank: number;
  unlocks: Record<string, number>;
  runs: number;
  best: number;
  kills: number;
  wins: number;
}

export const MOTIFS = [
  { name: 'ASHFALL', sub: 'the grey lung', pattern: 'bayer' as const },
  { name: 'GLASSWORK', sub: 'the cut lattice', pattern: 'checker' as const },
  { name: 'THE DROWN', sub: 'the slow tide', pattern: 'diag' as const },
  { name: 'NULL', sub: 'the last room', pattern: 'noise' as const },
];
