// ---------------------------------------------------------------------------
// World renderer. 1-bit: white/grey dither for structure, RED only for
// hazards, telegraphs and life.
// ---------------------------------------------------------------------------

import {
  Beam,
  Bullet,
  Enemy,
  PAL,
  Player,
  Room,
  TAU,
  TILE,
  Telegraph,
  VH,
  VW,
  clamp,
} from './core';
import { fillDither } from './dither';
import { Game } from './state';

type C2D = CanvasRenderingContext2D;

export function px(ctx: C2D, x: number, y: number, w: number, h: number, col: string) {
  ctx.fillStyle = col;
  ctx.fillRect(Math.round(x), Math.round(y), Math.max(1, Math.round(w)), Math.max(1, Math.round(h)));
}

export function disc(ctx: C2D, x: number, y: number, r: number, col: string) {
  ctx.fillStyle = col;
  const R = Math.max(1, Math.round(r));
  for (let j = -R; j <= R; j++) {
    const w = Math.floor(Math.sqrt(Math.max(0, R * R - j * j)) * 2 + 1);
    ctx.fillRect(Math.round(x) - (w >> 1), Math.round(y) + j, w, 1);
  }
}

export function ringLine(ctx: C2D, x: number, y: number, r: number, col: string, dash = 0) {
  ctx.fillStyle = col;
  const steps = Math.max(10, Math.round(r * 7));
  for (let i = 0; i < steps; i++) {
    if (dash && i % dash < dash / 2) continue;
    const a = (i / steps) * TAU;
    ctx.fillRect(Math.round(x + Math.cos(a) * r), Math.round(y + Math.sin(a) * r), 1, 1);
  }
}

export function line(ctx: C2D, x0: number, y0: number, x1: number, y1: number, col: string, dash = 0) {
  ctx.fillStyle = col;
  let x = Math.round(x0),
    y = Math.round(y0);
  const ex = Math.round(x1),
    ey = Math.round(y1);
  const dx = Math.abs(ex - x),
    dy = Math.abs(ey - y);
  const sx = x < ex ? 1 : -1,
    sy = y < ey ? 1 : -1;
  let err = dx - dy;
  let i = 0;
  for (;;) {
    if (dash === 0 || i % dash < dash / 2) ctx.fillRect(x, y, 1, 1);
    if (x === ex && y === ey) break;
    const e2 = 2 * err;
    if (e2 > -dy) {
      err -= dy;
      x += sx;
    }
    if (e2 < dx) {
      err += dx;
      y += sy;
    }
    i++;
    if (i > 900) break;
  }
}

export function diamond(ctx: C2D, x: number, y: number, r: number, col: string) {
  ctx.fillStyle = col;
  const R = Math.max(1, Math.round(r));
  for (let j = -R; j <= R; j++) {
    const w = Math.round((1 - Math.abs(j) / (R + 1)) * R * 2 + 1);
    ctx.fillRect(Math.round(x) - (w >> 1), Math.round(y) + j, w, 1);
  }
}

export function poly(ctx: C2D, pts: number[][], col: string) {
  ctx.fillStyle = col;
  ctx.beginPath();
  ctx.moveTo(pts[0][0], pts[0][1]);
  for (let i = 1; i < pts.length; i++) ctx.lineTo(pts[i][0], pts[i][1]);
  ctx.closePath();
  ctx.fill();
}

// ---------------------------------------------------------------------------
export function drawRoom(ctx: C2D, g: Game) {
  const r = g.room;
  if (r.bg) ctx.drawImage(r.bg, -g.cam.x, -g.cam.y);
  // doors
  for (const d of r.doors) {
    const x = d.tx * TILE - g.cam.x;
    const y = d.ty * TILE - g.cam.y;
    const vert = d.side === 'w' || d.side === 'e';
    if (d.open) {
      const t = (g.time * 2) % 1;
      ctx.fillStyle = PAL.white;
      if (vert) {
        px(ctx, x + 1, y + 1, 1, TILE - 2, PAL.white);
        px(ctx, x + TILE - 2, y + 1, 1, TILE - 2, PAL.white);
        for (let k = 0; k < 3; k++) {
          const cx = x + 2 + ((k * 3 + Math.floor(t * 9)) % 8);
          px(ctx, cx, y + 4, 2, 4, PAL.g5);
        }
      } else {
        px(ctx, x + 1, y + 1, TILE - 2, 1, PAL.white);
        px(ctx, x + 1, y + TILE - 2, TILE - 2, 1, PAL.white);
        for (let k = 0; k < 3; k++) {
          const cy = y + 2 + ((k * 3 + Math.floor(t * 9)) % 8);
          px(ctx, x + 4, cy, 4, 2, PAL.g5);
        }
      }
    } else {
      // locked: grey bars
      ctx.fillStyle = PAL.g3;
      if (vert) {
        for (let k = 0; k < 3; k++) px(ctx, x + 1, y + 1 + k * 4, TILE - 2, 2, PAL.g3);
      } else {
        for (let k = 0; k < 3; k++) px(ctx, x + 1 + k * 4, y + 1, 2, TILE - 2, PAL.g3);
      }
      ctx.fillStyle = PAL.g5;
      px(ctx, x + 5, y + 5, 2, 2, PAL.g5);
    }
  }
}

// ---------------------------------------------------------------------------
function drawTelegraph(ctx: C2D, t: Telegraph, sx: number, sy: number) {
  const k = clamp(t.t / t.dur, 0, 1);
  const blink = Math.floor(t.t * 22) % 2 === 0;
  const col = blink ? PAL.red : PAL.redMid;
  const x = t.x - sx,
    y = t.y - sy;
  switch (t.kind) {
    case 'line': {
      const ex = x + Math.cos(t.ang) * t.len;
      const ey = y + Math.sin(t.ang) * t.len;
      line(ctx, x, y, ex, ey, col, 4);
      line(ctx, x, y, ex, ey, blink ? PAL.red : PAL.redDark, 0);
      // sweep marker showing progress
      const mx = x + Math.cos(t.ang) * t.len * k;
      const my = y + Math.sin(t.ang) * t.len * k;
      px(ctx, mx - 1, my - 1, 3, 3, PAL.white);
      break;
    }
    case 'ring': {
      ringLine(ctx, x, y, t.rad * (0.35 + 0.65 * k), col, 3);
      ringLine(ctx, x, y, t.rad, PAL.redDark, 0);
      break;
    }
    case 'circle': {
      fillDither(ctx, 'bayer', 4 + Math.round(k * 8), x - t.rad, y - t.rad, t.rad * 2, t.rad * 2);
      ringLine(ctx, x, y, t.rad, col, 0);
      ringLine(ctx, x, y, t.rad * k, PAL.white, 0);
      break;
    }
    case 'wedge': {
      const steps = 16;
      for (let i = 0; i < steps; i++) {
        const a = t.ang - t.rad / 2 + (t.rad * i) / steps;
        const len = t.len * (0.4 + 0.6 * k);
        line(ctx, x, y, x + Math.cos(a) * len, y + Math.sin(a) * len, i % 2 ? col : PAL.redDark, 3);
      }
      ringLine(ctx, x, y, t.len * k, PAL.white, 2);
      break;
    }
    case 'dots': {
      for (let i = 0; i < 4; i++) {
        const a = (i / 4) * TAU + t.t * 4;
        const d = t.rad * (1.6 - k);
        px(ctx, x + Math.cos(a) * d - 1, y + Math.sin(a) * d - 1, 3, 3, col);
      }
      ringLine(ctx, x, y, t.rad, PAL.redDark, 3);
      break;
    }
  }
}

// ---------------------------------------------------------------------------
function drawPlayer(ctx: C2D, p: Player, sx: number, sy: number, time: number) {
  const x = Math.round(p.x - sx),
    y = Math.round(p.y - sy);
  // dash afterimages
  for (const gh of p.ghosts) {
    const gx = Math.round(gh.x - sx),
      gy = Math.round(gh.y - sy);
    fillDither(ctx, 'bayer', 6, gx - 4, gy - 8, 9, 11);
  }
  const blink = p.iframe > 0 && Math.floor(time * 24) % 2 === 0;
  const col = p.hitFlash > 0 ? PAL.black : blink ? PAL.g4 : PAL.white;
  const body = p.hitFlash > 0 ? PAL.white : blink ? PAL.g5 : PAL.white;
  // legs
  const step = Math.sin(p.anim * 14) > 0 ? 1 : -1;
  px(ctx, x - 3, y + 2 + (step > 0 ? 0 : 1), 2, 3, body);
  px(ctx, x + 1, y + 2 + (step > 0 ? 1 : 0), 2, 3, body);
  // torso
  px(ctx, x - 3, y - 3, 7, 5, body);
  px(ctx, x - 1, y - 2, 3, 3, PAL.black);
  // head
  px(ctx, x - 2, y - 8, 5, 4, body);
  px(ctx, x - 1, y - 7, 3, 2, PAL.black);
  // muzzle
  const mx = x + Math.cos(p.aim) * 6;
  const my = y + Math.sin(p.aim) * 6;
  px(ctx, mx - 1, my - 1, 3, 3, col);
  if (p.dashT > 0) ringLine(ctx, x, y, 8, PAL.white, 2);
}

// ---------------------------------------------------------------------------
function drawEnemy(ctx: C2D, e: Enemy, sx: number, sy: number, time: number) {
  const x = Math.round(e.x - sx),
    y = Math.round(e.y - sy);
  if (e.flash > 0) {
    // inverted silhouette
    drawShape(ctx, e, x, y, PAL.black, time);
    return;
  }
  drawShape(ctx, e, x, y, PAL.white, time);
}

function drawShape(ctx: C2D, e: Enemy, x: number, y: number, col: string, _time: number) {
  const dark = col === PAL.white ? PAL.black : PAL.white;
  const red = col === PAL.white ? PAL.red : PAL.redDark;
  switch (e.type) {
    case 'crawler': {
      diamond(ctx, x, y, e.r, col);
      px(ctx, x - 2, y - 1, 1, 2, dark);
      px(ctx, x + 1, y - 1, 1, 2, dark);
      break;
    }
    case 'splitter': {
      disc(ctx, x, y, e.r, col);
      line(ctx, x - 4, y - 2, x + 1, y + 3, dark, 0);
      line(ctx, x + 3, y - 3, x - 1, y + 2, dark, 0);
      px(ctx, x - 1, y - 4, 2, 2, red);
      break;
    }
    case 'spitter': {
      disc(ctx, x, y, e.r, col);
      ringLine(ctx, x, y, e.r - 2, dark, 0);
      const mx = x + Math.cos(e.ang) * (e.r + 2);
      const my = y + Math.sin(e.ang) * (e.r + 2);
      px(ctx, mx - 1, my - 1, 3, 3, red);
      break;
    }
    case 'lunger': {
      const a = e.state === 'act' ? e.data.ang : e.ang;
      poly(
        ctx,
        [
          [x + Math.cos(a) * (e.r + 4), y + Math.sin(a) * (e.r + 4)],
          [x + Math.cos(a + 2.3) * e.r, y + Math.sin(a + 2.3) * e.r],
          [x + Math.cos(a - 2.3) * e.r, y + Math.sin(a - 2.3) * e.r],
        ],
        col,
      );
      px(ctx, x - 1, y - 1, 2, 2, red);
      break;
    }
    case 'spinner': {
      ringLine(ctx, x, y, e.r, col, 0);
      disc(ctx, x, y, e.r - 3, col);
      for (let i = 0; i < 4; i++) {
        const a = e.spin + (i / 4) * TAU;
        line(ctx, x, y, x + Math.cos(a) * (e.r + 3), y + Math.sin(a) * (e.r + 3), col, 0);
      }
      px(ctx, x - 1, y - 1, 2, 2, red);
      break;
    }
    case 'node': {
      px(ctx, x - e.r, y - e.r, e.r * 2, e.r * 2, col);
      px(ctx, x - e.r + 2, y - e.r + 2, e.r * 2 - 4, e.r * 2 - 4, dark);
      disc(ctx, x, y, 2, red);
      break;
    }
    case 'warden': {
      disc(ctx, x, y, e.r, col);
      ringLine(ctx, x, y, e.r - 3, dark, 0);
      px(ctx, x - 4, y - 2, 2, 3, red);
      px(ctx, x + 2, y - 2, 2, 3, red);
      line(ctx, x - e.r, y + e.r - 2, x + e.r, y + e.r - 2, dark, 0);
      break;
    }
    default:
      drawBoss(ctx, e, x, y, col, _time);
  }
}

function drawBoss(ctx: C2D, e: Enemy, x: number, y: number, col: string, time: number) {
  const dark = col === PAL.white ? PAL.black : PAL.white;
  const red = col === PAL.white ? PAL.red : PAL.redDark;
  const ph = e.boss?.phase ?? 1;
  const r = e.r;
  switch (e.type) {
    case 'asher': {
      diamond(ctx, x, y, r, col);
      diamond(ctx, x, y, r - 4, dark);
      diamond(ctx, x, y, r - 8, col);
      disc(ctx, x, y, 3, red);
      for (let i = 0; i < ph; i++) {
        const a = time * 1.4 + (i / ph) * TAU;
        px(ctx, x + Math.cos(a) * (r + 5) - 1, y + Math.sin(a) * (r + 5) - 1, 3, 3, col);
      }
      break;
    }
    case 'choir': {
      disc(ctx, x, y, r - 4, col);
      for (let i = 0; i < 3; i++) {
        const rr = r - i * 4;
        ringLine(ctx, x, y, rr, i % 2 ? dark : col, 0);
      }
      for (let i = 0; i < 3 + ph; i++) {
        const a = time * (1.1 + i * 0.3) + (i / (3 + ph)) * TAU;
        px(ctx, x + Math.cos(a) * (r + 4) - 1, y + Math.sin(a) * (r + 4) - 1, 2, 2, col);
      }
      px(ctx, x - 1, y - 1, 3, 3, red);
      break;
    }
    case 'drowned': {
      disc(ctx, x, y, r, col);
      for (let j = -r; j <= r; j += 3) {
        const w = Math.floor(Math.sqrt(Math.max(0, r * r - j * j)) * 2);
        const off = Math.round(Math.sin(time * 3 + j * 0.6) * 2);
        px(ctx, x - w / 2 + off, y + j, w, 1, dark);
      }
      px(ctx, x - 6, y - 4, 3, 3, red);
      px(ctx, x + 3, y - 4, 3, 3, red);
      px(ctx, x - 1, y + 3, 3, 3, red);
      break;
    }
    default: {
      // sovereign
      const pts: number[][] = [];
      for (let i = 0; i < 8; i++) {
        const a = (i / 8) * TAU + time * 0.3;
        pts.push([x + Math.cos(a) * r, y + Math.sin(a) * r]);
      }
      poly(ctx, pts, col);
      poly(
        ctx,
        pts.map((p) => [p[0] * 0.6 + x * 0.4, p[1] * 0.6 + y * 0.4]),
        dark,
      );
      for (let i = 0; i < 4; i++) {
        const a = time * 2 + (i / 4) * TAU;
        line(ctx, x, y, x + Math.cos(a) * (r + 8), y + Math.sin(a) * (r + 8), col, 2);
      }
      disc(ctx, x, y, 4, red);
      break;
    }
  }
}

// ---------------------------------------------------------------------------
function drawBullet(ctx: C2D, b: Bullet, sx: number, sy: number) {
  const x = Math.round(b.x - sx),
    y = Math.round(b.y - sy);
  const tx = Math.round(b.x - sx - b.vx * 0.02),
    ty = Math.round(b.y - sy - b.vy * 0.02);
  line(ctx, tx, ty, x, y, PAL.g5, 0);
  px(ctx, x - 1, y - 1, 3, 3, PAL.white);
}

function drawHazard(ctx: C2D, b: Bullet, sx: number, sy: number) {
  const x = Math.round(b.x - sx),
    y = Math.round(b.y - sy);
  if (b.kind === 'shard') {
    diamond(ctx, x, y, b.r, PAL.red);
  } else {
    disc(ctx, x, y, b.r, PAL.red);
    px(ctx, x - 1, y - 1, 2, 2, PAL.white);
  }
}

function drawBeam(ctx: C2D, bm: Beam, sx: number, sy: number) {
  const x = bm.x - sx,
    y = bm.y - sy;
  const ex = x + Math.cos(bm.ang) * bm.len;
  const ey = y + Math.sin(bm.ang) * bm.len;
  const k = 1 - bm.t / bm.dur;
  const w = Math.max(1, Math.round(bm.w * k));
  line(ctx, x, y, ex, ey, PAL.red, 0);
  if (w > 2) {
    const nx = -Math.sin(bm.ang),
      ny = Math.cos(bm.ang);
    for (let d = -w; d <= w; d += 2) {
      line(ctx, x + nx * d, y + ny * d, ex + nx * d, ey + ny * d, d % 4 === 0 ? PAL.red : PAL.redMid, 0);
    }
  }
  line(ctx, x, y, ex, ey, PAL.white, 0);
}

// ---------------------------------------------------------------------------
export function drawWorld(ctx: C2D, g: Game) {
  const sx = g.cam.x;
  const sy = g.cam.y;
  drawRoom(ctx, g);

  // pickups
  for (const k of g.pickups) {
    const x = Math.round(k.x - sx),
      y = Math.round(k.y - sy);
    const bob = Math.sin(k.t * 6) * 1.5;
    if (k.kind === 'coin') {
      const w = 3 + Math.round(Math.abs(Math.cos(k.t * 4)) * 2);
      px(ctx, x - (w >> 1), y - 2 + bob, w, 4, PAL.white);
      px(ctx, x - (w >> 1), y - 1 + bob, w, 1, PAL.g3);
    } else {
      px(ctx, x - 3, y - 2 + bob, 6, 2, PAL.red);
      px(ctx, x - 2, y - 3 + bob, 4, 4, PAL.red);
      px(ctx, x - 1, y - 1 + bob, 2, 2, PAL.white);
    }
  }

  // particles
  for (const q of g.parts) {
    const a = clamp(q.life / q.max, 0, 1);
    const col = q.red ? (a > 0.5 ? PAL.red : PAL.redDark) : a > 0.5 ? PAL.white : PAL.g4;
    px(ctx, q.x - sx, q.y - sy, q.size, q.size, col);
  }

  // telegraphs (under bodies so shapes stay readable)
  for (const e of g.enemies) if (e.tele) drawTelegraph(ctx, e.tele, sx, sy);

  for (const b of g.beams) drawBeam(ctx, b, sx, sy);

  for (const e of g.enemies) drawEnemy(ctx, e, sx, sy, g.time);

  drawPlayer(ctx, g.player, sx, sy, g.time);

  for (const b of g.bullets) drawBullet(ctx, b, sx, sy);
  for (const b of g.hazards) drawHazard(ctx, b, sx, sy);

  // floating text
  for (const f of g.floats) {
    ctx.globalAlpha = clamp(f.t / 0.9, 0, 1);
    px(ctx, f.x - sx - 1, f.y - sy - 1, 1, 1, f.red ? PAL.red : PAL.white);
    ctx.globalAlpha = 1;
  }
}

export function drawVignette(ctx: C2D, g: Game) {
  // scanline-ish edge darkening keeps the 1-bit frame feeling like a screen
  ctx.fillStyle = PAL.g1;
  for (let i = 0; i < 3; i++) {
    const a = 0.06;
    ctx.globalAlpha = a;
    ctx.fillRect(0, i, VW, 1);
    ctx.fillRect(0, VH - 1 - i, VW, 1);
    ctx.fillRect(i, 0, 1, VH);
    ctx.fillRect(VW - 1 - i, 0, 1, VH);
    ctx.globalAlpha = 1;
  }
  if (g.hurtT > 0) {
    ctx.globalAlpha = clamp(g.hurtT, 0, 1) * 0.5;
    ctx.fillStyle = PAL.redDark;
    ctx.fillRect(0, 0, VW, VH);
    ctx.globalAlpha = 1;
  }
  if (g.flash > 0) {
    ctx.globalAlpha = clamp(g.flash, 0, 1) * 0.8;
    ctx.fillStyle = PAL.white;
    ctx.fillRect(0, 0, VW, VH);
    ctx.globalAlpha = 1;
  }
  if (g.fade > 0) {
    ctx.globalAlpha = clamp(g.fade, 0, 1);
    ctx.fillStyle = PAL.black;
    ctx.fillRect(0, 0, VW, VH);
    ctx.globalAlpha = 1;
  }
}

export function roomSize(r: Room) {
  return { w: r.w * TILE, h: r.h * TILE };
}
