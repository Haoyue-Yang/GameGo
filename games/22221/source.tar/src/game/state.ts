// ---------------------------------------------------------------------------
// Mutable game state + shared spawn/damage helpers.
// ---------------------------------------------------------------------------

import {
  Beam,
  Bullet,
  Enemy,
  FloatText,
  Particle,
  Pickup,
  Player,
  Powerup,
  RNG,
  Room,
  SaveData,
  Stats,
  TAU,
  baseStats,
  clamp,
  dist,
} from './core';
import { BOSS_NAMES, BOSS_SCRIPTS, BOSS_TYPES, ENEMIES, POWERUPS, UNLOCKS } from './content';
import { sfx } from './audio';

export type Mode = 'title' | 'shop' | 'playing' | 'draft' | 'dead' | 'victory';

export interface Game {
  mode: Mode;
  room: Room;
  player: Player;
  enemies: Enemy[];
  bullets: Bullet[];
  hazards: Bullet[];
  beams: Beam[];
  parts: Particle[];
  pickups: Pickup[];
  floats: FloatText[];
  cam: { x: number; y: number };
  shake: number;
  hitstop: number;
  flash: number;
  fade: number;
  fadeDir: number;
  pending: Room | null;
  motif: number;
  roomIndex: number;
  coins: number;
  kills: number;
  time: number;
  rng: RNG;
  draft: Powerup[];
  draftIdx: number;
  shopIdx: number;
  save: SaveData;
  boss: Enemy | null;
  bossIntro: number;
  banner: { text: string; sub: string; t: number } | null;
  nextId: number;
  deathT: number;
  clearT: number;
  hurtT: number;
  lastPickups: number;
  auraT: number;
}

export function makePlayer(stats: Stats): Player {
  return {
    x: 0,
    y: 0,
    vx: 0,
    vy: 0,
    r: 5,
    hp: stats.maxHp,
    aim: 0,
    fireCd: 0,
    dashCd: 0,
    dashCharges: stats.dashCharges,
    dashT: 0,
    dashAng: 0,
    iframe: 0,
    hitFlash: 0,
    anim: 0,
    stats,
    powerups: {},
    ghosts: [],
  };
}

export function statsFromUnlocks(save: SaveData): Stats {
  const s = baseStats();
  for (const u of UNLOCKS) {
    const lvl = save.unlocks[u.id] ?? 0;
    for (let i = 0; i < lvl; i++) u.apply(s);
  }
  return s;
}

export function createGame(save: SaveData): Game {
  const stats = statsFromUnlocks(save);
  const g: Game = {
    mode: 'title',
    room: null as unknown as Room,
    player: makePlayer(stats),
    enemies: [],
    bullets: [],
    hazards: [],
    beams: [],
    parts: [],
    pickups: [],
    floats: [],
    cam: { x: 0, y: 0 },
    shake: 0,
    hitstop: 0,
    flash: 0,
    fade: 0,
    fadeDir: 0,
    pending: null,
    motif: 0,
    roomIndex: 0,
    coins: 0,
    kills: 0,
    time: 0,
    rng: new RNG((Math.random() * 1e9) | 0),
    draft: [],
    draftIdx: 0,
    shopIdx: 0,
    save,
    boss: null,
    bossIntro: 0,
    banner: null,
    nextId: 1,
    deathT: 0,
    clearT: 0,
    hurtT: 0,
    lastPickups: 0,
    auraT: 0,
  };
  return g;
}

// --- fx helpers -------------------------------------------------------------
export function shake(g: Game, amt: number) {
  g.shake = Math.min(9, g.shake + amt);
}

export function burst(
  g: Game,
  x: number,
  y: number,
  n: number,
  red: boolean,
  speed = 60,
  size = 1,
) {
  for (let i = 0; i < n; i++) {
    const a = g.rng.range(0, TAU);
    const s = g.rng.range(speed * 0.25, speed);
    g.parts.push({
      x,
      y,
      vx: Math.cos(a) * s,
      vy: Math.sin(a) * s,
      life: g.rng.range(0.18, 0.5),
      max: 0.5,
      size,
      red,
      drag: 3.4,
    });
  }
}

export function addFloat(g: Game, x: number, y: number, text: string, red = false) {
  g.floats.push({ x, y, t: 0.9, text, red });
  if (g.floats.length > 24) g.floats.shift();
}

export function spawnHazard(
  g: Game,
  x: number,
  y: number,
  ang: number,
  speed: number,
  opts: { r?: number; dmg?: number; kind?: Bullet['kind']; homing?: number; life?: number } = {},
) {
  const slow = g.player.stats.slowBullets;
  g.hazards.push({
    x,
    y,
    vx: Math.cos(ang) * speed * slow,
    vy: Math.sin(ang) * speed * slow,
    r: opts.r ?? 3,
    dmg: opts.dmg ?? 1,
    life: opts.life ?? 4.5,
    friendly: false,
    pierce: 0,
    hit: [],
    homing: opts.homing ?? 0,
    ricochet: 0,
    kind: opts.kind ?? 'orb',
    ang,
    spin: g.rng.range(-6, 6),
  });
}

export function radial(g: Game, x: number, y: number, n: number, off: number, speed: number, opts = {}) {
  for (let i = 0; i < n; i++) spawnHazard(g, x, y, off + (i / n) * TAU, speed, opts);
}

export function fan(
  g: Game,
  x: number,
  y: number,
  ang: number,
  n: number,
  spread: number,
  speed: number,
  opts = {},
) {
  for (let i = 0; i < n; i++) {
    const t = n === 1 ? 0.5 : i / (n - 1);
    spawnHazard(g, x, y, ang + (t - 0.5) * spread, speed, opts);
  }
}

// --- spawning ---------------------------------------------------------------
export function spawnEnemy(g: Game, type: string, x: number, y: number): Enemy {
  const def = ENEMIES[type] ?? ENEMIES.crawler;
  const scale = 1 + g.motif * 0.42 + g.roomIndex * 0.14;
  const hp = Math.max(1, Math.round(def.hp * scale));
  const e: Enemy = {
    id: g.nextId++,
    type,
    x,
    y,
    vx: 0,
    vy: 0,
    r: def.r,
    hp,
    maxHp: hp,
    t: g.rng.range(0, 6),
    state: 'idle',
    timer: g.rng.range(0.3, 1.4),
    ang: g.rng.range(0, TAU),
    spin: g.rng.range(-2, 2),
    flash: 0,
    tele: null,
    contact: def.contact,
    coin: def.coin + g.motif,
    data: {},
  };
  g.enemies.push(e);
  return e;
}

export function spawnBoss(g: Game, motif: number): Enemy {
  const type = BOSS_TYPES[motif % 4];
  const def = ENEMIES[type];
  const e = spawnEnemy(g, type, (g.room.w * 12) / 2, (g.room.h * 12) / 2);
  e.hp = e.maxHp = def.hp;
  e.boss = {
    name: BOSS_NAMES[motif % 4],
    motif,
    phase: 1,
    maxPhase: 3,
    script: BOSS_SCRIPTS[motif % 4],
    idx: 0,
    invuln: 0,
    spin: 0,
    attack: '',
  };
  e.state = 'intro';
  e.timer = 1.6;
  g.boss = e;
  return e;
}

// --- damage -----------------------------------------------------------------
export function damageEnemy(g: Game, e: Enemy, dmg: number, kx = 0, ky = 0) {
  if (e.boss && (e.boss.invuln > 0 || e.state === 'intro')) return;
  e.hp -= dmg;
  e.flash = 0.09;
  if (!e.boss) {
    e.vx += kx;
    e.vy += ky;
  }
  if (e.hp <= 0) killEnemy(g, e);
}

export function killEnemy(g: Game, e: Enemy) {
  const i = g.enemies.indexOf(e);
  if (i < 0) return;
  g.enemies.splice(i, 1);
  g.kills++;
  const isBoss = !!e.boss;
  burst(g, e.x, e.y, isBoss ? 60 : 10, false, isBoss ? 190 : 90, isBoss ? 2 : 1);
  burst(g, e.x, e.y, isBoss ? 26 : 4, true, isBoss ? 150 : 70);
  shake(g, isBoss ? 8 : 1.6);
  if (isBoss) {
    g.flash = 0.5;
    g.hitstop = 0.28;
    sfx.boom();
  } else sfx.kill();
  // coins
  const n = isBoss ? 12 : Math.max(1, Math.round(e.coin * 0.6));
  for (let k = 0; k < n; k++) {
    const a = g.rng.range(0, TAU);
    const s = g.rng.range(20, 90);
    g.pickups.push({
      x: e.x,
      y: e.y,
      vx: Math.cos(a) * s,
      vy: Math.sin(a) * s,
      kind: 'coin',
      t: 0,
      value: isBoss ? Math.max(2, Math.round(e.coin / 12)) : 1,
    });
  }
  if (g.rng.chance(isBoss ? 1 : 0.05))
    g.pickups.push({ x: e.x, y: e.y, vx: 0, vy: 0, kind: 'heart', t: 0, value: 1 });
  // splitter
  if (e.type === 'splitter' && !isBoss) {
    for (let k = 0; k < 3; k++) {
      const a = (k / 3) * TAU;
      const c = spawnEnemy(g, 'crawler', e.x + Math.cos(a) * 10, e.y + Math.sin(a) * 10);
      c.hp = c.maxHp = Math.max(1, Math.round(c.maxHp * 0.6));
      c.r = 4;
    }
  }
  if (g.player.stats.lifesteal > 0 && g.rng.chance(g.player.stats.lifesteal) && !isBoss) {
    if (g.player.hp < g.player.stats.maxHp) {
      g.player.hp++;
      sfx.heal();
      addFloat(g, g.player.x, g.player.y - 12, '+1', false);
    }
  }
}

export function hurtPlayer(g: Game, dmg: number) {
  const p = g.player;
  if (p.iframe > 0 || p.dashT > 0 || g.mode !== 'playing') return;
  p.hp -= dmg;
  p.iframe = 0.95;
  p.hitFlash = 0.3;
  g.hurtT = 0.3;
  shake(g, 5);
  g.flash = 0.22;
  burst(g, p.x, p.y, 12, true, 110);
  sfx.hurt();
  if (p.hp <= 0) {
    p.hp = 0;
    g.hitstop = 0.3;
    burst(g, p.x, p.y, 40, true, 160, 2);
    sfx.death();
  }
}

export function healPlayer(g: Game, n: number) {
  const p = g.player;
  if (p.hp >= p.stats.maxHp) return;
  p.hp = Math.min(p.stats.maxHp, p.hp + n);
  sfx.heal();
  addFloat(g, p.x, p.y - 12, '+1', false);
}

// --- draft ------------------------------------------------------------------
export function rollDraft(g: Game): Powerup[] {
  const pool = POWERUPS.filter((p) => (g.player.powerups[p.id] ?? 0) < p.max);
  const picks: Powerup[] = [];
  const bag = g.rng.shuffle(pool);
  for (const p of bag) {
    if (picks.length >= 3) break;
    picks.push(p);
  }
  return picks;
}

export function applyPowerup(g: Game, p: Powerup) {
  const before = g.player.stats.maxHp;
  p.apply(g.player.stats);
  g.player.powerups[p.id] = (g.player.powerups[p.id] ?? 0) + 1;
  if (g.player.stats.maxHp > before) g.player.hp += g.player.stats.maxHp - before;
  if (p.id === 'phase') g.player.dashCharges = g.player.stats.dashCharges;
}

// --- misc ------------------------------------------------------------------
export function cameraFor(g: Game) {
  const rw = g.room.w * 12;
  const rh = g.room.h * 12;
  const p = g.player;
  let cx = p.x - 384 / 2;
  let cy = p.y - 216 / 2;
  cx = rw <= 384 ? (rw - 384) / 2 : clamp(cx, 0, rw - 384);
  cy = rh <= 216 ? (rh - 216) / 2 : clamp(cy, 0, rh - 216);
  g.cam.x = Math.round(cx);
  g.cam.y = Math.round(cy);
}

export function nearestEnemy(g: Game, x: number, y: number, maxD = 1e9): Enemy | null {
  let best: Enemy | null = null;
  let bd = maxD * maxD;
  for (const e of g.enemies) {
    const d = (e.x - x) ** 2 + (e.y - y) ** 2;
    if (d < bd) {
      bd = d;
      best = e;
    }
  }
  return best;
}

export function playerDist(g: Game, e: Enemy) {
  return dist(e.x, e.y, g.player.x, g.player.y);
}
