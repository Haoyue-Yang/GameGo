import { SaveData } from './core';

const KEY = 'nullroom.save.v1';

export function emptySave(): SaveData {
  return { bank: 0, unlocks: {}, runs: 0, best: 0, kills: 0, wins: 0 };
}

export function loadSave(): SaveData {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return emptySave();
    const parsed = JSON.parse(raw) as Partial<SaveData>;
    return { ...emptySave(), ...parsed, unlocks: { ...(parsed.unlocks ?? {}) } };
  } catch {
    return emptySave();
  }
}

export function writeSave(s: SaveData) {
  try {
    localStorage.setItem(KEY, JSON.stringify(s));
  } catch {
    /* storage unavailable -- run stays session-only */
  }
}
