// ---------------------------------------------------------------------------
// Enemy AI + multi-phase boss scripts. Every lethal attack runs through a
// telegraph first: the player always gets a red warning before it can kill.
// ---------------------------------------------------------------------------

import { Enemy, TAU, Telegraph, clamp, dist, moveBody } from './core';
import { ENEMIES } from './content';
import { Game, fan, radial, shake, spawnBoss, spawnEnemy, spawnHazard, burst, addFloat } from './state';
import { sfx } from './audio';

function toPlayer(g: Game, e: Enemy) {
  return Math.atan2(g.player.y - e.y, g.player.x - e.x);
}

function face(e: Enemy, ang: number, rate = 10) {
  let d = ((ang - e.ang + Math.PI * 3) % TAU) - Math.PI;
  e.ang += d * Math.min(1, rate * 0.016);
}

function seek(e: Enemy, ang: number, sp: number, rate = 6) {
  e.vx += (Math.cos(ang) * sp - e.vx) * rate * 0.016;
  e.vy += (Math.sin(ang) * sp - e.vy) * rate * 0.016;
}

function setTele(e: Enemy, t: Telegraph) {
  e.tele = t;
  sfx.tele();
}

function clearTele(e: Enemy) {
  e.tele = null;
}

// ---------------------------------------------------------------------------
// Regular enemies
// ---------------------------------------------------------------------------
function updateMinion(g: Game, e: Enemy, dt: number) {
  const def = ENEMIES[e.type] ?? ENEMIES.crawler;
  const p = g.player;
  const d = dist(e.x, e.y, p.x, p.y);
  const a = toPlayer(g, e);
  const sp = def.speed * (1 + g.motif * 0.05);
  e.t += dt;
  e.timer -= dt;

  switch (e.type) {
    case 'crawler': {
      const wob = Math.sin(e.t * 4 + e.id) * 0.5;
      seek(e, a + wob * 0.5, sp, 5);
      break;
    }
    case 'splitter': {
      seek(e, a, sp, 3);
      break;
    }
    case 'warden': {
      seek(e, a, sp, 3);
      if (e.state === 'idle' && e.timer <= 0) {
        e.state = 'tele';
        e.timer = 0.62;
        setTele(e, { kind: 'wedge', t: 0, dur: 0.62, ang: a, len: 130, rad: 0.8, x: e.x, y: e.y, n: 0 });
      } else if (e.state === 'tele') {
        e.tele!.x = e.x;
        e.tele!.y = e.y;
        e.tele!.ang = a;
        if (e.timer <= 0) {
          clearTele(e);
          fan(g, e.x, e.y, a, 5, 0.85, 118);
          e.state = 'rest';
          e.timer = 1.15;
        }
      } else if (e.state === 'rest' && e.timer <= 0) {
        e.state = 'idle';
        e.timer = 1.4;
        if (g.rng.chance(0.4)) {
          for (let k = 0; k < 2; k++) {
            const c = spawnEnemy(g, 'crawler', e.x + g.rng.range(-16, 16), e.y + g.rng.range(-16, 16));
            c.hp = c.maxHp = Math.max(1, Math.round(c.maxHp * 0.5));
          }
        }
      }
      break;
    }
    case 'spitter': {
      const want = 96;
      if (d < want - 26) seek(e, a + Math.PI, sp, 5);
      else if (d > want + 26) seek(e, a, sp, 4);
      else seek(e, a + Math.PI / 2, sp * 0.7, 3);
      if (e.state === 'idle' && e.timer <= 0) {
        e.state = 'tele';
        e.timer = 0.55;
        setTele(e, { kind: 'ring', t: 0, dur: 0.55, ang: a, len: 0, rad: 12, x: e.x, y: e.y, n: 0 });
      } else if (e.state === 'tele') {
        e.tele!.x = e.x;
        e.tele!.y = e.y;
        if (e.timer <= 0) {
          clearTele(e);
          const n = 1 + (g.motif >= 2 ? 2 : 0);
          fan(g, e.x, e.y, a, n, 0.34, 108, { r: 3.5 });
          e.state = 'rest';
          e.timer = 1.05;
        }
      } else if (e.state === 'rest' && e.timer <= 0) {
        e.state = 'idle';
        e.timer = 0.5;
      }
      break;
    }
    case 'lunger': {
      if (e.state === 'idle') {
        if (d > 78) seek(e, a, sp, 4);
        else if (e.timer <= 0) {
          e.state = 'tele';
          e.timer = 0.6;
          e.data.ang = a;
          setTele(e, { kind: 'line', t: 0, dur: 0.6, ang: a, len: 150, rad: 0, x: e.x, y: e.y, n: 0 });
        }
      } else if (e.state === 'tele') {
        e.vx *= 0.86;
        e.vy *= 0.86;
        e.tele!.x = e.x;
        e.tele!.y = e.y;
        if (e.timer > 0.2) {
          e.data.ang = a;
          e.tele!.ang = a;
        }
        if (e.timer <= 0) {
          clearTele(e);
          e.state = 'act';
          e.timer = 0.34;
          e.vx = Math.cos(e.data.ang) * 300;
          e.vy = Math.sin(e.data.ang) * 300;
          sfx.dash();
        }
      } else if (e.state === 'act') {
        if (e.timer <= 0) {
          e.state = 'rest';
          e.timer = 0.55;
        }
      } else if (e.state === 'rest') {
        e.vx *= 0.8;
        e.vy *= 0.8;
        if (e.timer <= 0) {
          e.state = 'idle';
          e.timer = 0.5;
        }
      }
      break;
    }
    case 'spinner': {
      const orbit = a + Math.PI / 2;
      if (d > 118) seek(e, a, sp, 3);
      else if (d < 82) seek(e, a + Math.PI, sp, 3);
      else seek(e, orbit, sp, 4);
      e.spin += dt * 3.2;
      if (e.state === 'idle' && e.timer <= 0) {
        e.state = 'tele';
        e.timer = 0.55;
        setTele(e, { kind: 'ring', t: 0, dur: 0.55, ang: 0, len: 0, rad: 30, x: e.x, y: e.y, n: 10 });
      } else if (e.state === 'tele') {
        e.tele!.x = e.x;
        e.tele!.y = e.y;
        if (e.timer <= 0) {
          clearTele(e);
          radial(g, e.x, e.y, 10, e.spin, 96);
          e.state = 'rest';
          e.timer = 1.5;
        }
      } else if (e.state === 'rest' && e.timer <= 0) {
        e.state = 'idle';
        e.timer = 0.4;
      }
      break;
    }
    case 'node': {
      e.vx = 0;
      e.vy = 0;
      if (e.state === 'idle' && e.timer <= 0) {
        e.state = 'tele';
        e.timer = 0.5;
        setTele(e, { kind: 'wedge', t: 0, dur: 0.5, ang: a, len: 150, rad: 0.5, x: e.x, y: e.y, n: 3 });
      } else if (e.state === 'tele') {
        e.tele!.ang = a;
        if (e.timer <= 0) {
          clearTele(e);
          fan(g, e.x, e.y, a, 3, 0.5, 124, { r: 3.5 });
          e.state = 'rest';
          e.timer = 1.35;
        }
      } else if (e.state === 'rest' && e.timer <= 0) {
        e.state = 'idle';
        e.timer = 0.4;
      }
      break;
    }
    default:
      seek(e, a, sp, 4);
  }

  face(e, a, e.type === 'node' ? 6 : 14);
  moveBody(g.room, e, dt);
}

// ---------------------------------------------------------------------------
// Boss attacks
// ---------------------------------------------------------------------------
interface Attack {
  tele: number;
  act: number;
  rest: number;
  telegraph?: (e: Enemy, g: Game) => Telegraph;
  start?: (e: Enemy, g: Game) => void;
  tick?: (e: Enemy, g: Game, dt: number) => void;
  follow?: boolean;
}

function spawnBeam(g: Game, e: Enemy, ang: number, dur: number) {
  g.beams.push({
    x: e.x,
    y: e.y,
    ang,
    len: 460,
    w: 7,
    t: 0,
    dur,
    tele: 0,
    active: true,
  });
  shake(g, 4);
  sfx.boom();
}

const ATTACKS: Record<string, Attack> = {
  fan: {
    tele: 0.5,
    act: 0.12,
    rest: 0.62,
    follow: true,
    telegraph: (e, g) => ({
      kind: 'wedge',
      t: 0,
      dur: 0.5,
      ang: toPlayer(g, e),
      len: 170,
      rad: 0.7,
      x: e.x,
      y: e.y,
      n: 0,
    }),
    start: (e, g) => {
      const a = toPlayer(g, e);
      fan(g, e.x, e.y, a, 5 + e.boss!.phase, 0.75, 128);
      sfx.hit();
    },
  },
  radial: {
    tele: 0.62,
    act: 0.14,
    rest: 0.7,
    telegraph: (e) => ({ kind: 'ring', t: 0, dur: 0.62, ang: 0, len: 0, rad: 44, x: e.x, y: e.y, n: 0 }),
    start: (e, g) => {
      radial(g, e.x, e.y, 14 + e.boss!.phase * 3, e.spin, 112);
      sfx.boom();
      shake(g, 3);
    },
  },
  cross: {
    tele: 0.5,
    act: 1.75,
    rest: 0.62,
    telegraph: (e) => ({ kind: 'ring', t: 0, dur: 0.5, ang: 0, len: 0, rad: 34, x: e.x, y: e.y, n: 4 }),
    tick: (e, g, dt) => {
      e.data.acc = (e.data.acc ?? 0) + dt;
      while (e.data.acc > 0.085) {
        e.data.acc -= 0.085;
        e.spin += 0.24;
        for (let k = 0; k < 4; k++) spawnHazard(g, e.x, e.y, e.spin + (k / 4) * TAU, 118);
      }
    },
  },
  spiral: {
    tele: 0.5,
    act: 2.2,
    rest: 0.6,
    telegraph: (e) => ({ kind: 'ring', t: 0, dur: 0.5, ang: 0, len: 0, rad: 30, x: e.x, y: e.y, n: 2 }),
    tick: (e, g, dt) => {
      e.data.acc = (e.data.acc ?? 0) + dt;
      while (e.data.acc > 0.055) {
        e.data.acc -= 0.055;
        e.spin += 0.38;
        spawnHazard(g, e.x, e.y, e.spin, 104);
        spawnHazard(g, e.x, e.y, e.spin + Math.PI, 104);
      }
    },
  },
  charge: {
    tele: 0.78,
    act: 0.6,
    rest: 0.8,
    follow: true,
    telegraph: (e, g) => ({
      kind: 'line',
      t: 0,
      dur: 0.78,
      ang: toPlayer(g, e),
      len: 300,
      rad: 0,
      x: e.x,
      y: e.y,
      n: 0,
    }),
    start: (e, g) => {
      const a = toPlayer(g, e);
      e.data.ang = a;
      e.vx = Math.cos(a) * 360;
      e.vy = Math.sin(a) * 360;
      sfx.dash();
      shake(g, 3);
    },
    tick: (e, g, dt) => {
      e.vx = Math.cos(e.data.ang) * 360;
      e.vy = Math.sin(e.data.ang) * 360;
      moveBody(g.room, e, dt);
      if (g.rng.chance(0.5)) burst(g, e.x, e.y, 1, false, 40);
    },
  },
  slam: {
    tele: 0.72,
    act: 0.42,
    rest: 0.75,
    telegraph: (_e, g) => ({
      kind: 'circle',
      t: 0,
      dur: 0.72,
      ang: 0,
      len: 0,
      rad: 40,
      x: g.player.x,
      y: g.player.y,
      n: 0,
    }),
    start: (e, g) => {
      e.data.tx = g.player.x;
      e.data.ty = g.player.y;
      e.data.done = 0;
    },
    tick: (e, g, dt) => {
      const tx = e.data.tx,
        ty = e.data.ty;
      const a = Math.atan2(ty - e.y, tx - e.x);
      const d = dist(e.x, e.y, tx, ty);
      if (d > 6) {
        e.vx = Math.cos(a) * 300;
        e.vy = Math.sin(a) * 300;
        moveBody(g.room, e, dt);
      } else if (!e.data.done) {
        e.data.done = 1;
        radial(g, e.x, e.y, 16, g.rng.range(0, TAU), 132);
        radial(g, e.x, e.y, 10, 0.3, 74, { r: 4 });
        burst(g, e.x, e.y, 26, true, 150);
        shake(g, 7);
        sfx.boom();
      }
    },
  },
  beam: {
    tele: 0.85,
    act: 0.5,
    rest: 0.85,
    follow: true,
    telegraph: (e, g) => ({
      kind: 'line',
      t: 0,
      dur: 0.85,
      ang: toPlayer(g, e),
      len: 460,
      rad: 0,
      x: e.x,
      y: e.y,
      n: 0,
    }),
    start: (e, g) => {
      e.data.ang = toPlayer(g, e);
      spawnBeam(g, e, e.data.ang, 0.5);
    },
  },
  summon: {
    tele: 0.55,
    act: 0.2,
    rest: 0.85,
    telegraph: (e) => ({ kind: 'ring', t: 0, dur: 0.55, ang: 0, len: 0, rad: 50, x: e.x, y: e.y, n: 3 }),
    start: (e, g) => {
      const types = ['crawler', 'spitter', 'lunger'];
      for (let k = 0; k < 3; k++) {
        const a = (k / 3) * TAU + g.rng.range(0, 1);
        const t = types[Math.min(types.length - 1, g.motif + (k % 2))];
        const m = spawnEnemy(g, t, e.x + Math.cos(a) * 26, e.y + Math.sin(a) * 26);
        m.hp = m.maxHp = Math.max(1, Math.round(m.maxHp * 0.7));
        burst(g, m.x, m.y, 8, false, 70);
      }
      sfx.phase();
    },
  },
  homing: {
    tele: 0.5,
    act: 0.3,
    rest: 0.7,
    telegraph: (e) => ({ kind: 'ring', t: 0, dur: 0.5, ang: 0, len: 0, rad: 26, x: e.x, y: e.y, n: 3 }),
    start: (e, g) => {
      const a = toPlayer(g, e);
      fan(g, e.x, e.y, a, 3, 0.9, 74, { r: 4.5, homing: 1.5, life: 6 });
    },
  },
  blink: {
    tele: 0.45,
    act: 0.22,
    rest: 0.45,
    telegraph: (_e, g) => ({
      kind: 'dots',
      t: 0,
      dur: 0.45,
      ang: 0,
      len: 0,
      rad: 16,
      x: g.player.x,
      y: g.player.y,
      n: 0,
    }),
    start: (e, g) => {
      burst(g, e.x, e.y, 14, false, 120);
      let bx = e.x,
        by = e.y;
      for (let tries = 0; tries < 12; tries++) {
        const a = g.rng.range(0, TAU);
        const d = g.rng.range(60, 110);
        bx = g.player.x + Math.cos(a) * d;
        by = g.player.y + Math.sin(a) * d;
        if (!moveBody(g.room, { x: bx, y: by, vx: 0, vy: 0, r: e.r }, 0).hitX) break;
      }
      e.x = bx;
      e.y = by;
      burst(g, e.x, e.y, 14, false, 120);
      const a = toPlayer(g, e);
      fan(g, e.x, e.y, a, 4, 0.6, 132);
      sfx.dash();
    },
  },
};

// ---------------------------------------------------------------------------
function updateBoss(g: Game, e: Enemy, dt: number) {
  const b = e.boss!;
  const p = g.player;
  e.t += dt;
  b.spin += dt * 0.9;

  if (e.state === 'intro') {
    e.timer -= dt;
    e.y += Math.sin(e.t * 6) * 0.2;
    if (e.timer <= 0) {
      e.state = 'idle';
      e.timer = 0.7;
    }
    return;
  }

  if (b.invuln > 0) {
    b.invuln -= dt;
    e.vx *= 0.9;
    e.vy *= 0.9;
    moveBody(g.room, e, dt);
    if (b.invuln <= 0) {
      e.state = 'idle';
      e.timer = 0.35;
    }
    return;
  }

  // phase gates
  const frac = e.hp / e.maxHp;
  const wantPhase = frac <= 0.34 ? 3 : frac <= 0.67 ? 2 : 1;
  if (wantPhase > b.phase) {
    b.phase = wantPhase;
    b.invuln = 1.15;
    b.idx = 0;
    e.state = 'idle';
    e.timer = 0;
    g.hazards.length = 0;
    g.beams.length = 0;
    g.flash = 0.45;
    shake(g, 8);
    g.hitstop = 0.18;
    burst(g, e.x, e.y, 40, false, 170, 2);
    addFloat(g, e.x, e.y - 26, 'PHASE ' + b.phase, false);
    sfx.phase();
    return;
  }

  const script = b.script[b.phase - 1];

  switch (e.state) {
    case 'idle': {
      // drift to a hover point around the player
      const a = Math.atan2(e.y - p.y, e.x - p.x) + Math.sin(e.t * 0.8) * 0.6;
      const want = 108;
      const d = dist(e.x, e.y, p.x, p.y);
      const sp = ENEMIES[e.type].speed * (1 + (b.phase - 1) * 0.22);
      if (Math.abs(d - want) > 14) seek(e, a, sp, 2.4);
      else {
        e.vx *= 0.92;
        e.vy *= 0.92;
      }
      moveBody(g.room, e, dt);
      face(e, Math.atan2(p.y - e.y, p.x - e.x), 5);
      e.timer -= dt;
      if (e.timer <= 0) {
        const name = script[b.idx % script.length];
        b.idx++;
        b.attack = name;
        const atk = ATTACKS[name];
        e.state = 'tele';
        e.timer = atk.tele * (b.phase === 3 ? 0.78 : 1);
        e.data.acc = 0;
        e.tele = atk.telegraph ? atk.telegraph(e, g) : null;
        if (e.tele) e.tele.dur = e.timer;
        sfx.tele();
      }
      break;
    }
    case 'tele': {
      e.vx *= 0.88;
      e.vy *= 0.88;
      moveBody(g.room, e, dt);
      const atk = ATTACKS[b.attack];
      if (atk?.follow && e.tele) {
        e.tele.x = e.x;
        e.tele.y = e.y;
        if (e.timer > 0.16) e.tele.ang = toPlayer(g, e);
      }
      e.timer -= dt;
      if (e.timer <= 0) {
        clearTele(e);
        e.state = 'act';
        e.timer = atk.act;
        atk.start?.(e, g);
      }
      break;
    }
    case 'act': {
      const atk = ATTACKS[b.attack];
      atk.tick?.(e, g, dt);
      if (!atk.tick) {
        e.vx *= 0.9;
        e.vy *= 0.9;
        moveBody(g.room, e, dt);
      }
      e.timer -= dt;
      if (e.timer <= 0) {
        e.state = 'rest';
        e.timer = atk.rest * (b.phase === 3 ? 0.7 : 1);
      }
      break;
    }
    case 'rest': {
      e.vx *= 0.86;
      e.vy *= 0.86;
      moveBody(g.room, e, dt);
      face(e, Math.atan2(p.y - e.y, p.x - e.x), 5);
      e.timer -= dt;
      if (e.timer <= 0) {
        e.state = 'idle';
        e.timer = 0.35;
      }
      break;
    }
  }
}

// ---------------------------------------------------------------------------
export function updateEnemies(g: Game, dt: number) {
  for (let i = g.enemies.length - 1; i >= 0; i--) {
    const e = g.enemies[i];
    if (e.flash > 0) e.flash -= dt;
    if (e.tele) e.tele.t += dt;
    if (e.boss) updateBoss(g, e, dt);
    else updateMinion(g, e, dt);
  }
  // soft separation so bodies do not stack
  for (let i = 0; i < g.enemies.length; i++) {
    const a = g.enemies[i];
    if (a.boss) continue;
    for (let j = i + 1; j < g.enemies.length; j++) {
      const b = g.enemies[j];
      if (b.boss) continue;
      const dx = b.x - a.x,
        dy = b.y - a.y;
      const d = Math.hypot(dx, dy);
      const min = a.r + b.r;
      if (d > 0.001 && d < min) {
        const push = ((min - d) / d) * 0.5;
        a.x -= dx * push;
        a.y -= dy * push;
        b.x += dx * push;
        b.y += dy * push;
      }
    }
  }
  // clamp inside room
  for (const e of g.enemies) {
    e.x = clamp(e.x, e.r, g.room.w * 12 - e.r);
    e.y = clamp(e.y, e.r, g.room.h * 12 - e.r);
  }
}

export function spawnBossFor(g: Game) {
  const b = spawnBoss(g, g.motif);
  g.bossIntro = 2.2;
  return b;
}
