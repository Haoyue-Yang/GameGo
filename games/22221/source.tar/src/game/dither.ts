// ---------------------------------------------------------------------------
// Ordered-dither pattern factory + static room background painter.
// Everything is white pixels on transparent, used as repeat patterns so the
// "grey" is really a dither screen -- true 1-bit.
// ---------------------------------------------------------------------------

import { Room, TILE, T_WALL, T_FLOOR, tileAt, MOTIFS } from './core';

const BAYER4 = [0, 8, 2, 10, 12, 4, 14, 6, 3, 11, 1, 9, 15, 7, 13, 5];

export type PatternKind = 'bayer' | 'checker' | 'diag' | 'noise';

function hash2(x: number, y: number) {
  let h = (x * 374761393 + y * 668265263) | 0;
  h = (h ^ (h >>> 13)) * 1274126177;
  return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
}

function threshold(kind: PatternKind, i: number, j: number): number {
  switch (kind) {
    case 'bayer':
      return BAYER4[(j & 3) * 4 + (i & 3)] / 16;
    case 'checker':
      return (((i & 1) + (j & 1)) & 1) * 0.5 + ((i >> 1) & 1) * 0.25;
    case 'diag':
      return ((i + j) & 3) / 4;
    case 'noise':
      return hash2(i, j);
  }
}

const patCache = new Map<string, HTMLCanvasElement>();

export function ditherCanvas(kind: PatternKind, level: number, size = 4): HTMLCanvasElement {
  const key = `${kind}:${level}:${size}`;
  const hit = patCache.get(key);
  if (hit) return hit;
  const c = document.createElement('canvas');
  c.width = size;
  c.height = size;
  const g = c.getContext('2d')!;
  g.fillStyle = '#ffffff';
  for (let j = 0; j < size; j++)
    for (let i = 0; i < size; i++) if (threshold(kind, i, j) < level / 16) g.fillRect(i, j, 1, 1);
  patCache.set(key, c);
  return c;
}

const patStyleCache = new WeakMap<CanvasRenderingContext2D, Map<string, CanvasPattern>>();
export function ditherPattern(
  ctx: CanvasRenderingContext2D,
  kind: PatternKind,
  level: number,
  size = 4,
): CanvasPattern {
  const key = `${kind}:${level}:${size}`;
  let per = patStyleCache.get(ctx);
  if (!per) {
    per = new Map();
    patStyleCache.set(ctx, per);
  }
  let p = per.get(key);
  if (!p) {
    p = ctx.createPattern(ditherCanvas(kind, level, size), 'repeat')!;
    per.set(key, p);
  }
  return p;
}

/** Fill a rect with a dither level, offset by the world origin so patterns align. */
export function fillDither(
  ctx: CanvasRenderingContext2D,
  kind: PatternKind,
  level: number,
  x: number,
  y: number,
  w: number,
  h: number,
  size = 4,
) {
  if (level <= 0) return;
  if (level >= 16) {
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(x, y, w, h);
    return;
  }
  const p = ditherPattern(ctx, kind, level, size);
  ctx.save();
  ctx.translate(Math.round(x), Math.round(y));
  ctx.fillStyle = p;
  ctx.fillRect(0, 0, Math.round(w), Math.round(h));
  ctx.restore();
}

// ---------------------------------------------------------------------------
// Room background: painted once per room into an offscreen canvas.
// ---------------------------------------------------------------------------
export function renderRoomBg(room: Room): HTMLCanvasElement {
  const kind = MOTIFS[room.motif % MOTIFS.length].pattern;
  const W = room.w * TILE;
  const H = room.h * TILE;
  const c = document.createElement('canvas');
  c.width = W;
  c.height = H;
  const g = c.getContext('2d')!;
  g.fillStyle = '#000000';
  g.fillRect(0, 0, W, H);

  // --- floor ---------------------------------------------------------------
  fillDither(g, kind, 2, 0, 0, W, H);
  // motif floor flavour
  if (room.motif === 0) {
    for (let n = 0; n < room.w * room.h * 0.06; n++) {
      const x = Math.floor(Math.random() * room.w) * TILE + 3;
      const y = Math.floor(Math.random() * room.h) * TILE + 3;
      if (tileAt(room, Math.floor(x / TILE), Math.floor(y / TILE)) !== T_FLOOR) continue;
      fillDither(g, 'noise', 6, x, y, 6, 6);
    }
  } else if (room.motif === 1) {
    g.fillStyle = '#ffffff';
    for (let ty = 2; ty < room.h - 2; ty += 4)
      for (let tx = 2; tx < room.w - 2; tx++) {
        if (tileAt(room, tx, ty) !== T_FLOOR) continue;
        if ((tx + ty) % 8 === 0) g.fillRect(tx * TILE + 5, ty * TILE + 5, 1, 1);
      }
  } else if (room.motif === 2) {
    for (let ty = 3; ty < room.h - 2; ty += 3) {
      for (let tx = 2; tx < room.w - 2; tx++) {
        if (tileAt(room, tx, ty) !== T_FLOOR) continue;
        const ph = Math.sin(tx * 0.7 + ty * 1.3);
        if (ph > 0.55) fillDither(g, 'diag', 5, tx * TILE, ty * TILE, TILE, 2);
      }
    }
  } else {
    for (let n = 0; n < room.w * room.h * 0.1; n++) {
      const x = Math.floor(Math.random() * room.w) * TILE;
      const y = Math.floor(Math.random() * room.h) * TILE;
      if (tileAt(room, x / TILE, y / TILE) !== T_FLOOR) continue;
      fillDither(g, 'noise', 8, x, y, TILE, TILE);
    }
  }

  // --- wall drop shadows onto the floor ------------------------------------
  for (let ty = 0; ty < room.h; ty++)
    for (let tx = 0; tx < room.w; tx++) {
      if (tileAt(room, tx, ty) !== T_FLOOR) continue;
      const x = tx * TILE,
        y = ty * TILE;
      if (tileAt(room, tx, ty - 1) === T_WALL) fillDither(g, kind, 6, x, y, TILE, 5);
      if (tileAt(room, tx - 1, ty) === T_WALL) fillDither(g, kind, 5, x, y, 4, TILE);
      if (tileAt(room, tx + 1, ty) === T_WALL) fillDither(g, kind, 3, x + TILE - 3, y, 3, TILE);
    }

  // --- wall bodies ---------------------------------------------------------
  for (let ty = 0; ty < room.h; ty++)
    for (let tx = 0; tx < room.w; tx++) {
      if (tileAt(room, tx, ty) !== T_WALL) continue;
      const x = tx * TILE,
        y = ty * TILE;
      const interior =
        tileAt(room, tx - 1, ty) === T_WALL &&
        tileAt(room, tx + 1, ty) === T_WALL &&
        tileAt(room, tx, ty - 1) === T_WALL &&
        tileAt(room, tx, ty + 1) === T_WALL;
      fillDither(g, kind, interior ? 7 : 12, x, y, TILE, TILE);
    }

  // --- wall silhouette: 1px white outline on every wall/floor edge ---------
  g.fillStyle = '#ffffff';
  for (let ty = 0; ty < room.h; ty++)
    for (let tx = 0; tx < room.w; tx++) {
      if (tileAt(room, tx, ty) !== T_WALL) continue;
      const x = tx * TILE,
        y = ty * TILE;
      if (tileAt(room, tx, ty - 1) !== T_WALL) g.fillRect(x, y, TILE, 1);
      if (tileAt(room, tx, ty + 1) !== T_WALL) g.fillRect(x, y + TILE - 1, TILE, 1);
      if (tileAt(room, tx - 1, ty) !== T_WALL) g.fillRect(x, y, 1, TILE);
      if (tileAt(room, tx + 1, ty) !== T_WALL) g.fillRect(x + TILE - 1, y, 1, TILE);
    }

  // --- wall face detail: lit top band, dark base ---------------------------
  for (let ty = 0; ty < room.h; ty++)
    for (let tx = 0; tx < room.w; tx++) {
      if (tileAt(room, tx, ty) !== T_WALL) continue;
      const x = tx * TILE,
        y = ty * TILE;
      if (tileAt(room, tx, ty - 1) !== T_WALL) fillDither(g, kind, 15, x + 1, y + 1, TILE - 2, 3);
      if (tileAt(room, tx, ty + 1) !== T_WALL) {
        g.fillStyle = '#000000';
        g.fillRect(x + 1, y + TILE - 4, TILE - 2, 3);
      }
    }

  // --- door frames ---------------------------------------------------------
  for (const d of room.doors) {
    const x = d.tx * TILE,
      y = d.ty * TILE;
    g.fillStyle = '#000000';
    g.fillRect(x, y, TILE, TILE);
    g.fillStyle = '#ffffff';
    if (d.side === 'w' || d.side === 'e') {
      g.fillRect(x, y, TILE, 1);
      g.fillRect(x, y + TILE - 1, TILE, 1);
    } else {
      g.fillRect(x, y, 1, TILE);
      g.fillRect(x + TILE - 1, y, 1, TILE);
    }
  }

  return c;
}
