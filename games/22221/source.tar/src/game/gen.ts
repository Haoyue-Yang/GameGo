// ---------------------------------------------------------------------------
// Room generation. Rooms are larger than the 384x216 viewport so the camera
// has something to clamp against. A guaranteed lane keeps every room solvable.
// ---------------------------------------------------------------------------

import { Door, RNG, Room, T_DOOR, T_FLOOR, T_LOCK, T_WALL, TILE, tileAt } from './core';
import { MOTIF_POOLS } from './content';
import { renderRoomBg } from './dither';

const ROOM_LABELS = [
  'ANTECHAMBER',
  'SERVICE SPINE',
  'DRY CISTERN',
  'SORTING FLOOR',
  'PALE GALLERY',
  'THE SUMP',
  'CUT WORKS',
  'HOLLOW VAULT',
  'TIDE LOCK',
  'SALT STAIR',
  'NULL APPROACH',
  'THE LAST ROOM',
];

function fillRect(t: Uint8Array, w: number, x0: number, y0: number, x1: number, y1: number, v: number) {
  for (let y = Math.max(0, y0); y <= y1; y++)
    for (let x = Math.max(0, x0); x <= x1; x++) t[y * w + x] = v;
}

export function makeRoom(
  rng: RNG,
  motif: number,
  kind: 'combat' | 'boss',
  roomIndex: number,
  difficulty: number,
): Room {
  const w = kind === 'boss' ? rng.int(36, 40) : rng.int(34, 48);
  const h = kind === 'boss' ? rng.int(26, 28) : rng.int(24, 32);
  const tiles = new Uint8Array(w * h).fill(T_WALL);

  // carve interior
  const ix0 = 2,
    iy0 = 2,
    ix1 = w - 3,
    iy1 = h - 3;
  fillRect(tiles, w, ix0, iy0, ix1, iy1, T_FLOOR);

  const cy = Math.floor(h / 2);
  const lane = 3; // guaranteed walkable band

  const place = (x0: number, y0: number, x1: number, y1: number) => {
    for (let y = y0; y <= y1; y++)
      for (let x = x0; x <= x1; x++) {
        if (x <= ix0 || x >= ix1 || y <= iy0 || y >= iy1) continue;
        if (Math.abs(y - cy) < lane) continue; // keep the lane clear
        tiles[y * w + x] = T_WALL;
      }
  };

  if (kind === 'combat') {
    if (motif === 0) {
      const n = rng.int(7, 11);
      for (let i = 0; i < n; i++) {
        const s = rng.int(1, 2);
        place(rng.int(ix0 + 1, ix1 - 3), rng.int(iy0 + 1, iy1 - 3), rng.int(ix0 + 1, ix1 - 3) + s, rng.int(iy0 + 1, iy1 - 3) + s);
      }
    } else if (motif === 1) {
      // symmetric diagonal lattice
      const cx = Math.floor(w / 2);
      for (let i = -14; i <= 14; i++) {
        const x = cx + i;
        const y = cy + Math.abs(i) * 2;
        if (y > iy0 && y < iy1) {
          tiles[y * w + x] = T_WALL;
          tiles[y * w + (w - 1 - x)] = T_WALL;
        }
      }
      for (let k = 0; k < 5; k++) place(rng.int(ix0 + 2, cx - 4), rng.int(iy0 + 1, cy - 4), rng.int(ix0 + 2, cx - 4), rng.int(iy0 + 1, cy - 4) + 3);
    } else if (motif === 2) {
      // large blocks with gaps
      for (let gy = iy0 + 1; gy < iy1 - 3; gy += 5)
        for (let gx = ix0 + 1; gx < ix1 - 3; gx += 6) {
          if (rng.chance(0.35)) continue;
          place(gx, gy, gx + 3, gy + 2);
        }
    } else {
      // null: corridor maze
      for (let gx = ix0 + 2; gx < ix1 - 2; gx += 4) {
        const top = rng.int(iy0 + 1, cy - 5);
        place(gx, top, gx, top + rng.int(4, 9));
      }
      for (let k = 0; k < 6; k++) place(rng.int(ix0 + 1, ix1 - 2), rng.int(iy0 + 1, iy1 - 2), rng.int(ix0 + 1, ix1 - 2), rng.int(iy0 + 1, iy1 - 2) + 2);
    }
  } else {
    // boss arena: open floor, four corner buttresses
    const bx = [ix0 + 1, ix1 - 4];
    const by = [iy0 + 1, iy1 - 4];
    for (const x of bx) for (const y of by) place(x, y, x + 2, y + 2);
    for (let k = 0; k < 3; k++) place(rng.int(ix0 + 3, ix1 - 5), rng.int(iy0 + 2, iy1 - 4), rng.int(ix0 + 3, ix1 - 5), rng.int(iy0 + 2, iy1 - 4));
    // guarantee the spawn point is open
    const ccx = Math.floor(w / 2),
      ccy = Math.floor(h / 2);
    for (let y = ccy - 4; y <= ccy + 4; y++)
      for (let x = ccx - 4; x <= ccx + 4; x++) {
        if (Math.hypot(x - ccx, y - ccy) > 4.4) continue;
        if (x > ix0 && x < ix1 && y > iy0 && y < iy1) tiles[y * w + x] = T_FLOOR;
      }
  }

  // doors
  const doors: Door[] = [];
  const mkDoor = (tx: number, ty: number, side: Door['side'], kind2: Door['kind']) => {
    tiles[ty * w + tx] = T_LOCK;
    doors.push({ tx, ty, side, kind: kind2, open: false });
  };
  mkDoor(1, cy, 'w', 'entry');
  if (kind === 'combat') mkDoor(w - 2, cy, 'e', 'exit');

  // carve a little pocket in front of each door so nobody spawns stuck
  for (const d of doors) {
    for (let y = d.ty - 1; y <= d.ty + 1; y++) {
      const lo = d.side === 'e' ? d.tx - 2 : d.tx;
      const hi = d.side === 'e' ? d.tx : d.tx + 2;
      for (let x = lo; x <= hi; x++)
        if (x >= 0 && x < w && y >= 0 && y < h) tiles[y * w + x] = T_FLOOR;
    }
    if (d.side === 'w') tiles[d.ty * w + 2] = T_FLOOR;
    if (d.side === 'e') tiles[d.ty * w + (w - 3)] = T_FLOOR;
  }

  const room: Room = {
    w,
    h,
    tiles,
    motif,
    kind,
    doors,
    spawns: [],
    cleared: false,
    bg: null,
    label: kind === 'boss' ? 'BOSS HALL' : ROOM_LABELS[(motif * 3 + roomIndex) % ROOM_LABELS.length],
  };

  // connectivity pass: flood from entry, wall off anything unreachable
  const seen = new Uint8Array(w * h);
  const stack = [cy * w + 2];
  seen[cy * w + 2] = 1;
  while (stack.length) {
    const i = stack.pop()!;
    const x = i % w,
      y = (i / w) | 0;
    const push = (nx: number, ny: number) => {
      if (nx < 0 || ny < 0 || nx >= w || ny >= h) return;
      const j = ny * w + nx;
      if (seen[j]) return;
      const t = tiles[j];
      if (t === T_WALL) return;
      seen[j] = 1;
      stack.push(j);
    };
    push(x + 1, y);
    push(x - 1, y);
    push(x, y + 1);
    push(x, y - 1);
  }
  for (let i = 0; i < tiles.length; i++) if (tiles[i] === T_FLOOR && !seen[i]) tiles[i] = T_WALL;

  // spawn points
  const pool = MOTIF_POOLS[motif % MOTIF_POOLS.length];
  const open: number[] = [];
  for (let i = 0; i < tiles.length; i++) if (tiles[i] === T_FLOOR && seen[i]) open.push(i);
  const entryX = 3 * TILE;
  const count = kind === 'boss' ? 0 : Math.min(14, 4 + motif + roomIndex + Math.floor(difficulty * 2));
  const shuffled = rng.shuffle(open);
  for (const idx of shuffled) {
    if (room.spawns.length >= count) break;
    const x = (idx % w) * TILE + TILE / 2;
    const y = ((idx / w) | 0) * TILE + TILE / 2;
    if (Math.hypot(x - entryX, y - cy * TILE) < 110) continue;
    room.spawns.push({ x, y, type: rng.pick(pool) });
  }
  if (count > 0 && room.spawns.length === 0) {
    // fallback: never hand out an empty room
    room.spawns.push({
      x: (w - 6) * TILE,
      y: cy * TILE,
      type: pool[0],
    });
  }

  room.bg = renderRoomBg(room);
  return room;
}

export function openDoors(room: Room) {
  for (const d of room.doors) {
    if (d.kind === 'exit') {
      d.open = true;
      room.tiles[d.ty * room.w + d.tx] = T_DOOR;
    }
  }
}

export function doorOpen(room: Room, side: 'w' | 'e' | 'n' | 's') {
  return room.doors.some((d) => d.side === side && d.open);
}

export function isFloor(room: Room, tx: number, ty: number) {
  const t = tileAt(room, tx, ty);
  return t === T_FLOOR || t === T_DOOR;
}
