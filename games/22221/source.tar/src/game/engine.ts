// ---------------------------------------------------------------------------
// Simulation: player control, projectiles, room flow, run/meta transitions.
// ---------------------------------------------------------------------------

import {
  Enemy,
  MOTIFS,
  RNG,
  Room,
  TAU,
  TILE,
  circleHitsWall,
  clamp,
  dist,
  moveBody,
  tileAt,
  T_DOOR,
} from './core';
import { BOSS_NAMES, POWERUPS } from './content';
import { makeRoom, openDoors } from './gen';
import { updateEnemies, spawnBossFor } from './ai';
import {
  Game,
  applyPowerup,
  burst,
  cameraFor,
  damageEnemy,
  healPlayer,
  hurtPlayer,
  makePlayer,
  nearestEnemy,
  rollDraft,
  shake,
  spawnEnemy,
  statsFromUnlocks,
} from './state';
import { sfx } from './audio';
import { writeSave } from './save';

export interface Input {
  up: boolean;
  down: boolean;
  left: boolean;
  right: boolean;
  fx: number;
  fy: number;
  dash: boolean;
  confirm: boolean;
  back: boolean;
  leftEdge: boolean;
  rightEdge: boolean;
  upEdge: boolean;
  downEdge: boolean;
}

export function emptyInput(): Input {
  return {
    up: false,
    down: false,
    left: false,
    right: false,
    fx: 0,
    fy: 0,
    dash: false,
    confirm: false,
    back: false,
    leftEdge: false,
    rightEdge: false,
    upEdge: false,
    downEdge: false,
  };
}

// --- run lifecycle ----------------------------------------------------------
export function startRun(g: Game) {
  const stats = statsFromUnlocks(g.save);
  g.player = makePlayer(stats);
  g.coins = 0;
  g.kills = 0;
  g.time = 0;
  g.motif = 0;
  g.roomIndex = 0;
  g.rng = new RNG((Math.random() * 1e9) | 0);
  g.lastPickups = 0;
  g.fade = 0;
  g.fadeDir = 0;
  g.pending = null;
  if (g.save.unlocks.u_mend) g.player.hp = Math.min(stats.maxHp, g.player.hp + 1);
  if (g.save.unlocks.u_relic) applyPowerup(g, g.rng.pick(POWERUPS));
  g.mode = 'playing';
  const room = makeRoom(g.rng, 0, 'combat', 0, 0);
  enterRoom(g, room, true);
  g.save.runs++;
  writeSave(g.save);
}

export function enterRoom(g: Game, room: Room, atEntry: boolean) {
  g.room = room;
  g.enemies = [];
  g.bullets = [];
  g.hazards = [];
  g.beams = [];
  g.pickups = [];
  g.parts = [];
  g.floats = [];
  g.boss = null;
  g.auraT = 0;
  const p = g.player;
  if (atEntry) {
    const d = room.doors.find((x) => x.kind === 'entry')!;
    p.x = (d.tx + 1) * TILE + 6;
    p.y = (d.ty + 0.5) * TILE;
  }
  p.vx = 0;
  p.vy = 0;
  p.dashT = 0;
  p.iframe = 0.6;
  for (const s of room.spawns) spawnEnemy(g, s.type, s.x, s.y);
  if (room.kind === 'boss') {
    spawnBossFor(g);
    g.banner = { text: BOSS_NAMES[g.motif], sub: MOTIFS[g.motif].name, t: 2.8 };
  } else {
    g.banner = { text: MOTIFS[g.motif].name, sub: room.label, t: 2.2 };
  }
  cameraFor(g);
}

function nextRoom(g: Game): Room {
  let motif = g.motif;
  let idx = g.roomIndex + 1;
  if (idx > 2) {
    motif++;
    idx = 0;
  }
  g.motif = motif;
  g.roomIndex = idx;
  const kind: 'combat' | 'boss' = idx === 2 ? 'boss' : 'combat';
  return makeRoom(g.rng, motif, kind, idx, (motif * 3 + idx) / 12);
}

function startTransition(g: Game) {
  if (g.fadeDir !== 0) return;
  g.pending = nextRoom(g);
  g.fadeDir = 1;
  sfx.door();
}

function bank(g: Game) {
  const gained = Math.round(g.coins * g.player.stats.coinMult);
  g.save.bank += gained;
  g.lastPickups = gained;
  g.save.best = Math.max(g.save.best, g.motif * 3 + g.roomIndex + (g.room.cleared ? 1 : 0));
  writeSave(g.save);
}

// --- player -----------------------------------------------------------------
function fire(g: Game) {
  const p = g.player;
  const s = p.stats;
  const n = Math.max(1, Math.round(s.proj));
  const total = s.spread * (n - 1);
  for (let i = 0; i < n; i++) {
    const t = n === 1 ? 0.5 : i / (n - 1);
    const a = p.aim + (t - 0.5) * total;
    g.bullets.push({
      x: p.x + Math.cos(a) * 7,
      y: p.y + Math.sin(a) * 7,
      vx: Math.cos(a) * s.bulletSpeed,
      vy: Math.sin(a) * s.bulletSpeed,
      r: 2.5,
      dmg: s.dmg,
      life: s.bulletLife,
      friendly: true,
      pierce: s.pierce,
      hit: [],
      homing: s.homing,
      ricochet: s.ricochet,
      kind: 'bolt',
      ang: a,
      spin: 0,
    });
  }
  sfx.shoot();
  burst(g, p.x + Math.cos(p.aim) * 8, p.y + Math.sin(p.aim) * 8, 1, false, 40);
}

function updatePlayer(g: Game, dt: number, input: Input) {
  const p = g.player;
  const s = p.stats;
  p.anim += dt;
  p.iframe = Math.max(0, p.iframe - dt);
  p.hitFlash = Math.max(0, p.hitFlash - dt);
  p.fireCd -= dt;

  if (p.dashCd > 0) {
    p.dashCd -= dt;
    if (p.dashCd <= 0) {
      p.dashCharges = Math.min(s.dashCharges, p.dashCharges + 1);
      if (p.dashCharges < s.dashCharges) p.dashCd = s.dashCd;
    }
  }

  let mx = (input.right ? 1 : 0) - (input.left ? 1 : 0);
  let my = (input.down ? 1 : 0) - (input.up ? 1 : 0);
  const ml = Math.hypot(mx, my);
  if (ml > 0) {
    mx /= ml;
    my /= ml;
  }

  if (input.fx !== 0 || input.fy !== 0) {
    const al = Math.hypot(input.fx, input.fy);
    p.aim = Math.atan2(input.fy / al, input.fx / al);
  }

  if (input.dash && p.dashT <= 0 && p.dashCharges > 0) {
    p.dashCharges--;
    if (p.dashCharges === 0) p.dashCd = s.dashCd;
    p.dashT = 0.17;
    p.dashAng = ml > 0 ? Math.atan2(my, mx) : p.aim;
    p.iframe = Math.max(p.iframe, 0.28);
    sfx.dash();
    burst(g, p.x, p.y, 7, false, 80);
  }

  if (p.dashT > 0) {
    p.dashT -= dt;
    const k = 0.55 + 0.45 * clamp(p.dashT / 0.17, 0, 1);
    p.vx = Math.cos(p.dashAng) * 330 * k;
    p.vy = Math.sin(p.dashAng) * 330 * k;
    p.ghosts.push({ x: p.x, y: p.y, a: p.aim, t: 0.2 });
  } else {
    p.vx += (mx * s.speed - p.vx) * Math.min(1, dt * 17);
    p.vy += (my * s.speed - p.vy) * Math.min(1, dt * 17);
  }
  for (let i = p.ghosts.length - 1; i >= 0; i--) {
    p.ghosts[i].t -= dt;
    if (p.ghosts[i].t <= 0) p.ghosts.splice(i, 1);
  }
  moveBody(g.room, p, dt);

  if ((input.fx !== 0 || input.fy !== 0) && p.fireCd <= 0) {
    fire(g);
    p.fireCd = 1 / s.fireRate;
  }
}

// --- projectiles ------------------------------------------------------------
function updateBullets(g: Game, dt: number) {
  const room = g.room;
  for (let i = g.bullets.length - 1; i >= 0; i--) {
    const b = g.bullets[i];
    b.life -= dt;
    if (b.life <= 0) {
      g.bullets.splice(i, 1);
      continue;
    }
    if (b.homing > 0) {
      const t = nearestEnemy(g, b.x, b.y, 150);
      if (t) {
        const want = Math.atan2(t.y - b.y, t.x - b.x);
        const cur = Math.atan2(b.vy, b.vx);
        let d = ((want - cur + Math.PI * 3) % TAU) - Math.PI;
        const na = cur + clamp(d, -b.homing * dt, b.homing * dt);
        const sp = Math.hypot(b.vx, b.vy);
        b.vx = Math.cos(na) * sp;
        b.vy = Math.sin(na) * sp;
      }
    }
    const nx = b.x + b.vx * dt;
    const ny = b.y + b.vy * dt;
    if (circleHitsWall(room, nx, ny, b.r)) {
      if (b.ricochet > 0) {
        b.ricochet--;
        if (circleHitsWall(room, nx, b.y, b.r)) b.vx = -b.vx;
        if (circleHitsWall(room, b.x, ny, b.r)) b.vy = -b.vy;
        b.x += b.vx * dt;
        b.y += b.vy * dt;
        sfx.hit();
        burst(g, b.x, b.y, 2, false, 40);
      } else {
        burst(g, b.x, b.y, 2, false, 40);
        g.bullets.splice(i, 1);
        continue;
      }
    } else {
      b.x = nx;
      b.y = ny;
    }
    for (const e of g.enemies) {
      if (b.hit.includes(e.id)) continue;
      if (dist(b.x, b.y, e.x, e.y) < e.r + b.r) {
        damageEnemy(g, e, b.dmg, b.vx * 0.06, b.vy * 0.06);
        b.hit.push(e.id);
        burst(g, b.x, b.y, 3, false, 60);
        sfx.hit();
        if (b.pierce > 0) b.pierce--;
        else {
          g.bullets.splice(i, 1);
          break;
        }
      }
    }
  }
}

function updateHazards(g: Game, dt: number) {
  const p = g.player;
  for (let i = g.hazards.length - 1; i >= 0; i--) {
    const b = g.hazards[i];
    b.life -= dt;
    if (b.life <= 0) {
      g.hazards.splice(i, 1);
      continue;
    }
    if (b.homing > 0) {
      const want = Math.atan2(p.y - b.y, p.x - b.x);
      const cur = Math.atan2(b.vy, b.vx);
      let d = ((want - cur + Math.PI * 3) % TAU) - Math.PI;
      const na = cur + clamp(d, -b.homing * dt, b.homing * dt);
      const sp = Math.hypot(b.vx, b.vy);
      b.vx = Math.cos(na) * sp;
      b.vy = Math.sin(na) * sp;
    }
    b.x += b.vx * dt;
    b.y += b.vy * dt;
    if (circleHitsWall(g.room, b.x, b.y, b.r)) {
      burst(g, b.x, b.y, 3, true, 50);
      g.hazards.splice(i, 1);
      continue;
    }
    if (p.iframe <= 0 && p.dashT <= 0 && dist(b.x, b.y, p.x, p.y) < p.r + b.r) {
      hurtPlayer(g, b.dmg);
      g.hazards.splice(i, 1);
    }
  }
}

function updateBeams(g: Game, dt: number) {
  const p = g.player;
  for (let i = g.beams.length - 1; i >= 0; i--) {
    const bm = g.beams[i];
    bm.t += dt;
    if (bm.t > bm.dur) {
      g.beams.splice(i, 1);
      continue;
    }
    if (bm.t < 0.06) continue;
    // distance from player to the beam segment
    const ex = bm.x + Math.cos(bm.ang) * bm.len;
    const ey = bm.y + Math.sin(bm.ang) * bm.len;
    const dx = ex - bm.x,
      dy = ey - bm.y;
    const t = clamp(((p.x - bm.x) * dx + (p.y - bm.y) * dy) / (dx * dx + dy * dy), 0, 1);
    const cx = bm.x + dx * t,
      cy = bm.y + dy * t;
    if (dist(cx, cy, p.x, p.y) < bm.w * 0.5 + p.r) hurtPlayer(g, 1);
    if (g.rng.chance(0.4)) {
      const s = g.rng.range(0, bm.len);
      burst(g, bm.x + Math.cos(bm.ang) * s, bm.y + Math.sin(bm.ang) * s, 1, true, 60);
    }
  }
}

function updatePickups(g: Game, dt: number) {
  const p = g.player;
  const s = p.stats;
  for (let i = g.pickups.length - 1; i >= 0; i--) {
    const k = g.pickups[i];
    k.t += dt;
    const d = dist(k.x, k.y, p.x, p.y);
    if (d < s.magnet) {
      const a = Math.atan2(p.y - k.y, p.x - k.x);
      const pull = 260 * (1 - d / s.magnet) + 40;
      k.vx += Math.cos(a) * pull * dt;
      k.vy += Math.sin(a) * pull * dt;
    }
    k.vx *= 0.94;
    k.vy *= 0.94;
    k.x += k.vx * dt;
    k.y += k.vy * dt;
    if (d < 8) {
      if (k.kind === 'coin') {
        g.coins += k.value;
        sfx.coin();
      } else {
        healPlayer(g, k.value);
      }
      g.pickups.splice(i, 1);
    }
  }
}

function updateParticles(g: Game, dt: number) {
  for (let i = g.parts.length - 1; i >= 0; i--) {
    const q = g.parts[i];
    q.life -= dt;
    if (q.life <= 0) {
      g.parts.splice(i, 1);
      continue;
    }
    q.x += q.vx * dt;
    q.y += q.vy * dt;
    q.vx -= q.vx * q.drag * dt;
    q.vy -= q.vy * q.drag * dt;
  }
}

function contactDamage(g: Game) {
  const p = g.player;
  for (const e of g.enemies) {
    if (dist(e.x, e.y, p.x, p.y) < e.r + p.r) {
      hurtPlayer(g, e.contact);
      const a = Math.atan2(p.y - e.y, p.x - e.x);
      p.vx = Math.cos(a) * 150;
      p.vy = Math.sin(a) * 150;
    }
  }
}

function auraTick(g: Game, dt: number) {
  const s = g.player.stats;
  if (s.aura <= 0) return;
  g.auraT -= dt;
  if (g.auraT > 0) return;
  g.auraT = 0.25;
  for (let i = g.enemies.length - 1; i >= 0; i--) {
    const e = g.enemies[i];
    if (dist(e.x, e.y, g.player.x, g.player.y) < 34 + e.r) {
      damageEnemy(g, e, s.aura * 0.25);
      if (g.rng.chance(0.5)) burst(g, e.x, e.y, 1, false, 40);
    }
  }
}

// --- room flow --------------------------------------------------------------
function checkClear(g: Game, dt: number) {
  if (g.room.cleared) {
    if (g.clearT > 0) g.clearT -= dt;
    return;
  }
  if (g.enemies.length > 0) return;
  g.room.cleared = true;
  g.clearT = 1.1;
  openDoors(g.room);
  sfx.clear();
  if (g.room.kind === 'boss') {
    if (g.motif >= 3) {
      g.banner = { text: 'THE ROOM IS QUIET', sub: 'ALL FOUR MOTIFS CROSSED', t: 3 };
      g.mode = 'victory';
      g.save.wins++;
      bank(g);
      sfx.win();
      return;
    }
    g.banner = { text: 'MOTIF CLEARED', sub: MOTIFS[g.motif].name, t: 2 };
    g.draft = rollDraft(g);
    g.draftIdx = 0;
    g.mode = g.draft.length ? 'draft' : 'playing';
  } else {
    g.banner = { text: 'ROOM CLEAR', sub: 'EXIT UNLOCKED', t: 1.6 };
    g.draft = rollDraft(g);
    g.draftIdx = 0;
    g.mode = g.draft.length ? 'draft' : 'playing';
  }
}

function checkDoor(g: Game) {
  const p = g.player;
  const tx = Math.floor(p.x / TILE);
  const ty = Math.floor(p.y / TILE);
  for (const d of g.room.doors) {
    if (d.kind !== 'exit' || !d.open) continue;
    if (Math.abs(d.tx - tx) <= 1 && Math.abs(d.ty - ty) <= 1) {
      startTransition(g);
      return;
    }
  }
}

export function chooseDraft(g: Game, index: number) {
  const p = g.draft[index];
  if (!p) return;
  applyPowerup(g, p);
  g.draft = [];
  g.mode = 'playing';
  sfx.buy();
  if (g.room.kind === 'boss') startTransition(g);
}

// --- main update ------------------------------------------------------------
export function update(g: Game, dtRaw: number, input: Input) {
  let dt = dtRaw;
  if (g.hitstop > 0) {
    g.hitstop -= dtRaw;
    dt = dtRaw * 0.12;
  }
  g.shake = Math.max(0, g.shake - dtRaw * 30);
  g.flash = Math.max(0, g.flash - dtRaw * 3.4);
  g.hurtT = Math.max(0, g.hurtT - dtRaw);
  if (g.banner) {
    g.banner.t -= dtRaw;
    if (g.banner.t <= 0) g.banner = null;
  }
  for (let i = g.floats.length - 1; i >= 0; i--) {
    const f = g.floats[i];
    f.t -= dtRaw;
    f.y -= 16 * dtRaw;
    if (f.t <= 0) g.floats.splice(i, 1);
  }

  if (g.mode === 'title' || g.mode === 'shop') {
    g.time += dtRaw;
    updateParticles(g, dt);
    return;
  }
  if (g.mode === 'dead' || g.mode === 'victory') {
    g.deathT += dtRaw;
    updateParticles(g, dt);
    updateHazards(g, dt);
    return;
  }
  if (g.mode === 'draft') {
    updateParticles(g, dt);
    return;
  }

  // room fade
  if (g.fadeDir !== 0) {
    g.fade += g.fadeDir * dtRaw * 3.2;
    if (g.fade >= 1) {
      g.fade = 1;
      if (g.pending) {
        enterRoom(g, g.pending, true);
        g.pending = null;
        g.fadeDir = -1;
      }
    } else if (g.fade <= 0) {
      g.fade = 0;
      g.fadeDir = 0;
    }
  }

  g.time += dt;
  if (g.bossIntro > 0) g.bossIntro -= dtRaw;
  updatePlayer(g, dt, input);
  updateEnemies(g, dt);
  updateBullets(g, dt);
  updateHazards(g, dt);
  updateBeams(g, dt);
  updatePickups(g, dt);
  updateParticles(g, dt);
  contactDamage(g);
  auraTick(g, dt);
  checkClear(g, dt);
  if (g.mode === 'playing') checkDoor(g);
  cameraFor(g);

  if (g.player.hp <= 0 && g.mode === 'playing') {
    g.mode = 'dead';
    g.deathT = 0;
    g.flash = 0.6;
    shake(g, 9);
    bank(g);
  }
}

// --- death ------------------------------------------------------------------
export function die(g: Game) {
  if (g.mode === 'dead') return;
  g.mode = 'dead';
  g.deathT = 0;
  bank(g);
}

export function bossOf(g: Game): Enemy | null {
  return g.boss && g.boss.hp > 0 ? g.boss : null;
}

export function coinText(g: Game) {
  return String(Math.round(g.coins * g.player.stats.coinMult));
}

export function doorTileUnder(g: Game) {
  const p = g.player;
  const t = tileAt(g.room, Math.floor(p.x / TILE), Math.floor(p.y / TILE));
  return t === T_DOOR;
}


