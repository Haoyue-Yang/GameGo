// ---------------------------------------------------------------------------
// Tiny WebAudio blip synth. No assets, all square/noise.
// ---------------------------------------------------------------------------

let ctx: AudioContext | null = null;
let master: GainNode | null = null;
let muted = false;

function ac(): AudioContext | null {
  if (typeof window === 'undefined') return null;
  if (!ctx) {
    const C = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!C) return null;
    ctx = new C();
    master = ctx.createGain();
    master.gain.value = 0.32;
    master.connect(ctx.destination);
  }
  if (ctx.state === 'suspended') void ctx.resume();
  return ctx;
}

export function unlockAudio() {
  ac();
}

export function setMuted(m: boolean) {
  muted = m;
  if (master) master.gain.value = m ? 0 : 0.32;
}

export function isMuted() {
  return muted;
}

function tone(
  type: OscillatorType,
  f0: number,
  f1: number,
  dur: number,
  vol: number,
  delay = 0,
) {
  const c = ac();
  if (!c || !master || muted) return;
  const t = c.currentTime + delay;
  const o = c.createOscillator();
  const g = c.createGain();
  o.type = type;
  o.frequency.setValueAtTime(f0, t);
  if (f1 !== f0) o.frequency.exponentialRampToValueAtTime(Math.max(20, f1), t + dur);
  g.gain.setValueAtTime(0, t);
  g.gain.linearRampToValueAtTime(vol, t + 0.006);
  g.gain.exponentialRampToValueAtTime(0.0008, t + dur);
  o.connect(g);
  g.connect(master);
  o.start(t);
  o.stop(t + dur + 0.02);
}

function noise(dur: number, vol: number, hp: number, delay = 0) {
  const c = ac();
  if (!c || !master || muted) return;
  const t = c.currentTime + delay;
  const len = Math.max(1, Math.floor(c.sampleRate * dur));
  const buf = c.createBuffer(1, len, c.sampleRate);
  const d = buf.getChannelData(0);
  for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / len);
  const src = c.createBufferSource();
  src.buffer = buf;
  const f = c.createBiquadFilter();
  f.type = 'highpass';
  f.frequency.value = hp;
  const g = c.createGain();
  g.gain.value = vol;
  src.connect(f);
  f.connect(g);
  g.connect(master);
  src.start(t);
}

export const sfx = {
  shoot: () => tone('square', 720, 300, 0.06, 0.055),
  hit: () => tone('square', 240, 140, 0.05, 0.05),
  kill: () => {
    noise(0.16, 0.16, 700);
    tone('square', 180, 60, 0.14, 0.06);
  },
  dash: () => {
    noise(0.14, 0.1, 1600);
    tone('sine', 420, 900, 0.12, 0.05);
  },
  hurt: () => {
    tone('sawtooth', 200, 70, 0.28, 0.12);
    noise(0.2, 0.14, 300);
  },
  coin: () => {
    tone('square', 1180, 1180, 0.04, 0.05);
    tone('square', 1760, 1760, 0.06, 0.045, 0.04);
  },
  heal: () => {
    tone('sine', 520, 780, 0.1, 0.07);
    tone('sine', 780, 1040, 0.12, 0.06, 0.08);
  },
  door: () => {
    tone('square', 120, 320, 0.18, 0.07);
    noise(0.2, 0.08, 500);
  },
  clear: () => {
    tone('square', 660, 660, 0.07, 0.06);
    tone('square', 880, 880, 0.07, 0.06, 0.07);
    tone('square', 1320, 1320, 0.12, 0.06, 0.14);
  },
  tele: () => tone('sine', 900, 1300, 0.14, 0.03),
  boom: () => {
    noise(0.4, 0.22, 180);
    tone('sawtooth', 140, 40, 0.4, 0.1);
  },
  phase: () => {
    tone('sawtooth', 90, 220, 0.5, 0.12);
    noise(0.5, 0.14, 200);
  },
  ui: () => tone('square', 880, 880, 0.03, 0.04),
  buy: () => {
    tone('square', 520, 780, 0.06, 0.06);
    tone('square', 1040, 1040, 0.09, 0.05, 0.05);
  },
  deny: () => tone('square', 180, 120, 0.12, 0.06),
  death: () => {
    tone('sawtooth', 300, 40, 0.9, 0.14);
    noise(0.8, 0.16, 120);
  },
  win: () => {
    const n = [523, 659, 784, 1046];
    n.forEach((f, i) => tone('square', f, f, 0.16, 0.06, i * 0.13));
  },
};
