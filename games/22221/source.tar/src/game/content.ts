// ---------------------------------------------------------------------------
// Content tables: draftable power-ups, banked-coin unlocks, enemy stats,
// and the four motif bosses with their multi-phase attack scripts.
// ---------------------------------------------------------------------------

import { Powerup, Unlock } from './core';

export const POWERUPS: Powerup[] = [
  {
    id: 'split',
    name: 'SPLIT CYCLE',
    desc: '+1 projectile, wider spread',
    max: 3,
    apply: (s) => {
      s.proj += 1;
      s.spread += 0.16;
      s.dmg = Math.max(1, s.dmg - 0);
    },
  },
  {
    id: 'cadence',
    name: 'CADENCE',
    desc: 'Fire 22% faster',
    max: 4,
    apply: (s) => {
      s.fireRate *= 1.22;
    },
  },
  {
    id: 'edge',
    name: 'HONED EDGE',
    desc: '+1 bullet damage',
    max: 4,
    apply: (s) => {
      s.dmg += 1;
    },
  },
  {
    id: 'pierce',
    name: 'PIERCING',
    desc: 'Bullets pass through 1 more foe',
    max: 3,
    apply: (s) => {
      s.pierce += 1;
    },
  },
  {
    id: 'velocity',
    name: 'OVERPRESSURE',
    desc: 'Faster, longer bullets',
    max: 3,
    apply: (s) => {
      s.bulletSpeed *= 1.18;
      s.bulletLife *= 1.15;
    },
  },
  {
    id: 'seek',
    name: 'SEEKER',
    desc: 'Bullets curve toward foes',
    max: 2,
    apply: (s) => {
      s.homing += 3.4;
    },
  },
  {
    id: 'bounce',
    name: 'RICOCHET',
    desc: 'Bullets bounce off walls',
    max: 2,
    apply: (s) => {
      s.ricochet += 2;
    },
  },
  {
    id: 'stride',
    name: 'STRIDE',
    desc: '+12% move speed',
    max: 3,
    apply: (s) => {
      s.speed *= 1.12;
    },
  },
  {
    id: 'phase',
    name: 'SECOND PHASE',
    desc: '+1 dash charge, shorter cooldown',
    max: 2,
    apply: (s) => {
      s.dashCharges += 1;
      s.dashCd *= 0.78;
    },
  },
  {
    id: 'vital',
    name: 'VITALITY',
    desc: '+1 max life, heal 1',
    max: 3,
    apply: (s) => {
      s.maxHp += 1;
    },
  },
  {
    id: 'siphon',
    name: 'SIPHON',
    desc: '18% chance a kill heals you',
    max: 3,
    apply: (s) => {
      s.lifesteal += 0.18;
    },
  },
  {
    id: 'aura',
    name: 'KINETIC FIELD',
    desc: 'Burn foes standing close',
    max: 3,
    apply: (s) => {
      s.aura += 1.6;
    },
  },
  {
    id: 'damp',
    name: 'DAMPEN',
    desc: 'Hazard shots travel 25% slower',
    max: 2,
    apply: (s) => {
      s.slowBullets *= 0.75;
    },
  },
  {
    id: 'magnet',
    name: 'DRAW',
    desc: 'Coins fly to you from far',
    max: 2,
    apply: (s) => {
      s.magnet += 60;
    },
  },
  {
    id: 'greed',
    name: 'GREED',
    desc: '+35% coins banked',
    max: 2,
    apply: (s) => {
      s.coinMult += 0.35;
    },
  },
];

export const UNLOCKS: Unlock[] = [
  {
    id: 'u_vital',
    name: 'REINFORCED FRAME',
    desc: '+1 max life per rank',
    costs: [45, 110, 220],
    apply: (s) => {
      s.maxHp += 1;
    },
  },
  {
    id: 'u_edge',
    name: 'SHARPENING STONE',
    desc: '+1 bullet damage per rank',
    costs: [60, 150],
    apply: (s) => {
      s.dmg += 1;
    },
  },
  {
    id: 'u_cadence',
    name: 'TRIGGER SPRING',
    desc: '+10% fire rate per rank',
    costs: [40, 95, 180],
    apply: (s) => {
      s.fireRate *= 1.1;
    },
  },
  {
    id: 'u_dash',
    name: 'SPARE CAPACITOR',
    desc: '+1 dash charge',
    costs: [260],
    apply: (s) => {
      s.dashCharges += 1;
    },
  },
  {
    id: 'u_stride',
    name: 'LIGHT SOLES',
    desc: '+8% move speed per rank',
    costs: [50, 120],
    apply: (s) => {
      s.speed *= 1.08;
    },
  },
  {
    id: 'u_greed',
    name: 'COIN AFFINITY',
    desc: '+30% coins banked per rank',
    costs: [55, 130],
    apply: (s) => {
      s.coinMult += 0.3;
    },
  },
  {
    id: 'u_relic',
    name: 'INHERITED RELIC',
    desc: 'Begin each run with a random power-up',
    costs: [200],
    apply: () => {},
  },
  {
    id: 'u_mend',
    name: 'FIELD MENDING',
    desc: 'Start each run with +1 life',
    costs: [170],
    apply: () => {},
  },
];

// --- enemies ---------------------------------------------------------------
export interface EnemyDef {
  hp: number;
  speed: number;
  r: number;
  coin: number;
  contact: number;
  boss?: boolean;
}

export const ENEMIES: Record<string, EnemyDef> = {
  crawler: { hp: 3, speed: 46, r: 5, coin: 1, contact: 1 },
  spitter: { hp: 4, speed: 34, r: 6, coin: 2, contact: 1 },
  lunger: { hp: 5, speed: 40, r: 6, coin: 2, contact: 1 },
  spinner: { hp: 7, speed: 38, r: 7, coin: 3, contact: 1 },
  node: { hp: 8, speed: 0, r: 7, coin: 3, contact: 1 },
  splitter: { hp: 9, speed: 30, r: 8, coin: 3, contact: 1 },
  warden: { hp: 16, speed: 26, r: 10, coin: 6, contact: 1 },
  // bosses
  asher: { hp: 80, speed: 30, r: 14, coin: 40, contact: 1, boss: true },
  choir: { hp: 112, speed: 40, r: 13, coin: 55, contact: 1, boss: true },
  drowned: { hp: 148, speed: 34, r: 15, coin: 70, contact: 1, boss: true },
  sovereign: { hp: 195, speed: 42, r: 16, coin: 100, contact: 1, boss: true },
};

export const BOSS_NAMES = ['THE ASHER', 'GLASS CHOIR', 'THE DROWNED', 'NULL SOVEREIGN'];

/** Attack scripts per phase. Phase 3 always runs the full kit, faster. */
export const BOSS_SCRIPTS: string[][][] = [
  // ASHER
  [
    ['fan', 'charge'],
    ['spiral', 'summon', 'fan'],
    ['cross', 'slam', 'charge', 'radial'],
  ],
  // GLASS CHOIR
  [
    ['fan', 'blink'],
    ['cross', 'beam', 'fan'],
    ['radial', 'charge', 'beam', 'summon'],
  ],
  // DROWNED
  [
    ['homing', 'slam'],
    ['spiral', 'summon', 'homing'],
    ['beam', 'charge', 'radial', 'slam'],
  ],
  // SOVEREIGN
  [
    ['cross', 'fan'],
    ['charge', 'beam', 'summon', 'radial'],
    ['spiral', 'beam', 'charge', 'cross', 'radial', 'slam'],
  ],
];

export const BOSS_TYPES = ['asher', 'choir', 'drowned', 'sovereign'];

/** Enemy pools per motif, weighted by room index. */
export const MOTIF_POOLS: string[][] = [
  ['crawler', 'crawler', 'spitter', 'lunger'],
  ['crawler', 'spitter', 'lunger', 'spinner', 'node'],
  ['crawler', 'lunger', 'spinner', 'node', 'splitter', 'spitter'],
  ['crawler', 'lunger', 'spinner', 'splitter', 'node', 'warden'],
];
