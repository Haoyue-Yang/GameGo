import { useEffect, useRef, useState } from 'react';
import { PAL, VH, VW } from '../game/core';
import { UNLOCKS } from '../game/content';
import { createGame, Game } from '../game/state';
import { chooseDraft, emptyInput, Input, startRun, update } from '../game/engine';
import { drawDeath, drawDraft, drawHud, drawPause, drawShop, drawTitle, drawVictory } from '../game/ui';
import { drawVignette, drawWorld } from '../game/render';
import { loadSave, writeSave } from '../game/save';
import { isMuted, setMuted, sfx, unlockAudio } from '../game/audio';

const HELD = {
  w: 'KeyW',
  a: 'KeyA',
  s: 'KeyS',
  d: 'KeyD',
  up: 'ArrowUp',
  down: 'ArrowDown',
  left: 'ArrowLeft',
  right: 'ArrowRight',
  space: 'Space',
};

export default function GameView() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const gameRef = useRef<Game | null>(null);
  const inputRef = useRef<Input>(emptyInput());
  const heldRef = useRef<Record<string, boolean>>({});
  const edgeRef = useRef<Record<string, boolean>>({});
  const pausedRef = useRef(false);
  const shopReturnRef = useRef<'title' | 'dead' | 'victory'>('title');
  const [scale, setScale] = useState(2);
  const [muted, setMutedState] = useState(false);

  // --- integer scaling ------------------------------------------------------
  useEffect(() => {
    const fit = () => {
      const pad = 24;
      const s = Math.max(
        1,
        Math.floor(Math.min((window.innerWidth - pad) / VW, (window.innerHeight - pad) / VH)),
      );
      setScale(s);
    };
    fit();
    window.addEventListener('resize', fit);
    return () => window.removeEventListener('resize', fit);
  }, []);

  // --- boot -----------------------------------------------------------------
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    canvas.width = VW;
    canvas.height = VH;
    const ctx = canvas.getContext('2d', { alpha: false });
    if (!ctx) return;
    ctx.imageSmoothingEnabled = false;

    const g = createGame(loadSave());
    gameRef.current = g;

    // --- input -------------------------------------------------------------
    const down = (ev: KeyboardEvent) => {
      const code = ev.code;
      if (
        [
          'ArrowUp',
          'ArrowDown',
          'ArrowLeft',
          'ArrowRight',
          'Space',
          'KeyW',
          'KeyA',
          'KeyS',
          'KeyD',
        ].includes(code)
      )
        ev.preventDefault();
      unlockAudio();
      if (!heldRef.current[code]) {
        heldRef.current[code] = true;
        edgeRef.current[code] = true;
      }
      if (code === 'KeyP' || code === 'Escape') {
        if (g.mode === 'playing' || g.mode === 'draft') pausedRef.current = !pausedRef.current;
      }
      if (code === 'KeyM') {
        const m = !isMuted();
        setMuted(m);
        setMutedState(m);
      }
    };
    const up = (ev: KeyboardEvent) => {
      heldRef.current[ev.code] = false;
    };
    const blur = () => {
      heldRef.current = {};
    };
    window.addEventListener('keydown', down);
    window.addEventListener('keyup', up);
    window.addEventListener('blur', blur);

    // --- mouse -------------------------------------------------------------
    const toLocal = (ev: MouseEvent) => {
      const r = canvas.getBoundingClientRect();
      return {
        x: ((ev.clientX - r.left) / r.width) * VW,
        y: ((ev.clientY - r.top) / r.height) * VH,
      };
    };
    const click = (ev: MouseEvent) => {
      unlockAudio();
      const p = toLocal(ev);
      const game = gameRef.current;
      if (!game) return;
      if (game.mode === 'title') {
        if (p.y > 150) {
          shopReturnRef.current = 'title';
          game.mode = 'shop';
          sfx.ui();
        } else {
          startRun(game);
        }
        return;
      }
      if (game.mode === 'draft') {
        const n = game.draft.length;
        const cw = 108;
        const gap = 12;
        const total = n * cw + (n - 1) * gap;
        const x0 = Math.round((VW - total) / 2);
        for (let i = 0; i < n; i++) {
          const x = x0 + i * (cw + gap);
          if (p.x >= x && p.x <= x + cw && p.y >= 54 && p.y <= 156) {
            game.draftIdx = i;
            chooseDraft(game, i);
            return;
          }
        }
        return;
      }
      if (game.mode === 'shop') {
        const rows = UNLOCKS.length;
        const scroll = Math.max(0, Math.min(rows - 11, game.shopIdx - 1));
        for (let i = 0; i < rows; i++) {
          const y = 42 + (i - scroll) * 15;
          if (p.y >= y - 3 && p.y <= y + 11) {
            if (game.shopIdx === i) buy(game, i);
            else game.shopIdx = i;
            return;
          }
        }
        return;
      }
      if (game.mode === 'dead' || game.mode === 'victory') {
        shopReturnRef.current = game.mode;
        game.mode = 'shop';
        sfx.ui();
      }
    };
    canvas.addEventListener('mousedown', click);

    // --- ui navigation -----------------------------------------------------
    const buy = (game: Game, i: number) => {
      const u = UNLOCKS[i];
      const lvl = game.save.unlocks[u.id] ?? 0;
      if (lvl >= u.costs.length) return;
      const cost = u.costs[lvl];
      if (game.save.bank < cost) {
        sfx.deny();
        return;
      }
      game.save.bank -= cost;
      game.save.unlocks[u.id] = lvl + 1;
      writeSave(game.save);
      sfx.buy();
    };

    const navUi = (game: Game, input: Input) => {
      if (game.mode === 'title') {
        if (input.confirm) startRun(game);
        if (input.back) {
          shopReturnRef.current = 'title';
          game.mode = 'shop';
          sfx.ui();
        }
        return;
      }
      if (game.mode === 'shop') {
        const rows = UNLOCKS.length;
        if (input.upEdge) game.shopIdx = (game.shopIdx + rows - 1) % rows;
        if (input.downEdge) game.shopIdx = (game.shopIdx + 1) % rows;
        if (input.confirm) buy(game, game.shopIdx);
        if (input.back) {
          game.mode = shopReturnRef.current;
          sfx.ui();
        }
        return;
      }
      if (game.mode === 'draft') {
        if (input.leftEdge) game.draftIdx = (game.draftIdx + game.draft.length - 1) % game.draft.length;
        if (input.rightEdge) game.draftIdx = (game.draftIdx + 1) % game.draft.length;
        if (input.confirm) chooseDraft(game, game.draftIdx);
        return;
      }
      if (game.mode === 'dead' || game.mode === 'victory') {
        if (input.confirm && game.deathT > 0.6) {
          shopReturnRef.current = game.mode;
          game.mode = 'shop';
          sfx.ui();
        }
      }
    };

    // --- loop --------------------------------------------------------------
    let raf = 0;
    let last = performance.now();
    let acc = 0;
    const STEP = 1 / 60;

    const buildInput = (): Input => {
      const h = heldRef.current;
      const e = edgeRef.current;
      const input = inputRef.current;
      input.up = !!h[HELD.w];
      input.down = !!h[HELD.s];
      input.left = !!h[HELD.a];
      input.right = !!h[HELD.d];
      input.fx = (h[HELD.right] ? 1 : 0) - (h[HELD.left] ? 1 : 0);
      input.fy = (h[HELD.down] ? 1 : 0) - (h[HELD.up] ? 1 : 0);
      input.dash = !!h[HELD.space];
      input.confirm = !!(e[HELD.space] || e['Enter']);
      input.back = !!(e['KeyU'] || e['Escape']);
      input.leftEdge = !!(e[HELD.a] || e[HELD.left]);
      input.rightEdge = !!(e[HELD.d] || e[HELD.right]);
      input.upEdge = !!(e[HELD.w] || e[HELD.up]);
      input.downEdge = !!(e[HELD.s] || e[HELD.down]);
      return input;
    };

    const draw = (game: Game) => {
      ctx.setTransform(1, 0, 0, 1, 0, 0);
      ctx.fillStyle = PAL.black;
      ctx.fillRect(0, 0, VW, VH);
      if (game.mode === 'title') {
        drawTitle(ctx, game);
        return;
      }
      if (game.mode === 'shop') {
        drawShop(ctx, game);
        return;
      }
      ctx.save();
      if (game.shake > 0.3)
        ctx.translate(
          Math.round((Math.random() - 0.5) * game.shake),
          Math.round((Math.random() - 0.5) * game.shake),
        );
      drawWorld(ctx, game);
      ctx.restore();
      drawVignette(ctx, game);
      drawHud(ctx, game);
      if (game.mode === 'draft') drawDraft(ctx, game);
      if (game.mode === 'dead') drawDeath(ctx, game);
      if (game.mode === 'victory') drawVictory(ctx, game);
      if (pausedRef.current) drawPause(ctx);
    };

    const frame = (now: number) => {
      raf = requestAnimationFrame(frame);
      let dt = (now - last) / 1000;
      last = now;
      if (dt > 0.25) dt = 0.25;
      const game = gameRef.current;
      if (!game) return;
      const input = buildInput();
      const frozen = pausedRef.current || game.mode === 'draft';
      if (!frozen) {
        acc += dt;
        let guard = 0;
        while (acc >= STEP && guard < 5) {
          update(game, STEP, input);
          acc -= STEP;
          guard++;
        }
        if (guard >= 5) acc = 0;
      }
      navUi(game, input);
      draw(game);
      // clear edges after consumption
      edgeRef.current = {};
    };
    raf = requestAnimationFrame(frame);

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener('keydown', down);
      window.removeEventListener('keyup', up);
      window.removeEventListener('blur', blur);
      canvas.removeEventListener('mousedown', click);
    };
  }, []);

  return (
    <div className="flex h-full w-full flex-col items-center justify-center gap-2 select-none">
      <canvas
        ref={canvasRef}
        width={VW}
        height={VH}
        className="block bg-black"
        style={{
          width: VW * scale,
          height: VH * scale,
          imageRendering: 'pixelated',
          boxShadow: '0 0 0 1px #262626, 0 0 60px rgba(255,255,255,0.06)',
        }}
        aria-label="Nullroom: a 1-bit top-down roguelite shooter"
        role="img"
      />
      <div className="flex items-center gap-4 font-mono text-[10px] tracking-[0.2em] text-neutral-600">
        <span>WASD MOVE</span>
        <span className="text-neutral-800">/</span>
        <span>ARROWS FIRE</span>
        <span className="text-neutral-800">/</span>
        <span>SPACE DASH</span>
        <span className="text-neutral-800">/</span>
        <span>P PAUSE</span>
        <span className="text-neutral-800">/</span>
        <button
          type="button"
          className="underline decoration-neutral-800 underline-offset-2 hover:text-neutral-400"
          onClick={() => {
            const m = !isMuted();
            setMuted(m);
            setMutedState(m);
          }}
        >
          {muted ? 'SOUND OFF' : 'SOUND ON'}
        </button>
      </div>
    </div>
  );
}
