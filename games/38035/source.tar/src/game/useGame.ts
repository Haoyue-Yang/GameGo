import { useCallback, useMemo, useReducer } from 'react';
import type { GameState } from './types';
import { ROOMS } from './rooms';
import { NPCS } from './npcs';
import { ITEMS } from './items';
import { CHOICES } from './casefile';
import {
  applyEffect,
  combineEffect,
  endingFor,
  initialState,
  meets,
  replyFor,
} from './engine';

export type Msg =
  | { t: 'start' }
  | { t: 'restart' }
  | { t: 'arrive'; x: number; y: number }
  | { t: 'interact'; id: string }
  | { t: 'action'; hotspot: string; action: string }
  | { t: 'hold'; item: string | null }
  | { t: 'combine'; a: string; b: string }
  | { t: 'open'; panel: GameState['panel'] }
  | { t: 'close' }
  | { t: 'talk'; npc: string }
  | { t: 'ask'; npc: string; topic: string }
  | { t: 'press'; npc: string; topic: string; idx: number }
  | { t: 'resolve'; choice: string; option: string }
  | { t: 'minigameDone' }
  | { t: 'accuse'; suspect: string }
  | { t: 'say'; text: string };

function say(s: GameState, text: string): GameState {
  return { ...s, log: [...s.log, text].slice(-60) };
}

function reducer(s: GameState, m: Msg): GameState {
  switch (m.t) {
    case 'start':
      return { ...initialState(), screen: 'game' };

    case 'restart':
      return initialState();

    case 'arrive':
      return { ...s, player: { x: m.x, y: m.y }, walking: false, pending: null };

    case 'say':
      return say(s, m.text);

    case 'close':
      return {
        ...s,
        panel: null,
        examine: null,
        talk: null,
        choice: null,
        minigame: null,
        held: null,
      };

    case 'open':
      return { ...s, panel: m.panel, examine: null, talk: null, choice: null, minigame: null };

    case 'hold':
      return { ...s, held: m.item };

    case 'interact': {
      const r = ROOMS[s.room];
      const h = r.hotspots.find((x) => x.id === m.id);
      if (!h) return s;
      const seen = { ...s.seen, [h.id]: true };

      if (h.kind === 'door') {
        if (!meets(s, h.requires)) {
          return say({ ...s, seen }, h.denied ?? 'It will not open.');
        }
        return applyEffect({ ...s, seen }, { goto: h.to });
      }

      // using a held item on a hotspot
      if (s.held) {
        const act = (h.actions ?? []).find(
          (a) => a.requires?.items?.includes(s.held!) && meets(s, a.requires),
        );
        if (act) {
          return applyEffect({ ...s, seen, held: null }, act.effect);
        }
        return say(
          { ...s, seen },
          `The ${ITEMS[s.held]?.name.toLowerCase() ?? 'thing'} does nothing here.`,
        );
      }

      return { ...s, seen, examine: { title: h.label, body: h.look, hotspot: h.id } };
    }

    case 'action': {
      const r = ROOMS[s.room];
      const h = r.hotspots.find((x) => x.id === m.hotspot);
      const a = h?.actions?.find((x) => x.id === m.action);
      if (!a) return s;
      if (!meets(s, a.requires)) return s;
      return applyEffect({ ...s, examine: null }, a.effect);
    }

    case 'combine': {
      const eff = combineEffect(m.a, m.b);
      if (!eff) {
        return say(s, 'Those two have nothing to say to each other.');
      }
      return applyEffect({ ...s, held: null }, eff);
    }

    case 'talk':
      return { ...s, talk: m.npc, examine: null, panel: null };

    case 'ask': {
      const npc = NPCS[m.npc];
      const topic = npc.topics.find((t) => t.id === m.topic);
      if (!topic) return s;
      const asked = { ...s.asked, [`${m.npc}:${m.topic}`]: true };
      let n: GameState = {
        ...s,
        asked,
        examine: null,
        log: [...s.log, `You: "${topic.q}"`, replyFor(s, m.npc, topic.a, topic.aWarm, topic.aCold)].slice(-60),
      };
      if (topic.effect) n = applyEffect(n, topic.effect);
      return n;
    }

    case 'press': {
      const npc = NPCS[m.npc];
      const topic = npc.topics.find((t) => t.id === m.topic);
      const opt = topic?.press?.[m.idx];
      if (!opt) return s;
      let n: GameState = {
        ...s,
        log: [...s.log, `You: "${opt.label}"`, `${npc.name}: "${opt.reply}"`].slice(-60),
      };
      n = applyEffect(n, { affinity: { [m.npc]: opt.affinity } });
      if (opt.effect) n = applyEffect(n, opt.effect);
      return n;
    }

    case 'resolve': {
      const def = CHOICES[m.choice];
      const opt = def?.options.find((o) => o.id === m.option);
      if (!opt) return s;
      let n: GameState = { ...s, choice: null };
      n = applyEffect(n, {
        text: opt.text,
        give: opt.give,
        consume: opt.consume,
        clues: opt.clues,
        flags: opt.flags,
        affinity: opt.affinity,
      });
      return n;
    }

    case 'minigameDone': {
      let n: GameState = { ...s, minigame: null };
      n = applyEffect(n, {
        text: 'The needle settles inside the band and the voice comes through clean. You drop the cylinder into the recorder and it takes everything.',
        give: ['cylinder'],
        flags: ['band_tuned'],
        choice: 'band',
      });
      return n;
    }

    case 'accuse': {
      const id = endingFor(s, m.suspect);
      return {
        ...s,
        screen: 'ending',
        ending: id,
        panel: null,
        examine: null,
        talk: null,
        choice: null,
        minigame: null,
      };
    }

    default:
      return s;
  }
}

export function useGame() {
  const [state, dispatch] = useReducer(reducer, undefined, initialState);

  const actions = useMemo(
    () => ({
      start: () => dispatch({ t: 'start' }),
      restart: () => dispatch({ t: 'restart' }),
      arrive: (x: number, y: number) => dispatch({ t: 'arrive', x, y }),
      interact: (id: string) => dispatch({ t: 'interact', id }),
      action: (hotspot: string, action: string) => dispatch({ t: 'action', hotspot, action }),
      hold: (item: string | null) => dispatch({ t: 'hold', item }),
      combine: (a: string, b: string) => dispatch({ t: 'combine', a, b }),
      open: (panel: GameState['panel']) => dispatch({ t: 'open', panel }),
      close: () => dispatch({ t: 'close' }),
      talk: (npc: string) => dispatch({ t: 'talk', npc }),
      ask: (npc: string, topic: string) => dispatch({ t: 'ask', npc, topic }),
      press: (npc: string, topic: string, idx: number) => dispatch({ t: 'press', npc, topic, idx }),
      resolve: (choice: string, option: string) => dispatch({ t: 'resolve', choice, option }),
      minigameDone: () => dispatch({ t: 'minigameDone' }),
      accuse: (suspect: string) => dispatch({ t: 'accuse', suspect }),
      say: (text: string) => dispatch({ t: 'say', text }),
    }),
    [],
  );

  const busy = useCallback(
    () => !!(state.panel || state.examine || state.talk || state.choice || state.minigame),
    [state.panel, state.examine, state.talk, state.choice, state.minigame],
  );

  return { state, actions, busy };
}
