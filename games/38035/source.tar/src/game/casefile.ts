export interface ClueDef {
  id: string;
  name: string;
  body: string;
  weight: number;
}

export const CLUES: ClueDef[] = [
  {
    id: 'wound',
    name: 'The Wound',
    body: 'Vane was not electrocuted. There is a puncture at the base of the skull, two millimetres wide, angled upward. Lightning does not make clean holes.',
    weight: 2,
  },
  {
    id: 'logbook',
    name: 'The Rewritten Log',
    body: 'The wireless log has an entry at 11:38 that has been scraped out and written again in a second, steadier hand. The first hand wrote: CALL RECEIVED — RELAY — DO NOT ANSWER. The second hand wrote: NOTHING.',
    weight: 2,
  },
  {
    id: 'letter',
    name: "Vane's Letter",
    body: 'A letter from Silas Vane to the Telegraph, dated the 14th: "The Marrow relay is not a hobby. There are guests in this house who are drugged and do not know it. The doctor has been paid to keep the house quiet. I go on air at midnight."',
    weight: 2,
  },
  {
    id: 'ledger',
    name: 'The Ledger',
    body: 'Eleven years of Hollowmere accounts, and one page written over in a second hand: fourteen payments of forty guineas each to A. QUILL, M.D., for "private consultations at the house". Nobody in this house has been ill.',
    weight: 2,
  },
  {
    id: 'shard',
    name: 'The Glass Shard',
    body: 'A cut splinter of green glass in Vane\'s coat, ringed with dried blood. The only green glass in Hollowmere is in the medicine cabinet in the master bedroom.',
    weight: 2,
  },
  {
    id: 'voice',
    name: 'The Voice on the Band',
    body: 'At 11:41 — three minutes after Vane died — a coded message went out over the Hollowmere relay: "THE RELAY STAYS DARK. THE BOY IS COLD. — A.Q." The man who sent it was alive, and he signed it.',
    weight: 3,
  },
  {
    id: 'boots',
    name: 'The Wet Boots',
    body: 'A pair of size-nine boots, still wet from the storm, propped on the cellar boiler to dry. Pike wears an eleven. The only other size nine in the house belongs to a doctor who was indoors all evening.',
    weight: 2,
  },
  {
    id: 'cabinet',
    name: 'The Missing Vial',
    body: 'Quill\'s medicine cabinet holds a full shelf of sodium amytal — and one vial one dram short, with a cork crusted in the same residue that rings the glass in Vane\'s pocket.',
    weight: 2,
  },
];

export const CLUE_MAP: Record<string, ClueDef> = Object.fromEntries(
  CLUES.map((c) => [c.id, c]),
);

export interface ChoiceOption {
  id: string;
  label: string;
  detail: string;
  requires?: { items?: string[]; clues?: string[] };
  text: string;
  give?: string[];
  consume?: string[];
  clues?: string[];
  flags?: string[];
  affinity?: Record<string, number>;
}

export interface ChoiceDef {
  id: string;
  title: string;
  body: string;
  warning: string;
  options: ChoiceOption[];
}

export const CHOICES: Record<string, ChoiceDef> = {
  ledger: {
    id: 'ledger',
    title: 'The Ledger Page',
    body: 'The page is written over in a second hand. You can tear it out and carry the truth in your pocket, or photograph it and leave the ledger whole — which leaves Hollowmere\'s eleven years of accounts intact, and Isolde\'s father\'s name in them.',
    warning: 'This cannot be undone.',
    options: [
      {
        id: 'tear',
        label: 'Tear the page out',
        detail: 'Hard evidence. The ledger is destroyed and the house learns you were in it.',
        text: 'You run your thumbnail along the fold and the page comes away with a sound like a small animal. In your pocket it is unarguable. On the desk, the ledger is now a wound that will not close.',
        give: ['ledger_page'],
        consume: ['ledger'],
        clues: ['ledger'],
        flags: ['torn'],
        affinity: { isolde: -2, thorne: -2 },
      },
      {
        id: 'photo',
        label: 'Photograph the page',
        detail: 'Needs the field camera. Weaker in court, kinder to the house.',
        requires: { items: ['camera'] },
        text: 'You set the camera on the blotter, open the shutter, and let the lamp do the work. The plate comes back grey and legible. The ledger stays shut, and so does the house.',
        give: ['ledger_photo'],
        clues: ['ledger'],
        flags: ['photographed'],
        affinity: { isolde: 1, thorne: -1 },
      },
    ],
  },
  band: {
    id: 'band',
    title: 'The Band',
    body: 'The needle sits inside the drifting band and the voice is still there, waiting. You can key the microphone and answer him — and let his own voice say his own name — or you can throw the set off and keep the relay dark, exactly as he asked.',
    warning: 'This cannot be undone.',
    options: [
      {
        id: 'answer',
        label: 'Answer the call',
        detail: 'Say his name back. He will answer, and the cylinder will hold it.',
        text: 'You key the microphone and say, "Dr. Quill, this is the Hollowmere relay." A long pause. Then, close and level: "You have made a mistake, Inspector." The cylinder takes it all.',
        give: ['reply'],
        clues: ['voice'],
        flags: ['answered'],
        affinity: { quill: -2, isolde: 1, vera: 1 },
      },
      {
        id: 'silence',
        label: 'Silence the band',
        detail: 'Throw the set off. The recording survives; the reply does not.',
        text: 'You pull the set off the wall. The band dies mid-word and the room goes so quiet you can hear the rain deciding to stop. What you have is a message. What you will never have is his voice saying his name.',
        clues: ['voice'],
        flags: ['silenced'],
        affinity: { isolde: -1, thorne: 1 },
      },
    ],
  },
};

export interface EndingDef {
  id: string;
  title: string;
  kicker: string;
  body: string[];
  tone: 'clear' | 'static' | 'dead';
}

export const ENDINGS: Record<string, EndingDef> = {
  clear: {
    id: 'clear',
    title: 'CLEAR SIGNAL',
    kicker: 'Ending I of III — the whole truth, carried out on the air',
    body: [
      'You do not shout. You put the cylinder on the desk and let the room listen to itself: a doctor\'s voice, three minutes after a man died, telling the world to stay quiet.',
      'Then the torn page, then the pressed letter, then the glass with the brown ring on it. Ambrose Quill does not deny any of it. He only asks, politely, whether the storm will hold until morning.',
      'It does not. The relay goes live at dawn with every coded message Hollowmere ever carried, and by noon the syndicate behind it is a list of names in a newspaper. Isolde Marrow loses her inheritance and keeps her house. Pike gets his wages back and his name back. Vera Lys writes nine thousand words and gets two of them right.',
      'Quill is taken at the cellar door with his boots still wet. You walk out into the rain with the set still warm in your hands, and somewhere out on the band, the signal is finally clear.',
    ],
    tone: 'clear',
  },
  static: {
    id: 'static',
    title: 'STATIC',
    kicker: 'Ending II of III — the right man, the wrong weight of proof',
    body: [
      'You name Ambrose Quill, and you are right, and it is not enough.',
      'The evidence holds him in the house and not in the room. No torn page, no recorded reply — only a doctor with a missing dram and a logbook someone else wrote over. The magistrate calls it a suspicion. The coroner calls it a storm.',
      'Quill leaves Hollowmere on the nine-forty train with a new address and a new name, and the relay keeps its secrets, and the guests keep coming, and the amytal keeps going round the table.',
      'You stand on the drive and watch the carriage go. The rain stops. Nothing else does.',
    ],
    tone: 'static',
  },
  dead: {
    id: 'dead',
    title: 'DEAD AIR',
    kicker: 'Ending III of III — the wrong name, and the band goes quiet',
    body: [
      'You say the name. The room turns to look at the wrong person, and for one long second it is almost enough.',
      'It is not. Somewhere behind you a door closes that you did not hear open, and the wireless set goes cold in your hands, and the band you spent the night tuning drifts off into nothing.',
      'Silas Vane stays dead in a room with a story that fits too neatly. The relay stays dark. The guests stay quiet. The storm goes on for another two days, and then it does not go on at all.',
      'You leave Hollowmere at first light with a case file nobody will read and a frequency nobody will use again.',
    ],
    tone: 'dead',
  },
};
