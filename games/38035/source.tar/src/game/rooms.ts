import type { Room } from './types';
import hallImg from '../assets/rooms/hall.jpg';
import galleryImg from '../assets/rooms/gallery.jpg';
import libraryImg from '../assets/rooms/library.jpg';
import wirelessImg from '../assets/rooms/wireless.jpg';
import conservatoryImg from '../assets/rooms/conservatory.jpg';
import cellarImg from '../assets/rooms/cellar.jpg';
import bedroomImg from '../assets/rooms/bedroom.jpg';

const WALK: [number, number, number, number] = [10, 66, 90, 92];
const DEPTH: [number, number, number, number] = [66, 0.76, 92, 1.08];

export const ROOMS: Record<string, Room> = {
  /* ─────────────────────────────  ENTRANCE HALL  ───────────────────────────── */
  hall: {
    id: 'hall',
    name: 'Entrance Hall',
    sub: 'Hollowmere Manor — 11:58 p.m.',
    img: hallImg,
    walk: WALK,
    depth: DEPTH,
    spawn: { x: 50, y: 86 },
    hotspots: [
      {
        id: 'hall_clock',
        label: 'Grandfather Clock',
        rect: [3, 20, 12, 44],
        stand: [13, 80],
        kind: 'thing',
        look: 'The pendulum hangs dead still and the hands are stopped at 11:41. Nothing in this house has kept time since the wire went.',
        actions: [
          {
            id: 'note',
            label: 'Note the time',
            effect: {
              text: '11:41. You write it down twice, because it is the only number in this house that nobody has tried to change.',
              flags: ['clock_seen'],
            },
          },
        ],
      },
      {
        id: 'hall_coat',
        label: 'Coat Stand',
        rect: [25, 28, 11, 36],
        stand: [31, 82],
        kind: 'thing',
        look: 'A long oilskin coat, still dripping onto the marble. The pockets are heavy.',
        actions: [
          {
            id: 'pocket',
            label: 'Search the pockets',
            effect: {
              text: 'A flask of lamp oil, a bent nail, and a groundskeeper\'s tally book. Pike keeps his house in his pockets.',
              give: ['oil_flask'],
              flags: ['coat_searched'],
            },
          },
        ],
      },
      {
        id: 'hall_stairs',
        label: 'Staircase',
        rect: [76, 12, 22, 46],
        stand: [78, 80],
        kind: 'thing',
        look: 'The stair goes up to the bedrooms. Under it, a low door with a brass plate: CELLAR. The plate is warm.',
      },
      {
        id: 'hall_to_conservatory',
        label: 'Glass Door — Conservatory',
        rect: [42, 10, 18, 36],
        stand: [50, 74],
        kind: 'door',
        to: 'conservatory',
        look: 'A glass door onto the conservatory. Rain runs down it in sheets and something inside is growing.',
      },
      {
        id: 'hall_to_cellar',
        label: 'Cellar Door',
        rect: [78, 54, 16, 20],
        stand: [80, 84],
        kind: 'door',
        to: 'cellar',
        requires: { items: ['brass_key'] },
        denied: 'Locked. A stubby brass keyhole, and the key is not on any ring in this house.',
        look: 'The cellar door. Cold comes up through it like breath.',
      },
      {
        id: 'hall_to_gallery',
        label: 'Arch — Long Gallery',
        rect: [0, 28, 6, 42],
        stand: [9, 80],
        kind: 'door',
        to: 'gallery',
        look: 'The arch into the long gallery, where the house keeps its portraits.',
      },
    ],
  },

  /* ─────────────────────────────  LONG GALLERY  ───────────────────────────── */
  gallery: {
    id: 'gallery',
    name: 'Long Gallery',
    sub: 'Eleven portraits and one empty frame',
    img: galleryImg,
    walk: WALK,
    depth: DEPTH,
    spawn: { x: 50, y: 86 },
    hotspots: [
      {
        id: 'gal_portraits',
        label: 'Portrait Wall',
        rect: [2, 12, 26, 38],
        stand: [16, 78],
        kind: 'thing',
        look: 'Eleven Marrows in eleven frames, each one a little paler than the last. The eleventh frame is empty and the dust on the wall behind it is undisturbed.',
        actions: [
          {
            id: 'note',
            label: 'Study the empty frame',
            effect: {
              text: 'The last Marrow was taken off this wall recently and never replaced. Whoever hung it did not want to look at it.',
              flags: ['portrait_seen'],
            },
          },
        ],
      },
      {
        id: 'gal_table',
        label: 'Side Table',
        rect: [70, 42, 14, 24],
        stand: [72, 82],
        kind: 'thing',
        look: 'A side table with a hurricane lamp on it, wick trimmed, reservoir dry.',
        actions: [
          {
            id: 'take',
            label: 'Take the lantern',
            effect: { text: 'You pocket the lantern. It will need oil.', give: ['lantern'] },
          },
        ],
      },
      {
        id: 'gal_to_hall',
        label: 'Arch — Entrance Hall',
        rect: [93, 18, 7, 48],
        stand: [88, 80],
        kind: 'door',
        to: 'hall',
        look: 'Back to the entrance hall.',
      },
      {
        id: 'gal_to_library',
        label: 'Arch — Library',
        rect: [0, 18, 7, 48],
        stand: [11, 80],
        kind: 'door',
        to: 'library',
        look: 'The library. There is a light on in there.',
      },
      {
        id: 'gal_to_wireless',
        label: 'Arch — Wireless Room',
        rect: [44, 12, 14, 42],
        stand: [50, 76],
        kind: 'door',
        to: 'wireless',
        look: 'The wireless room. The smell of hot dust and burnt wire.',
      },
    ],
  },

  /* ─────────────────────────────  LIBRARY  ───────────────────────────── */
  library: {
    id: 'library',
    name: 'Library',
    sub: 'Eleven years of accounts',
    img: libraryImg,
    walk: WALK,
    depth: DEPTH,
    spawn: { x: 50, y: 86 },
    hotspots: [
      {
        id: 'lib_desk',
        label: 'Writing Desk',
        rect: [36, 42, 26, 28],
        stand: [50, 80],
        kind: 'thing',
        look: 'A heavy desk under a green banker\'s lamp. The top drawer is locked; the bottom one hangs open.',
        actions: [
          {
            id: 'open',
            label: 'Unlock the top drawer',
            requires: { items: ['study_key'] },
            effect: {
              text: 'The key turns like it was made for this drawer. Inside: the manor ledger, and a folding field camera with one plate left.',
              give: ['ledger', 'camera'],
              flags: ['drawer_open'],
            },
          },
          {
            id: 'bottom',
            label: 'Search the open drawer',
            effect: {
              text: 'Blotting paper, a broken nib, and a receipt for forty guineas paid to A. QUILL, M.D., on the 9th of this month.',
              flags: ['receipt_seen'],
            },
          },
          {
            id: 'page',
            label: 'Deal with the written-over page',
            showIf: { items: ['ledger'] },
            hideIf: { flags: ['torn', 'photographed'] },
            effect: { choice: 'ledger' },
          },
        ],
      },
      {
        id: 'lib_fire',
        label: 'Fireplace',
        rect: [74, 24, 20, 42],
        stand: [76, 82],
        kind: 'thing',
        look: 'The fire is down to embers. Someone has been burning paper in here and did not clear the grate.',
        actions: [
          {
            id: 'rake',
            label: 'Rake the grate',
            effect: {
              text: 'You lift the iron and find half a letter, charred but legible at the edges. Vane\'s hand. Vane\'s name at the bottom.',
              give: ['charred_letter'],
              flags: ['letter_found'],
            },
          },
        ],
      },
      {
        id: 'lib_chair',
        label: 'Wingback Armchair',
        rect: [10, 42, 18, 30],
        stand: [18, 82],
        kind: 'thing',
        look: 'A wingback chair, still warm at the seat. A pair of reading glasses lies on the cushion, one lens starred.',
        actions: [
          {
            id: 'note',
            label: 'Examine the glasses',
            effect: {
              text: 'The starred lens is a jeweller\'s loupe that has been snapped out of its arm. Whoever did it did it in a hurry, and from behind.',
              flags: ['glasses_seen'],
            },
          },
        ],
      },
      {
        id: 'lib_shelves',
        label: 'Bookshelves',
        rect: [30, 6, 40, 34],
        stand: [46, 74],
        kind: 'thing',
        look: 'Law, land law, and a great deal of nothing. There is a gap on the third shelf where a medical text should be.',
        actions: [
          {
            id: 'note',
            label: 'Check the gap',
            effect: {
              text: 'The gap is exactly the width of a pharmacology manual, and the shelf above it is dusted while the gap is not. It was taken, not sold.',
              flags: ['shelf_seen'],
            },
          },
        ],
      },
      {
        id: 'lib_to_bedroom',
        label: 'Door — Master Bedroom',
        rect: [93, 22, 7, 44],
        stand: [88, 80],
        kind: 'door',
        to: 'bedroom',
        requires: { items: ['bed_key'] },
        denied: 'Locked from the other side. The key is not in the library.',
        look: 'The master bedroom door. It is locked, and it has been locked for hours.',
      },
      {
        id: 'lib_to_gallery',
        label: 'Arch — Long Gallery',
        rect: [0, 20, 7, 46],
        stand: [11, 80],
        kind: 'door',
        to: 'gallery',
        look: 'Back to the long gallery.',
      },
    ],
  },

  /* ─────────────────────────────  WIRELESS ROOM  ───────────────────────────── */
  wireless: {
    id: 'wireless',
    name: 'Wireless Room',
    sub: 'Where Silas Vane died',
    img: wirelessImg,
    walk: [8, 68, 90, 92],
    depth: [68, 0.76, 92, 1.08],
    spawn: { x: 50, y: 88 },
    hotspots: [
      {
        id: 'wire_log',
        label: 'Log Book',
        rect: [7, 46, 12, 20],
        stand: [13, 80],
        kind: 'thing',
        look: 'The wireless log, open on a small table. Every transmission of the month, in a neat hand — except one.',
        actions: [
          {
            id: 'read',
            label: 'Read the log',
            effect: {
              text: '11:38 — CALL RECEIVED — RELAY — DO NOT ANSWER. The line has been scraped out and rewritten: 11:38 — NOTHING. The second hand is steadier and smaller, and it is not Vane\'s.',
              clues: ['logbook'],
              flags: ['log_read'],
            },
          },
        ],
      },
      {
        id: 'wire_chair',
        label: 'Chair & Overcoat',
        rect: [20, 40, 13, 26],
        stand: [22, 80],
        kind: 'thing',
        look: 'Vane\'s overcoat, thrown over the chair back. The pockets have been turned out, but not well.',
        actions: [
          {
            id: 'search',
            label: 'Search the coat',
            effect: {
              text: 'A cut splinter of green glass, folded into the lining by a thumb. It was put there after the coat was taken off.',
              give: ['shard'],
              flags: ['coat_searched2'],
            },
          },
        ],
      },
      {
        id: 'wire_body',
        label: 'The Body of Silas Vane',
        rect: [34, 52, 18, 26],
        stand: [46, 84],
        kind: 'body',
        look: 'Silas Vane, thirty-one, wireless operator, on his back with his hands away from him. The wire has burned a scorch across his collar, which is the part of the story that is true.',
        actions: [
          {
            id: 'examine',
            label: 'Examine him properly',
            requires: { items: ['magnifier'] },
            effect: {
              text: 'You put the loupe to the base of his skull. There is a puncture there, two millimetres wide, angled upward — the sort of hole a cabinet pane makes when it is driven in. Lightning does not make clean holes. This man was killed, and then made to look shocked.',
              clues: ['wound'],
              flags: ['body_examined'],
            },
          },
          {
            id: 'look',
            label: 'Look at the scorch',
            effect: {
              text: 'The scorch is real. Someone did put a live wire through him — after, not before. It is the shape of a man covering his tracks with the only tool in the room.',
              flags: ['scorch_seen'],
            },
          },
        ],
      },
      {
        id: 'wire_set',
        label: 'Wireless Receiver',
        rect: [54, 36, 20, 26],
        stand: [58, 80],
        kind: 'thing',
        look: 'Vane\'s set: valves, a tuning band, a microphone that still works. The leads at the back have been cut — trimmed, not snapped. Someone wanted this set dead.',
        actions: [
          {
            id: 'take',
            label: 'Take the set',
            effect: {
              text: 'You lift the set off the bench. It is heavier than it looks and colder than it should be.',
              give: ['receiver'],
              flags: ['set_taken'],
            },
          },
          {
            id: 'tune',
            label: 'Tune the receiver',
            requires: { items: ['tuned_receiver'] },
            effect: { text: 'The band is live. The needle drifts. You will have to hold it.', minigame: 'band' },
          },
        ],
      },
      {
        id: 'wire_cables',
        label: 'Patch Panel',
        rect: [78, 16, 18, 42],
        stand: [80, 80],
        kind: 'thing',
        look: 'A wall of patch panels and hanging cables, all of them labelled in Vane\'s hand: RELAY — MARROW — DO NOT USE AFTER DARK.',
        actions: [
          {
            id: 'note',
            label: 'Read the labels',
            effect: {
              text: 'The relay is not a hobby. It carries coded traffic, and Vane knew exactly what it was carrying.',
              flags: ['relay_known'],
            },
          },
        ],
      },
      {
        id: 'wire_window',
        label: 'Barred Window',
        rect: [46, 4, 12, 22],
        stand: [52, 74],
        kind: 'thing',
        look: 'A barred window, latched from the inside. Rain comes through the gap in the latch and runs down the concrete.',
      },
      {
        id: 'wire_to_gallery',
        label: 'Door — Long Gallery',
        rect: [0, 30, 4, 40],
        stand: [9, 82],
        kind: 'door',
        to: 'gallery',
        look: 'Out to the gallery.',
      },
    ],
  },

  /* ─────────────────────────────  CONSERVATORY  ───────────────────────────── */
  conservatory: {
    id: 'conservatory',
    name: 'Conservatory',
    sub: 'Rain on iron and glass',
    img: conservatoryImg,
    walk: WALK,
    depth: DEPTH,
    spawn: { x: 50, y: 86 },
    hotspots: [
      {
        id: 'con_planter',
        label: 'Stone Planter',
        rect: [6, 42, 20, 28],
        stand: [16, 82],
        kind: 'thing',
        look: 'A stone planter of dead ferns. The soil has been turned over very recently, and something is sticking out of it.',
        actions: [
          {
            id: 'dig',
            label: 'Dig it out',
            requires: { items: ['trowel'] },
            effect: {
              text: 'You work the trowel in and come up with a stubby brass key, stamped C-1. Someone buried a key in a dead fern and hoped the storm would forget it.',
              give: ['brass_key'],
              flags: ['key_dug'],
            },
          },
        ],
      },
      {
        id: 'con_table',
        label: 'Iron Table',
        rect: [40, 44, 20, 24],
        stand: [48, 82],
        kind: 'thing',
        look: 'A wrought iron table with a watering can and a flower press on it, weighted with river stones and gone damp.',
        actions: [
          {
            id: 'take',
            label: 'Take the press',
            effect: {
              text: 'You take the press. It is waterlogged, which is exactly what charred paper wants.',
              give: ['damp_press'],
            },
          },
        ],
      },
      {
        id: 'con_glass',
        label: 'Cracked Panes',
        rect: [80, 10, 18, 42],
        stand: [82, 80],
        kind: 'thing',
        look: 'Three panes are broken from the outside and the glass has been swept up. Whoever came in here was not a burglar.',
        actions: [
          {
            id: 'note',
            label: 'Look for prints',
            effect: {
              text: 'There are prints in the dust on the sill, size nine, and they come in and go out again. Someone was in and out of this house tonight without using a door.',
              flags: ['prints_seen'],
            },
          },
        ],
      },
      {
        id: 'con_roof',
        label: 'Glass Roof',
        rect: [30, 2, 40, 18],
        stand: [46, 74],
        kind: 'thing',
        look: 'The roof is a sheet of rain. Somewhere above it the storm is deciding what to do next.',
      },
      {
        id: 'con_to_hall',
        label: 'Glass Door — Entrance Hall',
        rect: [0, 30, 5, 40],
        stand: [9, 80],
        kind: 'door',
        to: 'hall',
        look: 'Back into the hall.',
      },
    ],
  },

  /* ─────────────────────────────  CELLAR  ───────────────────────────── */
  cellar: {
    id: 'cellar',
    name: 'Cellar',
    sub: 'Cold, wet, and somebody else\'s boots',
    img: cellarImg,
    walk: WALK,
    depth: DEPTH,
    spawn: { x: 80, y: 86 },
    hotspots: [
      {
        id: 'cel_boiler',
        label: 'Cast Iron Boiler',
        rect: [66, 24, 24, 42],
        stand: [72, 82],
        kind: 'thing',
        look: 'The boiler is still warm. There is a gap behind it the width of a man\'s shoulder.',
        actions: [
          {
            id: 'reach',
            label: 'Reach behind the boiler',
            requires: { items: ['lit_lantern'] },
            effect: {
              text: 'You hold the lantern up and reach into the gap. Your fingers close on a key on a leather fob, and beside it a coil of copper wire, neatly coiled and labelled in Vane\'s hand.',
              give: ['bed_key', 'wire_coil'],
              flags: ['boiler_searched'],
            },
          },
        ],
      },
      {
        id: 'cel_crates',
        label: 'Barrels & Crates',
        rect: [6, 32, 22, 32],
        stand: [16, 82],
        kind: 'thing',
        look: 'Barrels and crates stacked to the vault. One crate has been opened and closed again, and not by a man who owns it.',
        actions: [
          {
            id: 'open',
            label: 'Open the crate',
            requires: { items: ['lit_lantern'] },
            effect: {
              text: 'Inside: wax cylinders, a spare valve, and a tin of amytal tablets with the label scraped off. This is not a cellar. It is a store.',
              flags: ['crate_opened'],
            },
          },
        ],
      },
      {
        id: 'cel_boots',
        label: 'Wet Boots',
        rect: [30, 54, 14, 18],
        stand: [36, 84],
        kind: 'thing',
        look: 'A pair of boots propped on the boiler to dry. Still wet, and the size is wrong for a man who was out in the storm all evening.',
        actions: [
          {
            id: 'measure',
            label: 'Measure them',
            effect: {
              text: 'Size nine. Pike wears an eleven and you have measured his feet twice tonight. The only other size nine in Hollowmere belongs to a doctor who was indoors all evening.',
              clues: ['boots'],
              flags: ['boots_measured'],
            },
          },
        ],
      },
      {
        id: 'cel_bulb',
        label: 'Hanging Bulb',
        rect: [44, 2, 10, 20],
        stand: [48, 76],
        kind: 'thing',
        look: 'A bare bulb on a flex, dead. The storm took the power at 11:30 and nobody has come down here to say so.',
      },
      {
        id: 'cel_stair',
        label: 'Stone Stair',
        rect: [88, 18, 12, 48],
        stand: [84, 80],
        kind: 'door',
        to: 'hall',
        look: 'The stair back up to the hall.',
      },
    ],
  },

  /* ─────────────────────────────  MASTER BEDROOM  ───────────────────────────── */
  bedroom: {
    id: 'bedroom',
    name: 'Master Bedroom',
    sub: 'Quill\'s room',
    img: bedroomImg,
    walk: WALK,
    depth: DEPTH,
    spawn: { x: 50, y: 86 },
    hotspots: [
      {
        id: 'bed_bed',
        label: 'Four-Poster Bed',
        rect: [40, 32, 34, 38],
        stand: [52, 82],
        kind: 'thing',
        look: 'The quilt is still warm at one corner, as though the bed was left in a hurry by someone who did not intend to come back to it.',
        actions: [
          {
            id: 'note',
            label: 'Search the bed',
            effect: {
              text: 'Under the pillow: a folded train timetable and a photograph of a house that is not Hollowmere. He has been here since Tuesday and he has been somewhere else too.',
              flags: ['bed_searched'],
            },
          },
        ],
      },
      {
        id: 'bed_wardrobe',
        label: 'Wardrobe',
        rect: [8, 14, 20, 46],
        stand: [16, 80],
        kind: 'thing',
        look: 'A tall wardrobe. Inside, a doctor\'s bag that has been packed and unpacked and packed again.',
        actions: [
          {
            id: 'note',
            label: 'Open the bag',
            effect: {
              text: 'Instruments, a stethoscope, and a small green glass case with a pane missing from its front. The case has been in a struggle.',
              flags: ['bag_opened'],
            },
          },
        ],
      },
      {
        id: 'bed_vanity',
        label: 'Writing Vanity',
        rect: [30, 24, 18, 26],
        stand: [36, 78],
        kind: 'thing',
        look: 'A vanity with an oval mirror. The mirror has been turned to the wall.',
        actions: [
          {
            id: 'note',
            label: 'Turn the mirror back',
            effect: {
              text: 'You turn it round. The glass is clean but the frame is scratched from the inside, as though something heavy was put down on it in a hurry.',
              flags: ['mirror_seen'],
            },
          },
        ],
      },
      {
        id: 'bed_cabinet',
        label: 'Medicine Cabinet',
        rect: [76, 32, 16, 28],
        stand: [78, 82],
        kind: 'thing',
        look: 'A glass-fronted medicine cabinet on a stand. It has a small combination lock, and the front pane is missing a corner.',
        actions: [
          {
            id: 'open',
            label: 'Work the combination',
            requires: { flags: ['cabinet_code'] },
            effect: {
              text: 'The combination turns. Inside, a full shelf of sodium amytal — and one vial one dram short, with a cork crusted in something sweet and bitter.',
              give: ['vial', 'cork'],
              clues: ['cabinet'],
              flags: ['cabinet_open'],
            },
          },
        ],
      },
      {
        id: 'bed_window',
        label: 'Storm Window',
        rect: [26, 6, 14, 18],
        stand: [30, 76],
        kind: 'thing',
        look: 'The window is latched and the latch is wet. Rain has been getting in here for hours.',
      },
      {
        id: 'bed_to_library',
        label: 'Door — Library',
        rect: [0, 32, 6, 38],
        stand: [9, 80],
        kind: 'door',
        to: 'library',
        look: 'Back to the library.',
      },
    ],
  },
};

export const ROOM_ORDER = [
  'hall',
  'gallery',
  'library',
  'wireless',
  'conservatory',
  'cellar',
  'bedroom',
];
