import type { ItemDef } from './types';

export const ITEMS: Record<string, ItemDef> = {
  magnifier: {
    id: 'magnifier',
    name: 'Brass Magnifier',
    desc: 'A jeweller\'s loupe on a brass arm. Vera Lys says it is "for reading other people\'s handwriting".',
    glyph: '◎',
  },
  trowel: {
    id: 'trowel',
    name: 'Garden Trowel',
    desc: 'Pike\'s own. The blade is black with old soil and something that used to be a key.',
    glyph: '⛏',
  },
  brass_key: {
    id: 'brass_key',
    name: 'Brass Cellar Key',
    desc: 'A stubby brass key, stamped C-1. It turns the cellar door in the gallery.',
    glyph: '⚿',
  },
  oil_flask: {
    id: 'oil_flask',
    name: 'Flask of Lamp Oil',
    desc: 'Half full of paraffin. The smell of it is the smell of every dark room in this house.',
    glyph: '⛽',
  },
  lantern: {
    id: 'lantern',
    name: 'Dead Storm Lantern',
    desc: 'A hurricane lamp from the gallery side table. Dry as a sermon.',
    glyph: '🏮',
  },
  lit_lantern: {
    id: 'lit_lantern',
    name: 'Lit Storm Lantern',
    desc: 'A small blue flame, shaking. It is enough to read by. It is not enough to hide by.',
    glyph: '🔆',
  },
  study_key: {
    id: 'study_key',
    name: 'Study Key',
    desc: 'Thorne\'s key to the library desk. He gave it up like a man handing over a confession he has already written.',
    glyph: '🗝',
  },
  camera: {
    id: 'camera',
    name: 'Field Camera',
    desc: 'A folding plate camera. One exposure left in the holder, and you are not wasting it.',
    glyph: '📷',
  },
  ledger: {
    id: 'ledger',
    name: 'Manor Ledger',
    desc: 'Every pound in and out of Hollowmere for eleven years. One page has been written over in a second hand.',
    glyph: '📕',
  },
  ledger_page: {
    id: 'ledger_page',
    name: 'Torn Ledger Page',
    desc: 'The page, in your pocket, with a ragged edge. Paper does not forgive being torn.',
    glyph: '📄',
  },
  ledger_photo: {
    id: 'ledger_photo',
    name: 'Photographed Ledger Page',
    desc: 'A glass plate of the page, ledger left whole. Weaker in a courtroom, kinder to the house.',
    glyph: '🖼',
  },
  charred_letter: {
    id: 'charred_letter',
    name: 'Charred Letter',
    desc: 'Half burned in the library grate. The ink survived better than the paper.',
    glyph: '🔥',
  },
  damp_press: {
    id: 'damp_press',
    name: 'Damp Press',
    desc: 'A conservatory flower press, weighted with river stones. Waterlogged and useful.',
    glyph: '⚖',
  },
  restored_letter: {
    id: 'restored_letter',
    name: 'Restored Letter',
    desc: 'Vane\'s letter to the Telegraph, pressed flat and legible. He named a doctor by name.',
    glyph: '✉',
  },
  wire_coil: {
    id: 'wire_coil',
    name: 'Spare Wire Coil',
    desc: 'A coil of copper from the cellar. Vane\'s set was cut deliberately — the ends were trimmed, not snapped.',
    glyph: '🌀',
  },
  receiver: {
    id: 'receiver',
    name: 'Wireless Receiver',
    desc: 'Vane\'s set. Cold valves, a dead tuning band, and a microphone that still works.',
    glyph: '📻',
  },
  tuned_receiver: {
    id: 'tuned_receiver',
    name: 'Tuned Receiver',
    desc: 'Live. The needle crawls across the band and something on the other end is still talking.',
    glyph: '📡',
  },
  shard: {
    id: 'shard',
    name: 'Glass Shard',
    desc: 'A splinter of green glass from Vane\'s coat pocket. Cut, not broken.',
    glyph: '🔹',
  },
  blood_shard: {
    id: 'blood_shard',
    name: 'Bloodied Glass Shard',
    desc: 'Under the loupe: a dried brown ring at the cut edge. This glass was in a wound.',
    glyph: '🩸',
  },
  bed_key: {
    id: 'bed_key',
    name: 'Bedroom Key',
    desc: 'Found wedged behind the cellar boiler. It opens the master bedroom in the gallery.',
    glyph: '🔑',
  },
  vial: {
    id: 'vial',
    name: 'Empty Amytal Vial',
    desc: 'Sodium amytal, one dram short. Quill\'s hand on the label, Quill\'s thumbprint on the glass.',
    glyph: '💊',
  },
  cork: {
    id: 'cork',
    name: 'Residue-Stained Cork',
    desc: 'The vial\'s cork, crusted with something sweet and bitter. It will name a compound.',
    glyph: '🍾',
  },
  cylinder: {
    id: 'cylinder',
    name: 'Wax Cylinder',
    desc: 'The recording of the coded message on the band. A voice that should have been dead.',
    glyph: '🎙',
  },
  reply: {
    id: 'reply',
    name: 'Recorded Reply',
    desc: 'You answered the band and he answered back. His own voice, saying his own name.',
    glyph: '🎧',
  },
};

export interface Combine {
  a: string;
  b: string;
  label: string;
  text: string;
  out?: string;
  consume?: string[];
  clues?: string[];
  flags?: string[];
  panel?: 'casefile';
}

export const COMBINES: Combine[] = [
  {
    a: 'oil_flask',
    b: 'lantern',
    label: 'Fill and light the lantern',
    text: 'You fill the reservoir, trim the wick, and strike. The blue flame catches and the room stops being a rumour.',
    out: 'lit_lantern',
    consume: ['oil_flask', 'lantern'],
  },
  {
    a: 'shard',
    b: 'magnifier',
    label: 'Examine the shard under the loupe',
    text: 'Under the glass the shard is not glass at all — it is the corner of a cabinet pane, and at the cut edge there is a dried brown ring. This was in a wound.',
    out: 'blood_shard',
    consume: ['shard'],
    clues: ['shard'],
  },
  {
    a: 'charred_letter',
    b: 'damp_press',
    label: 'Press the charred letter flat',
    text: 'You lay the charred sheet between the press plates and weight it with river stones. The ink climbs back out of the ash like a ghost remembering its name.',
    out: 'restored_letter',
    consume: ['charred_letter'],
    clues: ['letter'],
  },
  {
    a: 'wire_coil',
    b: 'receiver',
    label: 'Splice the coil into the receiver',
    text: 'You splice the copper into the cut leads. The valves warm, the band lights, and the needle begins to drift.',
    out: 'tuned_receiver',
    consume: ['wire_coil', 'receiver'],
  },
  {
    a: 'blood_shard',
    b: 'cork',
    label: 'Compare the shard against the cork',
    text: 'The residue on the cork and the ring on the shard are the same brown. One vial, one wound, one doctor.',
    clues: ['cabinet'],
  },
];
