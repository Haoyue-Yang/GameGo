import type { Npc } from './types';

export const NPCS: Record<string, Npc> = {
  /* ─────────────────────────────  DR. AMBROSE QUILL  ───────────────────────────── */
  quill: {
    id: 'quill',
    name: 'Dr. Ambrose Quill',
    role: 'Physician — no surgery, no patients',
    room: 'hall',
    pos: [66, 82],
    coat: '#2c3f5e',
    trim: '#9fb8d4',
    skin: '#c9d8e8',
    hat: 'bowler',
    build: 'slim',
    intro:
      'He is standing very straight by the hall clock, holding a folded newspaper he has not read. His hands are clean. That is the first thing you notice.',
    topics: [
      {
        id: 'q_vane',
        q: 'What did you find in the wireless room?',
        a: 'I found him at twenty to midnight. The wire had burned through his collar. Lightning finds the tallest iron in a house, Inspector, and Hollowmere has a great deal of iron.',
        aWarm: 'I found him at twenty to midnight. The wire had burned through his collar. I have told the house what I think, and I am willing to tell you the same.',
        aCold: 'I found him at twenty to midnight. The wire burned through his collar. That is the finding. I will not elaborate for a stranger.',
        press: [
          {
            label: 'You are certain it was the storm?',
            reply: 'I am certain of the wire. I am not a man who claims more than he can hold.',
            affinity: 1,
          },
          {
            label: 'You are certain of the wire — or of the cause?',
            reply: '…The cause. Yes. I have seen a great many storms and none of them have ever made a clean hole.',
            affinity: -1,
          },
        ],
      },
      {
        id: 'q_guests',
        q: 'Who is in the house?',
        a: 'The Marrow girl. A solicitor. A telegraphist from the Telegraph. Pike, who is not a guest. And me, who was asked to stay for the winter.',
        press: [
          {
            label: 'Asked by whom?',
            reply: 'By the house. One does not ask a doctor a second time.',
            affinity: 1,
          },
          {
            label: 'You were asked. Not invited.',
            reply: 'There is a difference, and it is not one I enjoy.',
            affinity: -1,
          },
        ],
      },
      {
        id: 'q_relay',
        q: 'Tell me about the relay.',
        a: 'It is a hobby. The old man\'s hobby. It carries weather reports and nothing else.',
        press: [
          {
            label: 'Vane\'s labels say otherwise.',
            reply: 'Vane was a clever boy with a grudge. Clever boys write things down, and then they die of storms.',
            affinity: -2,
          },
          {
            label: 'Then it carries weather reports.',
            reply: 'It carries weather reports.',
            affinity: 1,
          },
        ],
      },
      {
        id: 'q_cabinet',
        q: 'Your medicine cabinet is locked.',
        showIf: { flags: ['bed_key'] },
        a: 'It is a doctor\'s cabinet. There is nothing in it that belongs to the house.',
        press: [
          {
            label: 'Then give me the combination.',
            reply: '…Four, one, nine. You will find the shelf in order. I keep it in order.',
            affinity: 2,
            effect: { flags: ['cabinet_code'] },
          },
          {
            label: 'I will find it open anyway.',
            reply: 'Then we shall both be disappointed.',
            affinity: -2,
          },
        ],
      },
      {
        id: 'q_amytal',
        q: 'What is sodium amytal for?',
        showIf: { flags: ['crate_opened'] },
        a: 'Sleep. For patients who cannot sleep. There is nothing sinister in a sleeping draught.',
        press: [
          {
            label: 'There is a tin of it in the cellar with the label scraped off.',
            reply: '…That is not my tin. I do not keep my tin in a cellar.',
            affinity: -2,
          },
          {
            label: 'You keep it in the cellar?',
            reply: 'I keep it where I can reach it.',
            affinity: -1,
          },
        ],
      },
      {
        id: 'q_alibi',
        q: 'Where were you at 11:40?',
        showIf: { clues: ['wound'] },
        a: 'In my room. Reading. I have never once been anywhere else at that hour in my life.',
        press: [
          {
            label: 'The log says the relay went dark at 11:38.',
            reply: 'The log says nothing. I read it myself and I wrote what it said.',
            affinity: -2,
          },
          {
            label: 'Then you were reading.',
            reply: 'I was reading.',
            affinity: 1,
          },
        ],
      },
    ],
  },

  /* ─────────────────────────────  ISOLDE MARROW  ───────────────────────────── */
  isolde: {
    id: 'isolde',
    name: 'Isolde Marrow',
    role: 'Heiress of Hollowmere',
    room: 'library',
    pos: [66, 82],
    coat: '#33456b',
    trim: '#b6cbe2',
    skin: '#cfe0ef',
    hat: 'bun',
    build: 'petite',
    intro:
      'She is sitting in the wingback with the ledger shut on her knees, and she has been sitting there long enough for the chair to remember her shape.',
    topics: [
      {
        id: 'i_vane',
        q: 'What was Vane doing here?',
        a: 'He ran the relay. He was my father\'s man and he thought that made him my master. He was going on air at midnight with something he had found.',
        aWarm: 'He ran the relay. He was my father\'s man and he thought that made him my master. He was going on air at midnight, and I let him.',
        aCold: 'He ran the relay. That is all I will say about him.',
        press: [
          {
            label: 'What did he find?',
            reply: 'That the relay is not a hobby. I have known that since I was nineteen. I did not know what it was for.',
            affinity: 1,
          },
          {
            label: 'Then he was going to ruin you.',
            reply: 'He was going to tell the truth. Those are not the same thing, and I resent being told they are.',
            affinity: -1,
          },
        ],
      },
      {
        id: 'i_relay',
        q: 'The relay.',
        a: 'My father built it. It carries coded traffic for people who pay in cash and do not give their names. I have never asked what for. I am not proud of that.',
        press: [
          {
            label: 'Who pays?',
            reply: 'I do not know. Quill collects the money. That is all I know and it is all I will say.',
            affinity: 1,
          },
          {
            label: 'You have never asked.',
            reply: 'I have asked. I was told to stop.',
            affinity: -1,
          },
        ],
      },
      {
        id: 'i_thorne',
        q: 'Edmund Thorne.',
        a: 'He is my solicitor and my creditor. He wants the deed and he has been wanting it since my father died.',
        press: [
          {
            label: 'How much do you owe him?',
            reply: 'Forty thousand. He has been patient, which is worse than if he had been cruel.',
            affinity: 1,
          },
          {
            label: 'He has been in the house a week.',
            reply: 'He has been in the house since the funeral.',
            affinity: -1,
          },
        ],
      },
      {
        id: 'i_ledger',
        q: 'The ledger.',
        showIf: { flags: ['drawer_open'] },
        a: 'That is the house\'s business, and it is not yours.',
        press: [
          {
            label: 'There are fourteen payments to a doctor.',
            reply: '…Then read it properly before you tear it out. My father is in that book.',
            affinity: -1,
          },
          {
            label: 'I will read it properly.',
            reply: 'Then read it properly.',
            affinity: 1,
          },
        ],
      },
      {
        id: 'i_quill',
        q: 'Dr. Quill.',
        a: 'He has been here since Tuesday. He is not a doctor. There is no surgery in this county and he has no patients.',
        press: [
          {
            label: 'Who brought him?',
            reply: 'The house did. He came on the relay. Someone called him here and I did not ask who.',
            affinity: 1,
          },
          {
            label: 'You are sure?',
            reply: 'I am sure of nothing in this house.',
            affinity: -1,
          },
        ],
      },
    ],
  },

  /* ─────────────────────────────  CORNELIUS PIKE  ───────────────────────────── */
  pike: {
    id: 'pike',
    name: 'Cornelius Pike',
    role: 'Groundskeeper — thirty-one years',
    room: 'conservatory',
    pos: [64, 82],
    coat: '#243550',
    trim: '#8ea6c2',
    skin: '#c3d3e4',
    hat: 'cap',
    build: 'broad',
    intro:
      'He is on his knees among the broken glass with a broom he has not started using. He does not look up when you come in.',
    topics: [
      {
        id: 'p_storm',
        q: 'The storm.',
        a: 'I was out with the gutters since nine. Half the glass in here is gone. I didn\'t hear a thing in that room.',
        press: [
          {
            label: 'You did not hear anything?',
            reply: 'I heard the wire go. I heard it and I went back to the gutters.',
            affinity: -1,
          },
          {
            label: 'You heard it and kept working.',
            reply: 'I heard it and I kept working. That is the job.',
            affinity: 1,
          },
        ],
      },
      {
        id: 'p_vane',
        q: 'Silas Vane.',
        a: 'He let me in the cellar. Said the boiler was singing. He was in a hurry to be somewhere.',
        press: [
          {
            label: 'Hurry to where?',
            reply: 'To the wireless room. He went up the stair and I never saw him again.',
            affinity: 1,
          },
          {
            label: 'He was frightened.',
            reply: 'He was frightened of something. I don\'t know what and I don\'t want to.',
            affinity: -1,
          },
        ],
      },
      {
        id: 'p_trowel',
        q: 'I need a trowel.',
        a: 'You want my trowel. You want my trowel for digging in my planter.',
        press: [
          {
            label: 'I will return it.',
            reply: '…Take it. And put it back where it was.',
            affinity: 1,
            effect: { give: ['trowel'] },
          },
          {
            label: 'It is evidence.',
            reply: 'Everything in this house is evidence now. Take it.',
            affinity: -1,
            effect: { give: ['trowel'] },
          },
        ],
      },
      {
        id: 'p_boots',
        q: 'Your boots.',
        showIf: { clues: ['boots'] },
        a: 'My boots are an eleven and you know it. I have worn them through two winters.',
        press: [
          {
            label: 'Then whose are the nines?',
            reply: 'Then whose are the nines. I will tell you that too, when you tell me.',
            affinity: 1,
          },
          {
            label: 'I am not finished.',
            reply: 'Nobody is finished here.',
            affinity: -1,
          },
        ],
      },
      {
        id: 'p_quill',
        q: 'Dr. Quill.',
        a: 'He came up the drive on Tuesday in a good car. He doesn\'t walk to the village. He doesn\'t walk anywhere.',
        press: [
          {
            label: 'He has been here a week.',
            reply: 'A week and a day. And the guests have been sleeping like logs.',
            affinity: 1,
          },
          {
            label: 'You should have said so.',
            reply: 'I said it to the girl. She told me to mind the gutters.',
            affinity: -1,
          },
        ],
      },
    ],
  },

  /* ─────────────────────────────  VERA LYS  ───────────────────────────── */
  vera: {
    id: 'vera',
    name: 'Vera Lys',
    role: 'Telegraphist — The Telegraph',
    room: 'wireless',
    pos: [72, 86],
    coat: '#3a4c72',
    trim: '#a9c0da',
    skin: '#cddcea',
    hat: 'brim',
    build: 'slim',
    intro:
      'She is standing at the far wall with her notebook open and her pen not moving. She has been watching the body for an hour and she is not looking at it.',
    topics: [
      {
        id: 'v_story',
        q: 'You are here for the story.',
        a: 'I am here for the story. You are here for the truth. We want the same thing in different words.',
        press: [
          {
            label: 'I want the truth.',
            reply: 'Then stop asking me about the body and start asking about the money.',
            affinity: 1,
          },
          {
            label: 'You want a headline.',
            reply: 'I want a headline that is true. That is the whole job.',
            affinity: -1,
          },
        ],
      },
      {
        id: 'v_body',
        q: 'The body.',
        a: 'I have seen a hundred of them. This one has been tidied. Somebody wanted it to look like the storm did it, and they did a good job.',
        press: [
          {
            label: 'Who tidied it?',
            reply: 'Someone with a stethoscope and a steady hand. I would start there.',
            affinity: 1,
          },
          {
            label: 'That is not evidence.',
            reply: 'Nothing is evidence until you put it in front of someone who can use it.',
            affinity: -1,
          },
        ],
      },
      {
        id: 'v_loupe',
        q: 'I need a loupe.',
        a: 'You want my loupe. It is for reading other people\'s handwriting.',
        press: [
          {
            label: 'I will be careful with it.',
            reply: '…Take it. If you break it I will break something else.',
            affinity: 1,
            effect: { give: ['magnifier'] },
          },
          {
            label: 'It is evidence.',
            reply: 'Everything in this house is evidence now. Take it.',
            affinity: -1,
            effect: { give: ['magnifier'] },
          },
        ],
      },
      {
        id: 'v_relay',
        q: 'The relay.',
        a: 'I have been tapping it for three days. It is not weather. It is a syndicate, and the syndicate is paying a doctor to keep this house asleep.',
        press: [
          {
            label: 'A syndicate?',
            reply: 'A syndicate. I have got the first three words and I need the rest.',
            affinity: 1,
          },
          {
            label: 'You have been tapping it?',
            reply: 'I have been tapping it. That is not the same as running it.',
            affinity: -1,
          },
        ],
      },
      {
        id: 'v_quill',
        q: 'Dr. Quill.',
        a: 'He is not a doctor. There is no surgery in this county. He came on the relay and he has been here since Tuesday.',
        press: [
          {
            label: 'You are sure?',
            reply: 'I am sure of the relay. I can read a band.',
            affinity: 1,
          },
          {
            label: 'You are guessing.',
            reply: 'I am guessing faster than you are finding out.',
            affinity: -1,
          },
        ],
      },
    ],
  },

  /* ─────────────────────────────  EDMUND THORNE  ───────────────────────────── */
  thorne: {
    id: 'thorne',
    name: 'Edmund Thorne',
    role: 'Solicitor — creditor',
    room: 'gallery',
    pos: [38, 82],
    coat: '#283a58',
    trim: '#93aac6',
    skin: '#c6d5e6',
    hat: 'bowler',
    build: 'tall',
    intro:
      'He is standing in the middle of the gallery with his hat in his hands, and he is looking at the portraits as though he is reading a list of debts.',
    topics: [
      {
        id: 't_deed',
        q: 'The deed.',
        a: 'The deed is a document and I am the man who holds it. Isolde owes me forty thousand and I am patient.',
        press: [
          {
            label: 'You are patient.',
            reply: 'I am patient. I have been patient for eleven years.',
            affinity: 1,
          },
          {
            label: 'You are a creditor.',
            reply: 'I am a solicitor. There is a difference and it is not one I enjoy.',
            affinity: -1,
          },
        ],
      },
      {
        id: 't_vane',
        q: 'Silas Vane.',
        a: 'He was my clerk. He copied the accounts and he copied them badly, and he had opinions about what he copied.',
        press: [
          {
            label: 'Opinions?',
            reply: 'Opinions. He thought the accounts were wrong. He was right, which was inconvenient.',
            affinity: 1,
          },
          {
            label: 'He was blackmailing you.',
            reply: 'He was reading. I have never once been blackmailed by a man with a pencil.',
            affinity: -1,
          },
        ],
      },
      {
        id: 't_key',
        q: 'I need the library key.',
        a: 'You want the key to the desk. The desk is the house\'s business.',
        press: [
          {
            label: 'I will return it.',
            reply: '…Take it. And do not tear anything out.',
            affinity: 1,
            effect: { give: ['study_key'] },
          },
          {
            label: 'It is evidence.',
            reply: 'Everything in this house is evidence now. Take it.',
            affinity: -1,
            effect: { give: ['study_key'] },
          },
        ],
      },
      {
        id: 't_ledger',
        q: 'The ledger.',
        showIf: { flags: ['drawer_open'] },
        a: 'There is nothing in that ledger that concerns a dead wireless operator.',
        press: [
          {
            label: 'There are fourteen payments to a doctor.',
            reply: 'Then the house has a doctor. That is all.',
            affinity: -1,
          },
          {
            label: 'I will read it properly.',
            reply: 'Read it properly. I would.',
            affinity: 1,
          },
        ],
      },
      {
        id: 't_quill',
        q: 'Dr. Quill.',
        a: 'He is a guest. I did not invite him and I do not know how he came.',
        press: [
          {
            label: 'You do not know?',
            reply: 'I know what I signed. I do not know what was sent for.',
            affinity: 1,
          },
          {
            label: 'You are lying.',
            reply: 'I am not lying. I am being careful, which is the same thing in a house like this.',
            affinity: -1,
          },
        ],
      },
    ],
  },
};

export const NPC_ORDER = ['quill', 'isolde', 'pike', 'vera', 'thorne'];

export const SUSPECTS: { id: string; name: string; role: string }[] = [
  { id: 'quill', name: 'Dr. Ambrose Quill', role: 'Physician' },
  { id: 'isolde', name: 'Isolde Marrow', role: 'Heiress' },
  { id: 'pike', name: 'Cornelius Pike', role: 'Groundskeeper' },
  { id: 'vera', name: 'Vera Lys', role: 'Telegraphist' },
  { id: 'thorne', name: 'Edmund Thorne', role: 'Solicitor' },
];
