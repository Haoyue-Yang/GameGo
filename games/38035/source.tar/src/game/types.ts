export type Vec = { x: number; y: number };

export type Rect = [x: number, y: number, w: number, h: number];

/** A condition gate. All provided keys must be satisfied. */
export interface Req {
  items?: string[];
  clues?: string[];
  flags?: string[];
  /** minimum affinity per character id */
  affinity?: Record<string, number>;
  /** every sub-requirement must pass */
  all?: Req[];
  /** at least one sub-requirement must pass */
  any?: Req[];
}

/** Everything a game action can do to the world. */
export interface Effect {
  text?: string;
  give?: string[];
  consume?: string[];
  clues?: string[];
  flags?: string[];
  affinity?: Record<string, number>;
  goto?: string;
  panel?: PanelKind;
  choice?: string;
  minigame?: string;
  shout?: string;
}

export type PanelKind = 'casefile' | 'accuse' | 'help';

export interface Action {
  id: string;
  label: string;
  requires?: Req;
  /** hidden entirely when this requirement is met */
  hideIf?: Req;
  /** shown only when this requirement is met */
  showIf?: Req;
  effect: Effect;
}

export interface Hotspot {
  id: string;
  label: string;
  rect: Rect;
  /** where the detective stands to reach it */
  stand: [number, number];
  kind: 'thing' | 'door' | 'body';
  to?: string;
  requires?: Req;
  denied?: string;
  look: string;
  actions?: Action[];
}

export interface Room {
  id: string;
  name: string;
  sub: string;
  img: string;
  /** walkable band, in % of the frame */
  walk: [x0: number, y0: number, x1: number, y1: number];
  /** depth scaling: [farY, farScale, nearY, nearScale] */
  depth: [farY: number, farScale: number, nearY: number, nearScale: number];
  spawn: Vec;
  hotspots: Hotspot[];
}

export interface Topic {
  id: string;
  q: string;
  /** shown only when this passes */
  showIf?: Req;
  /** hidden once this passes */
  hideIf?: Req;
  a: string;
  /** alternate reply when affinity is high */
  aWarm?: string;
  /** alternate reply when affinity is low */
  aCold?: string;
  effect?: Effect;
  /** follow-up choices that shift affinity */
  press?: PressOption[];
}

export interface PressOption {
  label: string;
  reply: string;
  affinity: number;
  effect?: Effect;
}

export interface Npc {
  id: string;
  name: string;
  role: string;
  room: string;
  pos: [number, number];
  coat: string;
  trim: string;
  skin: string;
  hat: 'none' | 'cap' | 'brim' | 'bun' | 'bowler';
  build: 'tall' | 'slim' | 'broad' | 'petite';
  intro: string;
  topics: Topic[];
}

export interface ItemDef {
  id: string;
  name: string;
  desc: string;
  glyph: string;
}

export interface GameState {
  screen: 'title' | 'game' | 'ending';
  room: string;
  player: Vec;
  facing: 1 | -1;
  walking: boolean;
  /** hotspot id to resolve once the detective arrives */
  pending: string | null;
  items: string[];
  clues: string[];
  flags: Record<string, boolean>;
  affinity: Record<string, number>;
  held: string | null;
  seen: Record<string, boolean>;
  asked: Record<string, boolean>;
  panel: PanelKind | null;
  examine: { title: string; body: string; hotspot: string } | null;
  talk: string | null;
  choice: string | null;
  minigame: string | null;
  ending: string | null;
  log: string[];
  turn: number;
}
