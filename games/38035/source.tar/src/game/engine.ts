import type { Effect, GameState, Req, Room } from './types';
import { ROOMS } from './rooms';
import { NPCS } from './npcs';
import { COMBINES, ITEMS } from './items';
import { CHOICES, CLUE_MAP, ENDINGS } from './casefile';

export const KILLER = 'quill';
export const MIN_PROOF = 6;

export function initialState(): GameState {
  return {
    screen: 'title',
    room: 'hall',
    player: { ...ROOMS.hall.spawn },
    facing: 1,
    walking: false,
    pending: null,
    items: [],
    clues: [],
    flags: {},
    affinity: { quill: 0, isolde: 0, pike: 0, vera: 0, thorne: 0 },
    held: null,
    seen: {},
    asked: {},
    panel: null,
    examine: null,
    talk: null,
    choice: null,
    minigame: null,
    ending: null,
    log: [
      'HOLLOWMERE MANOR. 11:58 p.m. The wire went at 11:30 and the storm has not stopped since.',
      'Silas Vane, wireless operator, is dead in the wireless room. Five people are awake in this house.',
      'Find out who killed him, and be able to prove it before the nine-forty train.',
    ],
    turn: 0,
  };
}

/* ─────────────────────────────  requirements  ───────────────────────────── */

export function meets(s: GameState, r?: Req): boolean {
  if (!r) return true;
  if (r.items && !r.items.every((i) => s.items.includes(i))) return false;
  if (r.clues && !r.clues.every((c) => s.clues.includes(c))) return false;
  if (r.flags && !r.flags.every((f) => s.flags[f])) return false;
  if (r.affinity) {
    for (const [k, v] of Object.entries(r.affinity)) {
      if ((s.affinity[k] ?? 0) < v) return false;
    }
  }
  if (r.all && !r.all.every((sub) => meets(s, sub))) return false;
  if (r.any && !r.any.some((sub) => meets(s, sub))) return false;
  return true;
}

/* ─────────────────────────────  effects  ───────────────────────────── */

export function applyEffect(s: GameState, e: Effect): GameState {
  let n: GameState = { ...s };
  const log = [...n.log];

  if (e.text) log.push(e.text);

  if (e.give) {
    const items = [...n.items];
    for (const id of e.give) {
      if (!items.includes(id)) {
        items.push(id);
        log.push(`Taken: ${ITEMS[id]?.name ?? id}.`);
      }
    }
    n.items = items;
  }

  if (e.consume) {
    n.items = n.items.filter((i) => !e.consume!.includes(i));
  }

  if (e.clues) {
    const clues = [...n.clues];
    for (const id of e.clues) {
      if (!clues.includes(id)) {
        clues.push(id);
        log.push(`Case file: ${CLUE_MAP[id]?.name ?? id}.`);
      }
    }
    n.clues = clues;
  }

  if (e.flags) {
    n.flags = { ...n.flags };
    for (const f of e.flags) n.flags[f] = true;
  }

  if (e.affinity) {
    n.affinity = { ...n.affinity };
    for (const [k, v] of Object.entries(e.affinity)) {
      n.affinity[k] = Math.max(-3, Math.min(3, (n.affinity[k] ?? 0) + v));
    }
  }

  if (e.goto) {
    n.room = e.goto;
    n.player = { ...ROOMS[e.goto].spawn };
    n.pending = null;
    n.walking = false;
    n.examine = null;
    n.talk = null;
    log.push(`— ${ROOMS[e.goto].name} —`);
  }

  if (e.panel) n.panel = e.panel;
  if (e.choice) n.choice = e.choice;
  if (e.minigame) n.minigame = e.minigame;
  if (e.shout) log.push(e.shout);

  n.log = log.slice(-60);
  n.turn = n.turn + 1;
  return n;
}

/* ─────────────────────────────  room helpers  ───────────────────────────── */

export function room(s: GameState): Room {
  return ROOMS[s.room];
}

export function npcHere(s: GameState): string | null {
  const id = Object.keys(NPCS).find((k) => NPCS[k].room === s.room);
  return id ?? null;
}

export function npcAt(s: GameState): { id: string; x: number; y: number } | null {
  const id = npcHere(s);
  if (!id) return null;
  const n = NPCS[id];
  return { id, x: n.pos[0], y: n.pos[1] };
}

export function proof(s: GameState): number {
  return s.clues.reduce((t, c) => t + (CLUE_MAP[c]?.weight ?? 1), 0);
}

/** A single nudge toward whatever is still missing. */
export function nextHint(s: GameState): string {
  const has = (i: string) => s.items.includes(i);
  const clue = (c: string) => s.clues.includes(c);
  const f = (k: string) => !!s.flags[k];
  const steps: [boolean, string][] = [
    [!f('coat_searched'), 'Search the coat on the stand in the hall.'],
    [!has('magnifier') && !clue('wound'), 'Vera Lys is in the wireless room. Ask her for her loupe.'],
    [!clue('wound'), 'Examine Vane himself — with the loupe in your hand.'],
    [!clue('logbook'), 'Read the wireless log on the small table.'],
    [!has('trowel'), 'Pike is in the conservatory. Ask him for his trowel.'],
    [!has('brass_key'), 'Dig in the conservatory planter.'],
    [!has('lit_lantern'), 'The gallery lantern needs oil. Pike\'s coat has some.'],
    [!f('boiler_searched'), 'Search behind the cellar boiler.'],
    [!has('study_key'), 'Thorne is in the gallery. Ask him for the library key.'],
    [!f('drawer_open'), 'Unlock the top drawer of the library desk.'],
    [!f('torn') && !f('photographed'), 'Deal with the written-over page in the ledger.'],
    [!has('charred_letter') && !f('letter_found'), 'Rake the library grate.'],
    [!clue('letter'), 'Press the charred letter flat with the conservatory press.'],
    [!f('cabinet_code'), 'Quill will give you the cabinet combination if he trusts you.'],
    [!clue('cabinet'), 'Open the medicine cabinet in the master bedroom.'],
    [!clue('boots'), 'Measure the boots on the cellar boiler.'],
    [!f('band_tuned'), 'Splice the spare coil into the receiver and tune the band.'],
    [!f('answered') && !f('silenced'), 'Decide what to do with the band.'],
  ];
  const next = steps.find(([done]) => !done);
  if (next) return next[1];
  return 'You have what you need. Name a name.';
}

export function endingFor(s: GameState, suspect: string): string {
  if (suspect !== KILLER) return 'dead';
  const strong = s.flags.torn && s.flags.answered;
  if (strong && proof(s) >= MIN_PROOF) return 'clear';
  return 'static';
}

export function endingDef(id: string) {
  return ENDINGS[id] ?? ENDINGS.static;
}

/* ─────────────────────────────  dialogue  ───────────────────────────── */

export function visibleTopics(s: GameState, npcId: string) {
  return NPCS[npcId].topics.filter(
    (t) => meets(s, t.showIf) && !meets(s, t.hideIf),
  );
}

export function replyFor(s: GameState, npcId: string, a: string, warm?: string, cold?: string): string {
  const aff = s.affinity[npcId] ?? 0;
  if (aff >= 2 && warm) return warm;
  if (aff <= -2 && cold) return cold;
  return a;
}

/* ─────────────────────────────  combining  ───────────────────────────── */

export function findCombine(a: string, b: string) {
  return COMBINES.find(
    (c) => (c.a === a && c.b === b) || (c.a === b && c.b === a),
  );
}

export function combineEffect(a: string, b: string): Effect | null {
  const c = findCombine(a, b);
  if (!c) return null;
  return {
    text: c.text,
    give: c.out ? [c.out] : undefined,
    consume: c.consume,
    clues: c.clues,
    flags: c.flags,
    panel: c.panel,
  };
}

/* ─────────────────────────────  choices  ───────────────────────────── */

export function choiceOptions(s: GameState, id: string) {
  return CHOICES[id].options.filter((o) => {
    if (!o.requires) return true;
    if (o.requires.items && !o.requires.items.every((i) => s.items.includes(i))) return false;
    if (o.requires.clues && !o.requires.clues.every((c) => s.clues.includes(c))) return false;
    return true;
  });
}
