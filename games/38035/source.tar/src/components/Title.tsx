import { useEffect, useState } from 'react';
import titleImg from '../assets/title.jpg';

export function TitleScreen({ onStart }: { onStart: () => void }) {
  const [flash, setFlash] = useState(0);
  useEffect(() => {
    let alive = true;
    let timer: number;
    const schedule = () => {
      timer = window.setTimeout(() => {
        if (!alive) return;
        setFlash((f) => f + 1);
        schedule();
      }, 3200 + Math.random() * 7000);
    };
    schedule();
    return () => {
      alive = false;
      window.clearTimeout(timer);
    };
  }, []);

  return (
    <div className="duo relative w-full" style={{ aspectRatio: '16 / 9' }}>
      <img src={titleImg} alt="" draggable={false} />
      <div className="duo-tint" />
      <div className="duo-lift" />
      <div className="duo-quant" />
      <div className="rain" />
      <div className="rain rain-2" />
      <div className="vignette" />
      <div className="scanlines" />
      <div key={flash} className={flash ? 'flash flash-on' : 'flash'} />

      <div className="absolute inset-0 z-[60] flex flex-col items-center justify-center px-6 text-center">
        <p className="font-pixel text-[10px] tracking-[0.4em] text-ice-faint">
          A POINT-AND-CLICK MYSTERY
        </p>
        <h1 className="title-glow mt-3 font-pixel text-[30px] leading-[1.05] tracking-[0.1em] text-ice sm:text-[58px]">
          THE HOLLOWMERE
          <br />
          SIGNAL
        </h1>
        <p className="mt-4 max-w-xl font-term text-[17px] leading-snug text-ice-dim sm:text-[20px]">
          Silas Vane is dead in the wireless room. The storm took the wire at 11:30 and the house has
          not spoken since. Five people are awake. One of them is a doctor who is not a doctor.
        </p>
        <button className="btn btn-hot mt-7 !px-6 !py-3 !text-[12px]" onClick={onStart}>
          Enter the house
        </button>
        <p className="mt-5 font-term text-[15px] text-ice-faint">
          click the floor to walk · click a thing to examine · hold TAB to see every hotspot
        </p>
      </div>
    </div>
  );
}
