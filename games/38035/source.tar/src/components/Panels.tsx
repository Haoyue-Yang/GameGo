import { useEffect, useState } from 'react';
import type { GameState } from '../game/types';
import { ROOMS } from '../game/rooms';
import { NPCS, SUSPECTS } from '../game/npcs';
import { ITEMS } from '../game/items';
import { CHOICES, CLUES, CLUE_MAP, ENDINGS } from '../game/casefile';
import { meets, proof, replyFor, visibleTopics, choiceOptions } from '../game/engine';

/* ─────────────────────────────  shared shell  ───────────────────────────── */

export function Overlay({
  children,
  onClose,
  wide,
}: {
  children: React.ReactNode;
  onClose?: () => void;
  wide?: boolean;
}) {
  useEffect(() => {
    if (!onClose) return;
    const k = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', k);
    return () => window.removeEventListener('keydown', k);
  }, [onClose]);

  return (
    <div
      className="absolute inset-0 z-50 flex items-end justify-center bg-slate-ink/70 p-3 backdrop-blur-[2px] sm:p-6"
      onClick={onClose}
    >
      <div
        className={`fade-in panel max-h-full w-full overflow-hidden ${wide ? 'max-w-4xl' : 'max-w-2xl'}`}
        onClick={(e) => e.stopPropagation()}
      >
        {children}
      </div>
    </div>
  );
}

/* ─────────────────────────────  examine  ───────────────────────────── */

export function ExaminePanel({
  state,
  onAction,
  onClose,
}: {
  state: GameState;
  onAction: (hotspot: string, action: string) => void;
  onClose: () => void;
}) {
  const ex = state.examine!;
  const h = ROOMS[state.room].hotspots.find((x) => x.id === ex.hotspot);
  const acts = (h?.actions ?? []).filter(
    (a) =>
      meets(state, a.requires) &&
      !(a.hideIf && meets(state, a.hideIf)) &&
      !(a.showIf && !meets(state, a.showIf)),
  );

  return (
    <Overlay onClose={onClose}>
      <div className="flex items-center justify-between border-b border-slate-line px-4 py-2">
        <h2 className="font-pixel text-[12px] tracking-widest text-ice">{ex.title}</h2>
        <button className="btn !px-2 !py-1" onClick={onClose}>
          Close
        </button>
      </div>
      <p className="px-4 py-3 font-term text-[17px] leading-snug text-ice-dim">{ex.body}</p>
      {acts.length > 0 && (
        <div className="flex flex-wrap gap-2 border-t border-slate-line px-4 py-3">
          {acts.map((a) => (
            <button
              key={a.id}
              className="btn"
              onClick={() => onAction(ex.hotspot, a.id)}
            >
              {a.label}
            </button>
          ))}
        </div>
      )}
    </Overlay>
  );
}

/* ─────────────────────────────  dialogue  ───────────────────────────── */

const AFF_LABEL = (v: number) =>
  v >= 2 ? 'Warm' : v === 1 ? 'Civil' : v === 0 ? 'Neutral' : v === -1 ? 'Guarded' : 'Hostile';

function AffMeter({ v }: { v: number }) {
  const n = v + 3;
  return (
    <span className="inline-flex gap-[2px] align-middle">
      {Array.from({ length: 7 }).map((_, i) => (
        <span
          key={i}
          className="inline-block h-[9px] w-[5px]"
          style={{ background: i <= n ? '#cfe3f2' : 'rgba(45,66,96,0.9)' }}
        />
      ))}
    </span>
  );
}

export function TalkPanel({
  state,
  onAsk,
  onPress,
  onClose,
}: {
  state: GameState;
  onAsk: (npc: string, topic: string) => void;
  onPress: (npc: string, topic: string, idx: number) => void;
  onClose: () => void;
}) {
  const npc = NPCS[state.talk!];
  const aff = state.affinity[npc.id] ?? 0;
  const [active, setActive] = useState<{ topic: string; reply: string; press: boolean } | null>(
    null,
  );
  const [pressReply, setPressReply] = useState<string | null>(null);

  useEffect(() => {
    setActive(null);
    setPressReply(null);
  }, [npc.id]);

  const topics = visibleTopics(state, npc.id);
  const topic = active ? npc.topics.find((t) => t.id === active.topic) : null;

  return (
    <Overlay onClose={onClose} wide>
      <div className="flex items-center justify-between border-b border-slate-line px-4 py-2">
        <div>
          <h2 className="font-pixel text-[12px] tracking-widest text-ice">{npc.name}</h2>
          <p className="font-term text-[14px] text-ice-faint">{npc.role}</p>
        </div>
        <div className="flex items-center gap-3">
          <span className="font-term text-[15px] text-ice-dim">{AFF_LABEL(aff)}</span>
          <AffMeter v={aff} />
          <button className="btn !px-2 !py-1" onClick={onClose}>
            Leave
          </button>
        </div>
      </div>

      <div className="max-h-[52vh] overflow-y-auto scroll-thin px-4 py-3">
        {!active && (
          <>
            <p className="mb-3 font-term text-[17px] leading-snug text-ice-dim">{npc.intro}</p>
            <p className="mb-2 font-pixel text-[10px] tracking-widest text-ice-faint">
              ASK ABOUT
            </p>
            <div className="grid gap-2 sm:grid-cols-2">
              {topics.map((t) => (
                <button
                  key={t.id}
                  className="btn"
                  onClick={() => {
                    onAsk(npc.id, t.id);
                    setActive({
                      topic: t.id,
                      reply: replyFor(state, npc.id, t.a, t.aWarm, t.aCold),
                      press: !!t.press,
                    });
                  }}
                >
                  {t.q}
                </button>
              ))}
              {topics.length === 0 && (
                <p className="font-term text-[16px] text-ice-faint">
                  There is nothing left to ask.
                </p>
              )}
            </div>
          </>
        )}

        {active && topic && (
          <div>
            <p className="mb-2 font-term text-[16px] text-ice-faint">You: “{topic.q}”</p>
            <p className="mb-3 font-term text-[17px] leading-snug text-ice">
              {npc.name}: “{active.reply}”
            </p>
            {pressReply && (
              <p className="mb-3 font-term text-[17px] leading-snug text-ice">
                {npc.name}: “{pressReply}”
              </p>
            )}
            {active.press && !pressReply && (
              <>
                <p className="mb-2 font-pixel text-[10px] tracking-widest text-ice-faint">
                  PUSH
                </p>
                <div className="grid gap-2 sm:grid-cols-2">
                  {topic.press!.map((p, i) => (
                    <button
                      key={i}
                      className="btn"
                      onClick={() => {
                        onPress(npc.id, topic.id, i);
                        setPressReply(p.reply);
                      }}
                    >
                      {p.label}
                      <span className="ml-2 text-ice-faint">
                        {p.affinity > 0 ? `+${p.affinity}` : p.affinity}
                      </span>
                    </button>
                  ))}
                </div>
              </>
            )}
            <div className="mt-4 flex gap-2">
              <button className="btn" onClick={() => setActive(null)}>
                Ask something else
              </button>
              <button className="btn" onClick={onClose}>
                Leave
              </button>
            </div>
          </div>
        )}
      </div>
    </Overlay>
  );
}

/* ─────────────────────────────  irreversible choice  ───────────────────────────── */

export function ChoicePanel({
  state,
  onResolve,
  onClose,
}: {
  state: GameState;
  onResolve: (choice: string, option: string) => void;
  onClose: () => void;
}) {
  const def = CHOICES[state.choice!];
  const opts = choiceOptions(state, def.id);
  const [confirm, setConfirm] = useState<string | null>(null);

  return (
    <Overlay onClose={onClose} wide>
      <div className="border-b border-slate-line px-4 py-2">
        <h2 className="font-pixel text-[12px] tracking-widest text-ice">{def.title}</h2>
        <p className="font-pixel text-[9px] tracking-widest text-ice-faint">{def.warning}</p>
      </div>
      <p className="px-4 py-3 font-term text-[17px] leading-snug text-ice-dim">{def.body}</p>
      <div className="grid gap-2 border-t border-slate-line px-4 py-3 sm:grid-cols-2">
        {opts.map((o) => (
          <button
            key={o.id}
            className="btn"
            onClick={() => (confirm === o.id ? onResolve(def.id, o.id) : setConfirm(o.id))}
          >
            {o.label}
            <span className="mt-1 block font-term text-[14px] normal-case tracking-normal text-ice-faint">
              {o.detail}
            </span>
            {confirm === o.id && (
              <span className="mt-1 block font-pixel text-[9px] tracking-widest text-ice">
                ▸ click again to commit
              </span>
            )}
          </button>
        ))}
      </div>
    </Overlay>
  );
}

/* ─────────────────────────────  case file  ───────────────────────────── */

export function CaseFile({
  state,
  onAccuse,
  onClose,
}: {
  state: GameState;
  onAccuse: () => void;
  onClose: () => void;
}) {
  const p = proof(state);
  return (
    <Overlay onClose={onClose} wide>
      <div className="flex items-center justify-between border-b border-slate-line px-4 py-2">
        <h2 className="font-pixel text-[12px] tracking-widest text-ice">CASE FILE</h2>
        <div className="flex items-center gap-3">
          <span className="font-term text-[15px] text-ice-dim">
            proof {p} / {CLUES.reduce((t, c) => t + c.weight, 0)}
          </span>
          <button className="btn !px-2 !py-1" onClick={onClose}>
            Close
          </button>
        </div>
      </div>

      <div className="max-h-[54vh] overflow-y-auto scroll-thin px-4 py-3">
        <div className="mb-4 grid gap-2 sm:grid-cols-2">
          {CLUES.map((c) => {
            const have = state.clues.includes(c.id);
            return (
              <div
                key={c.id}
                className="border px-3 py-2"
                style={{
                  borderColor: have ? 'rgba(207,227,242,0.5)' : 'rgba(45,66,96,0.6)',
                  background: have ? 'rgba(207,227,242,0.07)' : 'transparent',
                }}
              >
                <p
                  className="font-pixel text-[10px] tracking-widest"
                  style={{ color: have ? '#cfe3f2' : 'rgba(109,135,164,0.7)' }}
                >
                  {have ? c.name : '— — — — — —'}
                </p>
                <p className="mt-1 font-term text-[15px] leading-snug text-ice-dim">
                  {have ? c.body : 'Not yet established.'}
                </p>
              </div>
            );
          })}
        </div>

        <p className="mb-2 font-pixel text-[10px] tracking-widest text-ice-faint">
          THE HOUSE — TONIGHT
        </p>
        <div className="grid gap-2 sm:grid-cols-2">
          {SUSPECTS.map((s) => {
            const aff = state.affinity[s.id] ?? 0;
            return (
              <div key={s.id} className="flex items-center justify-between border border-slate-line px-3 py-2">
                <div>
                  <p className="font-pixel text-[10px] tracking-widest text-ice">{s.name}</p>
                  <p className="font-term text-[14px] text-ice-faint">{s.role}</p>
                </div>
                <div className="flex items-center gap-2">
                  <span className="font-term text-[14px] text-ice-dim">{AFF_LABEL(aff)}</span>
                  <AffMeter v={aff} />
                </div>
              </div>
            );
          })}
        </div>

        <div className="mt-4 flex flex-wrap items-center gap-3 border-t border-slate-line pt-3">
          <p className="font-term text-[15px] text-ice-faint">
            {p >= 6
              ? 'Enough to hold a man in a room.'
              : 'Not enough to hold anyone anywhere.'}
          </p>
          <button className="btn btn-hot ml-auto" onClick={onAccuse}>
            Make the accusation
          </button>
        </div>
      </div>
    </Overlay>
  );
}

/* ─────────────────────────────  accusation  ───────────────────────────── */

export function AccusePanel({
  state,
  onAccuse,
  onClose,
}: {
  state: GameState;
  onAccuse: (id: string) => void;
  onClose: () => void;
}) {
  const [pick, setPick] = useState<string | null>(null);
  const p = proof(state);
  return (
    <Overlay onClose={onClose} wide>
      <div className="border-b border-slate-line px-4 py-2">
        <h2 className="font-pixel text-[12px] tracking-widest text-ice">THE ACCUSATION</h2>
        <p className="font-pixel text-[9px] tracking-widest text-ice-faint">
          There is no taking it back.
        </p>
      </div>
      <p className="px-4 py-3 font-term text-[17px] leading-snug text-ice-dim">
        The rain has stopped. Everyone in the house is awake and standing in the gallery, and they
        are waiting for you to say a name. Proof on the table: {p}.
      </p>
      <div className="grid gap-2 border-t border-slate-line px-4 py-3 sm:grid-cols-2">
        {SUSPECTS.map((s) => (
          <button
            key={s.id}
            className={`btn ${pick === s.id ? 'btn-hot' : ''}`}
            onClick={() => (pick === s.id ? onAccuse(s.id) : setPick(s.id))}
          >
            {s.name}
            <span className="mt-1 block font-term text-[14px] normal-case tracking-normal text-ice-faint">
              {s.role}
            </span>
            {pick === s.id && (
              <span className="mt-1 block font-pixel text-[9px] tracking-widest text-ice">
                ▸ click again to name them
              </span>
            )}
          </button>
        ))}
      </div>
    </Overlay>
  );
}

/* ─────────────────────────────  inventory  ───────────────────────────── */

export function Inventory({
  state,
  onHold,
  onCombine,
}: {
  state: GameState;
  onHold: (id: string | null) => void;
  onCombine: (a: string, b: string) => void;
}) {
  const held = state.held;
  return (
    <div className="flex items-center gap-2">
      <div className="flex flex-wrap gap-1">
        {Array.from({ length: 12 }).map((_, i) => {
          const id = state.items[i];
          if (!id) {
            return <div key={`e${i}`} className="slot slot-empty" />;
          }
          const it = ITEMS[id];
          return (
            <button
              key={id}
              className={`slot ${held === id ? 'slot-on' : ''}`}
              title={`${it.name} — ${it.desc}`}
              aria-label={it.name}
              onClick={() => {
                if (!held) {
                  onHold(id);
                } else if (held === id) {
                  onHold(null);
                } else {
                  onCombine(held, id);
                }
              }}
            >
              <span aria-hidden="true">{it.glyph}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}

export function HeldBanner({ state, onClear }: { state: GameState; onClear: () => void }) {
  if (!state.held) return null;
  const it = ITEMS[state.held];
  return (
    <div className="fade-in flex items-center gap-3 border border-ice/60 bg-ice/10 px-3 py-1">
      <span className="font-pixel text-[10px] tracking-widest text-ice">
        {it.glyph} {it.name}
      </span>
      <span className="font-term text-[14px] text-ice-dim">
        click a thing to use it · click another item to combine
      </span>
      <button className="btn !px-2 !py-0.5" onClick={onClear}>
        Put away
      </button>
    </div>
  );
}

/* ─────────────────────────────  ending  ───────────────────────────── */

export function EndingScreen({
  state,
  onRestart,
}: {
  state: GameState;
  onRestart: () => void;
}) {
  const def = ENDINGS[state.ending!] ?? ENDINGS.static;
  const tone =
    def.tone === 'clear' ? '#cfe3f2' : def.tone === 'static' ? '#9db6cf' : '#6d87a4';
  return (
    <div className="relative min-h-full w-full overflow-y-auto scroll-thin bg-slate-ink">
      <div className="mx-auto max-w-3xl px-5 py-10">
        <p className="font-pixel text-[10px] tracking-[0.3em] text-ice-faint">{def.kicker}</p>
        <h1
          className="title-glow mt-2 font-pixel text-[34px] leading-none tracking-[0.12em] sm:text-[52px]"
          style={{ color: tone }}
        >
          {def.title}
        </h1>
        <div className="mt-6 space-y-4">
          {def.body.map((p, i) => (
            <p key={i} className="font-term text-[19px] leading-snug text-ice-dim">
              {p}
            </p>
          ))}
        </div>

        <div className="mt-8 border border-slate-line p-4">
          <p className="mb-2 font-pixel text-[10px] tracking-widest text-ice-faint">
            THE FILE, CLOSED
          </p>
          <ul className="space-y-1">
            {CLUES.map((c) => (
              <li key={c.id} className="font-term text-[16px]">
                <span style={{ color: state.clues.includes(c.id) ? '#cfe3f2' : '#6d87a4' }}>
                  {state.clues.includes(c.id) ? '▪' : '▫'}
                </span>{' '}
                <span style={{ color: state.clues.includes(c.id) ? '#cfe3f2' : '#6d87a4' }}>
                  {state.clues.includes(c.id) ? c.name : 'unestablished'}
                </span>
              </li>
            ))}
          </ul>
          <p className="mt-3 font-term text-[16px] text-ice-faint">
            The ledger was{' '}
            {state.flags.torn ? 'torn open' : state.flags.photographed ? 'photographed' : 'never opened'}.{' '}
            The band was {state.flags.answered ? 'answered' : state.flags.silenced ? 'silenced' : 'never tuned'}.
          </p>
        </div>

        <div className="mt-6 flex flex-wrap gap-3">
          <button className="btn btn-hot" onClick={onRestart}>
            Another night at Hollowmere
          </button>
        </div>
      </div>
    </div>
  );
}

export function clueCount(s: GameState) {
  return s.clues.length;
}

export function clueMap() {
  return CLUE_MAP;
}
