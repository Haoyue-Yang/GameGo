import { useEffect, useRef, useState } from 'react';

const VW = 640;
const VH = 220;
const TIME = 42; // seconds

interface Props {
  onDone: () => void;
  onAbort: () => void;
}

export function SignalBand({ onDone, onAbort }: Props) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [hits, setHits] = useState(0);
  const [lock, setLock] = useState(0);
  const [timeLeft, setTimeLeft] = useState(TIME);
  const [failed, setFailed] = useState(false);
  const [won, setWon] = useState(false);
  const [dragging, setDragging] = useState(false);

  const g = useRef({
    bandX: 0.5,
    bandV: 0.06,
    knobX: 0.12,
    lock: 0,
    hits: 0,
    tol: 0.055,
    maxV: 0.1,
    t: 0,
    time: TIME,
    done: false,
  });

  useEffect(() => {
    const cv = canvasRef.current;
    if (!cv) return;
    const ctx = cv.getContext('2d');
    if (!ctx) return;

    const dpr = Math.min(2, window.devicePixelRatio || 1);
    cv.width = VW * dpr;
    cv.height = VH * dpr;
    ctx.scale(dpr, dpr);

    let raf = 0;
    let last = performance.now();
    const shown = { lock: -1, time: -1 };

    const wave = (x: number, t: number) =>
      Math.sin(x * 0.07 + t * 0.004) * 0.5 +
      Math.sin(x * 0.19 - t * 0.007) * 0.3 +
      Math.sin(x * 0.33 + t * 0.011) * 0.2;

    const draw = () => {
      const s = g.current;
      const cy = VH * 0.52;

      ctx.fillStyle = '#0b1220';
      ctx.fillRect(0, 0, VW, VH);

      // grid
      ctx.strokeStyle = 'rgba(45,66,96,0.5)';
      ctx.lineWidth = 1;
      for (let x = 0; x <= VW; x += 32) {
        ctx.beginPath();
        ctx.moveTo(x + 0.5, 0);
        ctx.lineTo(x + 0.5, VH);
        ctx.stroke();
      }
      for (let y = 0; y <= VH; y += 28) {
        ctx.beginPath();
        ctx.moveTo(0, y + 0.5);
        ctx.lineTo(VW, y + 0.5);
        ctx.stroke();
      }

      // waveform
      for (let x = 0; x < VW; x += 3) {
        const n = wave(x, s.t);
        const inBand = Math.abs(x / VW - s.bandX) < s.tol;
        const amp = (inBand ? 40 : 16) + 26 * Math.abs(n);
        ctx.fillStyle = inBand ? '#cfe3f2' : 'rgba(109,135,164,0.75)';
        ctx.fillRect(x, cy - amp / 2, 2, amp);
      }

      // band edges
      const bx = s.bandX * VW;
      ctx.fillStyle = 'rgba(207,227,242,0.10)';
      ctx.fillRect(bx - s.tol * VW, 0, s.tol * 2 * VW, VH);
      ctx.strokeStyle = 'rgba(207,227,242,0.55)';
      ctx.setLineDash([4, 4]);
      ctx.beginPath();
      ctx.moveTo(bx - s.tol * VW, 0);
      ctx.lineTo(bx - s.tol * VW, VH);
      ctx.moveTo(bx + s.tol * VW, 0);
      ctx.lineTo(bx + s.tol * VW, VH);
      ctx.stroke();
      ctx.setLineDash([]);

      // knob
      const kx = s.knobX * VW;
      ctx.fillStyle = '#cfe3f2';
      ctx.fillRect(kx - 1, 0, 2, VH);
      ctx.beginPath();
      ctx.moveTo(kx, VH - 26);
      ctx.lineTo(kx + 9, VH - 14);
      ctx.lineTo(kx, VH - 2);
      ctx.lineTo(kx - 9, VH - 14);
      ctx.closePath();
      ctx.fill();

      // lock meter
      ctx.fillStyle = 'rgba(11,18,32,0.9)';
      ctx.fillRect(16, 14, VW - 32, 10);
      ctx.strokeStyle = 'rgba(207,227,242,0.5)';
      ctx.strokeRect(16.5, 14.5, VW - 33, 9);
      ctx.fillStyle = s.lock > 0.85 ? '#ffffff' : '#9db6cf';
      ctx.fillRect(18, 16, (VW - 36) * s.lock, 6);

      // hits
      for (let i = 0; i < 3; i++) {
        ctx.fillStyle = i < s.hits ? '#cfe3f2' : 'rgba(45,66,96,0.9)';
        ctx.fillRect(VW - 60 + i * 16, 34, 10, 10);
      }

      // timer
      ctx.fillStyle = 'rgba(11,18,32,0.9)';
      ctx.fillRect(16, VH - 20, VW - 32, 6);
      ctx.fillStyle = s.time < 10 ? '#6d87a4' : '#2d4260';
      ctx.fillRect(18, VH - 18, (VW - 36) * Math.max(0, s.time / TIME), 2);
    };

    const step = (now: number) => {
      const s = g.current;
      const dt = Math.min(50, now - last);
      last = now;
      s.t += dt;

      if (!s.done) {
        s.time -= dt / 1000;
        if (s.time <= 0) {
          s.done = true;
          setFailed(true);
        }

        // band drift
        s.bandV += (Math.random() - 0.5) * 0.0009 * dt;
        s.bandV += Math.sin(s.t / 1100) * 0.00006 * dt;
        s.bandV = Math.max(-s.maxV, Math.min(s.maxV, s.bandV));
        s.bandX += (s.bandV * dt) / 1000;
        if (s.bandX < 0.05) {
          s.bandX = 0.05;
          s.bandV = Math.abs(s.bandV);
        }
        if (s.bandX > 0.95) {
          s.bandX = 0.95;
          s.bandV = -Math.abs(s.bandV);
        }

        // lock
        const d = Math.abs(s.knobX - s.bandX);
        if (d < s.tol) {
          s.lock += (dt / 1000) * (0.55 + 0.75 * (1 - d / s.tol));
        } else {
          s.lock -= (dt / 1000) * 0.5;
        }
        s.lock = Math.max(0, Math.min(1, s.lock));

        if (s.lock >= 1) {
          s.hits += 1;
          s.lock = 0;
          s.tol = Math.max(0.03, s.tol - 0.008);
          s.maxV = Math.min(0.22, s.maxV + 0.045);
          s.bandX = 0.1 + Math.random() * 0.8;
          s.bandV = (Math.random() - 0.5) * s.maxV * 2;
          setHits(s.hits);
          if (s.hits >= 3) {
            s.done = true;
            setWon(true);
          }
        }

        const lp = Math.round(s.lock * 100);
        if (lp !== shown.lock) {
          shown.lock = lp;
          setLock(s.lock);
        }
        const ts = Math.ceil(Math.max(0, s.time));
        if (ts !== shown.time) {
          shown.time = ts;
          setTimeLeft(ts);
        }
      }

      draw();
      raf = requestAnimationFrame(step);
    };

    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
  }, []);

  const setKnob = (clientX: number) => {
    const cv = canvasRef.current;
    if (!cv) return;
    const b = cv.getBoundingClientRect();
    g.current.knobX = Math.max(0.02, Math.min(0.98, (clientX - b.left) / b.width));
  };

  useEffect(() => {
    const key = (e: KeyboardEvent) => {
      if (e.key === 'ArrowLeft') {
        g.current.knobX = Math.max(0.02, g.current.knobX - 0.012);
        e.preventDefault();
      }
      if (e.key === 'ArrowRight') {
        g.current.knobX = Math.min(0.98, g.current.knobX + 0.012);
        e.preventDefault();
      }
    };
    window.addEventListener('keydown', key);
    return () => window.removeEventListener('keydown', key);
  }, []);

  const retry = () => {
    const s = g.current;
    s.bandX = 0.5;
    s.bandV = 0.06;
    s.knobX = 0.12;
    s.lock = 0;
    s.hits = 0;
    s.tol = 0.055;
    s.maxV = 0.1;
    s.time = TIME;
    s.done = false;
    setHits(0);
    setLock(0);
    setTimeLeft(TIME);
    setFailed(false);
    setWon(false);
  };

  return (
    <div className="fade-in panel w-full max-w-3xl p-5">
      <div className="mb-3 flex items-baseline justify-between gap-4">
        <h2 className="font-pixel text-[13px] tracking-widest text-ice">THE DRIFTING BAND</h2>
        <span className="font-term text-ice-faint">
          hold the needle inside the band · {hits}/3 locked
        </span>
      </div>

      <p className="mb-3 font-term text-[15px] leading-snug text-ice-dim">
        Drag the knob along the band — or use the arrow keys. The signal drifts. Hold the needle
        inside the marked region until the lock bar fills. Three locks and the voice comes through.
      </p>

      <div className="relative border border-slate-line bg-slate-ink">
        <canvas
          ref={canvasRef}
          className="block w-full touch-none"
          style={{ aspectRatio: `${VW} / ${VH}`, cursor: dragging ? 'grabbing' : 'grab' }}
          onPointerDown={(e) => {
            (e.target as HTMLElement).setPointerCapture(e.pointerId);
            setDragging(true);
            setKnob(e.clientX);
          }}
          onPointerMove={(e) => {
            if (dragging) setKnob(e.clientX);
          }}
          onPointerUp={() => setDragging(false)}
          onPointerCancel={() => setDragging(false)}
        />
        <div className="pointer-events-none absolute inset-0">
          <div className="scanlines" style={{ opacity: 0.35 }} />
        </div>
      </div>

      <div className="mt-3 flex items-center justify-between gap-3">
        <div className="font-term text-[15px] text-ice-faint">
          {won
            ? 'LOCKED. The voice is coming through.'
            : failed
              ? 'The band slipped away. Try again.'
              : `signal ${Math.round(lock * 100)}% · ${Math.ceil(timeLeft)}s`}
        </div>
        <div className="flex gap-2">
          {won ? (
            <button className="btn btn-hot" onClick={onDone}>
              Record it
            </button>
          ) : (
            <>
              <button className="btn" onClick={retry}>
                Reset
              </button>
              <button className="btn" onClick={onAbort}>
                Step away
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
