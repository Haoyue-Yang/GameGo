import { useCallback, useEffect, useRef, useState } from 'react';
import type { GameState } from '../game/types';
import { ROOMS } from '../game/rooms';
import { NPCS } from '../game/npcs';
import { meets } from '../game/engine';
import { Figure, Detective } from './Figure';

interface Props {
  state: GameState;
  actions: {
    arrive: (x: number, y: number) => void;
    interact: (id: string) => void;
    talk: (id: string) => void;
  };
  busy: () => boolean;
}

const BASE_H = 25; // % of frame height at depth scale 1

export function Scene({ state, actions, busy }: Props) {
  const r = ROOMS[state.room];
  const frameRef = useRef<HTMLDivElement | null>(null);
  const posRef = useRef({ ...state.player });
  const targetRef = useRef<{ x: number; y: number } | null>(null);
  const pendingRef = useRef<string | null>(null);
  const cbRef = useRef({ actions, busy });
  cbRef.current = { actions, busy };
  const roomRef = useRef(state.room);
  roomRef.current = state.room;

  const [pos, setPos] = useState({ ...state.player });
  const [facing, setFacing] = useState<1 | -1>(state.facing);
  const [walking, setWalking] = useState(false);
  const [reveal, setReveal] = useState(false);
  const [flash, setFlash] = useState(0);

  /* reset on room change */
  useEffect(() => {
    posRef.current = { ...ROOMS[state.room].spawn };
    targetRef.current = null;
    pendingRef.current = null;
    setPos({ ...ROOMS[state.room].spawn });
    setWalking(false);
  }, [state.room]);

  /* storm lightning */
  useEffect(() => {
    let alive = true;
    let timer: number;
    const schedule = () => {
      timer = window.setTimeout(() => {
        if (!alive) return;
        setFlash((f) => f + 1);
        schedule();
      }, 4200 + Math.random() * 9000);
    };
    schedule();
    return () => {
      alive = false;
      window.clearTimeout(timer);
    };
  }, []);

  /* walk loop */
  useEffect(() => {
    let raf = 0;
    let last = performance.now();
    const step = (t: number) => {
      const dt = Math.min(50, t - last);
      last = t;
      const tgt = targetRef.current;
      if (tgt) {
        const dx = tgt.x - posRef.current.x;
        const dy = tgt.y - posRef.current.y;
        const dist = Math.hypot(dx, dy);
        if (dist < 0.7) {
          posRef.current = { x: tgt.x, y: tgt.y };
          targetRef.current = null;
          setWalking(false);
          setPos({ x: tgt.x, y: tgt.y });
          const p = pendingRef.current;
          pendingRef.current = null;
          cbRef.current.actions.arrive(tgt.x, tgt.y);
          if (p) resolve(p);
        } else {
          const len = Math.min(dist, 0.052 * dt);
          posRef.current = {
            x: posRef.current.x + (dx / dist) * len,
            y: posRef.current.y + (dy / dist) * len,
          };
          if (Math.abs(dx) > 0.5) setFacing(dx > 0 ? 1 : -1);
          setPos({ ...posRef.current });
        }
      }
      raf = requestAnimationFrame(step);
    };
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const resolve = (id: string) => {
    const a = cbRef.current.actions;
    const here = Object.keys(NPCS).find((k) => NPCS[k].room === roomRef.current);
    if (id.startsWith('npc:')) {
      if (here) a.talk(here);
      return;
    }
    a.interact(id);
  };

  const goTo = useCallback(
    (x: number, y: number, pending: string | null) => {
      if (cbRef.current.busy()) return;
      const [x0, y0, x1, y1] = r.walk;
      targetRef.current = {
        x: Math.max(x0, Math.min(x1, x)),
        y: Math.max(y0, Math.min(y1, y)),
      };
      pendingRef.current = pending;
      setWalking(true);
    },
    [r],
  );

  const onFloor = (e: React.MouseEvent) => {
    if (cbRef.current.busy()) return;
    const el = frameRef.current;
    if (!el) return;
    const b = el.getBoundingClientRect();
    goTo(((e.clientX - b.left) / b.width) * 100, ((e.clientY - b.top) / b.height) * 100, null);
  };

  /* keyboard: reveal hotspots + arrow-key walking */
  useEffect(() => {
    const down = (e: KeyboardEvent) => {
      if (e.key === 'Tab') {
        e.preventDefault();
        setReveal(true);
        return;
      }
      const step = 9;
      const map: Record<string, [number, number]> = {
        ArrowLeft: [-step, 0],
        ArrowRight: [step, 0],
        ArrowUp: [0, -step],
        ArrowDown: [0, step],
      };
      const d = map[e.key];
      if (d) {
        e.preventDefault();
        const [x0, y0, x1, y1] = r.walk;
        const from = targetRef.current ?? posRef.current;
        goTo(
          Math.max(x0, Math.min(x1, from.x + d[0])),
          Math.max(y0, Math.min(y1, from.y + d[1])),
          null,
        );
      }
    };
    const up = (e: KeyboardEvent) => {
      if (e.key === 'Tab') setReveal(false);
    };
    window.addEventListener('keydown', down);
    window.addEventListener('keyup', up);
    return () => {
      window.removeEventListener('keydown', down);
      window.removeEventListener('keyup', up);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [goTo]);

  const depthScale = (y: number) => {
    const [fy, fs, ny, ns] = r.depth;
    const t = Math.max(0, Math.min(1, (y - fy) / (ny - fy)));
    return fs + (ns - fs) * t;
  };

  const npcId = Object.keys(NPCS).find((k) => NPCS[k].room === state.room) ?? null;
  const npc = npcId ? NPCS[npcId] : null;

  return (
    <div
      ref={frameRef}
      onClick={onFloor}
      className="duo relative w-full cursor-crosshair select-none"
      style={{ aspectRatio: '16 / 9' }}
    >
      <img src={r.img} alt={r.name} draggable={false} />
      <div className="duo-tint" />
      <div className="duo-lift" />
      <div className="duo-quant" />

      {/* hotspots */}
      {r.hotspots.map((h) => {
        const locked = h.kind === 'door' && !!h.requires && !meets(state, h.requires);
        return (
          <button
            key={h.id}
            type="button"
            className={`hs ${reveal ? 'hs-reveal' : ''}`}
            style={{
              left: `${h.rect[0]}%`,
              top: `${h.rect[1]}%`,
              width: `${h.rect[2]}%`,
              height: `${h.rect[3]}%`,
            }}
            onClick={(e) => {
              e.stopPropagation();
              goTo(h.stand[0], h.stand[1], h.id);
            }}
            aria-label={h.label}
          >
            <span className="hs-label">
              {h.label}
              {locked ? ' · locked' : ''}
            </span>
          </button>
        );
      })}

      {/* npc */}
      {npc && (
        <button
          type="button"
          className="absolute z-20 cursor-pointer border border-transparent hover:border-ice/70 hover:bg-ice/10"
          style={{
            left: `${npc.pos[0]}%`,
            top: `${npc.pos[1]}%`,
            height: `${BASE_H * depthScale(npc.pos[1])}%`,
            aspectRatio: '14 / 22',
            transform: 'translate(-50%, -100%)',
          }}
          onClick={(e) => {
            e.stopPropagation();
            const side = pos.x < npc.pos[0] ? -8 : 8;
            goTo(npc.pos[0] + side, npc.pos[1] + 1, `npc:${npc.id}`);
          }}
          aria-label={`Talk to ${npc.name}`}
        >
          <div className="figure-shadow" />
          <Figure
            coat={npc.coat}
            trim={npc.trim}
            skin={npc.skin}
            hat={npc.hat}
            build={npc.build}
            className="h-full w-full"
            facing={pos.x < npc.pos[0] ? 1 : -1}
          />
          <span className="hs-label" style={{ opacity: 1 }}>
            {npc.name}
          </span>
        </button>
      )}

      {/* detective */}
      <div
        className="figure"
        style={{
          left: `${pos.x}%`,
          top: `${pos.y}%`,
          height: `${BASE_H * depthScale(pos.y)}%`,
          aspectRatio: '14 / 22',
          transform: 'translate(-50%, -100%)',
        }}
      >
        <div className="figure-shadow" />
        <div className={walking ? 'bob h-full w-full' : 'h-full w-full'}>
          <Detective walking={walking} facing={facing} className="h-full w-full" />
        </div>
      </div>

      <div className="rain" />
      <div className="rain rain-2" />
      <div className="vignette" />
      <div className="scanlines" />
      <div key={flash} className={flash ? 'flash flash-on' : 'flash'} />
    </div>
  );
}


