interface FigureProps {
  coat: string;
  trim: string;
  skin: string;
  hat: 'none' | 'cap' | 'brim' | 'bun' | 'bowler';
  build: 'tall' | 'slim' | 'broad' | 'petite';
  walking?: boolean;
  facing?: 1 | -1;
  className?: string;
  dark?: boolean;
}

const INK = '#0a1120';

export function Figure({
  coat,
  trim,
  skin,
  hat,
  build,
  walking = false,
  facing = 1,
  className = '',
  dark = false,
}: FigureProps) {
  const sx = build === 'broad' ? 1.14 : build === 'slim' ? 0.9 : 1;
  const coatW = build === 'broad' ? 9 : 8;
  const coatX = build === 'broad' ? 2 : 3;
  const legA = walking ? 1 : 0;
  const legB = walking ? -1 : 0;

  return (
    <svg
      viewBox="0 0 14 22"
      className={className}
      style={{
        transform: `scaleX(${facing * sx})`,
        shapeRendering: 'crispEdges',
        opacity: dark ? 0.5 : 1,
        overflow: 'visible',
      }}
      aria-hidden="true"
    >
      {/* legs + boots */}
      <rect x={4} y={16} width={3} height={5 + legA} fill={INK} />
      <rect x={7} y={16} width={3} height={5 + legB} fill={INK} />
      <rect x={4} y={20} width={3} height={2} fill={INK} />
      <rect x={7} y={20} width={3} height={2} fill={INK} />
      <rect x={4} y={16} width={2} height={4} fill={coat} opacity={0.65} />
      <rect x={8} y={16} width={2} height={4} fill={coat} opacity={0.65} />

      {/* coat */}
      <rect x={coatX} y={7} width={coatW} height={9} fill={coat} />
      <rect x={coatX} y={7} width={2} height={9} fill={INK} opacity={0.35} />
      <rect x={coatX + coatW - 2} y={7} width={2} height={9} fill={INK} opacity={0.16} />
      <rect x={6} y={8} width={1} height={7} fill={INK} opacity={0.4} />

      {/* arms + hands */}
      <rect x={coatX - 1} y={8} width={1} height={6} fill={coat} />
      <rect x={coatX + coatW} y={8} width={1} height={6} fill={coat} />
      <rect x={coatX - 1} y={13} width={1} height={2} fill={skin} />
      <rect x={coatX + coatW} y={13} width={1} height={2} fill={skin} />

      {/* collar */}
      <rect x={coatX} y={6} width={coatW} height={1} fill={trim} />

      {/* head */}
      <rect x={4} y={3} width={6} height={4} fill={skin} />
      <rect x={4} y={3} width={6} height={1} fill={INK} opacity={0.22} />
      <rect x={5} y={5} width={1} height={1} fill={INK} />
      <rect x={8} y={5} width={1} height={1} fill={INK} />

      {hat === 'brim' && (
        <>
          <rect x={2} y={2} width={10} height={1} fill={INK} />
          <rect x={4} y={0} width={6} height={2} fill={coat} />
          <rect x={4} y={1} width={6} height={1} fill={trim} />
        </>
      )}
      {hat === 'cap' && (
        <>
          <rect x={3} y={2} width={8} height={1} fill={INK} />
          <rect x={4} y={0} width={6} height={2} fill={coat} />
          <rect x={10} y={2} width={2} height={1} fill={INK} />
        </>
      )}
      {hat === 'bowler' && (
        <>
          <rect x={2} y={2} width={10} height={1} fill={INK} />
          <rect x={4} y={0} width={6} height={2} fill={INK} />
          <rect x={4} y={1} width={6} height={1} fill={coat} opacity={0.85} />
        </>
      )}
      {hat === 'bun' && (
        <>
          <rect x={3} y={1} width={8} height={2} fill={coat} />
          <rect x={2} y={1} width={2} height={3} fill={coat} />
          <rect x={10} y={1} width={2} height={3} fill={coat} />
        </>
      )}
      {hat === 'none' && <rect x={3} y={1} width={8} height={2} fill={coat} />}
    </svg>
  );
}

export function Detective({ walking, facing, className }: { walking?: boolean; facing?: 1 | -1; className?: string }) {
  return (
    <Figure
      coat="#41597d"
      trim="#cfe3f2"
      skin="#dce9f6"
      hat="brim"
      build="tall"
      walking={walking}
      facing={facing}
      className={className}
    />
  );
}
