import { useEffect } from 'react';
import { useGame } from './game/useGame';
import { ROOMS } from './game/rooms';
import { CLUES } from './game/casefile';
import { nextHint, proof } from './game/engine';
import { Scene } from './components/Scene';
import { TitleScreen } from './components/Title';
import { SignalBand } from './components/SignalBand';
import {
  AccusePanel,
  CaseFile,
  ChoicePanel,
  EndingScreen,
  ExaminePanel,
  HeldBanner,
  Inventory,
  Overlay,
  TalkPanel,
} from './components/Panels';

export default function App() {
  const { state, actions, busy } = useGame();
  const r = ROOMS[state.room];
  const total = CLUES.reduce((t, c) => t + c.weight, 0);
  const p = proof(state);

  useEffect(() => {
    const k = (e: KeyboardEvent) => {
      if (busy()) return;
      if (e.key === 'j' || e.key === 'J') actions.open('casefile');
      if (e.key === 'i' || e.key === 'I') actions.open('help');
    };
    window.addEventListener('keydown', k);
    return () => window.removeEventListener('keydown', k);
  }, [actions, busy]);

  if (state.screen === 'title') {
    return (
      <div className="flex h-full items-center justify-center bg-[#070c15] p-2 sm:p-5">
        <div className="w-full max-w-[1180px]">
          <TitleScreen onStart={actions.start} />
        </div>
      </div>
    );
  }

  if (state.screen === 'ending') {
    return (
      <div className="h-full overflow-y-auto bg-[#070c15]">
        <EndingScreen state={state} onRestart={actions.restart} />
      </div>
    );
  }

  const last = state.log.slice(-3);

  return (
    <div className="flex min-h-full flex-col items-center justify-center gap-2 overflow-y-auto bg-[#070c15] p-2 sm:p-4">
      <div className="my-auto w-full max-w-[1180px]">
        {/* header */}
        <header className="mb-2 flex flex-wrap items-end justify-between gap-2 border-b border-slate-line pb-2">
          <div>
            <h1 className="font-pixel text-[13px] tracking-[0.18em] text-ice">{r.name.toUpperCase()}</h1>
            <p className="font-term text-[15px] text-ice-faint">{r.sub}</p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <span className="font-term text-[15px] text-ice-dim">
              proof {p}/{total}
            </span>
            <button className="btn" onClick={() => actions.open('casefile')}>
              Case file ({state.clues.length}/{CLUES.length})
            </button>
            <button className="btn" onClick={() => actions.open('help')}>
              How to play
            </button>
            <button className="btn btn-hot" onClick={() => actions.open('accuse')}>
              Accuse
            </button>
          </div>
        </header>

        {/* scene + overlays */}
        <div className="relative">
          <Scene state={state} actions={actions} busy={busy} />

          {state.examine && (
            <ExaminePanel state={state} onAction={actions.action} onClose={actions.close} />
          )}
          {state.talk && (
            <TalkPanel
              state={state}
              onAsk={actions.ask}
              onPress={actions.press}
              onClose={actions.close}
            />
          )}
          {state.choice && (
            <ChoicePanel state={state} onResolve={actions.resolve} onClose={actions.close} />
          )}
          {state.minigame === 'band' && (
            <div className="absolute inset-0 z-50 flex items-center justify-center bg-slate-ink/80 p-3 backdrop-blur-[2px]">
              <SignalBand onDone={actions.minigameDone} onAbort={actions.close} />
            </div>
          )}
          {state.panel === 'casefile' && (
            <CaseFile state={state} onAccuse={() => actions.open('accuse')} onClose={actions.close} />
          )}
          {state.panel === 'accuse' && (
            <AccusePanel state={state} onAccuse={actions.accuse} onClose={actions.close} />
          )}
          {state.panel === 'help' && (
            <Overlay onClose={actions.close} wide>
              <div className="border-b border-slate-line px-4 py-2">
                <h2 className="font-pixel text-[12px] tracking-widest text-ice">HOW TO PLAY</h2>
              </div>
              <div className="max-h-[56vh] overflow-y-auto scroll-thin px-4 py-3 font-term text-[17px] leading-snug text-ice-dim">
                <p className="mb-2">
                  <span className="text-ice">Click the floor</span> to walk. Click a thing, a door, or
                  a person to walk over and deal with it. Hold <span className="text-ice">TAB</span>{' '}
                  to outline every hotspot in the room.
                </p>
                <p className="mb-2">
                  <span className="text-ice">Inventory</span> is the strip under the scene. Click an
                  item to pick it up, then click a thing in the room to use it. Click a second item to
                  combine the two.
                </p>
                <p className="mb-2">
                  <span className="text-ice">People</span> answer questions. Pushing them changes how
                  much they trust you — trust opens doors that keys do not.
                </p>
                <p className="mb-2">
                  <span className="text-ice">Locked rooms</span> need clues as much as keys. The cellar
                  needs a brass key and a lit lantern. The medicine cabinet needs a combination that
                  only a doctor will give you.
                </p>
                <p className="mb-2">
                  <span className="text-ice">The receiver</span> must be spliced with the spare coil
                  before the band will drift. Drag the knob onto the drifting band and hold it.
                </p>
                <p className="mb-2">
                  <span className="text-ice">Two decisions cannot be undone</span> — what you do with
                  the ledger page, and what you do with the band. Together with the name you finally
                  say, they decide which of three endings you get.
                </p>
                <p>
                  Keys: <span className="text-ice">TAB</span> reveal hotspots ·{' '}
                  <span className="text-ice">J</span> case file · <span className="text-ice">I</span>{' '}
                  this page · <span className="text-ice">ESC</span> close.
                </p>
              </div>
            </Overlay>
          )}
        </div>

        {/* footer */}
        <div className="mt-2 grid gap-2 lg:grid-cols-[1fr_auto]">
          <div className="panel px-3 py-2">
            <p className="mb-1 flex items-baseline gap-2">
              <span className="font-pixel text-[9px] tracking-widest text-ice-faint">NARRATION</span>
              <span className="font-term text-[15px] text-ice-dim">
                <span className="text-ice">next:</span> {nextHint(state)}
              </span>
            </p>
            <div className="space-y-0.5">
              {last.map((l, i) => (
                <p
                  key={`${state.turn}-${i}`}
                  className="font-term text-[16px] leading-snug"
                  style={{ color: i === last.length - 1 ? '#cfe3f2' : '#6d87a4' }}
                >
                  {l}
                </p>
              ))}
            </div>
          </div>
          <div className="panel px-3 py-2">
            <p className="mb-1 font-pixel text-[9px] tracking-widest text-ice-faint">POCKETS</p>
            <Inventory state={state} onHold={actions.hold} onCombine={actions.combine} />
            <div className="mt-2">
              <HeldBanner state={state} onClear={() => actions.hold(null)} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
