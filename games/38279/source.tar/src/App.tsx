import { useCallback, useEffect, useRef, useState, type ReactNode } from "react";
import Arsenal from "@/components/Arsenal";
import Backdrop from "@/components/Backdrop";
import CardView, { type CardVisual } from "@/components/CardView";
import { Journal, TopBar, type LogLine } from "@/components/Hud";
import PixelSprite from "@/components/PixelSprite";
import {
  DECK_SIZE,
  HAND_SIZE,
  MAX_HEARTS,
  RESOLVE_PER_ROOM,
  TOTAL_ROOMS,
  buildDeck,
  canStrike,
  type CardInst,
  type Weapon,
} from "@/game/cards";

/* ---------------- fixed-camera stage ---------------- */
const STAGE_W = 1280;
const STAGE_H = 720;
const CARD_W = 150;
const CARD_H = 196;
const CARD_GAP = 26;
const ROW_W = 4 * CARD_W + 3 * CARD_GAP;
const ROW_X = (STAGE_W - ROW_W) / 2;
const ROW_Y = 372;
const TABLE = { x: 250, y: 298, w: 780, h: 302 };
/** Card row position relative to the table's top-left corner. */
const ROW_OFF_X = ROW_X - TABLE.x;
const ROW_OFF_Y = ROW_Y - TABLE.y;

type Phase = "title" | "play" | "transition" | "dying" | "won" | "lost";

interface State {
  deck: CardInst[];
  hand: CardInst[];
  resolved: number;
  hearts: number;
  arsenal: Weapon[];
  room: number;
  charm: number;
  phase: Phase;
  target: string | null;
  pendingWhetstone: boolean;
  carriedUid: string | null;
  kills: number;
  bareStrikes: number;
  log: LogLine[];
  logSeq: number;
  banner: string | null;
  /** uids that just slid onto the table (entrance animation) */
  newIds: string[];
  /** bumped on every new run so entrance animations replay */
  runId: number;
}

interface Floater {
  id: number;
  text: string;
  color: string;
  x: number;
  y: number;
}

function pushLog(s: State, text: string, tone: LogLine["tone"]): State {
  return { ...s, log: [{ id: s.logSeq, text, tone }, ...s.log].slice(0, 24), logSeq: s.logSeq + 1 };
}

function newGame(): State {
  const deck = buildDeck();
  const hand = deck.slice(0, HAND_SIZE);
  return {
    deck: deck.slice(HAND_SIZE),
    hand,
    resolved: 0,
    hearts: MAX_HEARTS,
    arsenal: [],
    room: 1,
    charm: 0,
    phase: "play",
    target: null,
    pendingWhetstone: false,
    carriedUid: null,
    kills: 0,
    bareStrikes: 0,
    log: [
      { id: 0, text: "Four cards hit the table. Resolve three, carry one.", tone: "info" },
    ],
    logSeq: 1,
    banner: "DEPTH 1",
    newIds: hand.map((c) => c.uid),
    runId: 0,
  };
}

function advanceRoom(s: State): State {
  if (s.hearts <= 0) return { ...s, phase: "dying", banner: "YOU FALL" };
  const carried = s.hand[0] ?? null;
  if (s.deck.length === 0) {
    return { ...s, phase: "won", carriedUid: carried?.uid ?? null, banner: "THE DECK IS EMPTY" };
  }
  const draw = s.deck.slice(0, RESOLVE_PER_ROOM);
  let ns: State = {
    ...s,
    deck: s.deck.slice(RESOLVE_PER_ROOM),
    hand: carried ? [carried, ...draw] : draw,
    room: s.room + 1,
    resolved: 0,
    target: null,
    pendingWhetstone: false,
    carriedUid: carried?.uid ?? null,
    phase: "transition",
    banner: `DEPTH ${s.room + 1}`,
    newIds: draw.map((c) => c.uid),
  };
  ns = pushLog(
    ns,
    carried ? `Carried over: ${carried.def.name}.` : "Nothing carried over.",
    "warn",
  );
  return ns;
}

function useStageScale() {
  const [scale, setScale] = useState(1);
  useEffect(() => {
    const fit = () =>
      setScale(Math.min(window.innerWidth / STAGE_W, window.innerHeight / STAGE_H));
    fit();
    window.addEventListener("resize", fit);
    return () => window.removeEventListener("resize", fit);
  }, []);
  return scale;
}

export default function App() {
  const scale = useStageScale();
  const [state, setState] = useState<State>(() => ({ ...newGame(), phase: "title" }));
  const [strikeFx, setStrikeFx] = useState<{
    weapon: string;
    weaponUid: string;
    card: string;
    kind: "kill" | "bare";
  } | null>(null);
  const [shaking, setShaking] = useState(false);
  const [floaters, setFloaters] = useState<Floater[]>([]);
  const [showRules, setShowRules] = useState(false);
  const seq = useRef(1);
  const runs = useRef(0);
  const timers = useRef<number[]>([]);

  const later = useCallback((fn: () => void, ms: number) => {
    timers.current.push(window.setTimeout(fn, ms));
  }, []);

  useEffect(() => () => timers.current.forEach((t) => window.clearTimeout(t)), []);

  /* room transition */
  useEffect(() => {
    if (state.phase !== "transition") return;
    const t = window.setTimeout(
      () => setState((s) => ({ ...s, phase: "play", banner: null, newIds: [] })),
      1150,
    );
    return () => window.clearTimeout(t);
  }, [state.phase, state.room]);

  /* clear the entrance-animation flag once cards have landed */
  useEffect(() => {
    if (state.phase !== "play" || state.newIds.length === 0) return;
    const t = window.setTimeout(() => setState((s) => ({ ...s, newIds: [] })), 700);
    return () => window.clearTimeout(t);
  }, [state.phase, state.newIds]);

  /* death beat */
  useEffect(() => {
    if (state.phase !== "dying") return;
    const t = window.setTimeout(() => setState((s) => ({ ...s, phase: "lost" })), 950);
    return () => window.clearTimeout(t);
  }, [state.phase]);

  const addFloater = useCallback(
    (cardUid: string, text: string, color: string) => {
      const idx = state.hand.findIndex((c) => c.uid === cardUid);
      const id = seq.current++;
      const x = ROW_X + Math.max(0, idx) * (CARD_W + CARD_GAP) + CARD_W / 2;
      setFloaters((f) => [...f, { id, text, color, x, y: ROW_Y - 4 }]);
      timers.current.push(
        window.setTimeout(() => setFloaters((f) => f.filter((fl) => fl.id !== id)), 950),
      );
    },
    [state.hand],
  );

  /** Apply an immediate effect, mark the card spent, then sweep the table. */
  const finishCard = useCallback(
    (uid: string, apply: (s: State) => State) => {
      setState((s) => {
        const ns = apply(s);
        return { ...ns, hand: ns.hand.map((c) => (c.uid === uid ? { ...c, spent: true } : c)) };
      });
      later(() => {
        setState((s) => {
          let ns: State = {
            ...s,
            hand: s.hand.filter((c) => c.uid !== uid),
            resolved: s.resolved + 1,
            target: s.target === uid ? null : s.target,
          };
          if (ns.hearts <= 0) ns = { ...ns, phase: "dying", banner: "YOU FALL" };
          else if (ns.resolved >= RESOLVE_PER_ROOM) ns = advanceRoom(ns);
          return ns;
        });
      }, 430);
    },
    [later],
  );

  const spentCount = state.hand.filter((c) => c.spent).length;
  const busy = state.resolved + spentCount >= RESOLVE_PER_ROOM;
  const interactive = state.phase === "play" && !busy;

  const targetCard = state.hand.find((c) => c.uid === state.target) ?? null;
  const targetValue = targetCard?.def.kind === "monster" ? targetCard.def.value : null;

  /* ---------------- actions ---------------- */
  const clickCard = (uid: string) => {
    if (!interactive) return;
    const card = state.hand.find((c) => c.uid === uid);
    if (!card || card.spent) return;

    if (card.def.kind === "monster") {
      setState((s) => ({ ...s, target: s.target === uid ? null : uid }));
      return;
    }

    if (card.def.kind === "weapon") {
      const w: Weapon = {
        uid: `w_${card.uid}`,
        name: card.def.name,
        sprite: card.def.sprite,
        strength: card.def.value,
        ceiling: card.def.value + 1,
        kills: 0,
      };
      finishCard(uid, (s) =>
        pushLog({ ...s, arsenal: [...s.arsenal, w] }, `Took up ${w.name} — reaches below ${w.ceiling}.`, "good"),
      );
      return;
    }

    if (card.def.item === "salve") {
      finishCard(uid, (s) => {
        const healed = Math.min(MAX_HEARTS, s.hearts + 5);
        return pushLog({ ...s, hearts: healed }, `Salve: +${healed - s.hearts} hearts.`, "good");
      });
      return;
    }

    if (card.def.item === "whetstone") {
      if (state.arsenal.length === 0) {
        finishCard(uid, (s) => pushLog(s, "Whetstone wasted — nothing to sharpen.", "warn"));
        return;
      }
      finishCard(uid, (s) =>
        pushLog({ ...s, pendingWhetstone: true }, "Whetstone ready: click a weapon to sharpen it.", "warn"),
      );
      return;
    }

    finishCard(uid, (s) =>
      pushLog({ ...s, charm: s.charm + 1 }, "Charm bound — your next bare-handed blow is free.", "good"),
    );
  };

  const strike = (weaponUid: string) => {
    if (!interactive || !targetCard || targetCard.def.kind !== "monster") return;
    const w = state.arsenal.find((a) => a.uid === weaponUid);
    if (!w) return;
    if (!canStrike(w, targetCard.def.value)) {
      setState((s) =>
        pushLog(
          s,
          `${w.name} reaches below ${w.ceiling} — not enough for ${targetCard.def.name} (${targetCard.def.value}).`,
          "warn",
        ),
      );
      return;
    }
    setStrikeFx({ weapon: w.sprite, weaponUid: w.uid, card: targetCard.uid, kind: "kill" });
    later(() => setStrikeFx(null), 360);
    addFloater(targetCard.uid, "SLAIN", "#5fbf5f");
    finishCard(targetCard.uid, (s) => {
      let ns: State = {
        ...s,
        kills: s.kills + 1,
        arsenal: s.arsenal.map((a) =>
          a.uid === weaponUid ? { ...a, ceiling: targetCard.def.value, kills: a.kills + 1 } : a,
        ),
      };
      ns = pushLog(
        ns,
        `${w.name} fells ${targetCard.def.name} (${targetCard.def.value}). It now reaches below ${targetCard.def.value}.`,
        "kill",
      );
      return ns;
    });
  };

  const bareHands = () => {
    if (!interactive || !targetCard || targetCard.def.kind !== "monster") return;
    const v = targetCard.def.value;
    const free = state.charm > 0;
    const dmg = free ? 0 : v;
    setStrikeFx({ weapon: "fist", weaponUid: "fist", card: targetCard.uid, kind: "bare" });
    later(() => setStrikeFx(null), 360);
    addFloater(targetCard.uid, free ? "CHARMED" : `-${dmg}`, free ? "#6ae0d0" : "#e05a4a");
    if (!free) {
      setShaking(true);
      timers.current.push(window.setTimeout(() => setShaking(false), 360));
    }
    finishCard(targetCard.uid, (s) => {
      let ns: State = {
        ...s,
        hearts: s.hearts - dmg,
        charm: free ? s.charm - 1 : s.charm,
        bareStrikes: s.bareStrikes + 1,
      };
      ns = pushLog(
        ns,
        free
          ? `The charm drinks the ${targetCard.def.name}.`
          : `Bare hands vs ${targetCard.def.name}: -${dmg} hearts.`,
        free ? "good" : "hurt",
      );
      return ns;
    });
  };

  const sharpen = (weaponUid: string) => {
    const w = state.arsenal.find((a) => a.uid === weaponUid);
    if (!w) return;
    setState((s) => {
      let ns: State = {
        ...s,
        pendingWhetstone: false,
        arsenal: s.arsenal.map((a) => (a.uid === weaponUid ? { ...a, ceiling: a.ceiling + 3 } : a)),
      };
      ns = pushLog(ns, `Whetstone: ${w.name} now reaches below ${w.ceiling + 3}.`, "good");
      return ns;
    });
  };

  const start = () => {
    timers.current.forEach((t) => window.clearTimeout(t));
    timers.current = [];
    setFloaters([]);
    setStrikeFx(null);
    setShowRules(false);
    setShaking(false);
    setState({ ...newGame(), phase: "play", runId: ++runs.current });
  };

  const resolvedTotal = DECK_SIZE - state.deck.length - state.hand.filter((c) => !c.spent).length;
  const remaining = state.hand.filter((c) => !c.spent).length;

  /* ---------------- render ---------------- */
  return (
    <div className="flex h-full w-full items-center justify-center overflow-hidden bg-[#08070c]">
      <div
        className="relative shrink-0 overflow-hidden bg-ink"
        style={{
          width: STAGE_W,
          height: STAGE_H,
          transform: `scale(${scale})`,
          transformOrigin: "center center",
        }}
      >
        <div className={shaking ? "anim-shake absolute inset-0" : "absolute inset-0"}>
          <Backdrop />

          {/* ---------------- card table ---------------- */}
          <div
            className="absolute"
            style={{
              left: TABLE.x,
              top: TABLE.y,
              width: TABLE.w,
              height: TABLE.h,
              background:
                "repeating-linear-gradient(180deg, rgba(0,0,0,0.13) 0 2px, rgba(255,255,255,0.03) 2px 4px, transparent 4px 9px), linear-gradient(180deg,#7a5a3c 0%,#5c4229 60%,#4a3524 100%)",
              boxShadow:
                "0 0 0 3px #100e17, inset 0 0 0 3px rgba(138,106,74,0.55), 0 10px 0 0 rgba(0,0,0,0.5)",
            }}
          >
            {/* felt / leather surface */}
            <div
              className="absolute"
              style={{
                left: 14,
                top: 14,
                right: 14,
                bottom: 26,
                background:
                  "radial-gradient(ellipse at 50% 34%, #3b2c40 0%, #241a2c 52%, #171120 100%)",
                boxShadow: "inset 0 0 0 3px #100e17, inset 0 0 0 5px rgba(200,212,220,0.10)",
              }}
            />
            {/* rivets */}
            {[
              [8, 8],
              [TABLE.w - 16, 8],
              [8, TABLE.h - 22],
              [TABLE.w - 16, TABLE.h - 22],
            ].map(([x, y], i) => (
              <div
                key={i}
                className="absolute h-[8px] w-[8px]"
                style={{ left: x, top: y, background: "#c8d4dc", boxShadow: "0 0 0 2px #100e17" }}
              />
            ))}

            {/* discard pile */}
            <div className="absolute" style={{ left: 22, top: 20, width: 30, height: 44 }}>
              {[3, 2, 1, 0].map((i) => (
                <div
                  key={i}
                  className="absolute px-card"
                  style={{ left: i * 2, top: i * 2, width: 24, height: 34, opacity: 0.9 }}
                />
              ))}
              <div className="absolute inset-0 flex items-center justify-center font-pixel text-[7px] text-bone">
                {resolvedTotal}
              </div>
              <div className="absolute -bottom-[11px] left-0 w-full text-center font-pixel text-[5px] text-wood3">
                SPENT
              </div>
            </div>

            {/* table label */}
            <div className="absolute bottom-[6px] left-0 right-0 text-center font-pixel text-[7px] tracking-widest text-wood3/80">
              {`RESOLVE ${RESOLVE_PER_ROOM} · CARRY 1 · ${DECK_SIZE - resolvedTotal}/${DECK_SIZE} CARDS LEFT`}
            </div>

            {/* cards */}
            <div
              className="absolute flex items-start"
              style={{ left: ROW_OFF_X, top: ROW_OFF_Y }}
            >
              {state.hand.map((card, i) => {
                const isCarried = state.carriedUid === card.uid && state.room > 1;
                const visual: CardVisual = card.spent
                  ? "spent"
                  : state.target === card.uid
                    ? "targeted"
                    : isCarried
                      ? "carried"
                      : state.newIds.includes(card.uid)
                        ? "drawn"
                        : "idle";
                const hint =
                  remaining === 1 && !card.spent
                    ? "CARRIES OVER"
                    : card.def.kind === "monster"
                      ? state.target === card.uid
                        ? "PICK A WEAPON BELOW"
                        : "CLICK TO TARGET"
                      : card.def.kind === "weapon"
                        ? "TAKE IT UP"
                        : "USE IT";
                return (
                  <div key={card.uid} className="relative" style={{ width: CARD_W, height: CARD_H }}>
                    <CardView
                      card={card}
                      visual={visual}
                      index={i}
                      onClick={() => clickCard(card.uid)}
                      disabled={!interactive}
                      hint={hint}
                      fx={
                        strikeFx && strikeFx.card === card.uid
                          ? strikeFx.kind
                          : null
                      }
                    />
                    {isCarried ? (
                      <div className="pointer-events-none absolute -bottom-[22px] left-1/2 -translate-x-1/2 whitespace-nowrap bg-arcane2 px-[5px] py-[2px] font-pixel text-[6px] text-bone">
                        CARRIES OVER
                      </div>
                    ) : null}
                  </div>
                );
              })}
              {state.hand.length < 4 ? (
                Array.from({ length: 4 - state.hand.length }, (_, i) => (
                  <div key={`empty${i}`} style={{ width: CARD_W, height: CARD_H }} />
                ))
              ) : null}
            </div>

            {/* strike flourish */}
            {strikeFx ? (
              <div
                className="pointer-events-none absolute"
                style={{
                  left:
                    ROW_OFF_X +
                    (state.hand.findIndex((c) => c.uid === strikeFx.card) || 0) *
                      (CARD_W + CARD_GAP),
                  top: ROW_OFF_Y + 56,
                }}
              >
                <div className="anim-slash">
                  <PixelSprite
                    sprite={strikeFx.weapon}
                    scale={4}
                    style={{ filter: "drop-shadow(0 0 6px rgba(255,208,106,0.8))" }}
                  />
                </div>
              </div>
            ) : null}
          </div>

          {/* ---------------- top bar + journal ---------------- */}
          <TopBar
            hearts={state.hearts}
            room={state.room}
            resolved={state.resolved + spentCount}
            deckCount={state.deck.length}
            carried={state.carriedUid}
          />
          <Journal lines={state.log} />

          {/* ---------------- prompts ---------------- */}
          {state.pendingWhetstone ? (
            <div className="pointer-events-none absolute bottom-[124px] left-1/2 -translate-x-1/2 bg-ink px-[14px] py-[7px] font-pixel text-[9px] text-gold" style={{ boxShadow: "0 0 0 3px #100e17, 0 0 0 6px rgba(247,210,74,0.22)" }}>
              WHETSTONE READY — CLICK A WEAPON TO SHARPEN IT
            </div>
          ) : null}
          {state.target && !state.pendingWhetstone ? (
            <div className="pointer-events-none absolute bottom-[124px] left-1/2 -translate-x-1/2 bg-ink px-[14px] py-[7px] font-pixel text-[9px] text-bone" style={{ boxShadow: "0 0 0 3px #100e17, 0 0 0 6px rgba(224,90,74,0.22)" }}>
              {targetValue !== null
                ? `STRIKE THE ${targetCard?.def.name.toUpperCase()} (${targetValue}) — PICK A WEAPON OR GO BARE-HANDED`
                : "PICK A MONSTER"}
            </div>
          ) : null}

          {/* ---------------- arsenal ---------------- */}
          <Arsenal
            arsenal={state.arsenal}
            targetValue={targetValue}
            pendingWhetstone={state.pendingWhetstone}
            charm={state.charm}
            strikeUid={strikeFx?.weaponUid ?? null}
            onStrike={strike}
            onSharpen={sharpen}
            onBareHands={bareHands}
            bareHandsDisabled={!interactive || targetValue === null}
          />

          {/* ---------------- floaters ---------------- */}
          {floaters.map((f) => (
            <div
              key={f.id}
              className="anim-float pointer-events-none absolute font-pixel text-[16px]"
              style={{ left: f.x, top: f.y, color: f.color, textShadow: "0 3px 0 #100e17" }}
            >
              {f.text}
            </div>
          ))}

          {/* ---------------- depth banner ---------------- */}
          {state.banner && state.phase !== "won" && state.phase !== "lost" ? (
            <div
              key={`${state.runId}-${state.banner}-${state.room}`}
              className="anim-banner pointer-events-none absolute left-1/2 top-[188px] -translate-x-1/2 whitespace-nowrap bg-ink px-[22px] py-[10px] font-pixel text-[20px] text-gold"
              style={{ boxShadow: "0 0 0 3px #100e17, 0 0 0 6px rgba(247,210,74,0.25)" }}
            >
              {state.banner}
            </div>
          ) : null}

          {/* ---------------- title ---------------- */}
          {state.phase === "title" ? (
            <Overlay>
              <div className="px-panel w-[720px] px-[34px] py-[30px] text-center">
                <div className="flex items-center justify-center gap-[14px]">
                  <PixelSprite sprite="torch" scale={3} className="anim-flicker" />
                  <h1 className="font-pixel text-[26px] leading-[34px] text-gold">
                    EMPTIER
                    <br />
                    OF THE DECK
                  </h1>
                  <PixelSprite sprite="torch" scale={3} className="anim-flicker-2" />
                </div>
                <p className="mt-[18px] font-ui text-[13px] leading-[18px] text-steel2">
                  A pixel dungeon of cards. Empty all {DECK_SIZE} cards from the table to escape.
                </p>
                <div className="mt-[20px] grid grid-cols-3 gap-[12px] text-left">
                  <Rule title="THE ROOM" body="Four cards. Resolve three. The fourth carries into the next room." />
                  <Rule title="THE WEAPON" body="A weapon that fells value X may only strike monsters below X." />
                  <Rule title="BARE HANDS" body="No weapon that reaches? You lose the monster's full value from 20 hearts." />
                </div>
                <div className="mt-[24px] flex items-center justify-center gap-[14px]">
                  <button
                    type="button"
                    onClick={start}
                    className="px-btn px-btn-gold px-[26px] py-[12px] font-pixel text-[13px] text-ink"
                  >
                    DESCEND
                  </button>
                  <button
                    type="button"
                    onClick={() => setShowRules((v) => !v)}
                    className="px-btn px-[18px] py-[12px] font-pixel text-[10px] text-bone"
                  >
                    {showRules ? "HIDE RULES" : "HOW TO PLAY"}
                  </button>
                </div>
                {showRules ? (
                  <div className="mt-[20px] border-t-[3px] border-ink pt-[16px] text-left font-ui text-[12px] leading-[17px] text-steel2">
                    <p>
                      <span className="text-gold">CLICK A MONSTER</span> to mark it, then click a weapon in
                      your arsenal to strike. Weapons show their reach as{" "}
                      <span className="text-moss">&lt;N</span> — they can only fell monsters with a value
                      strictly below N.
                    </p>
                    <p className="mt-[8px]">
                      <span className="text-gold">FELLING A MONSTER</span> of value X drops that weapon's
                      reach to below X. Save your heavy steel for the heavy things.
                    </p>
                    <p className="mt-[8px]">
                      <span className="text-gold">RELICS</span>: Salve restores 5 hearts. Whetstone adds +3
                      reach to a weapon. Charm makes your next bare-handed blow free.
                    </p>
                    <p className="mt-[8px]">
                      <span className="text-gold">THE CARRY</span> is your only planning tool — hold a monster
                      back until a better weapon lands on the table.
                    </p>
                  </div>
                ) : null}
              </div>
            </Overlay>
          ) : null}

          {/* ---------------- end screens ---------------- */}
          {state.phase === "won" || state.phase === "lost" ? (
            <Overlay>
              <div className="px-panel w-[600px] px-[34px] py-[30px] text-center">
                <h2
                  className="font-pixel text-[22px]"
                  style={{ color: state.phase === "won" ? "#f7d24a" : "#e05a4a" }}
                >
                  {state.phase === "won" ? "THE DECK IS EMPTY" : "YOU FALL"}
                </h2>
                <p className="mt-[14px] font-ui text-[13px] leading-[18px] text-steel2">
                  {state.phase === "won"
                    ? `You emptied all ${DECK_SIZE} cards and walked out of depth ${TOTAL_ROOMS} with ${Math.max(0, state.hearts)} hearts.`
                    : `The dungeon took you at depth ${state.room}. ${Math.max(0, state.hearts)} hearts left.`}
                </p>
                <div className="mt-[20px] grid grid-cols-2 gap-[10px]">
                  <Stat label="SLAIN WITH STEEL" value={state.kills} />
                  <Stat label="BARE-HANDED" value={state.bareStrikes} />
                  <Stat label="HEARTS LEFT" value={Math.max(0, state.hearts)} />
                  <Stat label="WEAPONS HELD" value={state.arsenal.length} />
                </div>
                <button
                  type="button"
                  onClick={start}
                  className="px-btn px-btn-gold mt-[24px] px-[26px] py-[12px] font-pixel text-[13px] text-ink"
                >
                  SHUFFLE AGAIN
                </button>
              </div>
            </Overlay>
          ) : null}
        </div>

        {/* CRT scanlines */}
        <div
          className="pointer-events-none absolute inset-0 z-[60]"
          style={{
            background:
              "repeating-linear-gradient(180deg, rgba(0,0,0,0.16) 0 1px, rgba(0,0,0,0) 1px 3px)",
          }}
        />
      </div>
    </div>
  );
}

function Overlay({ children }: { children: ReactNode }) {
  return (
    <div className="absolute inset-0 z-40 flex items-center justify-center bg-[#08070c]/82">
      {children}
    </div>
  );
}

function Rule({ title, body }: { title: string; body: string }) {
  return (
    <div className="border-[3px] border-ink bg-ink2/70 px-[10px] py-[10px]">
      <div className="font-pixel text-[7px] text-gold">{title}</div>
      <div className="mt-[7px] font-ui text-[11px] leading-[15px] text-steel2">{body}</div>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: number }) {
  return (
    <div className="border-[3px] border-ink bg-ink2/70 px-[10px] py-[10px]">
      <div className="font-pixel text-[6px] text-steel2">{label}</div>
      <div className="mt-[6px] font-pixel text-[16px] text-bone">{value}</div>
    </div>
  );
}
