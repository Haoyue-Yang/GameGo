/**
 * Fixed-camera backdrop: a muted pixel dungeon corridor receding to a
 * vanishing point, drawn entirely from SVG rects so it stays crisp and
 * needs no external assets.
 */

const FAR_Y = 250;
const NEAR_Y = 720;
const FAR_HW = 62;
const NEAR_HW = 720;
const CX = 640;

const H_SEAMS = Array.from({ length: 15 }, (_, i) => {
  const t = (i + 1) / 16;
  return FAR_Y + (NEAR_Y - FAR_Y) * Math.pow(t, 1.85);
});

const V_SEAMS = Array.from({ length: 17 }, (_, i) => {
  const j = i - 8;
  return {
    xFar: CX + j * (FAR_HW / 8),
    xNear: CX + j * (NEAR_HW / 8),
  };
});

const TORCHES = [
  { x: 268, y: 196, s: 4, cls: "anim-flicker" },
  { x: 1004, y: 196, s: 4, cls: "anim-flicker-2" },
  { x: 96, y: 356, s: 5, cls: "anim-flicker-2" },
  { x: 1176, y: 356, s: 5, cls: "anim-flicker" },
];

export default function Backdrop() {
  return (
    <svg
      width={1280}
      height={720}
      viewBox="0 0 1280 720"
      className="absolute inset-0"
      aria-hidden="true"
      focusable="false"
    >
      <defs>
        <pattern id="wallBrick" width="40" height="20" patternUnits="userSpaceOnUse">
          <rect width="40" height="20" fill="#171325" />
          <rect y="0" width="40" height="3" fill="#0e0c15" />
          <rect y="10" width="40" height="3" fill="#0e0c15" />
          <rect x="0" y="3" width="3" height="7" fill="#0e0c15" />
          <rect x="20" y="13" width="3" height="7" fill="#0e0c15" />
          <rect x="3" y="3" width="17" height="7" fill="#1e1930" />
          <rect x="23" y="13" width="17" height="7" fill="#1e1930" />
          <rect x="3" y="3" width="17" height="2" fill="#262038" />
        </pattern>

        <pattern id="floorBrick" width="48" height="24" patternUnits="userSpaceOnUse">
          <rect width="48" height="24" fill="#221c33" />
          <rect y="0" width="48" height="3" fill="#171325" />
          <rect y="12" width="48" height="3" fill="#171325" />
          <rect x="0" y="3" width="3" height="9" fill="#171325" />
          <rect x="24" y="15" width="3" height="9" fill="#171325" />
          <rect x="3" y="3" width="21" height="9" fill="#2b2440" />
          <rect x="27" y="15" width="21" height="9" fill="#2b2440" />
        </pattern>

        <radialGradient id="torchGlow" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="#f7d24a" stopOpacity="0.5" />
          <stop offset="45%" stopColor="#f09a3a" stopOpacity="0.16" />
          <stop offset="100%" stopColor="#f09a3a" stopOpacity="0" />
        </radialGradient>

        <radialGradient id="vignette" cx="50%" cy="46%" r="72%">
          <stop offset="0%" stopColor="#000000" stopOpacity="0.05" />
          <stop offset="55%" stopColor="#000000" stopOpacity="0.42" />
          <stop offset="100%" stopColor="#000000" stopOpacity="0.86" />
        </radialGradient>

        <linearGradient id="farWall" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#0a0810" />
          <stop offset="100%" stopColor="#1c1729" />
        </linearGradient>

        <clipPath id="floorClip">
          <path
            d={`M ${CX - FAR_HW} ${FAR_Y} L ${CX + FAR_HW} ${FAR_Y} L ${CX + NEAR_HW} ${NEAR_Y} L ${
              CX - NEAR_HW
            } ${NEAR_Y} Z`}
          />
        </clipPath>
      </defs>

      {/* stone walls everywhere */}
      <rect width="1280" height="720" fill="url(#wallBrick)" />

      {/* far end of the corridor */}
      <rect x={CX - FAR_HW} y={132} width={FAR_HW * 2} height={FAR_Y - 132} fill="url(#farWall)" />
      <rect x={CX - FAR_HW} y={132} width={FAR_HW * 2} height={4} fill="#0a0810" />
      <rect x={CX - FAR_HW - 8} y={128} width={FAR_HW * 2 + 16} height={6} fill="#241f30" />
      <rect x={CX - FAR_HW - 8} y={128} width={FAR_HW * 2 + 16} height={2} fill="#332c48" />

      {/* the path */}
      <g clipPath="url(#floorClip)">
        <rect x="-80" y={FAR_Y} width="1440" height={NEAR_Y - FAR_Y + 4} fill="url(#floorBrick)" />
        {V_SEAMS.map((s, i) => (
          <line
            key={`v${i}`}
            x1={s.xFar}
            y1={FAR_Y}
            x2={s.xNear}
            y2={NEAR_Y}
            stroke="#171325"
            strokeWidth={2}
          />
        ))}
        {H_SEAMS.map((y, i) => (
          <line
            key={`h${i}`}
            x1={-80}
            y1={y}
            x2={1360}
            y2={y}
            stroke="#171325"
            strokeWidth={2}
          />
        ))}
        {/* faint light pooling near the far door */}
        <rect x={CX - FAR_HW} y={FAR_Y} width={FAR_HW * 2} height="70" fill="#f09a3a" opacity="0.06" />
      </g>

      {/* wall / floor junction */}
      <line
        x1={CX - FAR_HW}
        y1={FAR_Y}
        x2={CX - NEAR_HW}
        y2={NEAR_Y}
        stroke="#0a0810"
        strokeWidth={6}
      />
      <line
        x1={CX + FAR_HW}
        y1={FAR_Y}
        x2={CX + NEAR_HW}
        y2={NEAR_Y}
        stroke="#0a0810"
        strokeWidth={6}
      />
      <line
        x1={CX - FAR_HW}
        y1={FAR_Y - 3}
        x2={CX - NEAR_HW}
        y2={NEAR_Y - 3}
        stroke="#332c48"
        strokeWidth={2}
      />
      <line
        x1={CX + FAR_HW}
        y1={FAR_Y - 3}
        x2={CX + NEAR_HW}
        y2={NEAR_Y - 3}
        stroke="#332c48"
        strokeWidth={2}
      />

      {/* torches */}
      {TORCHES.map((t, i) => (
        <g key={i}>
          <circle
            cx={t.x}
            cy={t.y}
            r={90 * (t.s / 4)}
            fill="url(#torchGlow)"
            className={t.cls}
          />
          <rect x={t.x - 4} y={t.y + 6} width={8} height={26 * (t.s / 4)} fill="#4a3524" />
          <rect x={t.x - 4} y={t.y + 6} width={3} height={26 * (t.s / 4)} fill="#6b4f34" />
          <rect x={t.x - 9} y={t.y - 6} width={18} height={12} fill="#7a8a98" />
          <rect x={t.x - 9} y={t.y - 6} width={18} height={3} fill="#c8d4dc" />
          <g className={t.cls}>
            <rect x={t.x - 5} y={t.y - 18} width={10} height={12} fill="#f09a3a" />
            <rect x={t.x - 3} y={t.y - 24} width={6} height={10} fill="#ffd06a" />
            <rect x={t.x - 1} y={t.y - 30} width={3} height={8} fill="#f7d24a" />
          </g>
        </g>
      ))}

      {/* mute the whole scene */}
      <rect width="1280" height="720" fill="url(#vignette)" />
      <rect width="1280" height="720" fill="#0d0b16" opacity="0.22" />
    </svg>
  );
}
