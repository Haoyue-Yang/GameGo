import { useMemo, type CSSProperties } from "react";
import { SPRITES, runsOf } from "@/game/sprites";

interface Props {
  sprite: string;
  /** Rendered pixel size of one grid cell (px). */
  scale?: number;
  className?: string;
  style?: CSSProperties;
  /** Tint overlay colour, e.g. for a "dead" monster. */
  tint?: string;
  tintOpacity?: number;
}

/**
 * Renders a 16x16 pixel sprite as an SVG made of horizontal colour runs.
 * `shape-rendering: crispEdges` keeps every pixel a hard square.
 */
export default function PixelSprite({
  sprite,
  scale = 4,
  className,
  style,
  tint,
  tintOpacity = 0.6,
}: Props) {
  const rows = SPRITES[sprite] ?? SPRITES.slime;
  const runs = useMemo(() => runsOf(rows), [rows]);
  const w = Math.max(...rows.map((r) => r.length));
  const h = rows.length;
  const size = scale * 16;

  return (
    <svg
      width={size}
      height={size}
      viewBox={`0 0 ${w} ${h}`}
      className={className}
      style={style}
      aria-hidden="true"
      focusable="false"
    >
      {runs.map((r, i) => (
        <rect key={i} x={r.x} y={r.y} width={r.w} height={1} fill={r.c} />
      ))}
      {tint ? <rect x={0} y={0} width={w} height={h} fill={tint} opacity={tintOpacity} /> : null}
    </svg>
  );
}
