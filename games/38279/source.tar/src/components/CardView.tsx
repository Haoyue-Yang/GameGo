import PixelSprite from "./PixelSprite";
import { KIND_LABEL, tierOf, type CardInst } from "@/game/cards";

export type CardVisual = "idle" | "targeted" | "spent" | "carried" | "drawn";

interface Props {
  card: CardInst;
  visual: CardVisual;
  index: number;
  onClick: () => void;
  disabled?: boolean;
  hint?: string;
  /** One-shot combat flourish applied to the card art. */
  fx?: "kill" | "bare" | null;
}

const TIER_RING: Record<string, string> = {
  low: "#5fbf5f",
  mid: "#f09a3a",
  high: "#e05a4a",
  boss: "#a06ad8",
};

export default function CardView({
  card,
  visual,
  index,
  onClick,
  disabled,
  hint,
  fx,
}: Props) {
  const { def } = card;
  const isMonster = def.kind === "monster";
  const isWeapon = def.kind === "weapon";
  const ring = isMonster || isWeapon ? TIER_RING[tierOf(def.value)] : "#6ae0d0";
  const targeted = visual === "targeted";
  const spent = visual === "spent";

  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled || spent}
      aria-label={`${KIND_LABEL[def.kind]}: ${def.name}${
        def.kind !== "item" ? `, value ${def.value}` : ""
      }. ${def.blurb}`}
      className={[
        "px-card group relative block h-[196px] w-[150px] shrink-0 select-none text-left",
        "transition-transform duration-150 ease-out",
        !disabled && !spent ? "hover:-translate-y-2 focus-visible:-translate-y-2" : "",
        spent ? "anim-pop pointer-events-none" : "",
        visual === "drawn" ? "anim-slidein" : "",
        targeted ? "anim-target z-20 -translate-y-3" : "",
      ].join(" ")}
      style={{
        animationDelay: visual === "drawn" ? `${index * 70}ms` : undefined,
        outline: visual === "carried" ? "2px solid #7a8a98" : undefined,
        outlineOffset: 2,
      }}
    >
      {/* kind + value header */}
      <div
        className="flex h-[24px] items-center justify-between px-[6px]"
        style={{ background: "rgba(16,14,23,0.55)" }}
      >
        <span
          className="font-pixel text-[7px] tracking-tight"
          style={{ color: ring }}
        >
          {KIND_LABEL[def.kind]}
        </span>
        {def.kind !== "item" ? (
          <span
            className="flex h-[16px] min-w-[16px] items-center justify-center px-[3px] font-pixel text-[8px] text-ink"
            style={{ background: ring }}
          >
            {def.value}
          </span>
        ) : (
          <span className="font-pixel text-[7px] text-steel2">RELIC</span>
        )}
      </div>

      {/* art window */}
      <div className="relative mt-[6px] flex h-[92px] w-full items-center justify-center">
        <div
          className="absolute inset-[6px]"
          style={{
            background: isMonster
              ? "radial-gradient(circle at 50% 62%, #2b2440 0%, #171325 78%)"
              : "radial-gradient(circle at 50% 55%, #241f30 0%, #14111d 80%)",
            boxShadow: "inset 0 0 0 2px rgba(16,14,23,0.9)",
          }}
        />
        <div
          className={
            fx === "kill"
              ? "relative anim-flash"
              : fx === "bare"
                ? "relative anim-shake"
                : "relative"
          }
        >
          <PixelSprite
            sprite={def.sprite}
            scale={5}
            className={isMonster && !spent && !fx ? "anim-bob" : ""}
            style={{ filter: "drop-shadow(0 3px 0 rgba(0,0,0,0.5))" }}
          />
        </div>
        {targeted ? (
          <div className="pointer-events-none absolute inset-[6px] border-2 border-gold/80" />
        ) : null}
      </div>

      {/* name + blurb */}
      <div className="mt-[6px] px-[7px] pb-[7px]">
        <div className="font-ui text-[13px] leading-[13px] font-bold text-bone">{def.name}</div>
        <div className="mt-[3px] font-ui text-[10px] leading-[12px] text-steel2">{def.blurb}</div>
        {isMonster ? (
          <div className="mt-[5px] font-pixel text-[6px] leading-[9px] text-blood/90">
            BARE HANDS: -{def.value}
          </div>
        ) : null}
        {isWeapon ? (
          <div className="mt-[5px] font-pixel text-[6px] leading-[9px] text-moss/90">
            STRIKES &lt; {def.value + 1}
          </div>
        ) : null}
      </div>

      {hint && !spent ? (
        <div className="pointer-events-none absolute -top-[26px] left-1/2 -translate-x-1/2 whitespace-nowrap bg-ink px-2 py-[3px] font-pixel text-[7px] text-gold opacity-0 transition-opacity group-hover:opacity-100">
          {hint}
        </div>
      ) : null}
    </button>
  );
}
