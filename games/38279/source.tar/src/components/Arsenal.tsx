import PixelSprite from "./PixelSprite";
import { canStrike, type Weapon } from "@/game/cards";

interface Props {
  arsenal: Weapon[];
  targetValue: number | null;
  pendingWhetstone: boolean;
  charm: number;
  strikeUid: string | null;
  onStrike: (uid: string) => void;
  onSharpen: (uid: string) => void;
  onBareHands: () => void;
  bareHandsDisabled: boolean;
}

export default function Arsenal({
  arsenal,
  targetValue,
  pendingWhetstone,
  charm,
  strikeUid,
  onStrike,
  onSharpen,
  onBareHands,
  bareHandsDisabled,
}: Props) {
  return (
    <div className="px-panel absolute bottom-[10px] left-[10px] flex h-[104px] w-[1260px] items-stretch gap-[12px] px-[12px] py-[8px]">
      <div className="flex w-[78px] shrink-0 flex-col justify-center">
        <div className="font-pixel text-[7px] text-gold">ARSENAL</div>
        <div className="mt-[6px] font-ui text-[10px] leading-[13px] text-steel2">
          {arsenal.length} held
        </div>
        <div className="mt-[6px] font-ui text-[9px] leading-[11px] text-steel2/70">
          &lt;N = highest value it can still fell
        </div>
        {charm > 0 ? (
          <div
            className="mt-[6px] flex items-center gap-[4px] font-pixel text-[6px]"
            style={{ color: "#6ae0d0" }}
          >
            <PixelSprite sprite="charm" scale={1} />
            CHARM {charm}
          </div>
        ) : null}
      </div>

      <div className="scroll-thin flex flex-1 items-center gap-[8px] overflow-x-auto pb-[2px]">
        {arsenal.length === 0 ? (
          <div className="px-[6px] py-[10px] font-ui text-[12px] text-blood2/90">
            Empty hands. Everything you meet will cost you its full value.
          </div>
        ) : (
          arsenal.map((w) => {
            const usable = targetValue !== null && canStrike(w, targetValue);
            const mode = pendingWhetstone ? "sharpen" : "strike";
            const active = mode === "sharpen" || usable;
            const spent = w.ceiling <= 1;
            return (
              <button
                key={w.uid}
                type="button"
                onClick={() => (pendingWhetstone ? onSharpen(w.uid) : onStrike(w.uid))}
                disabled={!active}
                aria-label={
                  pendingWhetstone
                    ? `Sharpen ${w.name}`
                    : `Strike with ${w.name}, reaches below ${w.ceiling}`
                }
                className={[
                  "px-btn relative flex h-[80px] w-[104px] shrink-0 flex-col items-center justify-center",
                  strikeUid === w.uid ? "anim-lunge" : "",
                  spent ? "opacity-50" : "",
                ].join(" ")}
                style={{
                  outline: pendingWhetstone
                    ? "2px solid #f7d24a"
                    : usable
                      ? "2px solid #5fbf5f"
                      : undefined,
                  outlineOffset: 2,
                }}
              >
                <PixelSprite sprite={w.sprite} scale={2} />
                <div className="mt-[2px] max-w-full truncate px-[4px] font-ui text-[11px] font-bold text-bone">
                  {w.name}
                </div>
                <div className="mt-[2px] flex items-center gap-[3px]">
                  <span
                    className="flex h-[14px] min-w-[14px] items-center justify-center px-[3px] font-pixel text-[7px] text-ink"
                    style={{ background: usable ? "#5fbf5f" : "#7a8a98" }}
                  >
                    &lt;{w.ceiling}
                  </span>
                  {w.ceiling < w.strength ? (
                    <span className="font-pixel text-[6px] text-blood2 line-through">
                      {w.strength}
                    </span>
                  ) : null}
                </div>
                {w.kills > 0 ? (
                  <span className="absolute top-[3px] right-[4px] font-pixel text-[6px] text-steel2">
                    x{w.kills}
                  </span>
                ) : null}
              </button>
            );
          })
        )}
      </div>

      <button
        type="button"
        onClick={onBareHands}
        disabled={bareHandsDisabled}
        aria-label="Strike with bare hands"
        className={[
          "px-btn px-btn-hot flex w-[126px] shrink-0 flex-col items-center justify-center",
          strikeUid === "fist" ? "anim-lunge" : "",
        ].join(" ")}
      >
        <PixelSprite sprite="fist" scale={2} />
        <div className="mt-[3px] font-pixel text-[8px] text-bone">BARE HANDS</div>
        <div className="mt-[4px] font-pixel text-[6px] text-blood">
          {targetValue !== null ? `-${targetValue} HEARTS` : "NO TARGET"}
        </div>
      </button>
    </div>
  );
}
