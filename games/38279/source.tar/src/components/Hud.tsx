import PixelSprite from "./PixelSprite";
import { MAX_HEARTS, RESOLVE_PER_ROOM, TOTAL_ROOMS } from "@/game/cards";

export function HeartBar({ hearts }: { hearts: number }) {
  const pips = Array.from({ length: MAX_HEARTS }, (_, i) => i < hearts);
  return (
    <div className="flex items-center gap-[3px]" aria-label={`${hearts} of ${MAX_HEARTS} hearts`}>
      {pips.map((full, i) => (
        <div
          key={i}
          className={full ? "" : "opacity-45"}
          style={full && hearts <= 5 ? { animation: "flicker 1s steps(3,end) infinite" } : undefined}
        >
          <PixelSprite sprite={full ? "heart" : "heartEmpty"} scale={1} />
        </div>
      ))}
    </div>
  );
}

export function TopBar({
  hearts,
  room,
  resolved,
  deckCount,
  carried,
}: {
  hearts: number;
  room: number;
  resolved: number;
  deckCount: number;
  carried: string | null;
}) {
  return (
    <div className="px-panel absolute top-[10px] left-[10px] flex h-[62px] w-[1260px] items-center justify-between px-[14px]">
      <div className="flex items-center gap-[12px]">
        <div>
          <div className="font-pixel text-[7px] text-blood2">HEARTS</div>
          <div className="mt-[5px]">
            <HeartBar hearts={hearts} />
          </div>
        </div>
        <div className="ml-[6px] border-l-[3px] border-ink pl-[14px]">
          <div className="font-pixel text-[7px] text-blood2">LIFE</div>
          <div className="font-pixel text-[15px] text-bone">
            {Math.max(0, hearts)}
            <span className="text-steel2">/{MAX_HEARTS}</span>
          </div>
        </div>
      </div>

      <div className="flex flex-col items-center">
        <div className="font-pixel text-[7px] text-steel2">DEPTH</div>
        <div className="font-pixel text-[15px] text-gold">
          {room}
          <span className="text-steel2">/{TOTAL_ROOMS}</span>
        </div>
        <div className="mt-[4px] flex items-center gap-[4px]">
          <span className="font-pixel text-[6px] text-steel2">RESOLVED</span>
          {Array.from({ length: RESOLVE_PER_ROOM }, (_, i) => (
            <span
              key={i}
              className="h-[7px] w-[7px]"
              style={{
                background: i < resolved ? "#f7d24a" : "#241f30",
                boxShadow: "0 0 0 2px #100e17",
              }}
            />
          ))}
          {carried ? (
            <span className="ml-[6px] font-pixel text-[6px] text-arcane">CARRY 1</span>
          ) : null}
        </div>
      </div>

      <div className="flex items-center gap-[12px]">
        <div className="text-right">
          <div className="font-pixel text-[7px] text-steel2">DECK</div>
          <div className="font-pixel text-[15px] text-bone">{deckCount}</div>
        </div>
        <div className="relative h-[46px] w-[34px]">
          {[3, 2, 1, 0].map((i) => (
            <div
              key={i}
              className="absolute px-card"
              style={{
                left: i * 4,
                top: i * 3,
                width: 26,
                height: 38,
                opacity: deckCount > 0 ? 1 : 0.3,
              }}
            />
          ))}
          {deckCount === 0 ? (
            <div className="absolute inset-0 flex items-center justify-center font-pixel text-[6px] text-blood2">
              EMPTY
            </div>
          ) : null}
        </div>
      </div>
    </div>
  );
}

export interface LogLine {
  id: number;
  text: string;
  tone: "info" | "kill" | "hurt" | "good" | "warn";
}

const TONE: Record<LogLine["tone"], string> = {
  info: "text-steel2",
  kill: "text-moss",
  hurt: "text-blood",
  good: "text-gold",
  warn: "text-arcane",
};

export function Journal({ lines }: { lines: LogLine[] }) {
  return (
    <div className="px-panel absolute top-[84px] right-[10px] flex h-[214px] w-[228px] flex-col">
      <div className="flex h-[22px] items-center border-b-[3px] border-ink px-[8px]">
        <span className="font-pixel text-[7px] text-gold">DUNGEON JOURNAL</span>
      </div>
      <div className="scroll-thin flex-1 overflow-hidden px-[8px] py-[6px]">
        {lines.slice(0, 9).map((l) => (
          <div
            key={l.id}
            className={`font-ui text-[11px] leading-[15px] ${TONE[l.tone]}`}
          >
            <span className="text-ink3">›</span> {l.text}
          </div>
        ))}
      </div>
    </div>
  );
}
