export type CardKind = "monster" | "weapon" | "item";
export type ItemKind = "salve" | "whetstone" | "charm";

export interface CardDef {
  kind: CardKind;
  name: string;
  sprite: string;
  /** Monster: threat value. Weapon: strike strength. Item: unused. */
  value: number;
  item?: ItemKind;
  blurb: string;
}

export interface CardInst {
  uid: string;
  def: CardDef;
  spent: boolean;
}

export interface Weapon {
  uid: string;
  name: string;
  sprite: string;
  /** Original strike strength. */
  strength: number;
  /** A weapon may only strike monsters with value strictly below this. */
  ceiling: number;
  kills: number;
}

/* ------------------------------------------------------------------ */
/*  Deck definition — 28 cards = 8 rooms of 4 (draw 4, then 3/room)   */
/* ------------------------------------------------------------------ */

const MONSTERS: CardDef[] = [
  { kind: "monster", name: "Slime", sprite: "slime", value: 2, blurb: "Wobbles. Bites." },
  { kind: "monster", name: "Bat", sprite: "bat", value: 3, blurb: "Screams in the dark." },
  { kind: "monster", name: "Bat", sprite: "bat", value: 3, blurb: "Screams in the dark." },
  { kind: "monster", name: "Goblin", sprite: "goblin", value: 4, blurb: "Greedy and quick." },
  { kind: "monster", name: "Goblin", sprite: "goblin", value: 5, blurb: "Greedy and quick." },
  { kind: "monster", name: "Skeleton", sprite: "skeleton", value: 6, blurb: "Still swinging." },
  { kind: "monster", name: "Wolf", sprite: "wolf", value: 8, blurb: "Hunts in the dark." },
  { kind: "monster", name: "Spider", sprite: "spider", value: 9, blurb: "Eight, and hungry." },
  { kind: "monster", name: "Ogre", sprite: "ogre", value: 12, blurb: "Smells of iron." },
  { kind: "monster", name: "Dragon", sprite: "dragon", value: 14, blurb: "The deck's last page." },
];

const WEAPONS: CardDef[] = [
  { kind: "weapon", name: "Dagger", sprite: "dagger", value: 3, blurb: "Quick, small work." },
  { kind: "weapon", name: "Dagger", sprite: "dagger", value: 3, blurb: "Quick, small work." },
  { kind: "weapon", name: "Sword", sprite: "sword", value: 4, blurb: "Honest steel." },
  { kind: "weapon", name: "Sword", sprite: "sword", value: 5, blurb: "Honest steel." },
  { kind: "weapon", name: "Spear", sprite: "spear", value: 6, blurb: "Keeps them off." },
  { kind: "weapon", name: "Axe", sprite: "axe", value: 7, blurb: "One clean chop." },
  { kind: "weapon", name: "Axe", sprite: "axe", value: 8, blurb: "One clean chop." },
  { kind: "weapon", name: "Halberd", sprite: "halberd", value: 9, blurb: "Long and cruel." },
  { kind: "weapon", name: "Greatsword", sprite: "greatsword", value: 11, blurb: "Two hands, no mercy." },
  { kind: "weapon", name: "Greatsword", sprite: "greatsword", value: 12, blurb: "Two hands, no mercy." },
  { kind: "weapon", name: "Warhammer", sprite: "warhammer", value: 13, blurb: "Ends arguments." },
  { kind: "weapon", name: "Sunblade", sprite: "sunblade", value: 15, blurb: "Burns anything." },
];

const ITEMS: CardDef[] = [
  { kind: "item", name: "Salve", sprite: "salve", value: 5, item: "salve", blurb: "Restore 5 hearts." },
  { kind: "item", name: "Salve", sprite: "salve", value: 5, item: "salve", blurb: "Restore 5 hearts." },
  { kind: "item", name: "Salve", sprite: "salve", value: 5, item: "salve", blurb: "Restore 5 hearts." },
  { kind: "item", name: "Whetstone", sprite: "whetstone", value: 3, item: "whetstone", blurb: "Sharpen a weapon: +3 reach." },
  { kind: "item", name: "Whetstone", sprite: "whetstone", value: 3, item: "whetstone", blurb: "Sharpen a weapon: +3 reach." },
  { kind: "item", name: "Charm", sprite: "charm", value: 0, item: "charm", blurb: "Next bare-handed blow is free." },
];

export const DECK: CardDef[] = [...MONSTERS, ...WEAPONS, ...ITEMS];
export const DECK_SIZE = DECK.length; // 28 = 4 + 3 * 8

export const HAND_SIZE = 4;
export const RESOLVE_PER_ROOM = 3;
export const TOTAL_ROOMS = DECK_SIZE / HAND_SIZE; // 8
export const MAX_HEARTS = 20;

export function shuffle<T>(input: T[]): T[] {
  const a = [...input];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

export function buildDeck(): CardInst[] {
  return shuffle(DECK).map((def, i) => ({ uid: `c${i}`, def, spent: false }));
}

/** A weapon may strike a monster only if the monster's value is below its ceiling. */
export function canStrike(weapon: Weapon, monsterValue: number): boolean {
  return monsterValue < weapon.ceiling;
}

export const KIND_LABEL: Record<CardKind, string> = {
  monster: "THREAT",
  weapon: "WEAPON",
  item: "RELIC",
};

export function tierOf(value: number): "low" | "mid" | "high" | "boss" {
  if (value <= 4) return "low";
  if (value <= 8) return "mid";
  if (value <= 12) return "high";
  return "boss";
}
