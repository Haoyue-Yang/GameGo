import { useEffect, useRef } from "react";
import { ITEMS } from "@/game/data";
import { VIEW_H, VIEW_W, createRuntime, update, type Runtime } from "@/game/runtime";
import { render } from "@/game/render";
import type { Entity, ItemId } from "@/game/types";

export interface HudInfo {
  oil: number;
  prompt: string | null;
  promptKind: Entity["kind"] | null;
  promptLabel: string | null;
  aggro: number;
}

interface Props {
  areaId: string;
  removed: Set<string>;
  oil: number;
  active: boolean;
  resetKey: number;
  onContact: (enemyId: string) => void;
  onInteract: (e: Entity) => void;
  onHud: (h: HudInfo) => void;
  onRuntime: (rt: Runtime) => void;
}

export default function GameCanvas({
  areaId,
  removed,
  oil,
  active,
  resetKey,
  onContact,
  onInteract,
  onHud,
  onRuntime,
}: Props) {
  const cvRef = useRef<HTMLCanvasElement | null>(null);
  const rtRef = useRef<Runtime | null>(null);
  const keys = useRef<Record<string, boolean>>({});
  const touch = useRef({ x: 0, y: 0 });
  const fired = useRef(false);
  const cb = useRef({ onContact, onInteract, onHud, onRuntime });
  cb.current = { onContact, onInteract, onHud, onRuntime };

  // (re)build the runtime when the area changes
  useEffect(() => {
    const rt = createRuntime(areaId, removed, oil);
    rtRef.current = rt;
    fired.current = false;
    cb.current.onRuntime(rt);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [areaId, resetKey]);

  useEffect(() => {
    const down = (ev: KeyboardEvent) => {
      const k = ev.key.toLowerCase();
      if (["arrowup", "arrowdown", "arrowleft", "arrowright", " ", "w", "a", "s", "d"].includes(k)) ev.preventDefault();
      keys.current[k] = true;
      if ((k === "e" || k === " " || k === "enter") && active && rtRef.current) {
        const t = rtRef.current.target;
        if (t) cb.current.onInteract(t);
      }
    };
    const up = (ev: KeyboardEvent) => {
      keys.current[ev.key.toLowerCase()] = false;
    };
    const blur = () => {
      keys.current = {};
    };
    window.addEventListener("keydown", down);
    window.addEventListener("keyup", up);
    window.addEventListener("blur", blur);
    return () => {
      window.removeEventListener("keydown", down);
      window.removeEventListener("keyup", up);
      window.removeEventListener("blur", blur);
    };
  }, [active]);

  useEffect(() => {
    const cv = cvRef.current;
    if (!cv) return;
    const ctx = cv.getContext("2d");
    if (!ctx) return;
    let raf = 0;
    let last = performance.now();
    let hudT = 0;

    const frame = (now: number) => {
      raf = requestAnimationFrame(frame);
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      const rt = rtRef.current;
      if (!rt) return;
      rt.oil = oil;

      if (active) {
        const k = keys.current;
        let ix = (k["d"] || k["arrowright"] ? 1 : 0) - (k["a"] || k["arrowleft"] ? 1 : 0);
        let iy = (k["s"] || k["arrowdown"] ? 1 : 0) - (k["w"] || k["arrowup"] ? 1 : 0);
        ix += touch.current.x;
        iy += touch.current.y;
        update(rt, dt, { x: ix, y: iy }, oil);

        if (rt.contact && !fired.current) {
          fired.current = true;
          cb.current.onContact(rt.contact);
        }
        if (!rt.contact) fired.current = false;

        hudT -= dt;
        if (hudT <= 0) {
          hudT = 0.12;
          const t = rt.target;
          let aggro = 0;
          for (const e of rt.entities) if (e.kind === "enemy" && e.aggro) aggro++;
          const itemName = t && t.kind === "item" ? ITEMS[t.ref as ItemId]?.name ?? null : null;
          cb.current.onHud({
            oil: Math.round(rt.oil),
            prompt: t ? t.label ?? itemName ?? null : null,
            promptKind: t ? t.kind : null,
            promptLabel: t ? t.label ?? null : null,
            aggro,
          });
        }
      }
      render(ctx, rt);
    };
    raf = requestAnimationFrame(frame);
    return () => cancelAnimationFrame(raf);
  }, [active, oil]);

  const hold = (x: number, y: number) => ({
    onPointerDown: (e: React.PointerEvent) => {
      e.preventDefault();
      touch.current = { x, y };
    },
    onPointerUp: () => {
      touch.current = { x: 0, y: 0 };
    },
    onPointerLeave: () => {
      touch.current = { x: 0, y: 0 };
    },
    onPointerCancel: () => {
      touch.current = { x: 0, y: 0 };
    },
  });

  const padBtn =
    "btn flex h-12 w-12 items-center justify-center text-bone text-lg select-none touch-none";

  return (
    <div className="relative flex h-full w-full flex-col items-center justify-center gap-3">
      <div
        className="relative w-full overflow-hidden border border-bone/10 bg-black shadow-[0_0_60px_rgba(0,0,0,0.9)]"
        style={{ aspectRatio: `${VIEW_W} / ${VIEW_H}`, maxHeight: "78vh" }}
      >
        <canvas ref={cvRef} width={VIEW_W} height={VIEW_H} className="h-full w-full" aria-label="Game view" />
      </div>

      {/* touch controls */}
      <div className="flex w-full max-w-2xl items-center justify-between px-2 md:hidden">
        <div className="grid grid-cols-3 grid-rows-3 gap-1">
          <span />
          <button className={padBtn} aria-label="Move up" {...hold(0, -1)}>
            ▲
          </button>
          <span />
          <button className={padBtn} aria-label="Move left" {...hold(-1, 0)}>
            ◀
          </button>
          <span />
          <button className={padBtn} aria-label="Move right" {...hold(1, 0)}>
            ▶
          </button>
          <span />
          <button className={padBtn} aria-label="Move down" {...hold(0, 1)}>
            ▼
          </button>
          <span />
        </div>
        <button
          className="btn h-16 w-16 rounded-full text-xs text-ember"
          aria-label="Interact"
          onPointerDown={(e) => {
            e.preventDefault();
            const t = rtRef.current?.target;
            if (t) onInteract(t);
          }}
        >
          USE
        </button>
      </div>
    </div>
  );
}
