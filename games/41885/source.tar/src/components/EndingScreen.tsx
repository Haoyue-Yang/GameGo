import { useEffect, useRef, useState } from "react";

type Ending = "protect" | "join";

interface Props {
  notes: number;
  deaths: number;
  onRestart: () => void;
}

export default function EndingScreen({ notes, deaths, onRestart }: Props) {
  const [choice, setChoice] = useState<Ending | null>(null);
  const ref = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const cv = ref.current;
    if (!cv) return;
    const ctx = cv.getContext("2d");
    if (!ctx) return;
    const W = 336;
    const H = 210;
    cv.width = W;
    cv.height = H;
    const drops = Array.from({ length: 120 }, () => ({
      x: Math.random() * W,
      y: Math.random() * H,
      v: 150 + Math.random() * 200,
      l: 5 + Math.random() * 9,
    }));
    const eyes = Array.from({ length: 14 }, () => ({
      x: 20 + Math.random() * (W - 40),
      y: 60 + Math.random() * (H - 90),
      p: Math.random() * 6,
    }));
    let raf = 0;
    let t = 0;
    const t0 = performance.now();

    const loop = (now: number) => {
      raf = requestAnimationFrame(loop);
      t += Math.min(0.05, (now - t0) / 1000 - t);
      const join = choice === "join";
      const flick = 0.8 + Math.sin(t * 7.1) * 0.1 + Math.sin(t * 12.7) * 0.06;
      const warmth = join ? Math.max(0, 1 - t / 3.2) : Math.min(1, t / 2.4);

      ctx.imageSmoothingEnabled = false;
      const bg = ctx.createLinearGradient(0, 0, 0, H);
      if (join) {
        bg.addColorStop(0, "#05060a");
        bg.addColorStop(1, "#02030a");
      } else {
        bg.addColorStop(0, `rgb(${10 + warmth * 26},${14 + warmth * 22},${24 + warmth * 12})`);
        bg.addColorStop(1, "#0a0a10");
      }
      ctx.fillStyle = bg;
      ctx.fillRect(0, 0, W, H);

      // fence line
      ctx.fillStyle = join ? "#0a0c12" : "#141821";
      for (let i = 0; i < 34; i++) ctx.fillRect(i * 10 + 2, H - 74, 3, 34);
      ctx.fillRect(0, H - 66, W, 3);
      ctx.fillRect(0, H - 56, W, 3);
      ctx.fillStyle = join ? "#07080d" : "#0e1218";
      ctx.fillRect(0, H - 40, W, 40);

      if (join) {
        // eyes in the dark, multiplying
        const n = Math.min(eyes.length, Math.floor(2 + t * 2.2));
        for (let i = 0; i < n; i++) {
          const e = eyes[i];
          const a = 0.35 + Math.sin(t * 2 + e.p) * 0.3;
          ctx.globalCompositeOperation = "lighter";
          ctx.globalAlpha = a;
          ctx.fillStyle = "#ff7a3a";
          ctx.fillRect(Math.round(e.x) - 4, Math.round(e.y), 9, 3);
          ctx.globalAlpha = a * 1.6;
          ctx.fillStyle = "#ffd0a0";
          ctx.fillRect(Math.round(e.x) - 3, Math.round(e.y) + 0.5, 2, 2);
          ctx.fillRect(Math.round(e.x) + 1, Math.round(e.y) + 0.5, 2, 2);
          ctx.globalAlpha = 1;
          ctx.globalCompositeOperation = "source-over";
        }
      } else {
        // the lantern grows into a beacon; the gates close
        const lx = W / 2;
        const ly = H - 52;
        ctx.fillStyle = "#15151f";
        ctx.fillRect(lx - 5, ly - 14, 10, 26);
        ctx.fillStyle = "#1e1e2a";
        ctx.fillRect(lx - 4, ly - 20, 8, 8);
        ctx.fillStyle = "#ffb95e";
        ctx.fillRect(lx + 6, ly - 5, 3, 4);
        ctx.globalCompositeOperation = "lighter";
        const rad = (60 + warmth * 130) * flick;
        const g = ctx.createRadialGradient(lx + 7, ly - 3, 0, lx + 7, ly - 3, rad);
        g.addColorStop(0, `rgba(255,214,150,${0.42 * flick})`);
        g.addColorStop(0.35, `rgba(255,170,90,${0.18 * flick})`);
        g.addColorStop(1, "rgba(0,0,0,0)");
        ctx.fillStyle = g;
        ctx.fillRect(0, 0, W, H);
        ctx.globalCompositeOperation = "source-over";
        // sealed gates
        ctx.fillStyle = "#2a2a34";
        ctx.fillRect(28, H - 78, 22, 40);
        ctx.fillRect(W - 50, H - 78, 22, 40);
        ctx.fillStyle = "#3a3a46";
        for (let i = 0; i < 5; i++) {
          ctx.fillRect(30 + i * 4, H - 76, 2, 36);
          ctx.fillRect(W - 48 + i * 4, H - 76, 2, 36);
        }
      }

      // rain thins out as the ending resolves
      const rainA = join ? 0.3 : 0.34 * Math.max(0.15, 1 - warmth * 0.7);
      ctx.strokeStyle = `rgba(190,215,235,${rainA})`;
      ctx.lineWidth = 1;
      ctx.beginPath();
      for (const d of drops) {
        d.y += d.v * Math.min(0.05, 1 / 60);
        d.x += d.v * 0.22 * Math.min(0.05, 1 / 60);
        if (d.y > H) {
          d.y = -8;
          d.x = Math.random() * (W + 60) - 30;
        }
        if (d.x > W + 20) d.x -= W + 40;
        ctx.moveTo(d.x, d.y);
        ctx.lineTo(d.x - d.l * 0.22, d.y - d.l);
      }
      ctx.stroke();

      const vg = ctx.createRadialGradient(W / 2, H / 2, H * 0.18, W / 2, H / 2, H * 0.92);
      vg.addColorStop(0, "rgba(0,0,0,0)");
      vg.addColorStop(1, join ? "rgba(0,0,0,0.95)" : "rgba(0,0,0,0.7)");
      ctx.fillStyle = vg;
      ctx.fillRect(0, 0, W, H);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [choice]);

  if (!choice) {
    return (
      <div className="relative flex h-full w-full flex-col items-center justify-center gap-4 p-4">
        <div className="relative w-full max-w-3xl overflow-hidden border border-blood/40">
          <canvas ref={ref} className="h-auto w-full" style={{ aspectRatio: "336 / 210" }} aria-hidden="true" />
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-1 bg-black/45">
            <h2 className="glow font-pixel text-lg tracking-widest-xl text-blood2 sm:text-2xl">THE HEART</h2>
            <p className="max-w-md text-center font-term text-base text-bone2">
              Three houses are quiet. The altar at the centre of the graveyard is warm for the first time in nine
              years, and it is asking you a question.
            </p>
          </div>
        </div>

        <p className="max-w-2xl text-center font-term text-base leading-snug text-bone2/80 sm:text-lg">
          The rain will not stop on its own. It needs a keeper — someone to hold the lantern at the centre of the
          graveyard so the dead stay where they are buried. Or it needs a mouth. The verse has nine verses and only
          eight voices.
        </p>

        <div className="grid w-full max-w-2xl gap-2 sm:grid-cols-2">
          <button
            className="btn p-4 text-left"
            onClick={() => setChoice("protect")}
            aria-label="Choose to protect"
          >
            <div className="font-pixel text-[11px] tracking-widest text-ember">PROTECT</div>
            <div className="mt-1 font-term text-base text-bone2/80">
              Hold the lantern. Seal the gates. Stay awake, and keep the graveyard where the dead can rest.
            </div>
          </button>
          <button
            className="btn p-4 text-left"
            onClick={() => setChoice("join")}
            aria-label="Choose to join"
          >
            <div className="font-pixel text-[11px] tracking-widest text-blood2">JOIN</div>
            <div className="mt-1 font-term text-base text-bone2/80">
              Give up the light. Take the ninth voice. Let the rain finally have something to fall on.
            </div>
          </button>
        </div>
        <p className="font-term text-sm text-bone2/50">
          {notes} notes read · {deaths} times the lantern went out
        </p>
      </div>
    );
  }

  const protect = choice === "protect";
  return (
    <div className="relative flex h-full w-full flex-col items-center justify-center gap-4 p-4">
      <div className="relative w-full max-w-3xl overflow-hidden border border-bone/10">
        <canvas ref={ref} className="h-auto w-full" style={{ aspectRatio: "336 / 210" }} aria-hidden="true" />
        <div className="absolute inset-0 flex items-center justify-center">
          <h2
            className="glow font-pixel text-xl tracking-widest-xl sm:text-3xl"
            style={{ color: protect ? "#ffb95e" : "#c8343c" }}
          >
            {protect ? "THE KEEPER" : "THE NINTH VOICE"}
          </h2>
        </div>
      </div>

      <div className="panel creep max-w-2xl p-4">
        <p className="font-term text-lg leading-snug text-bone2">
          {protect
            ? "You set the lantern on the altar and it takes the weight without complaint. The three gates fold shut behind you, and the houses go dark one after another, the way rooms go dark when a family finally sleeps. The rain keeps falling. It always will. But the graves stay where they are, and the things under them stay under them, and every so often a traveller comes to the fence and finds the light at the centre of the graveyard and turns back, and lives."
            : "You lower the lantern until the flame is the size of a fingernail, and then you let it go. The dark does not take you so much as it recognises you. Nine mouths open in the chapel that is not a chapel, and the eighth verse is finally complete. The rain stops for exactly one second — long enough for the graveyard to hear its own name — and then it starts again, and it is falling on you, and you are very glad of it."}
        </p>
        <p className="mt-3 font-term text-base text-bone2/60">
          {protect
            ? "ENDING I — PROTECT. You are the light that keeps the dark at a distance."
            : "ENDING II — JOIN. You are the thing that is only ever seen by its eyes."}
        </p>
      </div>

      <div className="flex flex-wrap items-center justify-center gap-2">
        <button className="btn px-6 py-3 text-xs text-ember" onClick={onRestart}>
          WALK IT AGAIN
        </button>
      </div>
    </div>
  );
}
