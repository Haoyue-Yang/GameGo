import { useEffect, useMemo, useRef, useState } from "react";
import { ENEMIES, ITEMS, STATUS } from "@/game/data";
import { enemyAct, intentText, playerAct, startCombat, type Action, type CombatState } from "@/game/combat";
import { drawCreature } from "@/game/tiles";
import type { ItemId, Player } from "@/game/types";

export interface CombatResult {
  result: "won" | "lost" | "fled";
  hp: number;
  oil: number;
  inv: Record<string, number>;
}

interface Props {
  enemyId: string;
  player: Player;
  onEnd: (r: CombatResult) => void;
}

const TONE: Record<string, string> = {
  you: "text-bone",
  them: "text-blood2",
  sys: "text-bone2/70 italic",
  crit: "text-ember2",
  bad: "text-blood2",
  good: "text-moss",
};

export default function CombatScreen({ enemyId, player, onEnd }: Props) {
  const [cs, setCs] = useState<CombatState>(() => startCombat(player, enemyId));
  const [menu, setMenu] = useState<"root" | "item">("root");
  const [float, setFloat] = useState<{ id: number; side: string; text: string; color: string } | null>(null);
  const [shake, setShake] = useState(0);
  const logRef = useRef<HTMLDivElement | null>(null);
  const def = ENEMIES[enemyId];

  // phase driver
  useEffect(() => {
    if (cs.phase === "intro") {
      const t = setTimeout(() => setCs((s) => ({ ...s, phase: "player" })), 1100);
      return () => clearTimeout(t);
    }
    if (cs.phase === "enemy") {
      const t = setTimeout(() => setCs((s) => enemyAct(s)), 820);
      return () => clearTimeout(t);
    }
    return;
  }, [cs.phase]);

  // fx feedback
  useEffect(() => {
    if (!cs.fx) return;
    const f = cs.fx;
    const text =
      f.kind === "miss" ? "MISS" : f.kind === "heal" ? `+${f.v}` : f.kind === "guard" ? "GUARD" : `${f.v}`;
    const color =
      f.kind === "crit" ? "#ffb95e" : f.kind === "heal" ? "#7fd8a0" : f.kind === "miss" ? "#8a8a96" : f.side === "player" ? "#c8343c" : "#e8e0d0";
    setFloat({ id: Date.now(), side: f.side, text, color });
    const timers: number[] = [];
    timers.push(window.setTimeout(() => setFloat(null), 780));
    if (cs.shake > 0) {
      setShake(cs.shake);
      timers.push(window.setTimeout(() => setShake(0), 340));
    }
    return () => timers.forEach((id) => clearTimeout(id));
  }, [cs.fx, cs.shake]);

  useEffect(() => {
    if (logRef.current) logRef.current.scrollTop = logRef.current.scrollHeight;
  }, [cs.log]);

  const act = (a: Action) => {
    if (cs.phase !== "player") return;
    setMenu("root");
    setCs((s) => playerAct(s, player, a));
  };

  const items = useMemo(() => Object.keys(cs.inv).filter((k) => (cs.inv[k] ?? 0) > 0), [cs.inv]);

  const finish = () => {
    const result = cs.phase === "won" ? "won" : cs.phase === "lost" ? "lost" : "fled";
    onEnd({ result, hp: cs.pHp, oil: cs.oil, inv: cs.inv });
  };

  const over = cs.phase === "won" || cs.phase === "lost" || cs.phase === "fled";

  // keyboard
  useEffect(() => {
    const h = (ev: KeyboardEvent) => {
      const k = ev.key.toLowerCase();
      if (over) {
        if (k === "enter" || k === " ") finish();
        return;
      }
      if (cs.phase !== "player") return;
      if (menu === "item") {
        if (k === "escape" || k === "backspace") setMenu("root");
        const idx = parseInt(k, 10);
        if (!isNaN(idx) && items[idx - 1]) act({ t: "item", item: items[idx - 1] as ItemId });
        return;
      }
      if (k === "1") act({ t: "strike" });
      if (k === "2") act({ t: "guard" });
      if (k === "3") act({ t: "lantern" });
      if (k === "4") act({ t: "heavy" });
      if (k === "5") setMenu("item");
      if (k === "6") act({ t: "flee" });
    };
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  });

  const hpPct = (cs.pHp / cs.pMax) * 100;
  const ePct = (cs.eHp / cs.eMax) * 100;
  const heavyReady = cs.resolve >= 5;

  return (
    <div className="relative flex h-full w-full flex-col items-center justify-center gap-2 p-2 sm:gap-3 sm:p-4">
      {/* enemy stage */}
      <div className={`panel relative w-full max-w-3xl overflow-hidden ${shake > 0 ? "shudder" : ""}`}>
        <div className="flex items-start justify-between gap-3 px-3 pt-2">
          <div>
            <div className="font-pixel text-[11px] tracking-widest text-blood2 sm:text-sm">{def.name}</div>
            <div className="font-term text-sm text-bone2/70">{def.title}</div>
          </div>
          <div className="text-right">
            <div className="font-pixel text-[9px] text-bone2/60">ROUND {cs.round}</div>
            {cs.boss && <div className="font-pixel text-[9px] text-blood2">KEEPER</div>}
          </div>
        </div>

        <div className="mx-3 mt-1 flex items-center gap-2">
          <div className="bar h-3 flex-1">
            <i style={{ width: `${ePct}%`, background: "linear-gradient(90deg,#5c161d,#c8343c)" }} />
          </div>
          <span className="w-16 font-pixel text-[9px] text-bone2/70">
            {cs.eHp}/{cs.eMax}
          </span>
        </div>

        <div className="mt-1 flex flex-wrap gap-1 px-3">
          {cs.eStatus.map((s) => (
            <span
              key={s.id}
              className="border px-1 font-pixel text-[8px]"
              style={{ color: STATUS[s.id].color, borderColor: `${STATUS[s.id].color}55` }}
            >
              {STATUS[s.id].name.toUpperCase()} {s.turns}
            </span>
          ))}
        </div>

        <div className="relative mt-1 h-32 sm:h-44">
          <EnemyStage cs={cs} enemyId={enemyId} />
          {float && float.side === "enemy" && (
            <div
              key={float.id}
              className="pointer-events-none absolute left-1/2 top-4 -translate-x-1/2 font-pixel text-lg"
              style={{ color: float.color, animation: "driftUp 0.8s ease-out both", textShadow: "0 0 10px rgba(0,0,0,0.9)" }}
            >
              {float.text}
            </div>
          )}
          <div className="absolute bottom-1 left-0 right-0 text-center">
            <span className="font-term text-sm text-ember/90">{intentText(cs.intent)}</span>
          </div>
        </div>
      </div>

      {/* player + actions */}
      <div className="panel w-full max-w-3xl p-2 sm:p-3">
        <div className="flex items-center justify-between gap-2">
          <span className="font-pixel text-[10px] tracking-widest text-bone">YOU</span>
          <span className="font-pixel text-[9px] text-bone2/60">
            ATK {player.atk} · DEF {player.def} · SPD {player.spd}
          </span>
        </div>
        <div className="mt-1 flex items-center gap-2">
          <div className="bar h-3 flex-1">
            <i style={{ width: `${hpPct}%`, background: "linear-gradient(90deg,#2b5a3a,#7fd8a0)" }} />
          </div>
          <span className="w-16 font-pixel text-[9px] text-bone2/70">
            {cs.pHp}/{cs.pMax}
          </span>
        </div>
        <div className="mt-1 flex items-center gap-2">
          <div className="bar h-2 flex-1">
            <i style={{ width: `${cs.oil}%`, background: "linear-gradient(90deg,#6a4a1a,#ffb95e)" }} />
          </div>
          <span className="w-16 font-pixel text-[9px] text-ember/80">OIL {cs.oil}</span>
        </div>
        <div className="mt-1 flex items-center gap-2">
          <div className="bar h-2 flex-1">
            <i style={{ width: `${(cs.resolve / 9) * 100}%`, background: "linear-gradient(90deg,#3a5a7a,#9fd8e8)" }} />
          </div>
          <span className="w-16 font-pixel text-[9px] text-cold/80">RES {cs.resolve}</span>
        </div>
        <div className="mt-1 flex flex-wrap gap-1">
          {cs.pStatus.map((s) => (
            <span
              key={s.id}
              className="border px-1 font-pixel text-[8px]"
              style={{ color: STATUS[s.id].color, borderColor: `${STATUS[s.id].color}55` }}
            >
              {STATUS[s.id].name.toUpperCase()} {s.turns}
            </span>
          ))}
          {float && float.side === "player" && (
            <span
              key={float.id}
              className="font-pixel text-xs"
              style={{ color: float.color, animation: "driftUp 0.8s ease-out both" }}
            >
              {float.text}
            </span>
          )}
        </div>
      </div>

      {/* log */}
      <div
        ref={logRef}
        className="scroll panel h-20 w-full max-w-3xl overflow-y-auto px-3 py-1 font-term text-sm leading-tight"
        aria-live="polite"
      >
        {cs.log.map((l, i) => (
          <div key={i} className={TONE[l.tone]}>
            {l.text}
          </div>
        ))}
      </div>

      {/* actions */}
      {!over && (
        <div className="w-full max-w-3xl">
          {menu === "root" ? (
            <div className="grid grid-cols-2 gap-1 sm:grid-cols-3">
              <button className="btn px-2 py-2 text-[10px]" onClick={() => act({ t: "strike" })} disabled={cs.phase !== "player"}>
                1 · STRIKE
              </button>
              <button className="btn px-2 py-2 text-[10px]" onClick={() => act({ t: "guard" })} disabled={cs.phase !== "player"}>
                2 · GUARD
              </button>
              <button
                className="btn px-2 py-2 text-[10px]"
                onClick={() => act({ t: "lantern" })}
                disabled={cs.phase !== "player" || cs.oil < 8}
              >
                3 · LANTERN <span className="text-ember/70">(-8 oil)</span>
              </button>
              <button
                className="btn px-2 py-2 text-[10px]"
                onClick={() => act({ t: "heavy" })}
                disabled={cs.phase !== "player" || !heavyReady}
              >
                4 · HEAVY BLOW <span className="text-cold/70">(res 5)</span>
              </button>
              <button className="btn px-2 py-2 text-[10px]" onClick={() => setMenu("item")} disabled={cs.phase !== "player"}>
                5 · ITEM
              </button>
              <button className="btn px-2 py-2 text-[10px]" onClick={() => act({ t: "flee" })} disabled={cs.phase !== "player" || cs.boss}>
                6 · FLEE
              </button>
            </div>
          ) : (
            <div className="panel p-2">
              <div className="mb-1 font-pixel text-[9px] text-bone2/70">SATCHEL — pick one</div>
              <div className="grid grid-cols-1 gap-1 sm:grid-cols-2">
                {items.length === 0 && <div className="font-term text-sm text-bone2/60">Empty. You are carrying nothing but the lantern.</div>}
                {items.map((k, i) => (
                  <button
                    key={k}
                    className="btn px-2 py-2 text-left text-[10px]"
                    onClick={() => act({ t: "item", item: k as ItemId })}
                    disabled={cs.phase !== "player"}
                  >
                    {i + 1} · {ITEMS[k as ItemId]?.name ?? k} ×{cs.inv[k]}
                    <div className="font-term text-xs text-bone2/60">{ITEMS[k as ItemId]?.desc}</div>
                  </button>
                ))}
              </div>
              <button className="btn mt-1 px-2 py-1 text-[9px]" onClick={() => setMenu("root")}>
                ESC · BACK
              </button>
            </div>
          )}
        </div>
      )}

      {/* result */}
      {over && (
        <div className="panel creep w-full max-w-3xl p-4 text-center">
          <div
            className="font-pixel text-sm tracking-widest-xl"
            style={{ color: cs.phase === "won" ? "#7fd8a0" : cs.phase === "lost" ? "#c8343c" : "#9fd8e8" }}
          >
            {cs.phase === "won" ? "IT IS QUIET" : cs.phase === "lost" ? "THE LANTERN GOES OUT" : "YOU RAN"}
          </div>
          <p className="mt-2 font-term text-base text-bone2">
            {cs.phase === "won"
              ? `${def.name} is finished. The rain keeps falling over what is left of it.`
              : cs.phase === "lost"
                ? "Something takes the lantern from your hand. The graveyard is very patient."
                : "You slip away into the wet dark. It will still be there."}
          </p>
          <button className="btn mt-3 px-6 py-2 text-[11px] text-ember" onClick={finish}>
            CONTINUE ⏎
          </button>
        </div>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ */
function EnemyStage({ cs, enemyId }: { cs: CombatState; enemyId: string }) {
  const ref = useRef<HTMLCanvasElement | null>(null);
  const def = ENEMIES[enemyId];
  useEffect(() => {
    const cv = ref.current;
    if (!cv) return;
    const ctx = cv.getContext("2d");
    if (!ctx) return;
    let raf = 0;
    const t0 = performance.now();
    const loop = (now: number) => {
      raf = requestAnimationFrame(loop);
      const t = (now - t0) / 1000;
      ctx.imageSmoothingEnabled = false;
      ctx.clearRect(0, 0, cv.width, cv.height);
      // ground glow
      const g = ctx.createRadialGradient(cv.width / 2, cv.height * 0.72, 4, cv.width / 2, cv.height * 0.72, cv.width * 0.5);
      g.addColorStop(0, "rgba(232,163,61,0.16)");
      g.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, cv.width, cv.height);
      ctx.fillStyle = "rgba(0,0,0,0.35)";
      ctx.fillRect(0, cv.height - 14, cv.width, 14);
      const dead = cs.phase === "won" ? Math.min(1, t / 0.7) : 0;
      drawCreature(ctx, def.sprite, cv.width / 2, cv.height * 0.56, def.boss ? 5 : 6, {
        lit: 0.75,
        t,
        hurt: cs.fx && cs.fx.side === "enemy" ? 1 : 0,
        dead,
      });
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [def, cs.phase, cs.fx]);
  return <canvas ref={ref} width={280} height={176} className="h-full w-full" aria-hidden="true" />;
}
