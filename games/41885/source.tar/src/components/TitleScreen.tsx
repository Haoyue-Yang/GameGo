import { useEffect, useRef, useState } from "react";

interface Props {
  hasSave: boolean;
  onNew: () => void;
  onContinue: () => void;
}

export default function TitleScreen({ hasSave, onNew, onContinue }: Props) {
  const ref = useRef<HTMLCanvasElement | null>(null);
  const [help, setHelp] = useState(false);

  useEffect(() => {
    const cv = ref.current;
    if (!cv) return;
    const ctx = cv.getContext("2d");
    if (!ctx) return;
    const W = 336;
    const H = 210;
    cv.width = W;
    cv.height = H;

    const drops = Array.from({ length: 130 }, () => ({
      x: Math.random() * W,
      y: Math.random() * H,
      v: 170 + Math.random() * 220,
      l: 5 + Math.random() * 10,
    }));
    const stones = Array.from({ length: 16 }, (_, i) => ({
      x: 12 + i * 20 + Math.random() * 8,
      h: 12 + Math.random() * 16,
      w: 7 + Math.random() * 6,
    }));
    const trees = Array.from({ length: 11 }, (_, i) => ({ x: i * 32 + Math.random() * 10, h: 40 + Math.random() * 30 }));

    let raf = 0;
    let t = 0;
    let bolt = 0;
    let nextBolt = 3;
    const t0 = performance.now();

    const loop = (now: number) => {
      raf = requestAnimationFrame(loop);
      const dt = Math.min(0.05, (now - t0) / 1000 - t);
      t += dt;
      nextBolt -= dt;
      if (nextBolt <= 0) {
        bolt = 0.6;
        nextBolt = 7 + Math.random() * 9;
      }
      if (bolt > 0) bolt = Math.max(0, bolt - dt * 2.2);

      const flick = 0.82 + Math.sin(t * 7.3) * 0.08 + Math.sin(t * 13.1) * 0.05;

      ctx.imageSmoothingEnabled = false;
      // sky
      const sky = ctx.createLinearGradient(0, 0, 0, H);
      sky.addColorStop(0, "#0a1020");
      sky.addColorStop(0.6, "#0b0f18");
      sky.addColorStop(1, "#07070c");
      ctx.fillStyle = sky;
      ctx.fillRect(0, 0, W, H);

      // moon smear
      ctx.globalAlpha = 0.16 + bolt * 0.5;
      ctx.fillStyle = "#8fa8c8";
      ctx.fillRect(248, 22, 18, 18);
      ctx.globalAlpha = 1;

      // distant trees
      for (const tr of trees) {
        ctx.fillStyle = "#0c1410";
        ctx.fillRect(tr.x, H - 96 - tr.h, 8, tr.h + 96);
        ctx.fillStyle = "#101a14";
        ctx.fillRect(tr.x - 6, H - 100 - tr.h, 20, 14);
      }

      // ground
      ctx.fillStyle = "#0d1410";
      ctx.fillRect(0, H - 44, W, 44);
      ctx.fillStyle = "#131c15";
      ctx.fillRect(0, H - 44, W, 3);

      // gravestones
      for (const s of stones) {
        ctx.fillStyle = "#1a2028";
        ctx.fillRect(s.x, H - 44 - s.h, s.w, s.h);
        ctx.fillStyle = "#232b34";
        ctx.fillRect(s.x, H - 44 - s.h, s.w, 2);
      }

      // the lantern bearer
      const lx = W / 2;
      const ly = H - 40;
      ctx.fillStyle = "rgba(0,0,0,0.5)";
      ctx.fillRect(lx - 8, ly + 12, 16, 4);
      ctx.fillStyle = "#15151f";
      ctx.fillRect(lx - 5, ly - 14, 10, 26);
      ctx.fillStyle = "#1e1e2a";
      ctx.fillRect(lx - 4, ly - 20, 8, 8);
      ctx.fillStyle = "#0a0a10";
      ctx.fillRect(lx - 3, ly - 18, 6, 5);
      ctx.fillStyle = "#6a5a3a";
      ctx.fillRect(lx + 6, ly - 6, 3, 6);
      ctx.fillStyle = "#ffb95e";
      ctx.fillRect(lx + 6, ly - 5, 3, 4);

      // lantern glow
      ctx.globalCompositeOperation = "lighter";
      const g = ctx.createRadialGradient(lx + 7, ly - 3, 0, lx + 7, ly - 3, 92 * flick);
      g.addColorStop(0, `rgba(255,196,120,${0.3 * flick})`);
      g.addColorStop(0.4, `rgba(255,150,70,${0.11 * flick})`);
      g.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, W, H);
      ctx.globalCompositeOperation = "source-over";

      // rain
      ctx.strokeStyle = "rgba(190,215,235,0.28)";
      ctx.lineWidth = 1;
      ctx.beginPath();
      for (const d of drops) {
        d.y += d.v * dt;
        d.x += d.v * 0.22 * dt;
        if (d.y > H) {
          d.y = -8;
          d.x = Math.random() * (W + 60) - 30;
        }
        if (d.x > W + 20) d.x -= W + 40;
        ctx.moveTo(d.x, d.y);
        ctx.lineTo(d.x - d.l * 0.22, d.y - d.l);
      }
      ctx.stroke();

      if (bolt > 0.02) {
        ctx.fillStyle = `rgba(190,215,255,${Math.min(0.4, bolt * 0.55)})`;
        ctx.fillRect(0, 0, W, H);
      }

      // vignette
      const vg = ctx.createRadialGradient(W / 2, H / 2, H * 0.2, W / 2, H / 2, H * 0.9);
      vg.addColorStop(0, "rgba(0,0,0,0)");
      vg.addColorStop(1, "rgba(0,0,0,0.85)");
      ctx.fillStyle = vg;
      ctx.fillRect(0, 0, W, H);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, []);

  return (
    <div className="relative flex h-full w-full flex-col items-center justify-center gap-4 p-4">
      <div className="relative w-full max-w-3xl overflow-hidden border border-bone/10">
        <canvas ref={ref} className="h-auto w-full" style={{ aspectRatio: "336 / 210" }} aria-hidden="true" />
        <div className="absolute inset-0 flex flex-col items-center justify-center gap-1">
          <h1
            className="glow font-pixel text-2xl tracking-widest-xl text-ember sm:text-4xl"
            style={{ textShadow: "0 0 12px rgba(232,163,61,0.6), 0 4px 0 #000" }}
          >
            LANTERNFALL
          </h1>
          <p className="font-term text-base text-bone2 sm:text-xl">Graveyard of the Nine</p>
        </div>
      </div>

      <p className="max-w-xl text-center font-term text-base leading-snug text-bone2/80 sm:text-lg">
        The rain has not stopped in nine years. Three houses still stand inside the fence, and each one is
        still waiting. Your lantern is the only thing that decides what you may see — and what may touch you.
      </p>

      <div className="flex flex-wrap items-center justify-center gap-2">
        <button className="btn px-6 py-3 text-xs text-ember" onClick={onNew}>
          BEGIN
        </button>
        {hasSave && (
          <button className="btn px-6 py-3 text-xs" onClick={onContinue}>
            CONTINUE
          </button>
        )}
        <button className="btn px-6 py-3 text-xs" onClick={() => setHelp((v) => !v)}>
          {help ? "CLOSE" : "HOW TO SURVIVE"}
        </button>
      </div>

      {help && (
        <div className="panel creep max-w-xl p-3 font-term text-base leading-snug text-bone2">
          <ul className="space-y-1">
            <li>
              <span className="font-pixel text-[10px] text-ember">MOVE</span> — WASD or the arrow keys. On
              touch, use the pad.
            </li>
            <li>
              <span className="font-pixel text-[10px] text-ember">INTERACT</span> — E, Space or Enter. Only
              things inside the lantern's reach can be touched.
            </li>
            <li>
              <span className="font-pixel text-[10px] text-ember">OIL</span> — a full lantern shows roughly six
              tiles. An empty one shows barely three. Find oil.
            </li>
            <li>
              <span className="font-pixel text-[10px] text-ember">EYES</span> — two glowing dots in the black
              means something is closer than you can see it.
            </li>
            <li>
              <span className="font-pixel text-[10px] text-ember">CONTACT</span> — touch a thing and the world
              stops. Combat is turn-based: read its intent, guard, raise the lantern, then strike.
            </li>
            <li>
              <span className="font-pixel text-[10px] text-ember">THUNDER</span> — a lightning flash reveals the
              whole ground for a heartbeat. Use it.
            </li>
          </ul>
        </div>
      )}
    </div>
  );
}
