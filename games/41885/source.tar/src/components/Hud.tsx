import { ITEMS } from "@/game/data";
import type { Player } from "@/game/types";
import type { HudInfo } from "./GameCanvas";

interface Props {
  areaName: string;
  areaSub: string;
  player: Player;
  hud: HudInfo;
  onJournal: () => void;
}

export default function Hud({ areaName, areaSub, player, hud, onJournal }: Props) {
  const hpPct = (player.hp / player.maxHp) * 100;
  const oilPct = (hud.oil / player.maxOil) * 100;
  const low = hud.oil < 15;

  return (
    <>
      {/* top bar */}
      <div className="pointer-events-none absolute left-0 right-0 top-0 z-30 flex items-start justify-between gap-2 p-2 sm:p-3">
        <div className="panel px-2 py-1">
          <div className="font-pixel text-[9px] tracking-widest text-ember sm:text-[11px]">{areaName}</div>
          <div className="font-term text-xs text-bone2/60 sm:text-sm">{areaSub}</div>
        </div>
        <div className="panel flex items-center gap-2 px-2 py-1">
          <span className="font-pixel text-[9px] text-bone2/70">
            {player.cleared.length}/3 HOUSES
          </span>
          <button
            className="btn pointer-events-auto px-2 py-1 text-[9px]"
            onClick={onJournal}
            aria-label="Open journal"
          >
            JOURNAL ({player.notes.length})
          </button>
        </div>
      </div>

      {/* bottom bar */}
      <div className="pointer-events-none absolute bottom-0 left-0 right-0 z-30 flex items-end justify-between gap-2 p-2 sm:p-3">
        <div className="panel w-44 px-2 py-1 sm:w-56">
          <div className="flex items-center justify-between">
            <span className="font-pixel text-[8px] text-bone2/70">VITALITY</span>
            <span className="font-pixel text-[8px] text-bone2">
              {player.hp}/{player.maxHp}
            </span>
          </div>
          <div className="bar mt-0.5 h-2">
            <i style={{ width: `${hpPct}%`, background: "linear-gradient(90deg,#2b5a3a,#7fd8a0)" }} />
          </div>
          <div className="mt-1 flex items-center justify-between">
            <span className={`font-pixel text-[8px] ${low ? "text-blood2" : "text-ember/80"}`}>LANTERN</span>
            <span className="font-pixel text-[8px] text-bone2">{hud.oil}</span>
          </div>
          <div className="bar mt-0.5 h-2">
            <i
              style={{
                width: `${oilPct}%`,
                background: low ? "linear-gradient(90deg,#5c161d,#c8343c)" : "linear-gradient(90deg,#6a4a1a,#ffb95e)",
              }}
            />
          </div>
          <div className="mt-1 flex items-center justify-between font-term text-xs text-bone2/70">
            <span>{ITEMS[player.weapon]?.name}</span>
            <span>ATK {player.atk}</span>
          </div>
        </div>

        <div className="flex flex-col items-end gap-1">
          {hud.aggro > 0 && (
            <div className="panel flick px-2 py-1 font-pixel text-[9px] text-blood2">
              {hud.aggro > 1 ? `${hud.aggro} THINGS ARE WATCHING` : "SOMETHING IS WATCHING"}
            </div>
          )}
          {hud.prompt && (
            <div className="panel px-2 py-1 text-right">
              <div className="font-pixel text-[9px] text-ember">
                [E] {hud.promptKind === "item" ? "TAKE" : hud.promptKind === "note" ? "READ" : hud.promptKind === "altar" ? "TOUCH" : "ENTER"}
              </div>
              <div className="font-term text-sm text-bone2/80">{hud.prompt}</div>
            </div>
          )}
          <div className="panel hidden px-2 py-1 font-term text-xs text-bone2/50 md:block">
            WASD / ARROWS move · E interact · the lantern decides what you can touch
          </div>
        </div>
      </div>
    </>
  );
}
