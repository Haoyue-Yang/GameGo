import { useCallback, useEffect, useRef, useState } from "react";
import CombatScreen, { type CombatResult } from "@/components/CombatScreen";
import EndingScreen from "@/components/EndingScreen";
import GameCanvas, { type HudInfo } from "@/components/GameCanvas";
import Hud from "@/components/Hud";
import TitleScreen from "@/components/TitleScreen";
import { ITEMS, NOTES } from "@/game/data";
import { AREAS, HOUSE_ORDER } from "@/game/maps";
import { clearCache, removeEntity, type Runtime } from "@/game/runtime";
import type { Entity, ItemId, Player } from "@/game/types";

type Screen = "title" | "world" | "combat" | "dead" | "ending";

const SAVE_KEY = "lanternfall.save.v1";

const freshPlayer = (): Player => ({
  hp: 40,
  maxHp: 40,
  atk: 6,
  def: 3,
  spd: 5,
  oil: 100,
  maxOil: 100,
  weapon: "graveIron",
  inv: { tonic: 1, salt: 1 },
  notes: [],
  cleared: [],
  deaths: 0,
});

interface SaveData {
  player: Player;
  removed: string[];
  areaId: string;
}

function loadSave(): SaveData | null {
  try {
    const raw = localStorage.getItem(SAVE_KEY);
    if (!raw) return null;
    const d = JSON.parse(raw) as SaveData;
    if (!d || !d.player || !Array.isArray(d.removed)) return null;
    return d;
  } catch {
    return null;
  }
}

export default function App() {
  const [screen, setScreen] = useState<Screen>("title");
  const [player, setPlayer] = useState<Player>(freshPlayer);
  const [areaId, setAreaId] = useState("graveyard");
  const [removed, setRemoved] = useState<Set<string>>(new Set());
  const [combat, setCombat] = useState<{ enemyId: string; entityId: string } | null>(null);
  const [hud, setHud] = useState<HudInfo>({ oil: 100, prompt: null, promptKind: null, promptLabel: null, aggro: 0 });
  const [toast, setToast] = useState<string | null>(null);
  const [journal, setJournal] = useState(false);
  const [note, setNote] = useState<string | null>(null);
  const [resetKey, setResetKey] = useState(0);
  const [hasSave, setHasSave] = useState(false);
  const rtRef = useRef<Runtime | null>(null);

  useEffect(() => {
    setHasSave(!!loadSave());
  }, []);

  const say = useCallback((msg: string) => {
    setToast(msg);
    window.setTimeout(() => setToast((t) => (t === msg ? null : t)), 2600);
  }, []);

  /* ---------------- persistence ---------------- */
  useEffect(() => {
    if (screen === "title") return;
    try {
      localStorage.setItem(SAVE_KEY, JSON.stringify({ player, removed: [...removed], areaId }));
    } catch {
      /* ignore */
    }
  }, [player, removed, areaId, screen]);

  /* ---------------- world interactions ---------------- */
  const killEntity = useCallback((id: string) => {
    const rt = rtRef.current;
    if (rt) removeEntity(rt, id);
    setRemoved((prev) => {
      const n = new Set(prev);
      n.add(id);
      return n;
    });
  }, []);

  const onInteract = useCallback(
    (e: Entity) => {
      if (e.kind === "item") {
        const id = e.ref as ItemId;
        const def = ITEMS[id];
        if (!def) return;
        killEntity(e.id);
        setPlayer((p) => {
          const n = { ...p, inv: { ...p.inv } };
          if (id === "oil") {
            n.oil = Math.min(p.maxOil, p.oil + 35);
            say("Lamp oil. The lantern swells and the dark backs off.");
          } else if (id === "tonic") {
            n.inv.tonic = (n.inv.tonic ?? 0) + 1;
            say("Grave tonic, bottled and cold.");
          } else if (id === "salt") {
            n.inv.salt = (n.inv.salt ?? 0) + 1;
            say("Hymn salt. It hums faintly.");
          } else if (id === "wardCharm") {
            n.inv.wardCharm = (n.inv.wardCharm ?? 0) + 1;
            say("A ward charm, still warm.");
          } else if (id === "graveIron") {
            n.weapon = "graveIron";
            n.atk = p.atk + 3;
            say("Grave iron. ATK +3.");
          } else if (id === "glassBlade") {
            n.weapon = "glassBlade";
            n.atk = p.atk + 6;
            say("A glass blade, sharp as a rumour. ATK +6.");
          }
          return n;
        });
      } else if (e.kind === "note") {
        killEntity(e.id);
        setNote(e.ref ?? null);
        setPlayer((p) => (p.notes.includes(e.ref ?? "") ? p : { ...p, notes: [...p.notes, e.ref ?? ""] }));
      } else if (e.kind === "exit") {
        const dest = e.ref ?? "graveyard";
        setAreaId(dest);
        setResetKey((k) => k + 1);
        say(AREAS[dest].name);
      } else if (e.kind === "altar") {
        if (player.cleared.length >= 3) {
          setScreen("ending");
        } else {
          say(`The altar is cold. ${3 - player.cleared.length} house${player.cleared.length === 2 ? "" : "es"} still stand.`);
        }
      }
    },
    [killEntity, player.cleared.length, say],
  );

  const onContact = useCallback((enemyId: string) => {
    const rt = rtRef.current;
    if (!rt) return;
    const ent = rt.entities.find((x) => x.id === rt.contact);
    setCombat({ enemyId, entityId: ent?.id ?? "" });
    setScreen("combat");
  }, []);

  const onCombatEnd = useCallback(
    (r: CombatResult) => {
      const c = combat;
      setPlayer((p) => ({ ...p, hp: r.hp, oil: r.oil, inv: r.inv }));
      if (r.result === "won" && c) {
        killEntity(c.entityId);
        const area = AREAS[areaId];
        if (area.bossId && c.enemyId === area.bossId && !player.cleared.includes(area.id)) {
          setPlayer((p) => {
            const maxHp = p.maxHp + 10;
            return { ...p, cleared: [...p.cleared, area.id], maxHp, hp: Math.min(maxHp, p.hp + 10) };
          });
          say(`${area.name} is quiet. The house is cleared. +10 vitality.`);
        }
      } else if (r.result === "lost") {
        setPlayer((p) => ({ ...p, deaths: p.deaths + 1 }));
        setScreen("dead");
      }
      const rt = rtRef.current;
      if (rt) {
        rt.contact = null;
        rt.grace = 1.6;
      }
      setCombat(null);
      setScreen("world");
    },
    [areaId, combat, killEntity, player.cleared, say],
  );

  /* ---------------- flow ---------------- */
  const newGame = () => {
    clearCache();
    setPlayer(freshPlayer());
    setRemoved(new Set());
    setAreaId("graveyard");
    setResetKey((k) => k + 1);
    setScreen("world");
    setToast("ST. COLDWATER GRAVEYARD — three gates, three houses. Follow the cold light.");
  };

  const continueGame = () => {
    const d = loadSave();
    if (!d) return newGame();
    clearCache();
    setPlayer({ ...freshPlayer(), ...d.player });
    setRemoved(new Set(d.removed));
    setAreaId(d.areaId ?? "graveyard");
    setResetKey((k) => k + 1);
    setScreen("world");
  };

  const respawn = () => {
    setPlayer((p) => ({ ...p, hp: Math.max(12, Math.ceil(p.maxHp * 0.6)), oil: Math.max(p.oil, 45) }));
    setAreaId("graveyard");
    setResetKey((k) => k + 1);
    setScreen("world");
    say("You wake at the south gate. The lantern is still yours. That is not nothing.");
  };

  const area = AREAS[areaId];
  const lowHp = player.hp / player.maxHp < 0.3;

  return (
    <div className="crt grain relative h-full w-full overflow-hidden bg-ink">
      {/* world */}
      {(screen === "world" || screen === "combat" || screen === "dead") && (
        <div className="absolute inset-0 flex items-center justify-center p-1 sm:p-3">
          <GameCanvas
            areaId={areaId}
            removed={removed}
            oil={player.oil}
            active={screen === "world" && !journal && !note}
            resetKey={resetKey}
            onContact={onContact}
            onInteract={onInteract}
            onHud={setHud}
            onRuntime={(rt) => {
              rtRef.current = rt;
            }}
          />
        </div>
      )}

      {screen === "world" && (
        <Hud
          areaName={area.name}
          areaSub={area.subtitle}
          player={player}
          hud={hud}
          onJournal={() => setJournal(true)}
        />
      )}

      {/* low health pulse */}
      {lowHp && screen !== "title" && (
        <div
          className="pointer-events-none absolute inset-0 z-20"
          style={{
            background: "radial-gradient(ellipse at center, rgba(0,0,0,0) 45%, rgba(120,10,16,0.4) 100%)",
            animation: "flick 2.6s infinite steps(1,end)",
          }}
        />
      )}

      {/* toast */}
      {toast && (
        <div className="pointer-events-none absolute left-1/2 top-16 z-40 -translate-x-1/2">
          <div className="panel creep px-3 py-1 text-center font-term text-base text-bone2">{toast}</div>
        </div>
      )}

      {/* combat */}
      {screen === "combat" && combat && (
        <div className="absolute inset-0 z-40 flex items-center justify-center bg-black/72 backdrop-blur-[1px]">
          <CombatScreen enemyId={combat.enemyId} player={player} onEnd={onCombatEnd} />
        </div>
      )}

      {/* death */}
      {screen === "dead" && (
        <div className="absolute inset-0 z-40 flex flex-col items-center justify-center gap-4 bg-black/88 p-4">
          <h2 className="glow font-pixel text-xl tracking-widest-xl text-blood2 sm:text-3xl">THE LANTERN GOES OUT</h2>
          <p className="max-w-lg text-center font-term text-lg leading-snug text-bone2">
            The rain closes over you. Somewhere a verse is completed, and it is almost your voice.
          </p>
          <div className="flex flex-wrap items-center justify-center gap-2">
            <button className="btn px-6 py-3 text-xs text-ember" onClick={respawn}>
              RISE AGAIN
            </button>
            <button className="btn px-6 py-3 text-xs" onClick={() => setScreen("title")}>
              ABANDON
            </button>
          </div>
          <p className="font-term text-sm text-bone2/50">
            Progress is kept. {player.cleared.length}/3 houses cleared.
          </p>
        </div>
      )}

      {/* note reader */}
      {note && (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/80 p-4">
          <div className="panel creep max-w-lg p-4">
            <div className="font-pixel text-[11px] tracking-widest text-ember">
              {NOTES[note]?.title ?? "A page"}
            </div>
            <p className="mt-2 font-term text-lg leading-snug text-bone2">{NOTES[note]?.body}</p>
            <button className="btn mt-3 px-5 py-2 text-[10px]" onClick={() => setNote(null)}>
              CLOSE
            </button>
          </div>
        </div>
      )}

      {/* journal */}
      {journal && (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/85 p-4">
          <div className="panel creep max-h-[86vh] w-full max-w-2xl overflow-y-auto p-4 scroll">
            <div className="flex items-center justify-between">
              <h2 className="font-pixel text-sm tracking-widest text-ember">JOURNAL</h2>
              <button className="btn px-3 py-1 text-[10px]" onClick={() => setJournal(false)}>
                CLOSE
              </button>
            </div>

            <div className="mt-3 grid gap-3 sm:grid-cols-2">
              <div>
                <div className="font-pixel text-[9px] text-bone2/60">THE THREE HOUSES</div>
                <ul className="mt-1 space-y-1 font-term text-base">
                  {HOUSE_ORDER.map((id) => {
                    const done = player.cleared.includes(id);
                    return (
                      <li key={id} className={done ? "text-moss" : "text-bone2/80"}>
                        {done ? "✕" : "·"} {AREAS[id].name}
                        <div className="font-term text-sm text-bone2/50">{AREAS[id].subtitle}</div>
                      </li>
                    );
                  })}
                </ul>
              </div>
              <div>
                <div className="font-pixel text-[9px] text-bone2/60">SATCHEL</div>
                <ul className="mt-1 space-y-1 font-term text-base text-bone2/80">
                  <li>{ITEMS[player.weapon].name} — ATK {player.atk}, DEF {player.def}, SPD {player.spd}</li>
                  <li>Lantern oil — {hud.oil}/{player.maxOil}</li>
                  {Object.entries(player.inv)
                    .filter(([, v]) => v > 0)
                    .map(([k, v]) => (
                      <li key={k}>
                        {ITEMS[k as ItemId]?.name ?? k} ×{v}
                      </li>
                    ))}
                  {Object.values(player.inv).every((v) => !v) && <li className="text-bone2/50">Nothing but the lantern.</li>}
                </ul>
              </div>
            </div>

            <div className="mt-4">
              <div className="font-pixel text-[9px] text-bone2/60">NOTES ({player.notes.length})</div>
              {player.notes.length === 0 && (
                <p className="mt-1 font-term text-base text-bone2/50">You have read nothing yet.</p>
              )}
              <div className="mt-1 space-y-2">
                {player.notes.map((n) => (
                  <div key={n} className="border-l border-ember/30 pl-2">
                    <div className="font-pixel text-[9px] text-ember/80">{NOTES[n]?.title}</div>
                    <p className="font-term text-base leading-snug text-bone2/80">{NOTES[n]?.body}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* title */}
      {screen === "title" && (
        <div className="absolute inset-0 z-50">
          <TitleScreen hasSave={hasSave} onNew={newGame} onContinue={continueGame} />
        </div>
      )}

      {/* ending */}
      {screen === "ending" && (
        <div className="absolute inset-0 z-50">
          <EndingScreen
            notes={player.notes.length}
            deaths={player.deaths}
            onRestart={() => {
              setHasSave(false);
              try {
                localStorage.removeItem(SAVE_KEY);
              } catch {
                /* ignore */
              }
              newGame();
            }}
          />
        </div>
      )}
    </div>
  );
}
