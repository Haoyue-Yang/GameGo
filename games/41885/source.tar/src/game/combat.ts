import { ENEMIES, ITEMS, STATUS, type MoveDef, type Status, type StatusId } from "./data";
import type { ItemId, Player } from "./types";

export interface LogLine {
  text: string;
  tone: "you" | "them" | "sys" | "crit" | "bad" | "good";
}

export interface Fx {
  side: "player" | "enemy";
  kind: "hit" | "crit" | "miss" | "heal" | "block" | "guard";
  v: number;
}

export interface CombatState {
  enemyId: string;
  eHp: number;
  eMax: number;
  eStatus: Status[];
  pHp: number;
  pMax: number;
  pDef: number;
  pStatus: Status[];
  phase: "intro" | "player" | "enemy" | "won" | "lost" | "fled";
  round: number;
  resolve: number;
  guarding: boolean;
  log: LogLine[];
  intent: MoveDef | null;
  fx: Fx | null;
  shake: number;
  oil: number;
  inv: Record<string, number>;
  boss: boolean;
}

export type Action =
  | { t: "strike" }
  | { t: "guard" }
  | { t: "lantern" }
  | { t: "heavy" }
  | { t: "flee" }
  | { t: "item"; item: ItemId };

const rnd = (n: number) => Math.floor(Math.random() * n);
const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v));

function clone(cs: CombatState): CombatState {
  return {
    ...cs,
    eStatus: cs.eStatus.map((s) => ({ ...s })),
    pStatus: cs.pStatus.map((s) => ({ ...s })),
    log: [...cs.log],
    inv: { ...cs.inv },
  };
}

function push(cs: CombatState, text: string, tone: LogLine["tone"] = "sys") {
  cs.log = [...cs.log, { text, tone }].slice(-30);
}

const has = (list: Status[], id: StatusId) => list.some((s) => s.id === id);

function addStatus(list: Status[], id: StatusId, turns: number) {
  const ex = list.find((s) => s.id === id);
  if (ex) ex.turns = Math.max(ex.turns, turns);
  else list.push({ id, turns });
}

function tick(list: Status[]): number {
  let dmg = 0;
  for (const s of list) {
    if (s.id === "burning") dmg += 4;
    if (s.id === "bleeding") dmg += 3;
  }
  for (const s of list) s.turns -= 1;
  for (let i = list.length - 1; i >= 0; i--) if (list[i].turns <= 0) list.splice(i, 1);
  return dmg;
}

function rollDamage(atk: number, def: number, mult: number, warded: boolean): number {
  let d = atk * mult - Math.max(0, def);
  d = Math.max(1, d + rnd(3));
  if (warded) d *= 0.5;
  return Math.max(1, Math.round(d));
}

export function startCombat(player: Player, enemyId: string): CombatState {
  const e = ENEMIES[enemyId];
  const cs: CombatState = {
    enemyId,
    eHp: e.hp,
    eMax: e.hp,
    eStatus: [],
    pHp: player.hp,
    pMax: player.maxHp,
    pDef: player.def,
    pStatus: [],
    phase: "intro",
    round: 1,
    resolve: 0,
    guarding: false,
    log: [],
    intent: null,
    fx: null,
    shake: 0,
    oil: player.oil,
    inv: { ...player.inv },
    boss: !!e.boss,
  };
  push(cs, `${e.name} steps out of the dark.`, "them");
  push(cs, e.desc, "sys");
  cs.intent = pickIntent(cs);
  return cs;
}

function pickIntent(cs: CombatState): MoveDef | null {
  const e = ENEMIES[cs.enemyId];
  const total = e.moves.reduce((a, m) => a + m.weight, 0);
  let r = Math.random() * total;
  for (const m of e.moves) {
    r -= m.weight;
    if (r <= 0) return m;
  }
  return e.moves[0];
}

/* ------------------------------------------------------------------ *
 * player turn
 * ------------------------------------------------------------------ */
export function playerAct(cs0: CombatState, player: Player, action: Action): CombatState {
  const cs = clone(cs0);
  const e = ENEMIES[cs.enemyId];
  cs.fx = null;
  cs.shake = 0;

  // burn / bleed tick at the start of the player's turn
  const selfDmg = tick(cs.pStatus);
  if (selfDmg > 0) {
    cs.pHp = Math.max(0, cs.pHp - selfDmg);
    push(cs, `You burn and bleed for ${selfDmg}.`, "bad");
  }
  if (cs.pHp <= 0) {
    cs.phase = "lost";
    push(cs, "The lantern goes out. So do you.", "bad");
    return cs;
  }
  if (has(cs.pStatus, "stunned")) {
    push(cs, "You are stunned — the verse holds you in place.", "bad");
    cs.phase = "enemy";
    return cs;
  }

  switch (action.t) {
    case "strike": {
      const crit = Math.random() < 0.13;
      if (Math.random() > 0.94) {
        push(cs, "Your swing goes wide into the dark.", "you");
        cs.resolve = Math.min(9, cs.resolve + 1);
        cs.fx = { side: "enemy", kind: "miss", v: 0 };
        break;
      }
      const d = rollDamage(player.atk, Math.max(0, e.def - (has(cs.eStatus, "cursed") ? 3 : 0)), crit ? 1.85 : 1, has(cs.eStatus, "warded"));
      cs.eHp = Math.max(0, cs.eHp - d);
      cs.resolve = Math.min(9, cs.resolve + 1);
      cs.fx = { side: "enemy", kind: crit ? "crit" : "hit", v: d };
      cs.shake = crit ? 1 : 0.5;
      push(cs, crit ? `CRITICAL — ${d} damage. It screams in a voice that is not its own.` : `You strike for ${d}.`, crit ? "crit" : "you");
      break;
    }
    case "guard": {
      cs.guarding = true;
      cs.resolve = Math.min(9, cs.resolve + 2);
      cs.pHp = Math.min(cs.pMax, cs.pHp + 1);
      cs.fx = { side: "player", kind: "guard", v: 0 };
      push(cs, "You raise the lantern and brace. Resolve +2.", "good");
      break;
    }
    case "lantern": {
      const cost = 8;
      if (cs.oil < cost) {
        push(cs, "Not enough oil. The flame will not answer.", "bad");
        break;
      }
      cs.oil -= cost;
      const d = Math.max(2, Math.round(3 + player.atk * 0.25));
      cs.eHp = Math.max(0, cs.eHp - d);
      addStatus(cs.eStatus, "blinded", 2);
      cs.fx = { side: "enemy", kind: "hit", v: d };
      cs.shake = 0.8;
      push(cs, `You raise the lantern. ${d} damage — ${e.name} is BLINDED.`, "crit");
      break;
    }
    case "heavy": {
      if (cs.resolve < 5) break;
      cs.resolve = 0;
      const d = rollDamage(player.atk * 2.2, Math.max(0, e.def - (has(cs.eStatus, "cursed") ? 3 : 0)), 1, has(cs.eStatus, "warded"));
      cs.eHp = Math.max(0, cs.eHp - d);
      cs.fx = { side: "enemy", kind: "crit", v: d };
      cs.shake = 1.4;
      push(cs, `HEAVY BLOW — ${d} damage. The dark flinches.`, "crit");
      break;
    }
    case "flee": {
      if (e.boss) {
        push(cs, "It has already decided you stay.", "bad");
        break;
      }
      const chance = clamp(0.3 + (player.spd - e.spd) * 0.09, 0.08, 0.85);
      if (Math.random() < chance) {
        cs.phase = "fled";
        push(cs, "You run. The lantern swings behind you like a tail.", "good");
        return cs;
      } else {
        push(cs, "You cannot get away. It is faster in the dark.", "bad");
        cs.phase = "enemy";
        return cs;
      }
      break;
    }
    case "item": {
      if (!cs.inv[action.item] || !ITEMS[action.item]) break;
      cs.inv[action.item] -= 1;
      if (action.item === "tonic") {
        const h = Math.min(14, cs.pMax - cs.pHp);
        cs.pHp += h;
        cs.fx = { side: "player", kind: "heal", v: h };
        push(cs, `You drink the tonic. +${h} vitality.`, "good");
      } else if (action.item === "oil") {
        cs.oil = Math.min(100, cs.oil + 35);
        push(cs, "You feed the lantern. The dark pulls back a little.", "good");
      } else if (action.item === "salt") {
        const d = 12;
        cs.eHp = Math.max(0, cs.eHp - d);
        addStatus(cs.eStatus, "blinded", 1);
        cs.fx = { side: "enemy", kind: "hit", v: d };
        push(cs, `Hymn salt bursts. ${d} damage and it is BLINDED.`, "crit");
      } else if (action.item === "wardCharm") {
        addStatus(cs.pStatus, "warded", 3);
        push(cs, "The charm warms. You are WARDed.", "good");
      }
      break;
    }
  }

  if (cs.eHp <= 0) {
    cs.phase = "won";
    push(cs, `${e.name} comes apart like wet paper.`, "good");
    return cs;
  }
  cs.guarding = false;
  cs.phase = "enemy";
  return cs;
}

/* ------------------------------------------------------------------ *
 * enemy turn
 * ------------------------------------------------------------------ */
export function enemyAct(cs0: CombatState): CombatState {
  const cs = clone(cs0);
  const e = ENEMIES[cs.enemyId];
  cs.fx = null;
  cs.shake = 0;
  cs.round += 1;

  const selfDmg = tick(cs.eStatus);
  if (selfDmg > 0) {
    cs.eHp = Math.max(0, cs.eHp - selfDmg);
    push(cs, `${e.name} takes ${selfDmg} from its own wounds.`, "good");
  }
  if (cs.eHp <= 0) {
    cs.phase = "won";
    push(cs, `${e.name} comes apart like wet paper.`, "good");
    return cs;
  }
  if (has(cs.eStatus, "stunned")) {
    push(cs, `${e.name} is stunned and cannot move.`, "good");
    cs.phase = "player";
    cs.intent = pickIntent(cs);
    return cs;
  }

  const mv = cs.intent ?? pickIntent(cs);
  const blinded = has(cs.eStatus, "blinded");
  const atkMod = (blinded ? -0.25 : 0) + (has(cs.eStatus, "drained") ? -0.2 : 0) + (has(cs.eStatus, "chilled") ? -0.15 : 0);
  const warded = has(cs.pStatus, "warded");
  const cursedDef = has(cs.pStatus, "cursed") ? -3 : 0;
  const guardMul = cs.guarding ? 0.4 : 1;

  push(cs, mv.tell, "them");

  switch (mv.kind) {
    case "attack":
    case "heavy": {
      const acc = 0.92 * (blinded ? 0.45 : 1);
      if (Math.random() > acc) {
        push(cs, `${e.name} misses.`, "good");
        cs.fx = { side: "player", kind: "miss", v: 0 };
        break;
      }
      let d = rollDamage(e.atk * (1 + atkMod) * mv.power, Math.max(0, cs.pDef + cursedDef), 1, warded);
      d = Math.max(1, Math.round(d * guardMul));
      cs.pHp = Math.max(0, cs.pHp - d);
      cs.fx = { side: "player", kind: cs.guarding ? "block" : "hit", v: d };
      cs.shake = cs.guarding ? 0.4 : 1;
      push(cs, cs.guarding ? `You block ${mv.name} — ${d} damage.` : `${mv.name} lands for ${d}.`, cs.guarding ? "good" : "bad");
      if (mv.status && Math.random() < mv.status.chance) {
        addStatus(cs.pStatus, mv.status.id, mv.status.turns);
        push(cs, `You are ${STATUS[mv.status.id].name.toUpperCase()} — ${STATUS[mv.status.id].desc}.`, "bad");
      }
      break;
    }
    case "heal": {
      const h = Math.min(mv.heal ?? 10, cs.eMax - cs.eHp);
      cs.eHp += h;
      cs.fx = { side: "enemy", kind: "heal", v: h };
      push(cs, `${e.name} mends itself for ${h}.`, "bad");
      break;
    }
    case "buff": {
      if (mv.status && Math.random() < mv.status.chance) {
        addStatus(cs.eStatus, mv.status.id, mv.status.turns);
        push(cs, `${e.name} is ${STATUS[mv.status.id].name.toUpperCase()}.`, "bad");
      }
      break;
    }
    case "debuff":
    case "drain": {
      if (mv.power > 0) {
        let d = rollDamage(e.atk * (1 + atkMod) * mv.power, Math.max(0, cs.pDef + cursedDef), 1, warded);
        d = Math.max(1, Math.round(d * guardMul));
        cs.pHp = Math.max(0, cs.pHp - d);
        cs.fx = { side: "player", kind: cs.guarding ? "block" : "hit", v: d };
        cs.shake = 0.7;
        push(cs, `${mv.name} — ${d} damage.`, "bad");
      }
      if (mv.name === "Snuff") {
        const lost = Math.min(cs.oil, 14);
        cs.oil -= lost;
        push(cs, `The lure drinks ${lost} oil. Your lantern gutters.`, "bad");
      }
      if (mv.status && Math.random() < mv.status.chance) {
        addStatus(cs.pStatus, mv.status.id, mv.status.turns);
        push(cs, `You are ${STATUS[mv.status.id].name.toUpperCase()} — ${STATUS[mv.status.id].desc}.`, "bad");
      }
      break;
    }
    case "guard": {
      addStatus(cs.eStatus, "warded", 2);
      push(cs, `${e.name} hardens.`, "bad");
      break;
    }
  }

  if (cs.pHp <= 0) {
    cs.phase = "lost";
    push(cs, "The lantern goes out. So do you.", "bad");
    return cs;
  }
  cs.guarding = false;
  cs.phase = "player";
  cs.intent = pickIntent(cs);
  return cs;
}

export function intentText(mv: MoveDef | null): string {
  if (!mv) return "…";
  if (mv.kind === "heal") return "It will mend itself";
  if (mv.kind === "buff") return "It will harden";
  if (mv.kind === "heavy") return `It is winding up ${mv.name}`;
  return `It will use ${mv.name}`;
}
