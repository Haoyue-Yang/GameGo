import { ENEMIES } from "./data";
import { VIEW_H, VIEW_W, lightRadius, los, type Runtime } from "./runtime";
import { TILE, drawCreature, drawPickup, drawPlayer, drawTile } from "./tiles";
import type { Area, Entity } from "./types";

const mapCache = new Map<string, HTMLCanvasElement>();
let lightCv: HTMLCanvasElement | null = null;

function getMap(area: Area): HTMLCanvasElement {
  let c = mapCache.get(area.id);
  if (c) return c;
  c = document.createElement("canvas");
  c.width = area.w * TILE;
  c.height = area.h * TILE;
  const g = c.getContext("2d")!;
  g.imageSmoothingEnabled = false;
  for (let y = 0; y < area.h; y++) {
    for (let x = 0; x < area.w; x++) {
      drawTile(g, area.tiles[y * area.w + x], x * TILE, y * TILE, x, y);
    }
  }
  mapCache.set(area.id, c);
  return c;
}

const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v));

export function render(ctx: CanvasRenderingContext2D, rt: Runtime) {
  const { area } = rt;
  const map = getMap(area);
  ctx.imageSmoothingEnabled = false;

  let camX = rt.px * TILE - VIEW_W / 2;
  let camY = rt.py * TILE - VIEW_H / 2;
  const maxX = area.w * TILE - VIEW_W;
  const maxY = area.h * TILE - VIEW_H;
  camX = maxX <= 0 ? maxX / 2 : clamp(camX, 0, maxX);
  camY = maxY <= 0 ? maxY / 2 : clamp(camY, 0, maxY);
  const sh = rt.shake;
  camX += (Math.random() - 0.5) * sh * 5;
  camY += (Math.random() - 0.5) * sh * 5;
  const ox = -camX;
  const oy = -camY;

  ctx.fillStyle = "#04040a";
  ctx.fillRect(0, 0, VIEW_W, VIEW_H);
  ctx.drawImage(map, Math.round(ox), Math.round(oy));

  const x0 = Math.max(0, Math.floor(camX / TILE) - 1);
  const y0 = Math.max(0, Math.floor(camY / TILE) - 1);
  const x1 = Math.min(area.w - 1, Math.ceil((camX + VIEW_W) / TILE));
  const y1 = Math.min(area.h - 1, Math.ceil((camY + VIEW_H) / TILE));

  // animated water shimmer
  for (let y = y0; y <= y1; y++) {
    for (let x = x0; x <= x1; x++) {
      if (area.tiles[y * area.w + x] !== "water") continue;
      const ph = Math.sin(rt.t * 2.2 + x * 0.9 + y * 1.3);
      if (ph > 0.55) {
        ctx.fillStyle = "rgba(120,190,230,0.10)";
        ctx.fillRect(Math.round(ox + x * TILE + 3), Math.round(oy + y * TILE + 5 + ph * 4), 9, 1);
      }
    }
  }

  // footstep ripples
  for (const r of rt.ripples) {
    ctx.strokeStyle = `rgba(180,200,220,${Math.max(0, r.a) * 0.35})`;
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.ellipse(Math.round(ox + r.x * TILE), Math.round(oy + r.y * TILE), r.r, r.r * 0.45, 0, 0, Math.PI * 2);
    ctx.stroke();
  }

  // entities
  for (const e of rt.entities) {
    const ex = ox + (e.fx ?? e.x + 0.5) * TILE;
    const ey = oy + (e.fy ?? e.y + 0.5) * TILE;
    if (ex < -24 || ey < -32 || ex > VIEW_W + 24 || ey > VIEW_H + 32) continue;
    const i = Math.floor(e.y) * area.w + Math.floor(e.x);
    const lit = rt.light[i];
    if (e.kind === "item" || e.kind === "note") {
      if (lit < 0.05 && rt.bolt < 0.05) continue;
      drawPickup(ctx, e.ref ?? "note", ex, ey, 1, rt.t + e.x);
      if (lit > 0.25) {
        ctx.globalAlpha = 0.18 + Math.sin(rt.t * 3 + e.x) * 0.06;
        ctx.fillStyle = e.kind === "item" ? "#ffb95e" : "#c8c0a8";
        ctx.fillRect(Math.round(ex - 4), Math.round(ey - 6), 8, 12);
        ctx.globalAlpha = 1;
      }
    } else if (e.kind === "exit") {
      // a cold light bleeds through the gate — visible even in the black, if you can see the line
      const dd = Math.hypot(rt.px - (e.fx ?? e.x + 0.5), rt.py - (e.fy ?? e.y + 0.5));
      if (dd < 17 && los(area, rt.px, rt.py, e.fx ?? e.x + 0.5, e.fy ?? e.y + 0.5)) {
        const far = clamp(1 - dd / 17, 0, 1);
        ctx.globalCompositeOperation = "lighter";
        ctx.globalAlpha = 0.08 + far * 0.3;
        ctx.fillStyle = "#3f74a8";
        ctx.fillRect(Math.round(ex - 8), Math.round(ey - 11), 16, 22);
        ctx.globalAlpha = 1;
        ctx.globalCompositeOperation = "source-over";
      }
      if (lit < 0.05 && rt.bolt < 0.05) continue;
      ctx.globalAlpha = 0.25 + Math.sin(rt.t * 2.4) * 0.08;
      ctx.fillStyle = "#6f9ec4";
      ctx.fillRect(Math.round(ex - 7), Math.round(ey - 9), 14, 18);
      ctx.globalAlpha = 1;
      ctx.fillStyle = "#9fd8e8";
      ctx.fillRect(Math.round(ex - 1), Math.round(ey - 5), 2, 10);
      ctx.fillRect(Math.round(ex - 4), Math.round(ey - 5), 8, 2);
    } else if (e.kind === "altar") {
      const pulse = 0.3 + Math.sin(rt.t * 1.8) * 0.12;
      ctx.globalAlpha = pulse;
      ctx.fillStyle = "#c8343c";
      ctx.fillRect(Math.round(ex - 10), Math.round(ey - 12), 20, 24);
      ctx.globalAlpha = 1;
    }
  }

  // enemies
  const eyeRange = lightRadius(rt.oil) * 2.1;
  for (const e of rt.entities) {
    if (e.kind !== "enemy") continue;
    const def = ENEMIES[e.ref ?? ""];
    if (!def) continue;
    const ex = ox + (e.fx ?? e.x + 0.5) * TILE;
    const ey = oy + (e.fy ?? e.y + 0.5) * TILE;
    if (ex < -32 || ey < -40 || ex > VIEW_W + 32 || ey > VIEW_H + 40) continue;
    const i = Math.floor(e.y) * area.w + Math.floor(e.x);
    const lit = rt.light[i];
    const d = Math.hypot(rt.px - (e.fx ?? e.x + 0.5), rt.py - (e.fy ?? e.y + 0.5));
    const u = def.boss ? 1.5 : 1;
    if (lit > 0.04 || rt.bolt > 0.05) {
      drawCreature(ctx, def.sprite, ex, ey, u, { lit: Math.max(lit, rt.bolt * 0.8), t: rt.t });
    } else if (d < eyeRange) {
      // only the eyes survive the dark
      const a = clamp(1 - d / eyeRange, 0, 1) * (e.aggro ? 1 : 0.62);
      const c = def.boss ? "#ff6a4a" : "#ff8a3a";
      ctx.globalCompositeOperation = "lighter";
      ctx.globalAlpha = a * 0.5;
      ctx.fillStyle = c;
      ctx.fillRect(Math.round(ex - 4 * u), Math.round(ey - 5 * u), 9 * u, 3 * u);
      ctx.globalAlpha = a;
      ctx.fillStyle = "#ffd0a0";
      ctx.fillRect(Math.round(ex - 3 * u), Math.round(ey - 4.4 * u), 1.6 * u, 1.6 * u);
      ctx.fillRect(Math.round(ex + 1.4 * u), Math.round(ey - 4.4 * u), 1.6 * u, 1.6 * u);
      ctx.globalAlpha = 1;
      ctx.globalCompositeOperation = "source-over";
    }
  }

  // player
  drawPlayer(ctx, ox + rt.px * TILE, oy + rt.py * TILE, 1, rt.facing, rt.t, rt.moving);

  /* ---------------- darkness / lantern mask ---------------- */
  if (!lightCv) {
    lightCv = document.createElement("canvas");
    lightCv.width = VIEW_W;
    lightCv.height = VIEW_H;
  }
  const lc = lightCv.getContext("2d")!;
  lc.globalCompositeOperation = "source-over";
  lc.clearRect(0, 0, VIEW_W, VIEW_H);
  lc.fillStyle = "#000000";
  lc.fillRect(0, 0, VIEW_W, VIEW_H);
  lc.globalCompositeOperation = "destination-out";

  // remembered ground (dim memory of where the lantern has been)
  const mr = Math.ceil(lightRadius(rt.oil) * 2.6);
  for (let y = y0; y <= y1; y++) {
    for (let x = x0; x <= x1; x++) {
      const i = y * area.w + x;
      if (rt.seen[i] < 0.05) continue;
      if (Math.abs(x - rt.px) > mr || Math.abs(y - rt.py) > mr) continue;
      const a = 0.1 + rt.seen[i] * 0.1;
      lc.fillStyle = `rgba(0,0,0,${a})`;
      lc.fillRect(Math.round(ox + x * TILE), Math.round(oy + y * TILE), TILE, TILE);
    }
  }

  // lit ground — soft blobs so the lantern edge is organic
  const R = 12;
  for (let y = y0; y <= y1; y++) {
    for (let x = x0; x <= x1; x++) {
      const i = y * area.w + x;
      const v = rt.light[i];
      if (v <= 0.02) continue;
      const cx = ox + x * TILE + TILE / 2;
      const cy = oy + y * TILE + TILE / 2;
      const g = lc.createRadialGradient(cx, cy, 0, cx, cy, R);
      g.addColorStop(0, `rgba(0,0,0,${Math.min(1, v)})`);
      g.addColorStop(0.5, `rgba(0,0,0,${Math.min(1, v * 0.8)})`);
      g.addColorStop(1, "rgba(0,0,0,0)");
      lc.fillStyle = g;
      lc.fillRect(cx - R, cy - R, R * 2, R * 2);
    }
  }

  // lightning reveals everything, briefly
  if (rt.bolt > 0.02) {
    lc.globalAlpha = Math.min(0.82, rt.bolt * 1.5);
    lc.fillStyle = "#000000";
    lc.fillRect(0, 0, VIEW_W, VIEW_H);
    lc.globalAlpha = 1;
  }

  ctx.drawImage(lightCv, 0, 0);

  /* ---------------- warm lantern glow ---------------- */
  ctx.globalCompositeOperation = "lighter";
  const pcx = ox + rt.px * TILE;
  const pcy = oy + rt.py * TILE;
  const rad = lightRadius(rt.oil) * TILE * rt.flicker;
  const gg = ctx.createRadialGradient(pcx, pcy, 0, pcx, pcy, rad);
  gg.addColorStop(0, `rgba(255,196,120,${0.2 * rt.flicker})`);
  gg.addColorStop(0.45, `rgba(255,150,70,${0.08 * rt.flicker})`);
  gg.addColorStop(1, "rgba(0,0,0,0)");
  ctx.fillStyle = gg;
  ctx.fillRect(pcx - rad, pcy - rad, rad * 2, rad * 2);
  ctx.globalCompositeOperation = "source-over";

  // cold ambient tint
  ctx.fillStyle = area.kind === "house" ? "rgba(30,40,64,0.16)" : "rgba(24,36,58,0.2)";
  ctx.fillRect(0, 0, VIEW_W, VIEW_H);

  // lightning flash
  if (rt.bolt > 0.02) {
    ctx.fillStyle = `rgba(190,215,255,${Math.min(0.42, rt.bolt * 0.6)})`;
    ctx.fillRect(0, 0, VIEW_W, VIEW_H);
  }

  /* ---------------- rain ---------------- */
  const rainA = 0.1 + area.rain * 0.3;
  ctx.strokeStyle = `rgba(190,215,235,${rainA})`;
  ctx.lineWidth = 1;
  ctx.beginPath();
  for (const d of rt.drops) {
    ctx.moveTo(d.x, d.y);
    ctx.lineTo(d.x - d.l * 0.22, d.y - d.l);
  }
  ctx.stroke();
  if (area.rain > 0.4) {
    ctx.fillStyle = `rgba(200,220,240,${0.05 + area.rain * 0.06})`;
    for (let i = 0; i < 26; i++) {
      const rx = (i * 97 + Math.floor(rt.t * 220)) % VIEW_W;
      const ry = (i * 53 + Math.floor(rt.t * 460)) % VIEW_H;
      ctx.fillRect(rx, ry, 1, 1);
    }
  }

  /* ---------------- interaction prompt ---------------- */
  const tg = rt.target;
  if (tg) {
    const tx = ox + (tg.fx ?? tg.x + 0.5) * TILE;
    const ty = oy + (tg.fy ?? tg.y + 0.5) * TILE;
    const bob = Math.sin(rt.t * 5) * 1.5;
    ctx.fillStyle = "#ffb95e";
    ctx.fillRect(Math.round(tx - 1), Math.round(ty - 16 + bob), 3, 3);
    ctx.fillRect(Math.round(tx - 3), Math.round(ty - 14 + bob), 7, 1);
    ctx.fillRect(Math.round(tx - 2), Math.round(ty - 13 + bob), 5, 1);
  }

  /* ---------------- vignette ---------------- */
  const vg = ctx.createRadialGradient(VIEW_W / 2, VIEW_H / 2, VIEW_H * 0.28, VIEW_W / 2, VIEW_H / 2, VIEW_H * 0.82);
  vg.addColorStop(0, "rgba(0,0,0,0)");
  vg.addColorStop(1, "rgba(0,0,0,0.72)");
  ctx.fillStyle = vg;
  ctx.fillRect(0, 0, VIEW_W, VIEW_H);
}

export function entityLabel(e: Entity): string {
  switch (e.kind) {
    case "item":
      return "TAKE";
    case "note":
      return "READ";
    case "exit":
      return "ENTER";
    case "altar":
      return "TOUCH";
    default:
      return "";
  }
}
