import type { Area, Entity, TileKind } from "./types";

/* ------------------------------------------------------------------ *
 * tiny grid builder
 * ------------------------------------------------------------------ */
class G {
  w: number;
  h: number;
  t: TileKind[];
  constructor(w: number, h: number, fill: TileKind) {
    this.w = w;
    this.h = h;
    this.t = new Array<TileKind>(w * h).fill(fill);
  }
  set(x: number, y: number, k: TileKind) {
    if (x < 0 || y < 0 || x >= this.w || y >= this.h) return;
    this.t[y * this.w + x] = k;
  }
  get(x: number, y: number): TileKind {
    if (x < 0 || y < 0 || x >= this.w || y >= this.h) return "void";
    return this.t[y * this.w + x];
  }
  rect(x: number, y: number, w: number, h: number, k: TileKind) {
    for (let j = y; j < y + h; j++) for (let i = x; i < x + w; i++) this.set(i, j, k);
  }
  frame(x: number, y: number, w: number, h: number, k: TileKind) {
    for (let i = x; i < x + w; i++) {
      this.set(i, y, k);
      this.set(i, y + h - 1, k);
    }
    for (let j = y; j < y + h; j++) {
      this.set(x, j, k);
      this.set(x + w - 1, j, k);
    }
  }
  /** room with a wall shell */
  room(x: number, y: number, w: number, h: number, floor: TileKind) {
    this.rect(x - 1, y - 1, w + 2, h + 2, "wall");
    this.rect(x, y, w, h, floor);
  }
  hline(x1: number, x2: number, y: number, k: TileKind) {
    for (let i = Math.min(x1, x2); i <= Math.max(x1, x2); i++) this.set(i, y, k);
  }
  vline(y1: number, y2: number, x: number, k: TileKind) {
    for (let j = Math.min(y1, y2); j <= Math.max(y1, y2); j++) this.set(x, j, k);
  }
  scatter(k: TileKind, n: number, rng: () => number, on: TileKind[]) {
    let tries = 0;
    while (n > 0 && tries < n * 60) {
      tries++;
      const x = Math.floor(rng() * this.w);
      const y = Math.floor(rng() * this.h);
      if (on.includes(this.get(x, y))) {
        this.set(x, y, k);
        n--;
      }
    }
  }
}

function rng(seed: number) {
  let s = seed >>> 0;
  return () => {
    s = (s + 0x6d2b79f5) >>> 0;
    let t = Math.imul(s ^ (s >>> 15), 1 | s);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const E = (id: string, kind: Entity["kind"], x: number, y: number, ref?: string, label?: string): Entity => ({
  id,
  kind,
  x,
  y,
  ref,
  label,
});

/* ------------------------------------------------------------------ *
 * GRAVEYARD — the hub
 * ------------------------------------------------------------------ */
function buildGraveyard(): Area {
  const W = 46;
  const H = 34;
  const g = new G(W, H, "grass");
  const rand = rng(1337);

  // treeline + fence
  g.rect(0, 0, W, 2, "tree");
  g.rect(0, H - 2, W, 2, "tree");
  g.rect(0, 0, 2, H, "tree");
  g.rect(W - 2, 0, 2, H, "tree");
  g.frame(3, 3, W - 6, H - 6, "fence");

  // scatter first so nothing can block the routes carved afterwards
  g.scatter("grave", 48, rand, ["grass"]);
  g.scatter("tree", 24, rand, ["grass"]);
  g.scatter("rubble", 9, rand, ["grass"]);

  // main cross paths
  g.vline(4, H - 3, 24, "dirt");
  g.vline(4, H - 3, 25, "dirt");
  g.hline(4, W - 4, 17, "dirt");
  g.hline(4, W - 4, 18, "dirt");

  // mausoleum (west) — room() shells the interior with wall on rows y5..y13
  g.room(6, 6, 8, 7, "stone");
  g.set(9, 13, "door");
  g.set(10, 13, "door");
  g.rect(8, 14, 4, 1, "dirt");
  g.vline(14, 17, 9, "dirt");
  g.set(7, 7, "shrine");
  g.set(12, 11, "rubble");

  // chapel ruin (east)
  g.room(31, 6, 8, 7, "stone");
  g.set(34, 13, "door");
  g.set(35, 13, "door");
  g.rect(33, 14, 4, 1, "dirt");
  g.vline(14, 17, 34, "dirt");
  g.set(33, 7, "altar");
  g.set(34, 7, "altar");
  g.set(37, 11, "rubble");

  // the heart altar
  g.rect(21, 10, 3, 4, "stone");
  g.rect(21, 11, 2, 2, "altar");
  g.set(23, 11, "stone");

  // well
  g.rect(27, 20, 2, 2, "well");

  // gates
  g.set(24, 3, "gate");
  g.set(25, 3, "gate");
  g.set(3, 17, "gate");
  g.set(3, 18, "gate");
  g.set(W - 4, 17, "gate");
  g.set(W - 4, 18, "gate");

  g.scatter("blood", 4, rand, ["dirt"]);

  const entities: Entity[] = [
    E("g_exit1", "exit", 24, 3, "house1", "THE WIDOW'S HOUSE"),
    E("g_exit2", "exit", 3, 17, "house2", "THE DROWNED MANOR"),
    E("g_exit3", "exit", W - 4, 17, "house3", "ASHEN CHAPEL"),
    E("g_altar", "altar", 23, 11, "ending", "THE HEART"),
    E("g_oil1", "item", 8, 11, "oil"),
    E("g_oil2", "item", 36, 11, "oil"),
    E("g_tonic1", "item", 33, 11, "tonic"),
    E("g_iron1", "item", 12, 8, "graveIron"),
    E("g_note1", "note", 10, 11, "note1"),
    E("g_note2", "note", 37, 12, "note2"),
    E("g_note3", "note", 25, 27, "note3"),
    E("g_gh1", "enemy", 18, 24, "ghoul"),
    E("g_hd1", "enemy", 31, 22, "hound"),
    E("g_hk1", "enemy", 14, 21, "husk"),
  ];

  return {
    id: "graveyard",
    name: "ST. COLDWATER GRAVEYARD",
    subtitle: "the rain has not stopped in nine years",
    kind: "graveyard",
    w: W,
    h: H,
    tiles: g.t,
    entities,
    spawn: { x: 24.5, y: 30.5 },
    rain: 1,
    ambient: 0.05,
  };
}

/* ------------------------------------------------------------------ *
 * HOUSE 1 — THE WIDOW'S HOUSE
 * ------------------------------------------------------------------ */
function buildHouse1(): Area {
  const W = 28;
  const H = 23;
  const g = new G(W, H, "wall");
  const rand = rng(77);

  g.rect(10, 16, 8, 5, "floor");
  g.set(13, 21, "door");
  g.set(14, 21, "door");
  g.vline(6, 16, 13, "floor");
  g.vline(6, 16, 14, "floor");
  g.set(13, 6, "stairs");
  g.set(14, 6, "stairs");

  g.rect(3, 7, 9, 6, "floor");
  g.hline(11, 13, 10, "floor");
  g.rect(4, 3, 7, 5, "wood");
  g.hline(8, 9, 4, "floor");

  g.rect(16, 7, 8, 6, "floor");
  g.hline(15, 16, 10, "floor");

  g.rect(9, 3, 10, 3, "floor");
  g.rect(19, 1, 8, 6, "floor");
  g.hline(18, 19, 3, "floor");

  g.set(5, 4, "bed");
  g.set(6, 4, "bed");
  g.set(6, 10, "table");
  g.set(7, 10, "table");
  g.set(20, 11, "table");
  g.set(17, 8, "crate");
  g.set(21, 2, "bed");
  g.set(22, 2, "bed");
  g.set(25, 5, "crate");
  g.set(12, 18, "blood");
  g.set(13, 19, "blood");
  g.set(23, 4, "blood");
  g.scatter("rubble", 6, rand, ["wood"]);

  const entities: Entity[] = [
    E("h1_exit", "exit", 13, 21, "graveyard", "OUT TO THE RAIN"),
    E("h1_hk", "enemy", 6, 9, "husk"),
    E("h1_dl", "enemy", 20, 9, "doll"),
    E("h1_wd", "enemy", 22, 4, "widow"),
    E("h1_it", "item", 4, 5, "salt"),
    E("h1_oil", "item", 21, 12, "oil"),
    E("h1_tc", "item", 12, 19, "tonic"),
    E("h1_nt", "note", 16, 8, "note4"),
  ];

  return {
    id: "house1",
    name: "THE WIDOW'S HOUSE",
    subtitle: "she is still waiting at the table",
    kind: "house",
    w: W,
    h: H,
    tiles: g.t,
    entities,
    spawn: { x: 13.5, y: 20.5 },
    bossId: "widow",
    rain: 0.15,
    ambient: 0.03,
  };
}

/* ------------------------------------------------------------------ *
 * HOUSE 2 — THE DROWNED MANOR
 * ------------------------------------------------------------------ */
function buildHouse2(): Area {
  const W = 30;
  const H = 23;
  const g = new G(W, H, "wall");
  const rand = rng(909);

  g.rect(11, 17, 8, 5, "water");
  g.set(14, 22, "door");
  g.set(15, 22, "door");
  g.vline(8, 17, 14, "water");
  g.vline(8, 17, 15, "water");

  g.rect(2, 8, 9, 7, "wood");
  g.hline(11, 14, 11, "water");
  g.rect(17, 8, 10, 7, "floor");
  g.hline(16, 17, 11, "water");

  g.rect(8, 4, 14, 4, "stone");
  g.rect(19, 1, 9, 3, "stone");
  g.hline(18, 19, 5, "stone");

  g.set(3, 9, "bed");
  g.set(4, 9, "bed");
  g.set(9, 13, "table");
  g.set(20, 13, "table");
  g.set(21, 13, "table");
  g.set(25, 9, "crate");
  g.set(10, 5, "crate");
  g.set(12, 2, "bed");
  g.set(13, 2, "bed");
  g.set(26, 2, "shrine");
  g.set(12, 19, "blood");
  g.set(16, 20, "blood");
  g.set(22, 11, "blood");
  g.scatter("rubble", 8, rand, ["floor"]);
  g.set(17, 11, "floor");
  g.set(18, 11, "floor");

  const entities: Entity[] = [
    E("h2_exit", "exit", 14, 22, "graveyard", "OUT TO THE RAIN"),
    E("h2_wr1", "enemy", 6, 11, "wretch"),
    E("h2_an", "enemy", 21, 12, "angler"),
    E("h2_wr2", "enemy", 12, 19, "wretch"),
    E("h2_dr", "enemy", 23, 2, "drowned"),
    E("h2_gb", "item", 4, 12, "glassBlade"),
    E("h2_oil", "item", 24, 13, "oil"),
    E("h2_tc", "item", 16, 20, "tonic"),
    E("h2_nt", "note", 18, 9, "note5"),
  ];

  return {
    id: "house2",
    name: "THE DROWNED MANOR",
    subtitle: "the water is still rising, slowly",
    kind: "house",
    w: W,
    h: H,
    tiles: g.t,
    entities,
    spawn: { x: 14.5, y: 20.5 },
    bossId: "drowned",
    rain: 0.35,
    ambient: 0.04,
  };
}

/* ------------------------------------------------------------------ *
 * HOUSE 3 — ASHEN CHAPEL
 * ------------------------------------------------------------------ */
function buildHouse3(): Area {
  const W = 30;
  const H = 25;
  const g = new G(W, H, "wall");
  const rand = rng(4242);

  g.rect(12, 19, 6, 5, "stone");
  g.set(14, 24, "door");
  g.set(15, 24, "door");
  g.rect(9, 8, 12, 11, "stone");
  for (let i = 0; i < 3; i++) for (let j = 0; j < 3; j++) g.set(11 + i * 4, 10 + j * 3, "pillar");

  g.rect(3, 10, 6, 5, "stone");
  g.hline(8, 9, 12, "stone");
  g.rect(21, 10, 6, 5, "stone");
  g.hline(20, 21, 12, "stone");

  g.rect(10, 2, 10, 5, "stone");
  g.vline(7, 8, 14, "stone");
  g.vline(7, 8, 15, "stone");
  g.set(13, 4, "altar");
  g.set(14, 4, "altar");
  g.set(4, 12, "shrine");
  g.set(26, 12, "shrine");
  g.set(17, 16, "blood");
  g.set(12, 21, "blood");
  g.set(19, 12, "blood");
  g.scatter("rubble", 10, rand, ["stone"]);
  g.rect(12, 18, 6, 2, "stone");
  g.rect(14, 6, 2, 3, "stone");
  g.set(9, 12, "stone");
  g.set(20, 12, "stone");

  const entities: Entity[] = [
    E("h3_exit", "exit", 14, 24, "graveyard", "OUT TO THE RAIN"),
    E("h3_as1", "enemy", 12, 12, "ashen"),
    E("h3_be1", "enemy", 24, 12, "bell"),
    E("h3_as2", "enemy", 5, 12, "ashen"),
    E("h3_be2", "enemy", 16, 16, "bell"),
    E("h3_ch", "enemy", 15, 3, "choir"),
    E("h3_wc", "item", 6, 11, "wardCharm"),
    E("h3_oil", "item", 25, 13, "oil"),
    E("h3_tc", "item", 13, 21, "tonic"),
    E("h3_nt", "note", 18, 17, "note6"),
  ];

  return {
    id: "house3",
    name: "ASHEN CHAPEL",
    subtitle: "nine voices, one throat",
    kind: "house",
    w: W,
    h: H,
    tiles: g.t,
    entities,
    spawn: { x: 14.5, y: 22.5 },
    bossId: "choir",
    rain: 0.5,
    ambient: 0.02,
  };
}

/* ------------------------------------------------------------------ */
export const AREAS: Record<string, Area> = {
  graveyard: buildGraveyard(),
  house1: buildHouse1(),
  house2: buildHouse2(),
  house3: buildHouse3(),
};

export const HOUSE_ORDER = ["house1", "house2", "house3"];
