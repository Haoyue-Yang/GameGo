import { AREAS } from "./maps";
import { ENEMIES } from "./data";
import { TILES, type Area, type Entity } from "./types";

export const VIEW_W = 336;
export const VIEW_H = 210;

export const PLAYER_SPEED = 4.3;

export interface Drop {
  x: number;
  y: number;
  v: number;
  l: number;
}

export interface Ripple {
  x: number;
  y: number;
  r: number;
  a: number;
}

export interface Runtime {
  area: Area;
  entities: Entity[];
  px: number;
  py: number;
  moving: boolean;
  facing: number;
  light: Float32Array;
  seen: Float32Array;
  t: number;
  flicker: number;
  sputter: number;
  nextSputter: number;
  bolt: number;
  nextBolt: number;
  drops: Drop[];
  ripples: Ripple[];
  shake: number;
  contact: string | null;
  target: Entity | null;
  stepT: number;
  oil: number;
  /** seconds of immunity to contact after a fight */
  grace: number;
}

/** entity positions survive area switches */
const cache = new Map<string, Entity[]>();

export function tileAt(area: Area, x: number, y: number) {
  const tx = Math.floor(x);
  const ty = Math.floor(y);
  if (tx < 0 || ty < 0 || tx >= area.w || ty >= area.h) return "void" as const;
  return area.tiles[ty * area.w + tx];
}

export function isSolid(area: Area, tx: number, ty: number) {
  if (tx < 0 || ty < 0 || tx >= area.w || ty >= area.h) return true;
  return TILES[area.tiles[ty * area.w + tx]].solid;
}

export function isOpaque(area: Area, tx: number, ty: number) {
  if (tx < 0 || ty < 0 || tx >= area.w || ty >= area.h) return true;
  return TILES[area.tiles[ty * area.w + tx]].opaque;
}

function canStand(area: Area, x: number, y: number, r: number) {
  return (
    !isSolid(area, Math.floor(x - r), Math.floor(y - r)) &&
    !isSolid(area, Math.floor(x + r), Math.floor(y - r)) &&
    !isSolid(area, Math.floor(x - r), Math.floor(y + r)) &&
    !isSolid(area, Math.floor(x + r), Math.floor(y + r))
  );
}

export function lightRadius(oil: number) {
  return 2.85 + (Math.min(100, Math.max(0, oil)) / 100) * 3.15;
}

export function los(area: Area, x0: number, y0: number, x1: number, y1: number) {
  const dx = x1 - x0;
  const dy = y1 - y0;
  const dist = Math.hypot(dx, dy);
  const steps = Math.max(1, Math.ceil(dist / 0.22));
  for (let i = 1; i < steps; i++) {
    const f = i / steps;
    if (isOpaque(area, Math.floor(x0 + dx * f), Math.floor(y0 + dy * f))) return false;
  }
  return true;
}

export function createRuntime(areaId: string, removed: Set<string>, oil: number): Runtime {
  const area = AREAS[areaId];
  let ents = cache.get(areaId);
  if (!ents) {
    ents = area.entities.map((e) => ({
      ...e,
      fx: e.x + 0.5,
      fy: e.y + 0.5,
      tx: e.x,
      ty: e.y,
      facing: 0,
      step: Math.random() * 0.4,
      aggro: false,
    }));
    cache.set(areaId, ents);
  }
  const live = ents.filter((e) => !removed.has(e.id));
  const rt: Runtime = {
    area,
    entities: live,
    px: area.spawn.x,
    py: area.spawn.y,
    moving: false,
    facing: 0,
    light: new Float32Array(area.w * area.h),
    seen: new Float32Array(area.w * area.h),
    t: 0,
    flicker: 1,
    sputter: 0,
    nextSputter: 4 + Math.random() * 6,
    bolt: 0,
    nextBolt: 6 + Math.random() * 10,
    drops: [],
    ripples: [],
    shake: 0,
    contact: null,
    target: null,
    stepT: 0,
    oil,
    grace: 0.6,
  };
  const n = Math.floor(area.rain * 90) + 12;
  for (let i = 0; i < n; i++) {
    rt.drops.push({ x: Math.random() * VIEW_W, y: Math.random() * VIEW_H, v: 150 + Math.random() * 190, l: 4 + Math.random() * 8 });
  }
  return rt;
}

export function syncCache(rt: Runtime) {
  cache.set(rt.area.id, rt.entities);
}

export function removeEntity(rt: Runtime, id: string) {
  rt.entities = rt.entities.filter((e) => e.id !== id);
  syncCache(rt);
}

export function clearCache() {
  cache.clear();
}

/* ------------------------------------------------------------------ *
 * light
 * ------------------------------------------------------------------ */
export function computeLight(rt: Runtime) {
  const { area } = rt;
  rt.light.fill(0);
  const radius = lightRadius(rt.oil) * rt.flicker;
  const cx = rt.px;
  const cy = rt.py;
  const r = Math.ceil(radius) + 1;
  const px = Math.floor(cx);
  const py = Math.floor(cy);
  for (let y = py - r; y <= py + r; y++) {
    if (y < 0 || y >= area.h) continue;
    for (let x = px - r; x <= px + r; x++) {
      if (x < 0 || x >= area.w) continue;
      const i = y * area.w + x;
      const dx = x + 0.5 - cx;
      const dy = y + 0.5 - cy;
      const d = Math.hypot(dx, dy);
      if (d > radius) continue;
      if (!los(area, cx, cy, x + 0.5, y + 0.5)) continue;
      const fall = 1 - d / radius;
      let v = Math.min(1, fall * fall * 1.75 + 0.18);
      if (d < 0.75) v = 1;
      rt.light[i] = v;
      if (v > rt.seen[i]) rt.seen[i] = v;
    }
  }
}

/* ------------------------------------------------------------------ *
 * update
 * ------------------------------------------------------------------ */
export interface Input {
  x: number;
  y: number;
}

export function update(rt: Runtime, dt: number, input: Input, oil: number): void {
  rt.t += dt;
  rt.oil = oil;
  if (rt.grace > 0) rt.grace = Math.max(0, rt.grace - dt);
  const { area } = rt;

  // lantern flicker
  rt.nextSputter -= dt;
  if (rt.nextSputter <= 0) {
    rt.sputter = 0.28 + Math.random() * 0.3;
    rt.nextSputter = 5 + Math.random() * 9;
  }
  if (rt.sputter > 0) rt.sputter = Math.max(0, rt.sputter - dt);
  const base = 1 + Math.sin(rt.t * 7.3) * 0.045 + Math.sin(rt.t * 13.7) * 0.03 + Math.sin(rt.t * 3.1) * 0.02;
  const dip = rt.sputter > 0 ? 0.55 + Math.sin(rt.t * 40) * 0.12 : 1;
  const lowOil = oil < 15 ? 0.82 + Math.sin(rt.t * 17) * 0.12 : 1;
  rt.flicker = Math.max(0.35, base * dip * lowOil);

  // lightning
  rt.nextBolt -= dt;
  if (rt.nextBolt <= 0) {
    rt.bolt = 0.55;
    rt.nextBolt = 16 + Math.random() * 20;
  }
  if (rt.bolt > 0) {
    rt.bolt = Math.max(0, rt.bolt - dt * 1.9);
    if (rt.bolt < 0.34 && rt.bolt > 0.2) rt.bolt = 0.5;
  }

  // player movement
  let mx = input.x;
  let my = input.y;
  const mag = Math.hypot(mx, my);
  rt.moving = false;
  if (mag > 0.1) {
    mx /= mag;
    my /= mag;
    rt.facing = Math.abs(mx) > Math.abs(my) ? (mx < 0 ? 2 : 3) : my < 0 ? 1 : 0;
    const nx = rt.px + mx * PLAYER_SPEED * dt;
    if (canStand(area, nx, rt.py, 0.28)) rt.px = nx;
    const ny = rt.py + my * PLAYER_SPEED * dt;
    if (canStand(area, rt.px, ny, 0.28)) rt.py = ny;
    rt.moving = true;
    rt.stepT -= dt;
    if (rt.stepT <= 0) {
      rt.stepT = 0.3;
      rt.ripples.push({ x: rt.px, y: rt.py + 0.35, r: 1, a: 0.5 });
    }
  }

  // enemies
  for (const e of rt.entities) {
    if (e.kind !== "enemy") continue;
    const def = ENEMIES[e.ref ?? ""];
    if (!def) continue;
    const ex = e.fx ?? e.x + 0.5;
    const ey = e.fy ?? e.y + 0.5;
    const d = Math.hypot(rt.px - ex, rt.py - ey);
    const canSee = rt.grace <= 0 && d < def.sight && los(area, rt.px, rt.py, ex, ey);
    e.aggro = canSee;

    e.step = (e.step ?? 0) - dt;
    if (e.step <= 0) {
      e.step = canSee ? 0.26 : 0.75;
      if (canSee) {
        const dx = Math.sign(rt.px - ex);
        const dy = Math.sign(rt.py - ey);
        const opts: Array<[number, number]> = [];
        if (Math.abs(rt.px - ex) > Math.abs(rt.py - ey)) {
          opts.push([dx, 0], [0, dy]);
        } else {
          opts.push([0, dy], [dx, 0]);
        }
        for (const [ox, oy] of opts) {
          if (ox === 0 && oy === 0) continue;
          if (!isSolid(area, Math.floor(ex) + ox, Math.floor(ey) + oy)) {
            e.tx = Math.floor(ex) + ox;
            e.ty = Math.floor(ey) + oy;
            break;
          }
        }
      } else if (Math.random() < 0.55) {
        const ox = Math.floor(Math.random() * 3) - 1;
        const oy = Math.floor(Math.random() * 3) - 1;
        if (!isSolid(area, Math.floor(ex) + ox, Math.floor(ey) + oy)) {
          e.tx = Math.floor(ex) + ox;
          e.ty = Math.floor(ey) + oy;
        }
      }
    }

    // glide toward tile target
    const gx = (e.tx ?? e.x) + 0.5;
    const gy = (e.ty ?? e.y) + 0.5;
    const gdx = gx - ex;
    const gdy = gy - ey;
    const gd = Math.hypot(gdx, gdy);
    if (gd > 0.02) {
      const sp = def.speed * (canSee ? 1.25 : 0.7) * dt;
      const stepX = (gdx / gd) * Math.min(sp, gd);
      const stepY = (gdy / gd) * Math.min(sp, gd);
      if (canStand(area, ex + stepX, ey, 0.26)) e.fx = ex + stepX;
      if (canStand(area, ex, ey + stepY, 0.26)) e.fy = ey + stepY;
      e.facing = Math.abs(gdx) > Math.abs(gdy) ? (gdx < 0 ? 2 : 3) : gdy < 0 ? 1 : 0;
    } else {
      e.fx = gx;
      e.fy = gy;
    }

    if (d < 0.92 && !rt.contact && rt.grace <= 0) rt.contact = e.id;
  }

  computeLight(rt);

  // interaction target — must be inside the lantern's reach
  let best: Entity | null = null;
  let bestD = 2.1;
  for (const e of rt.entities) {
    if (e.kind === "enemy") continue;
    const d = Math.hypot(rt.px - (e.fx ?? e.x + 0.5), rt.py - (e.fy ?? e.y + 0.5));
    if (d > bestD) continue;
    const i = Math.floor(e.y) * area.w + Math.floor(e.x);
    if (rt.light[i] < 0.06 && rt.bolt < 0.05) continue;
    bestD = d;
    best = e;
  }
  rt.target = best;

  // rain + ripples
  for (const d of rt.drops) {
    d.y += d.v * dt;
    d.x += d.v * 0.22 * dt;
    if (d.y > VIEW_H) {
      d.y = -10;
      d.x = Math.random() * (VIEW_W + 60) - 30;
    }
    if (d.x > VIEW_W + 20) d.x -= VIEW_W + 40;
  }
  for (let i = rt.ripples.length - 1; i >= 0; i--) {
    const r = rt.ripples[i];
    r.r += dt * 22;
    r.a -= dt * 1.5;
    if (r.a <= 0) rt.ripples.splice(i, 1);
  }
  if (rt.shake > 0) rt.shake = Math.max(0, rt.shake - dt * 3);
}
