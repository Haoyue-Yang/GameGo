import type { ItemDef, ItemId } from "./types";
import type { SpriteId } from "./tiles";

/* ------------------------------------------------------------------ *
 * items
 * ------------------------------------------------------------------ */
export const ITEMS: Record<ItemId, ItemDef> = {
  oil: { id: "oil", name: "Lamp Oil", desc: "Feeds the lantern. +35 oil.", kind: "consumable" },
  tonic: { id: "tonic", name: "Grave Tonic", desc: "Bitter. Restores 14 vitality.", kind: "consumable" },
  salt: { id: "salt", name: "Hymn Salt", desc: "12 damage and blinds the dead.", kind: "consumable" },
  graveIron: { id: "graveIron", name: "Grave Iron", desc: "A nail pulled from a coffin lid. ATK +3.", kind: "weapon", atk: 3 },
  glassBlade: { id: "glassBlade", name: "Glass Blade", desc: "Shard of a drowned window. ATK +6.", kind: "weapon", atk: 6 },
  wardCharm: { id: "wardCharm", name: "Ward Charm", desc: "Halves damage for 3 turns.", kind: "relic" },
};

/* ------------------------------------------------------------------ *
 * statuses
 * ------------------------------------------------------------------ */
export type StatusId = "blinded" | "stunned" | "burning" | "cursed" | "bleeding" | "warded" | "drained" | "chilled";

export const STATUS: Record<StatusId, { name: string; color: string; desc: string }> = {
  blinded: { name: "Blinded", color: "#ffb95e", desc: "accuracy -55%, attack -25%" },
  stunned: { name: "Stunned", color: "#9fd8e8", desc: "loses its next turn" },
  burning: { name: "Burning", color: "#e8a33d", desc: "4 damage each turn" },
  cursed: { name: "Cursed", color: "#a86ad8", desc: "defence -3" },
  bleeding: { name: "Bleeding", color: "#c8343c", desc: "3 damage each turn" },
  warded: { name: "Warded", color: "#7fd8a0", desc: "incoming damage halved" },
  drained: { name: "Drained", color: "#6f9ec4", desc: "attack -3" },
  chilled: { name: "Chilled", color: "#7fd8f0", desc: "attack -2, defence -1" },
};

export interface Status {
  id: StatusId;
  turns: number;
}

/* ------------------------------------------------------------------ *
 * enemies
 * ------------------------------------------------------------------ */
export interface MoveDef {
  name: string;
  tell: string;
  kind: "attack" | "heavy" | "guard" | "buff" | "debuff" | "heal" | "drain";
  power: number;
  weight: number;
  status?: { id: StatusId; chance: number; turns: number };
  heal?: number;
}

export interface EnemyDef {
  id: string;
  name: string;
  title: string;
  hp: number;
  atk: number;
  def: number;
  spd: number;
  sprite: SpriteId;
  desc: string;
  boss?: boolean;
  /** world AI sight range in tiles */
  sight: number;
  speed: number;
  moves: MoveDef[];
}

export const ENEMIES: Record<string, EnemyDef> = {
  ghoul: {
    id: "ghoul",
    name: "Grave Ghoul",
    title: "buried facing the wrong way",
    hp: 20,
    atk: 7,
    def: 1,
    spd: 3,
    sprite: "ghoul",
    desc: "Clay-caked hands. It still remembers how to reach.",
    sight: 7,
    speed: 1.5,
    moves: [
      { name: "Rake", tell: "It drags a hand through the mud.", kind: "attack", power: 1, weight: 3 },
      { name: "Grave Lunge", tell: "It crouches; dirt spills from its ribs.", kind: "heavy", power: 1.7, weight: 1 },
      {
        name: "Grasp",
        tell: "Cold fingers close on your wrist.",
        kind: "debuff",
        power: 0.4,
        weight: 1,
        status: { id: "drained", chance: 0.75, turns: 3 },
      },
    ],
  },
  hound: {
    id: "hound",
    name: "Ash Hound",
    title: "it hunts by the smell of oil",
    hp: 16,
    atk: 6,
    def: 0,
    spd: 6,
    sprite: "hound",
    desc: "Too many legs. Too fast for the dark.",
    sight: 9,
    speed: 2.6,
    moves: [
      { name: "Snap", tell: "It circles, low and fast.", kind: "attack", power: 1, weight: 3 },
      { name: "Lunge", tell: "It plants its hind legs.", kind: "heavy", power: 1.5, weight: 2 },
      {
        name: "Howl",
        tell: "It lifts its head to the rain.",
        kind: "buff",
        power: 0,
        weight: 1,
        status: { id: "warded", chance: 1, turns: 2 },
      },
    ],
  },
  husk: {
    id: "husk",
    name: "Weeping Husk",
    title: "a coat with nothing left in it",
    hp: 26,
    atk: 8,
    def: 2,
    spd: 2,
    sprite: "husk",
    desc: "It keeps apologising. It never stops apologising.",
    sight: 6,
    speed: 1.2,
    moves: [
      { name: "Clutch", tell: "It reaches with both hands.", kind: "attack", power: 1, weight: 3 },
      {
        name: "Mourning Cry",
        tell: "The walls begin to hum.",
        kind: "debuff",
        power: 0.5,
        weight: 2,
        status: { id: "cursed", chance: 0.7, turns: 3 },
      },
      { name: "Collapse", tell: "It folds in on itself.", kind: "heavy", power: 1.8, weight: 1 },
    ],
  },
  doll: {
    id: "doll",
    name: "Porcelain Doll",
    title: "it was left awake",
    hp: 22,
    atk: 9,
    def: 1,
    spd: 7,
    sprite: "doll",
    desc: "Cracked at the cheek. It wants to be held.",
    sight: 8,
    speed: 2.4,
    moves: [
      { name: "Pinprick", tell: "It tucks a needle behind its ear.", kind: "attack", power: 1, weight: 3 },
      {
        name: "Glass Cut",
        tell: "It turns its head the wrong way.",
        kind: "heavy",
        power: 1.6,
        weight: 2,
        status: { id: "bleeding", chance: 0.6, turns: 3 },
      },
      { name: "Rewind", tell: "Its joints click backwards.", kind: "buff", power: 0, weight: 1, status: { id: "warded", chance: 1, turns: 2 } },
    ],
  },
  widow: {
    id: "widow",
    name: "The Widow",
    title: "keeper of the first house",
    hp: 62,
    atk: 11,
    def: 3,
    spd: 4,
    sprite: "widow",
    desc: "She has been waiting at the table for nine years, and she has set a place for you.",
    boss: true,
    sight: 10,
    speed: 1.7,
    moves: [
      { name: "Veil Strike", tell: "Her veil lifts like a wing.", kind: "attack", power: 1, weight: 3 },
      {
        name: "Grief",
        tell: "She recites a name that is almost yours.",
        kind: "debuff",
        power: 0.6,
        weight: 2,
        status: { id: "drained", chance: 0.8, turns: 3 },
      },
      {
        name: "Widow's Grasp",
        tell: "She takes your hand and does not let go.",
        kind: "heavy",
        power: 1.9,
        weight: 2,
        status: { id: "bleeding", chance: 0.5, turns: 3 },
      },
      { name: "Sew the Dark", tell: "She pulls a thread of shadow tight.", kind: "heal", power: 0, weight: 1, heal: 10 },
    ],
  },
  wretch: {
    id: "wretch",
    name: "Silt Wretch",
    title: "swallowed the manor's cellar",
    hp: 30,
    atk: 9,
    def: 3,
    spd: 2,
    sprite: "wretch",
    desc: "It is mostly water now, and it is still trying to be a person.",
    sight: 6,
    speed: 1.3,
    moves: [
      { name: "Slap", tell: "It swings a sodden arm.", kind: "attack", power: 1, weight: 3 },
      {
        name: "Drown",
        tell: "Water pours out of its mouth.",
        kind: "heavy",
        power: 1.7,
        weight: 2,
        status: { id: "chilled", chance: 0.7, turns: 3 },
      },
      { name: "Bloat", tell: "It swells with silt.", kind: "buff", power: 0, weight: 1, status: { id: "warded", chance: 1, turns: 2 } },
    ],
  },
  angler: {
    id: "angler",
    name: "Lantern Angler",
    title: "it copies your light",
    hp: 26,
    atk: 10,
    def: 1,
    spd: 5,
    sprite: "angler",
    desc: "It carries a lure of stolen flame. It wants yours.",
    sight: 11,
    speed: 2.2,
    moves: [
      { name: "Lash", tell: "The eel coils tight.", kind: "attack", power: 1, weight: 3 },
      {
        name: "Snuff",
        tell: "The lure flares and your lantern gutters.",
        kind: "debuff",
        power: 0.5,
        weight: 3,
      },
      { name: "Bite", tell: "Teeth like broken glass.", kind: "heavy", power: 1.8, weight: 2, status: { id: "bleeding", chance: 0.5, turns: 3 } },
    ],
  },
  drowned: {
    id: "drowned",
    name: "The Drowned Bride",
    title: "keeper of the second house",
    hp: 78,
    atk: 13,
    def: 4,
    spd: 4,
    sprite: "drowned",
    desc: "Her gown is still wet. The chapel below the manor is still filling.",
    boss: true,
    sight: 11,
    speed: 1.8,
    moves: [
      { name: "Tide Hand", tell: "Her hand leaves a wet print in the air.", kind: "attack", power: 1, weight: 3 },
      {
        name: "Undertow",
        tell: "The floor turns to water.",
        kind: "heavy",
        power: 2,
        weight: 2,
        status: { id: "chilled", chance: 0.7, turns: 3 },
      },
      {
        name: "Drowning Hymn",
        tell: "She sings with her mouth full of silt.",
        kind: "debuff",
        power: 0.6,
        weight: 2,
        status: { id: "cursed", chance: 0.8, turns: 3 },
      },
      { name: "Resurface", tell: "She draws a breath she should not have.", kind: "heal", power: 0, weight: 1, heal: 14 },
    ],
  },
  ashen: {
    id: "ashen",
    name: "Ashen Novice",
    title: "burned at the ninth vigil",
    hp: 34,
    atk: 12,
    def: 3,
    spd: 3,
    sprite: "ashen",
    desc: "No face. It prays anyway, and the prayer is a warning.",
    sight: 8,
    speed: 1.6,
    moves: [
      { name: "Censer", tell: "It swings a hot chain.", kind: "attack", power: 1, weight: 3 },
      {
        name: "Ashfall",
        tell: "Cinders pour from its hood.",
        kind: "heavy",
        power: 1.8,
        weight: 2,
        status: { id: "burning", chance: 0.7, turns: 3 },
      },
      { name: "Kneel", tell: "It bows to something behind you.", kind: "buff", power: 0, weight: 1, status: { id: "warded", chance: 1, turns: 2 } },
    ],
  },
  bell: {
    id: "bell",
    name: "Bell Wraith",
    title: "it rings for the living",
    hp: 30,
    atk: 11,
    def: 2,
    spd: 6,
    sprite: "bell",
    desc: "Every ring takes something out of you.",
    sight: 10,
    speed: 2.3,
    moves: [
      { name: "Toll", tell: "The bronze shivers.", kind: "attack", power: 1, weight: 3 },
      {
        name: "Peal",
        tell: "Nine notes, all at once.",
        kind: "heavy",
        power: 1.9,
        weight: 2,
        status: { id: "stunned", chance: 0.4, turns: 1 },
      },
      {
        name: "Knell",
        tell: "It rings your own name.",
        kind: "debuff",
        power: 0.5,
        weight: 2,
        status: { id: "drained", chance: 0.8, turns: 3 },
      },
    ],
  },
  choir: {
    id: "choir",
    name: "The Choir of Nine",
    title: "keeper of the third house",
    hp: 104,
    atk: 15,
    def: 5,
    spd: 5,
    sprite: "choir",
    desc: "Nine mouths. One throat. It has been singing the same verse since the rain began.",
    boss: true,
    sight: 12,
    speed: 1.9,
    moves: [
      { name: "Verse", tell: "The mouths open in sequence.", kind: "attack", power: 1, weight: 3 },
      {
        name: "Antiphon",
        tell: "It sings the answer to your own voice.",
        kind: "heavy",
        power: 2.1,
        weight: 2,
        status: { id: "cursed", chance: 0.6, turns: 3 },
      },
      {
        name: "Litany",
        tell: "Nine voices braid into one.",
        kind: "debuff",
        power: 0.7,
        weight: 2,
        status: { id: "stunned", chance: 0.45, turns: 1 },
      },
      {
        name: "Requiem",
        tell: "It sings for you, in advance.",
        kind: "heal",
        power: 0,
        weight: 1,
        heal: 18,
      },
    ],
  },
};

/* ------------------------------------------------------------------ *
 * notes
 * ------------------------------------------------------------------ */
export const NOTES: Record<string, { title: string; body: string }> = {
  note1: {
    title: "Mausoleum ledger",
    body: "Nine graves were dug on the night the rain started. Nine names. I can only read eight — the ninth is written in my own hand and I have never been here before.",
  },
  note2: {
    title: "Chapel ruin, scratched into stone",
    body: "THE LANTERN IS NOT A LIGHT. IT IS A PERMISSION. WHAT IT SHOWS YOU, YOU MAY TOUCH. WHAT IT HIDES, WILL TOUCH YOU.",
  },
  note3: {
    title: "A child's slate, wedged under a stone",
    body: "Mama says the houses are full of her friends. I am not allowed to go in. I am not allowed to look. I am not allowed to blow out the light.",
  },
  note4: {
    title: "The Widow's letter, unsent",
    body: "You will come at the end of the rain, and you will be cold, and you will be carrying a light. I have set a place for you. Please sit. Please do not look at the nursery.",
  },
  note5: {
    title: "Manor housekeeper's log",
    body: "Day 400. The water came up through the floor again. We stopped measuring it. The bride's dress was found dry in the wet room, which is the part nobody talks about.",
  },
  note6: {
    title: "Chapel confession, in ash",
    body: "We sang to keep the graveyard quiet. Then the singing learned our names. If you are reading this, you are already in the verse. Choose: hold the lantern, or become the light it hides.",
  },
};
