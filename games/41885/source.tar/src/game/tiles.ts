import type { TileKind } from "./types";

export const TILE = 16;

/* ------------------------------------------------------------------ *
 * deterministic per-tile noise
 * ------------------------------------------------------------------ */
export function hash2(x: number, y: number, s = 0): number {
  let h = Math.imul(x | 0, 374761393) ^ Math.imul(y | 0, 668265263) ^ Math.imul(s | 0, 1442695041);
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
}

function px(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, c: string) {
  ctx.fillStyle = c;
  ctx.fillRect(Math.round(x), Math.round(y), Math.round(w), Math.round(h));
}

/* ------------------------------------------------------------------ *
 * tile painting — everything is procedural pixel art
 * ------------------------------------------------------------------ */
export function drawTile(ctx: CanvasRenderingContext2D, kind: TileKind, x: number, y: number, tx: number, ty: number) {
  const r = (n: number) => hash2(tx, ty, n);
  switch (kind) {
    case "grass": {
      px(ctx, x, y, TILE, TILE, "#1b2a1e");
      for (let i = 0; i < 7; i++) {
        const hx = Math.floor(r(i) * TILE);
        const hy = Math.floor(r(i + 40) * TILE);
        px(ctx, x + hx, y + hy, 1, 2, r(i + 80) > 0.6 ? "#2c4030" : "#243525");
      }
      break;
    }
    case "dirt": {
      px(ctx, x, y, TILE, TILE, "#2c2318");
      for (let i = 0; i < 9; i++) {
        const hx = Math.floor(r(i + 3) * TILE);
        const hy = Math.floor(r(i + 30) * TILE);
        px(ctx, x + hx, y + hy, 1, 1, r(i + 60) > 0.5 ? "#3a2d1e" : "#231c13");
      }
      break;
    }
    case "wall": {
      px(ctx, x, y, TILE, TILE, "#23232b");
      px(ctx, x, y, TILE, 1, "#33333d");
      for (let row = 0; row < 3; row++) {
        const ry = y + 1 + row * 5;
        px(ctx, x, ry, TILE, 1, "#17171d");
        const off = row % 2 === 0 ? 0 : 4;
        px(ctx, x + ((off + 8) % TILE), ry, 1, 5, "#17171d");
      }
      if (r(7) > 0.86) px(ctx, x + Math.floor(r(9) * 12), y + Math.floor(r(11) * 12), 3, 2, "#2e2e38");
      break;
    }
    case "floor": {
      px(ctx, x, y, TILE, TILE, "#3a2e25");
      px(ctx, x, y + 7, TILE, 1, "#2c231c");
      px(ctx, x, y + 15, TILE, 1, "#2c231c");
      px(ctx, x + Math.floor(r(1) * 14), y + 3, 1, 1, "#4a3b2e");
      px(ctx, x + Math.floor(r(2) * 14), y + 11, 1, 1, "#2c231c");
      break;
    }
    case "wood": {
      px(ctx, x, y, TILE, TILE, "#4a3524");
      for (let i = 0; i < 3; i++) px(ctx, x, y + 2 + i * 5, TILE, 1, "#3c2a1c");
      px(ctx, x + Math.floor(r(5) * 12), y + Math.floor(r(6) * 12), 3, 1, "#57402c");
      break;
    }
    case "stone": {
      px(ctx, x, y, TILE, TILE, "#33333a");
      px(ctx, x, y, TILE, 1, "#3d3d46");
      px(ctx, x, y + 8, TILE, 1, "#26262d");
      px(ctx, x + (tx % 2 === 0 ? 4 : 11), y, 1, 8, "#26262d");
      px(ctx, x + (tx % 2 === 0 ? 11 : 4), y + 8, 1, 8, "#26262d");
      break;
    }
    case "grave": {
      px(ctx, x, y, TILE, TILE, "#2c2318");
      px(ctx, x + 2, y + 5, 12, 9, "#565663");
      px(ctx, x + 2, y + 5, 12, 1, "#6a6a78");
      px(ctx, x + 2, y + 13, 12, 1, "#3c3c48");
      px(ctx, x + 7, y + 7, 2, 6, "#3c3c48");
      px(ctx, x + 5, y + 9, 6, 2, "#3c3c48");
      if (r(3) > 0.7) px(ctx, x + 3, y + 12, 4, 1, "#2a2a32");
      break;
    }
    case "water": {
      px(ctx, x, y, TILE, TILE, "#10202f");
      for (let i = 0; i < 3; i++) {
        const wy = y + 2 + i * 5 + Math.floor(r(i + 2) * 2);
        px(ctx, x + Math.floor(r(i + 9) * 6), wy, 6, 1, "#16304a");
      }
      px(ctx, x, y, TILE, 1, "#16304a");
      break;
    }
    case "tree": {
      px(ctx, x, y, TILE, TILE, "#1b2a1e");
      px(ctx, x + 6, y + 9, 4, 7, "#2a1d14");
      px(ctx, x + 2, y + 1, 12, 9, "#16241a");
      px(ctx, x + 4, y, 8, 3, "#1d2f22");
      px(ctx, x + 1, y + 4, 3, 4, "#16241a");
      px(ctx, x + 12, y + 3, 3, 5, "#16241a");
      px(ctx, x + 5, y + 2, 2, 2, "#22382a");
      break;
    }
    case "fence": {
      px(ctx, x, y, TILE, TILE, "#1b2a1e");
      px(ctx, x + 2, y + 2, 2, 13, "#3a2a1c");
      px(ctx, x + 11, y + 2, 2, 13, "#3a2a1c");
      px(ctx, x, y + 5, TILE, 2, "#463324");
      px(ctx, x, y + 11, TILE, 2, "#463324");
      px(ctx, x + 2, y + 2, 2, 1, "#57402c");
      break;
    }
    case "door": {
      px(ctx, x, y, TILE, TILE, "#23232b");
      px(ctx, x + 1, y + 1, 14, 15, "#2a1d14");
      px(ctx, x + 2, y + 2, 12, 14, "#5a412c");
      px(ctx, x + 3, y + 3, 10, 12, "#4a3524");
      px(ctx, x + 11, y + 9, 2, 2, "#c8a05a");
      px(ctx, x + 3, y + 3, 10, 1, "#6a4f34");
      break;
    }
    case "gate": {
      px(ctx, x, y, TILE, TILE, "#14141c");
      for (let i = 0; i < 4; i++) px(ctx, x + 1 + i * 4, y, 2, TILE, "#4a4a55");
      px(ctx, x, y + 4, TILE, 2, "#565663");
      px(ctx, x, y + 11, TILE, 2, "#565663");
      px(ctx, x + 1, y + 1, 2, 2, "#6a6a78");
      break;
    }
    case "stairs": {
      px(ctx, x, y, TILE, TILE, "#3a2e25");
      for (let i = 0; i < 4; i++) {
        px(ctx, x, y + i * 4, TILE, 2, "#4a3b2e");
        px(ctx, x, y + i * 4 + 2, TILE, 2, "#2c231c");
      }
      break;
    }
    case "rubble": {
      px(ctx, x, y, TILE, TILE, "#2c2318");
      px(ctx, x + 1, y + 8, 6, 5, "#3a3a44");
      px(ctx, x + 8, y + 5, 6, 8, "#44444e");
      px(ctx, x + 5, y + 2, 4, 4, "#33333d");
      px(ctx, x + 9, y + 6, 3, 2, "#565663");
      break;
    }
    case "altar": {
      px(ctx, x, y, TILE, TILE, "#26262d");
      px(ctx, x + 1, y + 2, 14, 13, "#4a4a58");
      px(ctx, x + 1, y + 2, 14, 2, "#5e5e6e");
      px(ctx, x + 3, y + 6, 10, 8, "#3a3a46");
      px(ctx, x + 6, y + 8, 4, 4, "#8e1c22");
      px(ctx, x + 7, y + 9, 2, 2, "#c8343c");
      break;
    }
    case "bed": {
      px(ctx, x, y, TILE, TILE, "#3a2e25");
      px(ctx, x + 1, y + 1, 14, 14, "#4a3524");
      px(ctx, x + 2, y + 3, 12, 11, "#6a6a72");
      px(ctx, x + 3, y + 4, 10, 4, "#8a8a92");
      px(ctx, x + 2, y + 10, 12, 1, "#565663");
      break;
    }
    case "table": {
      px(ctx, x, y, TILE, TILE, "#3a2e25");
      px(ctx, x + 1, y + 2, 14, 10, "#5a412c");
      px(ctx, x + 1, y + 2, 14, 2, "#6a4f34");
      px(ctx, x + 2, y + 12, 3, 3, "#3c2a1c");
      px(ctx, x + 11, y + 12, 3, 3, "#3c2a1c");
      break;
    }
    case "pillar": {
      px(ctx, x, y, TILE, TILE, "#1e1e28");
      px(ctx, x + 2, y, 12, TILE, "#3d3d46");
      px(ctx, x + 2, y, 3, TILE, "#4e4e5a");
      px(ctx, x + 12, y, 2, TILE, "#2a2a34");
      px(ctx, x + 1, y, 14, 3, "#565663");
      px(ctx, x + 1, y + 13, 14, 3, "#565663");
      break;
    }
    case "well": {
      px(ctx, x, y, TILE, TILE, "#26262d");
      px(ctx, x + 1, y + 1, 14, 14, "#4a4a58");
      px(ctx, x + 3, y + 3, 10, 10, "#0a0a10");
      px(ctx, x + 4, y + 5, 8, 1, "#16304a");
      px(ctx, x + 2, y + 2, 12, 2, "#5e5e6e");
      break;
    }
    case "blood": {
      px(ctx, x, y, TILE, TILE, "#3a2e25");
      px(ctx, x + 2, y + 3, 11, 10, "#4a1218");
      px(ctx, x + 4, y + 5, 7, 6, "#5c161d");
      px(ctx, x + 1, y + 10, 3, 2, "#4a1218");
      px(ctx, x + 12, y + 4, 3, 2, "#4a1218");
      break;
    }
    case "shrine": {
      px(ctx, x, y, TILE, TILE, "#26262d");
      px(ctx, x + 3, y + 5, 10, 10, "#4a4a58");
      px(ctx, x + 3, y + 5, 10, 2, "#5e5e6e");
      px(ctx, x + 5, y + 1, 2, 4, "#c8c0a8");
      px(ctx, x + 9, y + 2, 2, 3, "#c8c0a8");
      px(ctx, x + 5, y, 2, 1, "#ffb95e");
      px(ctx, x + 9, y + 1, 2, 1, "#e8a33d");
      break;
    }
    case "crate": {
      px(ctx, x, y, TILE, TILE, "#3a2e25");
      px(ctx, x + 1, y + 2, 14, 13, "#4a3524");
      px(ctx, x + 1, y + 2, 14, 1, "#5a412c");
      px(ctx, x + 1, y + 14, 14, 1, "#33241a");
      ctx.strokeStyle = "#33241a";
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(x + 1.5, y + 3.5);
      ctx.lineTo(x + 14.5, y + 14.5);
      ctx.moveTo(x + 14.5, y + 3.5);
      ctx.lineTo(x + 1.5, y + 14.5);
      ctx.stroke();
      break;
    }
    case "void":
    default:
      px(ctx, x, y, TILE, TILE, "#05050a");
      break;
  }
}

/* ------------------------------------------------------------------ *
 * creatures
 * ------------------------------------------------------------------ */
export type SpriteId =
  | "ghoul"
  | "hound"
  | "husk"
  | "doll"
  | "widow"
  | "wretch"
  | "angler"
  | "drowned"
  | "ashen"
  | "bell"
  | "choir";

export interface CreatureOpts {
  /** 0..1 how lit the creature is */
  lit: number;
  hurt?: number;
  dead?: number;
  t?: number;
}

/** draws a creature centred on (cx, cy) with unit size u */
export function drawCreature(
  ctx: CanvasRenderingContext2D,
  sprite: SpriteId,
  cx: number,
  cy: number,
  u: number,
  opts: CreatureOpts,
) {
  const t = opts.t ?? 0;
  const bob = Math.sin(t * 2.4) * u * 0.35;
  const lit = Math.max(0, Math.min(1, opts.lit));
  ctx.save();
  ctx.translate(Math.round(cx), Math.round(cy) + Math.round(bob));
  if (opts.dead) {
    ctx.globalAlpha = Math.max(0, 1 - opts.dead);
    ctx.translate(0, opts.dead * u * 3);
    ctx.rotate(opts.dead * 0.5);
  }
  if (opts.hurt) ctx.globalAlpha *= Math.max(0.2, 1 - opts.hurt * 0.6);

  const shade = (c: string) => (lit > 0.35 ? c : shadeDark(c));
  const eye = (ex: number, ey: number, c: string, s = 1) => {
    ctx.fillStyle = c;
    ctx.fillRect(Math.round(ex * u), Math.round(ey * u), Math.round(s * u), Math.round(s * u));
    ctx.globalAlpha *= 0.35;
    ctx.fillStyle = c;
    ctx.fillRect(Math.round((ex - 1) * u), Math.round(ey * u), Math.round(3 * u), Math.round(s * u));
    ctx.globalAlpha /= 0.35;
  };

  switch (sprite) {
    case "ghoul": {
      px(ctx, -3 * u, -1 * u, 6 * u, 6 * u, shade("#4a5a48"));
      px(ctx, -2 * u, -4 * u, 4 * u, 3 * u, shade("#5c6b56"));
      px(ctx, -4 * u, 0, 2 * u, 5 * u, shade("#3f4d3d"));
      px(ctx, 2 * u, 0, 2 * u, 5 * u, shade("#3f4d3d"));
      px(ctx, -3 * u, 4 * u, 2 * u, 2 * u, shade("#2f3a2d"));
      px(ctx, 1 * u, 4 * u, 2 * u, 2 * u, shade("#2f3a2d"));
      px(ctx, -1 * u, -1 * u, 2 * u, 3 * u, shade("#3a4636"));
      eye(-1.5, -3.2, "#d8e05a");
      eye(1.5, -3.2, "#d8e05a");
      break;
    }
    case "hound": {
      px(ctx, -5 * u, -1 * u, 9 * u, 3 * u, shade("#3a3a42"));
      px(ctx, 3 * u, -3 * u, 4 * u, 3 * u, shade("#44444e"));
      px(ctx, 6 * u, -2 * u, 2 * u, 2 * u, shade("#2c2c34"));
      px(ctx, -4 * u, 2 * u, 1.4 * u, 3 * u, shade("#2c2c34"));
      px(ctx, 2 * u, 2 * u, 1.4 * u, 3 * u, shade("#2c2c34"));
      px(ctx, -3 * u, -2 * u, 1 * u, 1 * u, shade("#565663"));
      px(ctx, 0 * u, -2 * u, 1 * u, 1 * u, shade("#565663"));
      px(ctx, -5 * u, -1 * u, 2 * u, 1 * u, shade("#2c2c34"));
      eye(5.4, -2.4, "#c8343c");
      break;
    }
    case "husk": {
      px(ctx, -2.5 * u, -3 * u, 5 * u, 8 * u, shade("#b8b2a4"));
      px(ctx, -2 * u, -6 * u, 4 * u, 3 * u, shade("#c8c2b4"));
      px(ctx, -4 * u, -2 * u, 1.6 * u, 6 * u, shade("#a49e90"));
      px(ctx, 2.4 * u, -2 * u, 1.6 * u, 6 * u, shade("#a49e90"));
      px(ctx, -2.5 * u, 5 * u, 2 * u, 2 * u, shade("#8e887c"));
      px(ctx, 0.5 * u, 5 * u, 2 * u, 2 * u, shade("#8e887c"));
      px(ctx, -1.6 * u, -5.4 * u, 1.2 * u, 1.4 * u, "#0a0a10");
      px(ctx, 0.4 * u, -5.4 * u, 1.2 * u, 1.4 * u, "#0a0a10");
      px(ctx, -1 * u, -2 * u, 2 * u, 4 * u, shade("#9a9488"));
      break;
    }
    case "doll": {
      px(ctx, -2 * u, -1 * u, 4 * u, 5 * u, shade("#6a2a3a"));
      px(ctx, -2.4 * u, -4 * u, 4.8 * u, 3.4 * u, shade("#e8e0d0"));
      px(ctx, -1 * u, -3 * u, 2 * u, 1 * u, shade("#c8c0b0"));
      px(ctx, -0.4 * u, -4 * u, 0.8 * u, 3 * u, shade("#a89c8c"));
      px(ctx, -3 * u, 0, 1.4 * u, 3 * u, shade("#5a2030"));
      px(ctx, 1.6 * u, 0, 1.4 * u, 3 * u, shade("#5a2030"));
      eye(-1.4, -3.4, "#c8343c");
      eye(1.4, -3.4, "#c8343c");
      break;
    }
    case "widow": {
      px(ctx, -3.5 * u, -1 * u, 7 * u, 8 * u, shade("#14141c"));
      px(ctx, -2.5 * u, -5 * u, 5 * u, 4 * u, shade("#2a2a34"));
      px(ctx, -1.8 * u, -4.4 * u, 3.6 * u, 3 * u, shade("#d8d2c2"));
      px(ctx, -4.5 * u, -1 * u, 1.4 * u, 6 * u, shade("#1e1e28"));
      px(ctx, 3.1 * u, -1 * u, 1.4 * u, 6 * u, shade("#1e1e28"));
      px(ctx, -5 * u, 4 * u, 2 * u, 1.4 * u, shade("#d8d2c2"));
      px(ctx, 3 * u, 4 * u, 2 * u, 1.4 * u, shade("#d8d2c2"));
      px(ctx, -3.5 * u, 6 * u, 7 * u, 1.4 * u, shade("#0a0a10"));
      eye(-1.1, -3.6, "#ffb95e");
      eye(1.1, -3.6, "#ffb95e");
      break;
    }
    case "wretch": {
      px(ctx, -4 * u, -2 * u, 8 * u, 7 * u, shade("#3a4a38"));
      px(ctx, -2 * u, -5 * u, 4 * u, 3 * u, shade("#465844"));
      px(ctx, -5 * u, 0, 1.4 * u, 5 * u, shade("#2f3d2d"));
      px(ctx, 3.6 * u, 0, 1.4 * u, 5 * u, shade("#2f3d2d"));
      px(ctx, -3 * u, 4 * u, 2 * u, 2 * u, shade("#26331f"));
      px(ctx, 1 * u, 4 * u, 2 * u, 2 * u, shade("#26331f"));
      px(ctx, -3 * u, -1 * u, 6 * u, 1 * u, shade("#2f3d2d"));
      eye(0, -4, "#c8343c", 2);
      break;
    }
    case "angler": {
      for (let i = 0; i < 6; i++) {
        const sx = -4 * u + i * 1.6 * u;
        px(ctx, sx, -1 * u + Math.sin(t * 3 + i) * u * 0.5, 1.8 * u, 3 * u, shade(i % 2 ? "#2a3a4a" : "#22303e"));
      }
      px(ctx, 3 * u, -2 * u, 3 * u, 3 * u, shade("#2a3a4a"));
      px(ctx, 3 * u, -1 * u, 3 * u, 1 * u, shade("#c8c0b0"));
      px(ctx, -4 * u, -5 * u, 1 * u, 4 * u, shade("#1a2634"));
      px(ctx, -5 * u, -6 * u, 3 * u, 2 * u, "#7fe0d0");
      ctx.globalAlpha *= 0.3;
      px(ctx, -6 * u, -7 * u, 5 * u, 4 * u, "#7fe0d0");
      ctx.globalAlpha /= 0.3;
      eye(4.4, -1.4, "#c8343c");
      break;
    }
    case "drowned": {
      px(ctx, -4 * u, -1 * u, 8 * u, 9 * u, shade("#cfd8dc"));
      px(ctx, -3 * u, -6 * u, 6 * u, 5 * u, shade("#1a2a34"));
      px(ctx, -2 * u, -4.6 * u, 4 * u, 3.4 * u, shade("#e8eef0"));
      px(ctx, -4 * u, -5 * u, 1.4 * u, 7 * u, shade("#1a2a34"));
      px(ctx, 2.6 * u, -5 * u, 1.4 * u, 7 * u, shade("#1a2a34"));
      px(ctx, -5 * u, 5 * u, 10 * u, 2 * u, shade("#b8c4c8"));
      px(ctx, -2 * u, 0, 4 * u, 4 * u, shade("#9fb0b6"));
      eye(-1.2, -3.8, "#7fd8f0");
      eye(1.2, -3.8, "#7fd8f0");
      break;
    }
    case "ashen": {
      px(ctx, -3 * u, -2 * u, 6 * u, 9 * u, shade("#4a4a52"));
      px(ctx, -2.6 * u, -6 * u, 5.2 * u, 4 * u, shade("#565660"));
      px(ctx, -1.6 * u, -5 * u, 3.2 * u, 2.6 * u, "#0a0a10");
      px(ctx, -4.4 * u, -1 * u, 1.4 * u, 5 * u, shade("#3e3e46"));
      px(ctx, 3 * u, -1 * u, 1.4 * u, 5 * u, shade("#3e3e46"));
      px(ctx, -3 * u, 6 * u, 6 * u, 1.4 * u, shade("#33333b"));
      px(ctx, -1 * u, -1 * u, 2 * u, 5 * u, shade("#5e5e68"));
      break;
    }
    case "bell": {
      px(ctx, -4 * u, -5 * u, 8 * u, 6 * u, shade("#6a6a52"));
      px(ctx, -5 * u, -1 * u, 10 * u, 2 * u, shade("#7e7e62"));
      px(ctx, -1 * u, -1 * u, 2 * u, 3 * u, shade("#4a4a3a"));
      px(ctx, -3 * u, 1 * u, 6 * u, 6 * u, shade("#2a2a34"));
      px(ctx, -4 * u, 6 * u, 8 * u, 2 * u, shade("#1e1e28"));
      eye(-1.6, 2.4, "#d8d2c2");
      eye(1.6, 2.4, "#d8d2c2");
      break;
    }
    case "choir": {
      px(ctx, -7 * u, -6 * u, 14 * u, 14 * u, shade("#0e0e14"));
      px(ctx, -6 * u, -7 * u, 12 * u, 3 * u, shade("#16161e"));
      px(ctx, -8 * u, -2 * u, 2 * u, 8 * u, shade("#0a0a10"));
      px(ctx, 6 * u, -2 * u, 2 * u, 8 * u, shade("#0a0a10"));
      for (let i = 0; i < 9; i++) {
        const mx = -5 * u + (i % 3) * 4 * u;
        const my = -3 * u + Math.floor(i / 3) * 3.4 * u;
        const open = 1 + Math.sin(t * 4 + i) * 0.5;
        px(ctx, mx, my, 2.6 * u, 1.4 * u + open * u * 0.5, "#2a0a10");
        px(ctx, mx + 0.4 * u, my + 0.3 * u, 1.8 * u, 0.8 * u, "#8e1c22");
      }
      eye(-4.5, -6, "#c8343c");
      eye(4.5, -6, "#c8343c");
      eye(0, -6.6, "#c8343c");
      break;
    }
  }
  ctx.restore();
}

function shadeDark(c: string): string {
  const m = c.replace("#", "");
  const n = parseInt(m, 16);
  const r = Math.max(4, Math.floor(((n >> 16) & 255) * 0.3));
  const g = Math.max(4, Math.floor(((n >> 8) & 255) * 0.3));
  const b = Math.max(6, Math.floor((n & 255) * 0.34));
  return `rgb(${r},${g},${b})`;
}

/* ------------------------------------------------------------------ *
 * the player
 * ------------------------------------------------------------------ */
export function drawPlayer(
  ctx: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  u: number,
  facing: number,
  t: number,
  moving: boolean,
) {
  const step = moving ? Math.sin(t * 11) : 0;
  ctx.save();
  ctx.translate(Math.round(cx), Math.round(cy));
  // shadow
  ctx.globalAlpha = 0.35;
  px(ctx, -3 * u, 5 * u, 6 * u, 2 * u, "#000000");
  ctx.globalAlpha = 1;
  // legs
  px(ctx, -2 * u, 3 * u + step * u * 0.5, 1.6 * u, 3 * u, "#2a2018");
  px(ctx, 0.4 * u, 3 * u - step * u * 0.5, 1.6 * u, 3 * u, "#2a2018");
  // cloak
  px(ctx, -3 * u, -2 * u, 6 * u, 6 * u, "#2b2b36");
  px(ctx, -3 * u, -2 * u, 6 * u, 1.4 * u, "#3a3a48");
  px(ctx, -3 * u, 3 * u, 6 * u, 1.4 * u, "#1e1e28");
  // hood
  px(ctx, -2.4 * u, -5 * u, 4.8 * u, 3.4 * u, "#33333f");
  px(ctx, -1.8 * u, -4.2 * u, 3.6 * u, 2.4 * u, "#0a0a10");
  if (facing !== 1) {
    px(ctx, -1.2 * u, -3.6 * u, 0.8 * u, 0.8 * u, "#8e7a5a");
    px(ctx, 0.4 * u, -3.6 * u, 0.8 * u, 0.8 * u, "#8e7a5a");
  }
  // lantern arm
  const lx = facing === 2 ? -4.4 : facing === 3 ? 4.4 : 3.4;
  const ly = 0.4;
  px(ctx, lx - 0.6 * u, ly - 1.4 * u, 1.4 * u, 2.6 * u, "#6a5a3a");
  px(ctx, lx - 0.9 * u, ly - 1.8 * u, 2 * u, 0.6 * u, "#8a7a4a");
  const fl = 0.7 + Math.sin(t * 9) * 0.3;
  px(ctx, lx - 0.5 * u, ly - 1.2 * u, 1.2 * u, 1.6 * u, "#ffb95e");
  ctx.globalAlpha = 0.45 * fl;
  px(ctx, lx - 1.4 * u, ly - 2 * u, 3 * u, 3.4 * u, "#e8a33d");
  ctx.globalAlpha = 1;
  ctx.restore();
}

/* ------------------------------------------------------------------ *
 * pickups
 * ------------------------------------------------------------------ */
export function drawPickup(
  ctx: CanvasRenderingContext2D,
  ref: string,
  cx: number,
  cy: number,
  u: number,
  t: number,
) {
  const bob = Math.sin(t * 2.2) * u * 0.4;
  ctx.save();
  ctx.translate(Math.round(cx), Math.round(cy) + Math.round(bob));
  ctx.globalAlpha = 0.3;
  px(ctx, -2 * u, 4 * u, 4 * u, 1.6 * u, "#000000");
  ctx.globalAlpha = 1;
  switch (ref) {
    case "oil":
      px(ctx, -1.6 * u, -2 * u, 3.2 * u, 5 * u, "#4a3a1a");
      px(ctx, -1 * u, -3 * u, 2 * u, 1.4 * u, "#6a5a2a");
      px(ctx, -1.2 * u, -0.6 * u, 2.4 * u, 2.6 * u, "#ffb95e");
      break;
    case "tonic":
      px(ctx, -1.4 * u, -1.6 * u, 2.8 * u, 4.6 * u, "#3a5a4a");
      px(ctx, -0.8 * u, -3 * u, 1.6 * u, 1.6 * u, "#6a7a6a");
      px(ctx, -1 * u, -0.6 * u, 2 * u, 3 * u, "#7fd8a0");
      break;
    case "salt":
      px(ctx, -2 * u, 1 * u, 4 * u, 2 * u, "#c8c0b0");
      px(ctx, -1.2 * u, -0.6 * u, 2.4 * u, 2 * u, "#e8e0d0");
      px(ctx, -0.4 * u, -2 * u, 0.8 * u, 1.4 * u, "#d8d2c2");
      break;
    case "graveIron":
      px(ctx, -0.8 * u, -4 * u, 1.6 * u, 8 * u, "#8a8a96");
      px(ctx, -1.6 * u, 2 * u, 3.2 * u, 1.4 * u, "#4a3524");
      px(ctx, -0.4 * u, -4.6 * u, 0.8 * u, 1 * u, "#c8c8d2");
      break;
    case "glassBlade":
      px(ctx, -0.8 * u, -4 * u, 1.6 * u, 8 * u, "#9fd8e8");
      px(ctx, -1.6 * u, 2 * u, 3.2 * u, 1.4 * u, "#2a3a4a");
      px(ctx, -0.4 * u, -4.6 * u, 0.8 * u, 1 * u, "#e8f8ff");
      break;
    case "wardCharm":
      px(ctx, -2 * u, -2 * u, 4 * u, 4 * u, "#6a5a3a");
      px(ctx, -1.2 * u, -1.2 * u, 2.4 * u, 2.4 * u, "#e8a33d");
      px(ctx, -0.6 * u, -0.6 * u, 1.2 * u, 1.2 * u, "#fff0c0");
      break;
    default:
      px(ctx, -2 * u, -3 * u, 4 * u, 6 * u, "#c8c0a8");
      px(ctx, -1.4 * u, -1.8 * u, 2.8 * u, 0.8 * u, "#6a6252");
      px(ctx, -1.4 * u, -0.4 * u, 2.8 * u, 0.8 * u, "#6a6252");
      px(ctx, -1.4 * u, 1 * u, 1.8 * u, 0.8 * u, "#6a6252");
      break;
  }
  ctx.restore();
}
