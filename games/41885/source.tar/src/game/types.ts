export type TileKind =
  | "void"
  | "grass"
  | "dirt"
  | "wall"
  | "floor"
  | "wood"
  | "stone"
  | "grave"
  | "water"
  | "tree"
  | "fence"
  | "door"
  | "gate"
  | "stairs"
  | "rubble"
  | "altar"
  | "bed"
  | "table"
  | "pillar"
  | "well"
  | "blood"
  | "shrine"
  | "crate";

export interface TileDef {
  /** blocks movement */
  solid: boolean;
  /** blocks lantern light */
  opaque: boolean;
}

export const TILES: Record<TileKind, TileDef> = {
  void: { solid: true, opaque: true },
  grass: { solid: false, opaque: false },
  dirt: { solid: false, opaque: false },
  wall: { solid: true, opaque: true },
  floor: { solid: false, opaque: false },
  wood: { solid: false, opaque: false },
  stone: { solid: false, opaque: false },
  grave: { solid: false, opaque: false },
  water: { solid: false, opaque: false },
  tree: { solid: true, opaque: true },
  fence: { solid: true, opaque: false },
  door: { solid: false, opaque: false },
  gate: { solid: true, opaque: true },
  stairs: { solid: false, opaque: false },
  rubble: { solid: true, opaque: false },
  altar: { solid: true, opaque: false },
  bed: { solid: true, opaque: false },
  table: { solid: true, opaque: false },
  pillar: { solid: true, opaque: true },
  well: { solid: true, opaque: false },
  blood: { solid: false, opaque: false },
  shrine: { solid: true, opaque: false },
  crate: { solid: true, opaque: false },
};

export type ItemId = "oil" | "tonic" | "salt" | "graveIron" | "glassBlade" | "wardCharm";

export interface ItemDef {
  id: ItemId;
  name: string;
  desc: string;
  kind: "consumable" | "weapon" | "relic";
  atk?: number;
}

export type EntityKind = "enemy" | "item" | "note" | "exit" | "altar";

export interface Entity {
  id: string;
  kind: EntityKind;
  x: number;
  y: number;
  /** enemy id / item id / note id / destination area id */
  ref?: string;
  label?: string;
  /** runtime only */
  fx?: number;
  fy?: number;
  tx?: number;
  ty?: number;
  facing?: number;
  step?: number;
  aggro?: boolean;
  dead?: boolean;
}

export interface Area {
  id: string;
  name: string;
  subtitle: string;
  kind: "graveyard" | "house";
  w: number;
  h: number;
  tiles: TileKind[];
  entities: Entity[];
  spawn: { x: number; y: number };
  bossId?: string;
  /** 0..1 rain strength */
  rain: number;
  /** 0..1 base ambient light */
  ambient: number;
}

export interface Player {
  hp: number;
  maxHp: number;
  atk: number;
  def: number;
  spd: number;
  oil: number;
  maxOil: number;
  weapon: ItemId;
  inv: Record<string, number>;
  notes: string[];
  cleared: string[];
  deaths: number;
}
