import * as THREE from "three";
import { colleagueTexture, toonGradient } from "./textures";

const GRAD = toonGradient(3);

/**
 * A flat cel-shaded cardboard standee: one printed cutout on a bent-card
 * stand, leaning in over the desk.
 */
export class Standee {
  group = new THREE.Group();
  state: "entering" | "idle" | "leaving" = "entering";
  private tex: THREE.Texture;
  private mat: THREE.MeshToonMaterial;
  private plane: THREE.Mesh;
  private phase = Math.random() * 10;
  private t = 0;
  private fromX: number;
  private toX: number;

  constructor(kind: number, x: number, z: number, facing: number) {
    this.tex = colleagueTexture(kind);
    this.mat = new THREE.MeshToonMaterial({
      map: this.tex,
      gradientMap: GRAD,
      transparent: true,
      alphaTest: 0.45,
      emissive: new THREE.Color(0x33455f),
      emissiveIntensity: 0.75,
      side: THREE.DoubleSide,
    });
    this.plane = new THREE.Mesh(new THREE.PlaneGeometry(0.42, 1.31), this.mat);
    this.plane.position.y = 0.655;
    this.group.add(this.plane);

    // bent-card stand
    const cardMat = new THREE.MeshToonMaterial({
      color: 0xcfc6b2,
      gradientMap: GRAD,
      side: THREE.DoubleSide,
    });
    for (const s of [-1, 1]) {
      const leg = new THREE.Mesh(new THREE.PlaneGeometry(0.07, 0.5), cardMat);
      leg.position.set(s * 0.11, 0.25, -0.05);
      leg.rotation.x = -0.5;
      this.group.add(leg);
    }
    const base = new THREE.Mesh(new THREE.PlaneGeometry(0.34, 0.06), cardMat);
    base.rotation.x = -Math.PI / 2;
    base.position.set(0, 0.005, -0.2);
    this.group.add(base);

    this.fromX = x - 1.15;
    this.toX = x;
    this.group.position.set(this.fromX, 0, z);
    this.group.rotation.y = facing;
  }

  leave() {
    this.state = "leaving";
    this.fromX = this.group.position.x;
    this.toX = this.fromX - 1.25;
  }

  update(dt: number) {
    this.t += dt;
    const sway = Math.sin(this.t * 1.3 + this.phase) * 0.022;
    if (this.state === "entering" || this.state === "leaving") {
      const k = 1 - Math.exp(-2.6 * dt);
      this.group.position.x += (this.toX - this.group.position.x) * k;
      if (Math.abs(this.toX - this.group.position.x) < 0.01) {
        this.state = this.state === "entering" ? "idle" : "leaving";
      }
    }
    this.group.rotation.z = sway;
    this.group.rotation.x = -0.1 + Math.sin(this.t * 0.9 + this.phase) * 0.012;
    this.plane.position.y = 0.655 + Math.sin(this.t * 1.7 + this.phase) * 0.006;
  }

  get done() {
    return this.state === "leaving" && Math.abs(this.group.position.x - this.toX) < 0.02;
  }

  dispose() {
    this.tex.dispose();
    this.mat.dispose();
    this.plane.geometry.dispose();
  }
}
