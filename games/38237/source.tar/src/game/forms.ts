import * as THREE from "three";
import type { FormData, Verdict } from "./core";
import { formTexture, rnd } from "./textures";

export type FormState = "desk" | "held" | "filing" | "gone";

const FORM_W = 0.19;
const FORM_H = 0.26;

/** A curled, printed attestation sheet with a paperclip. */
export class FormCard {
  group = new THREE.Group();
  data: FormData;
  mesh: THREE.Mesh;
  state: FormState = "desk";
  slot = -1;
  filedVerdict: Verdict | null = null;
  correct = false;

  private targetPos = new THREE.Vector3();
  private targetQuat = new THREE.Quaternion();
  private speed = 9;
  private fileT = 0;
  private hop = 0;
  private paperMat: THREE.MeshStandardMaterial;
  private paperTex: THREE.Texture;

  constructor(data: FormData) {
    this.data = data;

    const geo = new THREE.PlaneGeometry(FORM_W, FORM_H, 14, 20);
    const pos = geo.attributes.position as THREE.BufferAttribute;
    for (let i = 0; i < pos.count; i++) {
      const x = pos.getX(i);
      const y = pos.getY(i);
      const u = x / (FORM_W / 2);
      const v = y / (FORM_H / 2);
      const curl = -(u * u * 0.0055 + v * v * 0.0075) + Math.sin(u * 2.2 + v * 1.4) * 0.0016;
      pos.setZ(i, curl);
    }
    geo.computeVertexNormals();

    this.paperTex = formTexture(data);
    this.paperMat = new THREE.MeshStandardMaterial({
      map: this.paperTex,
      roughness: 0.93,
      metalness: 0,
      side: THREE.DoubleSide,
    });
    this.mesh = new THREE.Mesh(geo, this.paperMat);
    this.mesh.castShadow = true;
    this.mesh.receiveShadow = true;
    this.group.add(this.mesh);

    // paperclip on tampered forms
    if (data.stamp) {
      const clipMat = new THREE.MeshStandardMaterial({ color: 0x9aa4b2, roughness: 0.35, metalness: 0.8 });
      for (let i = 0; i < 2; i++) {
        const clip = new THREE.Mesh(new THREE.TorusGeometry(0.014, 0.0018, 5, 14), clipMat);
        clip.position.set(-FORM_W / 2 + 0.02, FORM_H / 2 - 0.03 - i * 0.006, 0.006);
        clip.rotation.set(Math.PI / 2, 0, 0.06 * i);
        this.group.add(clip);
      }
    }
  }

  /** lay flat in a desk slot */
  layout(slot: number, deskY: number) {
    this.slot = slot;
    const x = -0.4 + slot * 0.2;
    const z = 0.11 + (slot % 2 === 0 ? 0.012 : -0.008);
    this.targetPos.set(x, deskY + 0.004 + slot * 0.0008, z);
    const e = new THREE.Euler(-Math.PI / 2, 0, (rnd() - 0.5) * 0.16 + slot * 0.02);
    this.targetQuat.setFromEuler(e);
    this.speed = 7;
  }

  /** raise toward the camera */
  hold(pos: THREE.Vector3, quat: THREE.Quaternion) {
    this.state = "held";
    this.targetPos.copy(pos);
    this.targetQuat.copy(quat);
    this.speed = 13;
  }

  fileTo(center: THREE.Vector3, verdict: Verdict) {
    this.state = "filing";
    this.filedVerdict = verdict;
    this.fileT = 0;
    this.hop = 0.06;
    this.targetPos.set(center.x + (rnd() - 0.5) * 0.05, center.y + 0.02, center.z + (rnd() - 0.5) * 0.03);
    this.targetQuat.setFromEuler(new THREE.Euler(-Math.PI / 2, (rnd() - 0.5) * 0.3, 0));
    this.speed = 11;
  }

  update(dt: number, camera: THREE.Camera) {
    const k = 1 - Math.exp(-this.speed * dt);
    if (this.state === "filing") {
      this.fileT += dt;
      this.hop *= Math.exp(-4 * dt);
    }
    this.group.position.lerp(this.targetPos, k);
    this.group.position.y += this.hop * Math.sin(Math.min(1, this.fileT * 4) * Math.PI);
    this.group.quaternion.slerp(this.targetQuat, k);
    if (this.state === "filing" && this.group.position.distanceTo(this.targetPos) < 0.004) {
      this.state = "gone";
    }
    void camera;
  }

  dispose() {
    this.paperTex.dispose();
    this.paperMat.dispose();
    this.mesh.geometry.dispose();
  }
}
