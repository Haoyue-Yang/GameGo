import * as THREE from "three";

/**
 * Single-pass VHS degradation: barrel warp, chromatic aberration, luminance
 * bleed, scanlines, aperture grille, grain, tracking tear, rolling band,
 * vignette. `uSpike` is driven up on misfiles and at the climax.
 */
export class PostFX {
  rt: THREE.WebGLRenderTarget;
  private scene = new THREE.Scene();
  private cam = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);
  private mat: THREE.ShaderMaterial;
  uniforms: Record<string, THREE.IUniform>;

  constructor(w: number, h: number) {
    this.rt = new THREE.WebGLRenderTarget(w, h, {
      minFilter: THREE.LinearFilter,
      magFilter: THREE.LinearFilter,
      depthBuffer: true,
      stencilBuffer: false,
    });
    this.uniforms = {
      tDiffuse: { value: this.rt.texture },
      uRes: { value: new THREE.Vector2(w, h) },
      uTime: { value: 0 },
      uSpike: { value: 0 },
    };
    this.mat = new THREE.ShaderMaterial({
      uniforms: this.uniforms,
      depthTest: false,
      depthWrite: false,
      vertexShader: /* glsl */ `
        varying vec2 vUv;
        void main(){ vUv = uv; gl_Position = vec4(position.xy, 0.0, 1.0); }
      `,
      fragmentShader: /* glsl */ `
        precision highp float;
        uniform sampler2D tDiffuse;
        uniform vec2 uRes;
        uniform float uTime;
        uniform float uSpike;
        varying vec2 vUv;

        float hash(vec2 p){ return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453123); }

        void main(){
          vec2 c = vUv - 0.5;
          float r2 = dot(c, c);
          // barrel warp of the whole frame
          vec2 uv = 0.5 + c * (1.0 + 0.05 * r2 + uSpike * 0.03 * r2);

          // tracking tear: a horizontal slice slides sideways
          float row = floor(uv.y * 110.0);
          float tearSeed = hash(vec2(row, floor(uTime * 9.0)));
          float tear = step(0.982 - uSpike * 0.16, tearSeed);
          uv.x += tear * (0.012 + 0.075 * uSpike);

          // chromatic aberration, stronger at the edges
          float ab = (0.0013 + 0.0075 * uSpike) * (0.3 + r2 * 2.0);
          vec2 dir = normalize(c + vec2(1e-5));
          vec3 col;
          col.r = texture2D(tDiffuse, uv + dir * ab).r;
          col.g = texture2D(tDiffuse, uv).g;
          col.b = texture2D(tDiffuse, uv - dir * ab).b;

          // luminance bleed (phosphor smear)
          float bl = 0.0022 + 0.006 * uSpike;
          vec3 smear = texture2D(tDiffuse, uv + vec2(bl, 0.0)).rgb
                     + texture2D(tDiffuse, uv - vec2(bl, 0.0)).rgb
                     + texture2D(tDiffuse, uv + vec2(0.0, bl)).rgb
                     + texture2D(tDiffuse, uv - vec2(0.0, bl)).rgb;
          col = mix(col, smear * 0.25, 0.42);

          // scanlines + aperture grille
          float sl = sin(uv.y * uRes.y * 1.55 + uTime * 1.1);
          col *= 1.0 - (0.10 + 0.12 * uSpike) * (0.5 + 0.5 * sl);
          float grille = 0.5 + 0.5 * sin(uv.x * uRes.x * 3.14159);
          col *= 1.0 - 0.045 * grille;

          // rolling bright band
          float roll = exp(-pow(fract(uv.y + uTime * 0.045) - 0.5, 2.0) * 700.0);
          col += roll * (0.035 + 0.06 * uSpike);

          // grain
          float g = hash(uv * uRes * 0.5 + fract(uTime) * vec2(37.0, 17.0));
          col += (g - 0.5) * (0.05 + 0.20 * uSpike);

          // cold lift + vignette
          col *= vec3(0.94, 0.98, 1.10);
          float vig = smoothstep(1.05, 0.28, length(c) * 1.42);
          col *= mix(0.42, 1.0, vig);

          col = max(col, vec3(0.0));
          gl_FragColor = vec4(pow(col, vec3(1.0 / 2.2)), 1.0);
        }
      `,
    });
    const quad = new THREE.Mesh(new THREE.PlaneGeometry(2, 2), this.mat);
    quad.frustumCulled = false;
    this.scene.add(quad);
  }

  setSize(w: number, h: number) {
    this.rt.setSize(w, h);
    (this.uniforms.uRes.value as THREE.Vector2).set(w, h);
  }

  spike(amount: number) {
    this.uniforms.uSpike.value = Math.min(1, (this.uniforms.uSpike.value as number) + amount);
  }

  render(renderer: THREE.WebGLRenderer, scene: THREE.Scene, camera: THREE.Camera, time: number) {
    this.uniforms.uTime.value = time;
    const s = this.uniforms.uSpike.value as number;
    this.uniforms.uSpike.value = s > 0.001 ? Math.max(0, s - 0.012) : 0;
    renderer.setRenderTarget(this.rt);
    renderer.clear();
    renderer.render(scene, camera);
    renderer.setRenderTarget(null);
    renderer.render(this.scene, this.cam);
  }

  dispose() {
    this.rt.dispose();
    this.mat.dispose();
  }
}
