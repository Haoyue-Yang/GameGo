import * as THREE from "three";
import {
  MANUAL_LINES,
  derive,
  predMatch,
  predText,
  type DayDef,
  type FormData,
  type Verdict,
} from "./core";

interface Win {
  id: string;
  title: string;
  x: number;
  y: number;
  w: number;
  h: number;
  open: boolean;
  z: number;
  scroll: number;
  scrollable: boolean;
  scrollMax: number;
}

const W = 512;
const H = 384;
const BAR = 6;

const C = {
  bg: "#080d16",
  bg2: "#0d1524",
  body: "#0f1a2b",
  title: "#1d3b56",
  titleActive: "#2b5c80",
  text: "#cfe3f5",
  dim: "#6d87a3",
  green: "#7fd6c8",
  red: "#e0655f",
  amber: "#e0b45f",
  white: "#eaf4ff",
};

function verdictColor(v: Verdict) {
  return v === "CLEAR" ? C.green : v === "SANCTION" ? C.red : C.amber;
}

export class OS {
  canvas = document.createElement("canvas");
  ctx: CanvasRenderingContext2D;
  texture: THREE.CanvasTexture;
  windows: Win[] = [];
  day: DayDef | null = null;
  currentForm: FormData | null = null;
  filed = 0;
  misfiles = 0;
  clock = 8 * 60 + 2;
  private bootT = 0;
  private zTop = 10;
  private drag: { id: string; dx: number; dy: number } | null = null;
  private scrollDrag: { id: string; top: number; track: number; thumb: number; max: number } | null = null;
  private toastText = "";
  private toastT = 0;
  private t = 0;
  private frame = 0;
  private dirty = true;

  constructor() {
    this.canvas.width = W;
    this.canvas.height = H;
    this.ctx = this.canvas.getContext("2d")!;
    this.texture = new THREE.CanvasTexture(this.canvas);
    this.texture.colorSpace = THREE.SRGBColorSpace;
    this.texture.magFilter = THREE.LinearFilter;
    this.texture.minFilter = THREE.LinearFilter;
    this.texture.generateMipmaps = false;
    this.layoutWindows();
  }

  private layoutWindows() {
    this.windows = [
      { id: "dir", title: "DIRECTIVES", x: 6, y: 22, w: 232, h: 236, open: true, z: 3, scroll: 0, scrollable: true, scrollMax: 0 },
      { id: "reg", title: "REGISTRY", x: 244, y: 22, w: 262, h: 186, open: true, z: 4, scroll: 0, scrollable: false, scrollMax: 0 },
      { id: "man", title: "MANUAL", x: 244, y: 212, w: 262, h: 148, open: true, z: 5, scroll: 0, scrollable: false, scrollMax: 0 },
      { id: "note", title: "NOTES", x: 6, y: 264, w: 232, h: 96, open: true, z: 6, scroll: 0, scrollable: true, scrollMax: 0 },
    ];
  }

  setDay(day: DayDef) {
    this.day = day;
    this.filed = 0;
    this.misfiles = 0;
    this.bootT = 0;
    this.clock = day.day === 1 ? 8 * 60 + 2 : day.day === 2 ? 7 * 60 + 58 : 22 * 60 + 47;
    this.layoutWindows();
    this.pushToast("DIRECTIVES RECEIVED · " + day.directives.length);
    this.dirty = true;
  }

  pushToast(text: string) {
    this.toastText = text;
    this.toastT = 3.4;
    this.dirty = true;
  }

  /* ---------------- input ---------------- */

  private winAt(x: number, y: number) {
    const sorted = [...this.windows].sort((a, b) => b.z - a.z);
    for (const w of sorted) {
      if (!w.open) continue;
      if (x >= w.x && x <= w.x + w.w && y >= w.y && y <= w.y + w.h) return w;
    }
    return null;
  }

  private taskbarRects() {
    const rects: { id: string; x: number; y: number; w: number; h: number }[] = [];
    let x = 10;
    for (const w of this.windows) {
      const bw = Math.max(60, w.title.length * 7.2 + 16);
      rects.push({ id: w.id, x, y: H - 22, w: bw, h: 18 });
      x += bw + 6;
    }
    return rects;
  }

  private barRect(w: Win) {
    const top = w.y + 17;
    const track = w.h - 18;
    const client = w.h - 17;
    const max = Math.max(1, w.scrollMax - client);
    const thumb = Math.max(12, Math.round((client / (client + max)) * track));
    return { top, track, thumb, max };
  }

  pointerDown(x: number, y: number): boolean {
    for (const r of this.taskbarRects()) {
      if (x >= r.x && x <= r.x + r.w && y >= r.y && y <= r.y + r.h) {
        const w = this.windows.find((q) => q.id === r.id);
        if (w) {
          w.open = !w.open;
          if (w.open) w.z = ++this.zTop;
        }
        this.dirty = true;
        return true;
      }
    }
    const w = this.winAt(x, y);
    if (!w) return false;
    w.z = ++this.zTop;

    if (w.scrollable) {
      const b = this.barRect(w);
      const bx = w.x + w.w - BAR - 1;
      if (x >= bx && x <= bx + BAR && y >= b.top && y <= b.top + b.track) {
        const thumbY = b.top + (w.scroll / b.max) * (b.track - b.thumb);
        if (y >= thumbY && y <= thumbY + b.thumb) {
          this.scrollDrag = { id: w.id, top: b.top, track: b.track, thumb: b.thumb, max: b.max };
          return true;
        }
        w.scroll = Math.max(0, Math.min(b.max, ((y - b.top) / b.track) * b.max));
        this.dirty = true;
        return true;
      }
    }
    if (y <= w.y + 16) {
      this.drag = { id: w.id, dx: x - w.x, dy: y - w.y };
      return true;
    }
    this.dirty = true;
    return true;
  }

  pointerMove(x: number, y: number) {
    if (this.scrollDrag) {
      const w = this.windows.find((q) => q.id === this.scrollDrag!.id);
      if (w) {
        const b = this.barRect(w);
        const t = (y - this.scrollDrag.top - b.thumb / 2) / Math.max(1, b.track - b.thumb);
        w.scroll = Math.max(0, Math.min(b.max, t * b.max));
        this.dirty = true;
      }
      return;
    }
    if (!this.drag) return;
    const w = this.windows.find((q) => q.id === this.drag!.id);
    if (!w) return;
    w.x = Math.max(0, Math.min(W - w.w, x - this.drag.dx));
    w.y = Math.max(18, Math.min(H - 26 - w.h, y - this.drag.dy));
    this.dirty = true;
  }

  pointerUp() {
    this.drag = null;
    this.scrollDrag = null;
  }

  /* ---------------- drawing ---------------- */

  private text(s: string, x: number, y: number, color = C.text, font = "11px 'Courier New', monospace") {
    this.ctx.font = font;
    this.ctx.fillStyle = color;
    this.ctx.textBaseline = "top";
    this.ctx.fillText(s, x, y);
  }

  private wrap(s: string, x: number, y: number, maxW: number, lh: number, color: string, font: string) {
    this.ctx.font = font;
    const words = s.split(" ");
    let line = "";
    let cy = y;
    for (const word of words) {
      const test = line ? line + " " + word : word;
      if (this.ctx.measureText(test).width > maxW && line) {
        this.text(line, x, cy, color, font);
        cy += lh;
        line = word;
      } else {
        line = test;
      }
    }
    if (line) this.text(line, x, cy, color, font);
    return cy + lh;
  }

  private draw() {
    const ctx = this.ctx;
    ctx.imageSmoothingEnabled = false;
    const g = ctx.createLinearGradient(0, 0, 0, H);
    g.addColorStop(0, C.bg2);
    g.addColorStop(1, C.bg);
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, W, H);
    ctx.strokeStyle = "rgba(60,110,150,0.07)";
    ctx.lineWidth = 1;
    for (let i = -H; i < W; i += 14) {
      ctx.beginPath();
      ctx.moveTo(i, 0);
      ctx.lineTo(i + H, H);
      ctx.stroke();
    }

    // top bar
    ctx.fillStyle = "#0a1220";
    ctx.fillRect(0, 0, W, 18);
    ctx.fillStyle = "rgba(127,214,200,0.5)";
    ctx.fillRect(0, 18, W, 1);
    this.text("COMPLIANCE OS v2.11", 8, 4, C.green, "bold 11px 'Courier New', monospace");
    const mm = Math.floor(this.clock % 60);
    const hh = Math.floor((this.clock / 60) % 24);
    const day = this.day ? this.day.day : 1;
    const quota = this.day ? this.day.quota : 0;
    const dots = "●".repeat(this.misfiles) + "○".repeat(Math.max(0, 3 - this.misfiles));
    ctx.textAlign = "right";
    this.text(
      `DAY ${day}  FILED ${this.filed}/${quota}  MISFILE ${dots}  ${String(hh).padStart(2, "0")}:${String(mm).padStart(2, "0")}`,
      W - 8,
      4,
      this.misfiles >= 2 ? C.red : C.dim,
      "11px 'Courier New', monospace"
    );
    ctx.textAlign = "left";

    // windows
    const sorted = [...this.windows].sort((a, b) => a.z - b.z);
    for (const w of sorted) {
      if (!w.open) continue;
      const active = this.drag?.id === w.id;
      ctx.fillStyle = "rgba(0,0,0,0.45)";
      ctx.fillRect(w.x + 3, w.y + 4, w.w, w.h);
      ctx.fillStyle = C.body;
      ctx.fillRect(w.x, w.y, w.w, w.h);
      ctx.strokeStyle = active ? C.green : "#22405c";
      ctx.lineWidth = 1;
      ctx.strokeRect(w.x + 0.5, w.y + 0.5, w.w - 1, w.h - 1);
      ctx.fillStyle = active ? C.titleActive : C.title;
      ctx.fillRect(w.x + 1, w.y + 1, w.w - 2, 15);
      this.text(w.title, w.x + 6, w.y + 3, C.white, "bold 11px 'Courier New', monospace");
      ctx.fillStyle = "#0d1a28";
      ctx.fillRect(w.x + w.w - 15, w.y + 3, 12, 11);
      this.text("x", w.x + w.w - 11, w.y + 3, C.red, "11px 'Courier New', monospace");

      ctx.save();
      ctx.beginPath();
      ctx.rect(w.x + 1, w.y + 16, w.w - 2, w.h - 17);
      ctx.clip();
      ctx.translate(0, -w.scroll);
      if (w.id === "dir") this.drawDirectives(w);
      if (w.id === "reg") this.drawRegistry(w);
      if (w.id === "man") this.drawManual(w);
      if (w.id === "note") this.drawNotes(w);
      ctx.restore();

      if (w.scrollable && w.scrollMax > w.h - 17) this.drawScrollbar(w);
    }

    // taskbar
    ctx.fillStyle = "#0a1220";
    ctx.fillRect(0, H - 24, W, 24);
    ctx.fillStyle = "rgba(127,214,200,0.35)";
    ctx.fillRect(0, H - 24, W, 1);
    for (const r of this.taskbarRects()) {
      const w = this.windows.find((q) => q.id === r.id)!;
      ctx.fillStyle = w.open ? "#1d3b56" : "#131f2e";
      ctx.fillRect(r.x, r.y, r.w, r.h);
      ctx.strokeStyle = w.open ? C.green : "#22405c";
      ctx.strokeRect(r.x + 0.5, r.y + 0.5, r.w - 1, r.h - 1);
      this.text(w.title, r.x + 7, r.y + 3, w.open ? C.white : C.dim, "10px 'Courier New', monospace");
    }
    this.text(this.day ? `QUOTA ${this.filed}/${this.day.quota}` : "STANDBY", W - 92, H - 19, C.green, "bold 11px 'Courier New', monospace");

    // toast
    if (this.toastT > 0) {
      ctx.globalAlpha = Math.min(1, this.toastT / 0.6);
      ctx.fillStyle = "#0b1a12";
      ctx.fillRect(W / 2 - 118, 24, 236, 20);
      ctx.strokeStyle = C.green;
      ctx.strokeRect(W / 2 - 117.5, 24.5, 235, 19);
      this.text(this.toastText, W / 2 - 112, 29, C.green, "bold 11px 'Courier New', monospace");
      ctx.globalAlpha = 1;
    }
    this.dirty = false;
    this.texture.needsUpdate = true;
  }

  private drawScrollbar(w: Win) {
    const ctx = this.ctx;
    const b = this.barRect(w);
    const bx = w.x + w.w - BAR - 1;
    ctx.fillStyle = "#0a1220";
    ctx.fillRect(bx, b.top, BAR, b.track);
    const thumbY = b.top + (w.scroll / b.max) * (b.track - b.thumb);
    ctx.fillStyle = "#2b5c80";
    ctx.fillRect(bx, thumbY, BAR, b.thumb);
    ctx.fillStyle = C.green;
    ctx.fillRect(bx, thumbY, BAR, 1);
    ctx.fillRect(bx, thumbY + b.thumb - 1, BAR, 1);
  }

  private drawDirectives(w: Win) {
    const ctx = this.ctx;
    if (!this.day) {
      this.text("AWAITING DIRECTIVES", w.x + 8, w.y + 26, C.dim);
      w.scrollMax = 0;
      return;
    }
    const voided = new Set(this.day.notes.filter((n) => n.voids).map((n) => n.voids!));
    const rescinded = new Set<string>();
    if (this.currentForm) {
      for (const d of this.day.directives) {
        if (d.rescinds && !voided.has(d.id) && predMatch(this.currentForm, d.pred)) rescinded.add(d.rescinds);
      }
    }
    const revealed = Math.floor(this.bootT / 0.4);
    let y = w.y + 24;
    this.day.directives.forEach((d, i) => {
      if (i > revealed) return;
      const isVoid = voided.has(d.id);
      const isResc = rescinded.has(d.id);
      const dead = isVoid || isResc;
      const col = dead ? C.dim : verdictColor(d.action);
      this.text(d.id, w.x + 8, y, dead ? C.dim : C.white, "bold 11px 'Courier New', monospace");
      this.text(`#${d.seq}`, w.x + 44, y, C.dim);
      this.text(d.rescindOnly ? "RESCIND" : d.action, w.x + 68, y, d.rescindOnly ? C.amber : col, "bold 11px 'Courier New', monospace");
      y += 14;
      let yy = this.wrap(predText(d.pred), w.x + 8, y, w.w - 24, 11, C.dim, "10px 'Courier New', monospace");
      yy = this.wrap(d.text, w.x + 8, yy, w.w - 24, 11, dead ? C.dim : C.text, "10px 'Courier New', monospace");
      if (dead) {
        ctx.strokeStyle = C.red;
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(w.x + 6, y - 4);
        ctx.lineTo(w.x + w.w - 12, y - 4);
        ctx.stroke();
        this.text(isVoid ? "VOID — SEE NOTES" : "RESCINDED FOR THIS FORM", w.x + 8, y - 11, C.red, "10px 'Courier New', monospace");
        yy += 11;
      }
      y = yy + 5;
    });
    if (revealed < this.day.directives.length && Math.floor(this.t * 4) % 2 === 0) {
      this.text("█", w.x + 8, y, C.green);
    }
    w.scrollMax = y - w.y - 16;
  }

  private drawRegistry(w: Win) {
    const f = this.currentForm;
    if (!f) {
      this.text("NO FORM IN HAND", w.x + 8, w.y + 26, C.dim);
      this.text("RAISE A FORM TO QUERY", w.x + 8, w.y + 40, C.dim);
      w.scrollMax = 0;
      return;
    }
    const d = derive(f);
    let y = w.y + 24;
    this.text(`${f.id} · ${f.applicant}`, w.x + 8, y, C.white, "bold 11px 'Courier New', monospace");
    y += 16;
    const rows: [string, string, string][] = [
      ["REG DEPT", f.regDept, C.text],
      ["REG CLEARANCE", `LVL ${f.regClearance}`, C.text],
      ["REG SUPERVISOR", f.regSupervisor, C.text],
      ["ATTESTED", f.regAttested ? "YES" : "NO", f.regAttested ? C.text : C.amber],
      ["FLAG", f.regFlagged ? "*** FLAGGED ***" : "NONE", f.regFlagged ? C.red : C.text],
    ];
    for (const [k, v, col] of rows) {
      this.text(k, w.x + 8, y, C.dim, "10px 'Courier New', monospace");
      this.text(v, w.x + 112, y, col, "10px 'Courier New', monospace");
      y += 13;
    }
    y += 3;
    this.ctx.fillStyle = "rgba(127,214,200,0.18)";
    this.ctx.fillRect(w.x + 6, y, w.w - 12, 1);
    y += 5;
    this.text("DECLARED vs REGISTRY", w.x + 8, y, C.green, "bold 10px 'Courier New', monospace");
    y += 14;
    const checks: [string, string, boolean][] = [
      ["DEPT", `${f.dept} / ${f.regDept}`, !d.deptMismatch],
      ["CLR", `${f.clearance} / ${f.regClearance}`, d.overClearance <= 0],
      ["SUP", `${f.supervisor} / ${f.regSupervisor}`, !d.supMismatch],
      ["SIG", f.signature, f.signature === "VALID"],
      ["SEAL", f.seal, f.seal === "VALID"],
    ];
    for (const [k, v, ok] of checks) {
      this.text(k, w.x + 8, y, C.dim, "10px 'Courier New', monospace");
      this.text(v, w.x + 52, y, ok ? C.text : C.red, "10px 'Courier New', monospace");
      this.text(ok ? "OK" : "CONTRADICT", w.x + 172, y, ok ? C.dim : C.red, "10px 'Courier New', monospace");
      y += 13;
    }
    w.scrollMax = y - w.y - 16;
  }

  private drawManual(w: Win) {
    let y = w.y + 24;
    for (let i = 0; i < MANUAL_LINES.length; i++) {
      const line = MANUAL_LINES[i];
      const head = i === 0 || line[0] === "1" || line[0] === "2" || line[0] === "3";
      const yy = this.wrap(line, w.x + 8, y, w.w - 16, 11, head ? C.green : C.text, "10px 'Courier New', monospace");
      y = yy + (head ? 3 : 0);
    }
    w.scrollMax = y - w.y - 16;
  }

  private drawNotes(w: Win) {
    if (!this.day) {
      this.text("EMPTY", w.x + 8, w.y + 26, C.dim);
      w.scrollMax = 0;
      return;
    }
    let y = w.y + 24;
    this.text("OFFICER'S MARGINALIA", w.x + 8, y, C.amber, "bold 10px 'Courier New', monospace");
    y += 15;
    for (const n of this.day.notes) {
      y = this.wrap(n.text, w.x + 8, y, w.w - 24, 11, C.text, "10px 'Courier New', monospace");
      if (n.voids) {
        this.text(`=> ${n.voids} IS VOID`, w.x + 10, y, C.red, "10px 'Courier New', monospace");
        y += 12;
      }
      y += 3;
    }
    w.scrollMax = y - w.y - 16;
  }

  /* ---------------- loop ---------------- */

  update(dt: number) {
    this.t += dt;
    this.clock += dt * 12;
    if (this.bootT < 10) this.bootT += dt;
    if (this.toastT > 0) {
      this.toastT -= dt;
      this.dirty = true;
    }
    if (this.bootT < 10) this.dirty = true;
    this.frame++;
    if (this.dirty && this.frame % 2 === 0) this.draw();
  }
}
