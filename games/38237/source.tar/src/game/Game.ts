import * as THREE from "three";
import {
  DAYS,
  DIALOGUES,
  computeEnding,
  resolveVerdict,
  type DayDef,
  type Directive,
  type Ending,
  type FormData,
  type Verdict,
} from "./core";
import { buildEnvironment, type Env } from "./environment";
import { FormCard } from "./forms";
import { OS } from "./os";
import { PostFX } from "./postfx";
import { Standee } from "./standees";

export type Phase = "intro" | "brief" | "play" | "dayEnd" | "ending";

export interface Feedback {
  correct: boolean;
  verdict: Verdict;
  reason: string;
  formId: string;
  filedAs: Verdict;
}

export interface Snapshot {
  phase: Phase;
  dayIndex: number;
  dayTitle: string;
  dayBrief: string;
  filed: number;
  quota: number;
  misfiles: number;
  relation: number;
  obedience: number;
  recallUsed: boolean;
  canRecall: boolean;
  dialogue: (typeof DIALOGUES)[string] | null;
  dialogueResult: string | null;
  feedback: Feedback | null;
  ending: Ending | null;
  hint: string;
  onDesk: number;
}

class Blips {
  private ac: AudioContext | null = null;
  private ok() {
    if (!this.ac) {
      const Ctor = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (Ctor) this.ac = new Ctor();
    }
    if (this.ac && this.ac.state === "suspended") void this.ac.resume();
    return this.ac;
  }
  tone(freq: number, dur: number, type: OscillatorType, gain: number, delay = 0) {
    const ac = this.ok();
    if (!ac) return;
    const t = ac.currentTime + delay;
    const o = ac.createOscillator();
    const g = ac.createGain();
    o.type = type;
    o.frequency.setValueAtTime(freq, t);
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(gain, t + 0.008);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g).connect(ac.destination);
    o.start(t);
    o.stop(t + dur + 0.02);
  }
  noise(dur: number, gain: number) {
    const ac = this.ok();
    if (!ac) return;
    const len = Math.floor(ac.sampleRate * dur);
    const buf = ac.createBuffer(1, len, ac.sampleRate);
    const d = buf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / len);
    const src = ac.createBufferSource();
    src.buffer = buf;
    const g = ac.createGain();
    g.gain.value = gain;
    const f = ac.createBiquadFilter();
    f.type = "bandpass";
    f.frequency.value = 900;
    src.connect(f).connect(g).connect(ac.destination);
    src.start();
  }
  click() { this.tone(760, 0.03, "square", 0.025); }
  raise() { this.tone(420, 0.07, "triangle", 0.035); }
  file() { this.tone(300, 0.1, "triangle", 0.05); this.tone(600, 0.07, "square", 0.02, 0.05); }
  bad() { this.noise(0.35, 0.09); this.tone(120, 0.3, "sawtooth", 0.05); }
  push() { this.tone(220, 0.06, "square", 0.03); this.tone(330, 0.06, "square", 0.03, 0.08); this.tone(440, 0.1, "square", 0.03, 0.16); }
}

const SLOTS = 5;

export class Game {
  private renderer: THREE.WebGLRenderer;
  private scene = new THREE.Scene();
  private camera: THREE.PerspectiveCamera;
  private env: Env;
  private os = new OS();
  private postfx: PostFX;
  private blips = new Blips();
  private raycaster = new THREE.Raycaster();
  private pointer = new THREE.Vector2();
  private clock = new THREE.Clock();
  private raf = 0;
  private container: HTMLElement;
  private onSnapshot: (s: Snapshot) => void;

  private basePos = new THREE.Vector3(0, 1.28, 0.88);
  private baseTarget = new THREE.Vector3(0, 0.9, -0.26);
  private shake = 0;

  private forms: FormCard[] = [];
  private queue: FormData[] = [];
  private held: FormCard | null = null;
  private heldLight: THREE.PointLight;
  private standee: Standee | null = null;

  private phase: Phase = "intro";
  private dayIndex = 0;
  private day: DayDef = DAYS[0];
  private directives: Directive[] = [];
  private filed = 0;
  private misfiles = 0;
  private relation = 0;
  private obedience = 0;
  private recallUsed = false;
  private lastFiled: { card: FormCard; correct: boolean } | null = null;
  private dialogueKey: string | null = null;
  private dialogueResult: string | null = null;
  private dialogueTimer = 0;
  private feedback: Feedback | null = null;
  private feedbackTimer = 0;
  private ending: Ending | null = null;
  private totalMisfiles = 0;
  private interrupted = false;
  private climaxDone = false;
  private pointerDownAt = new THREE.Vector2();
  private pointerMoved = false;
  private draggingOS = false;
  private hint = "";

  constructor(container: HTMLElement, onSnapshot: (s: Snapshot) => void) {
    this.container = container;
    this.onSnapshot = onSnapshot;

    this.renderer = new THREE.WebGLRenderer({ antialias: false, powerPreference: "high-performance" });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.5));
    this.renderer.setSize(container.clientWidth, container.clientHeight);
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.05;
    container.appendChild(this.renderer.domElement);
    this.renderer.domElement.style.display = "block";
    this.renderer.domElement.style.touchAction = "none";
    this.renderer.domElement.style.cursor = "default";

    this.scene.background = new THREE.Color(0x03060c);
    this.scene.fog = new THREE.FogExp2(0x040810, 0.21);

    this.camera = new THREE.PerspectiveCamera(46, container.clientWidth / container.clientHeight, 0.05, 40);
    this.camera.position.copy(this.basePos);
    this.camera.lookAt(this.baseTarget);

    this.env = buildEnvironment(this.scene);
    (this.env.screen.material as THREE.MeshBasicMaterial).map = this.os.texture;
    (this.env.screen.material as THREE.MeshBasicMaterial).needsUpdate = true;

    this.heldLight = new THREE.PointLight(0xffc48a, 0, 1.3, 2);
    this.scene.add(this.heldLight);

    this.postfx = new PostFX(container.clientWidth, container.clientHeight);

    const el = this.renderer.domElement;
    el.addEventListener("pointerdown", this.onDown);
    el.addEventListener("pointermove", this.onMove);
    window.addEventListener("pointerup", this.onUp);
    window.addEventListener("resize", this.onResize);

    this.hint = "CLICK A FORM TO RAISE IT · DRAG IT ONTO A TRAY TO FILE";
    this.loop();
    this.emit();
  }

  /* ------------------------------------------------------------ */
  /* public API                                                    */
  /* ------------------------------------------------------------ */

  start() {
    this.dayIndex = 0;
    this.day = DAYS[0];
    this.phase = "brief";
    this.emit();
  }

  beginPlay() {
    this.beginDay(this.dayIndex);
  }

  nextDay() {
    if (this.dayIndex >= DAYS.length - 1) {
      this.finish();
      return;
    }
    this.dayIndex += 1;
    this.day = DAYS[this.dayIndex];
    this.phase = "brief";
    this.emit();
  }

  restart() {
    for (const f of this.forms) {
      this.scene.remove(f.group);
      f.dispose();
    }
    this.forms = [];
    if (this.standee) {
      this.scene.remove(this.standee.group);
      this.standee.dispose();
      this.standee = null;
    }
    this.relation = 0;
    this.obedience = 0;
    this.totalMisfiles = 0;
    this.ending = null;
    this.beginDay(0);
  }

  recall() {
    if (this.recallUsed || !this.lastFiled || this.phase !== "play") return;
    const { card, correct } = this.lastFiled;
    this.recallUsed = true;
    this.lastFiled = null;
    this.filed = Math.max(0, this.filed - (correct ? 1 : 0));
    if (!correct) this.misfiles = Math.max(0, this.misfiles - 1);
    card.state = "desk";
    card.filedVerdict = null;
    const slot = this.freeSlot();
    card.layout(slot, this.env.deskY);
    this.blips.raise();
    this.os.pushToast("RECALL AUTHORISED");
    this.hint = "THE FORM IS BACK ON THE DESK. ONE RECALL PER DAY.";
    this.emit();
  }

  reply(index: number) {
    if (!this.dialogueKey) return;
    const d = DIALOGUES[this.dialogueKey];
    const opt = d.options[Math.max(0, Math.min(d.options.length - 1, index))];
    this.relation = THREE.MathUtils.clamp(this.relation + opt.relation, -1, 1);
    this.obedience = THREE.MathUtils.clamp(this.obedience + opt.obedience, -1, 1);
    this.dialogueResult = opt.result;
    this.dialogueTimer = 4.6;
    this.dialogueKey = null;
    this.blips.click();
    if (this.standee) this.standee.leave();
    this.emit();
  }

  dismissDialogue() {
    if (this.standee) this.standee.leave();
    this.dialogueResult = null;
    this.emit();
  }

  dispose() {
    cancelAnimationFrame(this.raf);
    const el = this.renderer.domElement;
    el.removeEventListener("pointerdown", this.onDown);
    el.removeEventListener("pointermove", this.onMove);
    window.removeEventListener("pointerup", this.onUp);
    window.removeEventListener("resize", this.onResize);
    this.postfx.dispose();
    this.renderer.dispose();
    if (el.parentElement) el.parentElement.removeChild(el);
  }

  /* ------------------------------------------------------------ */
  /* day flow                                                      */
  /* ------------------------------------------------------------ */

  private beginDay(i: number) {
    this.dayIndex = i;
    this.day = DAYS[i];
    this.directives = this.day.directives.filter((d) => !(i === 2 && d.id === "D-07"));
    this.filed = 0;
    this.misfiles = 0;
    this.recallUsed = false;
    this.lastFiled = null;
    this.interrupted = false;
    this.climaxDone = false;
    this.feedback = null;
    this.dialogueResult = null;
    this.dialogueKey = null;
    for (const f of this.forms) {
      this.scene.remove(f.group);
      f.dispose();
    }
    this.forms = [];
    if (this.standee) {
      this.scene.remove(this.standee.group);
      this.standee.dispose();
      this.standee = null;
    }
    this.queue = [...this.day.forms];
    // deterministic-ish shuffle
    for (let k = this.queue.length - 1; k > 0; k--) {
      const j = Math.floor(Math.random() * (k + 1));
      [this.queue[k], this.queue[j]] = [this.queue[j], this.queue[k]];
    }
    this.os.setDay({ ...this.day, directives: this.directives });
    this.phase = "play";
    this.hint = "CROSS-CHECK DIRECTIVES, REGISTRY, MANUAL AND NOTES. ONE VERDICT IS CORRECT.";
    this.blips.push();
    this.spawn();
    this.emit();
  }

  private finish() {
    this.ending = computeEnding(this.obedience, this.relation, this.totalMisfiles, this.misfiles >= 3);
    this.phase = "ending";
    this.emit();
  }

  private freeSlot() {
    const used = new Set(this.forms.filter((f) => f.state === "desk").map((f) => f.slot));
    for (let s = 0; s < SLOTS; s++) if (!used.has(s)) return s;
    return 0;
  }

  private spawn() {
    const remaining = this.day.quota - this.filed;
    const want = Math.min(SLOTS, remaining + 1, this.queue.length);
    while (
      this.queue.length > 0 &&
      this.forms.filter((f) => f.state === "desk" || f.state === "held").length < want
    ) {
      const data = this.queue.shift()!;
      const card = new FormCard(data);
      const slot = this.freeSlot();
      card.layout(slot, this.env.deskY);
      card.group.position.set(slot === 0 ? -0.4 : -0.4 + slot * 0.2, this.env.deskY + 0.12, 0.11);
      this.scene.add(card.group);
      this.forms.push(card);
    }
  }

  private fileForm(card: FormCard, verdict: Verdict) {
    const day: DayDef = { ...this.day, directives: this.directives };
    const res = resolveVerdict(card.data, day);
    const correct = res.verdict === verdict;
    const tray = this.env.trays.find((t) => t.verdict === verdict)!;
    card.fileTo(tray.center, verdict);
    this.held = null;
    this.heldLight.intensity = 0;
    this.os.currentForm = null;

    if (correct) {
      this.filed += 1;
      this.os.filed = this.filed;
      this.lastFiled = { card, correct: true };
      this.blips.file();
      this.feedback = { correct: true, verdict: res.verdict, reason: res.reason, formId: card.data.id, filedAs: verdict };
      this.os.pushToast(`FILED · ${verdict}`);
    } else {
      this.misfiles += 1;
      this.totalMisfiles += 1;
      this.os.misfiles = this.misfiles;
      this.lastFiled = { card, correct: false };
      this.blips.bad();
      this.postfx.spike(0.6);
      this.shake = 1;
      this.feedback = { correct: false, verdict: res.verdict, reason: res.reason, formId: card.data.id, filedAs: verdict };
      this.os.pushToast("MISFILE · " + res.verdict);
    }
    this.feedbackTimer = 5;
    this.hint = correct
      ? "CORRECT. " + res.reason
      : `MISFILE. CORRECT VERDICT WAS ${res.verdict}. ${res.reason}`;

    if (this.misfiles >= 3) {
      this.ending = computeEnding(this.obedience, this.relation, this.totalMisfiles, true);
      this.phase = "ending";
      this.postfx.spike(1);
      this.shake = 1.4;
      this.emit();
      return;
    }
    if (this.filed >= this.day.quota) {
      this.phase = "dayEnd";
      this.emit();
      return;
    }
    if (!this.interrupted && this.filed >= this.day.interruptAt) {
      this.interrupt();
    }
    this.spawn();
    this.emit();
  }

  private interrupt() {
    this.interrupted = true;
    this.dialogueKey = this.day.dialogue;
    const d = DIALOGUES[this.day.dialogue];
    const s = new Standee(d.kind, -0.55, -0.9, Math.atan2(0.55, 1.78));
    s.group.scale.setScalar(0.86);
    this.scene.add(s.group);
    this.standee = s;
    this.blips.tone(180, 0.2, "sine", 0.04);
    this.emit();
  }

  private climax() {
    if (this.climaxDone) return;
    this.climaxDone = true;
    const d07 = DAYS[2].directives.find((d) => d.id === "D-07")!;
    this.directives.push(d07);
    this.os.setDay({ ...this.day, directives: this.directives });
    this.os.filed = this.filed;
    this.os.misfiles = this.misfiles;
    this.postfx.spike(0.9);
    this.shake = 1.2;
    this.blips.bad();
    this.os.pushToast("!!! DIRECTIVE D-07 PUSHED !!!");
    this.hint = "D-07 HAS NO SEAL. CHECK THE NOTES BEFORE YOU OBEY IT.";
  }

  /* ------------------------------------------------------------ */
  /* pointer                                                       */
  /* ------------------------------------------------------------ */

  private setPointer(e: PointerEvent) {
    const r = this.renderer.domElement.getBoundingClientRect();
    this.pointer.set(((e.clientX - r.left) / r.width) * 2 - 1, -((e.clientY - r.top) / r.height) * 2 + 1);
  }

  private holdPlanePoint(): THREE.Vector3 {
    const dist = 0.62;
    const halfH = Math.tan((this.camera.fov * Math.PI) / 360) * dist;
    const halfW = halfH * this.camera.aspect;
    const fwd = new THREE.Vector3();
    this.camera.getWorldDirection(fwd);
    const right = new THREE.Vector3().crossVectors(fwd, new THREE.Vector3(0, 1, 0)).normalize();
    const up = new THREE.Vector3().crossVectors(right, fwd).normalize();
    const px = THREE.MathUtils.clamp(this.pointer.x, -1, 1) * halfW * 0.94;
    const py = THREE.MathUtils.clamp(this.pointer.y, -1, 1) * halfH * 0.86;
    return this.camera.position.clone().addScaledVector(fwd, dist).addScaledVector(right, px).addScaledVector(up, py);
  }

  private holdQuat(pos: THREE.Vector3) {
    const dummy = new THREE.Object3D();
    dummy.position.copy(pos);
    dummy.lookAt(this.camera.position);
    return dummy.quaternion.clone();
  }

  private onDown = (e: PointerEvent) => {
    this.setPointer(e);
    this.pointerDownAt.set(e.clientX, e.clientY);
    this.pointerMoved = false;
    if (this.phase !== "play") return;

    this.raycaster.setFromCamera(this.pointer, this.camera);

    // CRT first
    const hitScreen = this.raycaster.intersectObject(this.env.screen, false)[0];
    if (hitScreen && hitScreen.uv) {
      const cx = hitScreen.uv.x * 512;
      const cy = (1 - hitScreen.uv.y) * 384;
      this.draggingOS = this.os.pointerDown(cx, cy);
      if (this.draggingOS) this.blips.click();
      return;
    }

    const meshes = this.forms.filter((f) => f.state !== "gone").map((f) => f.mesh);
    const hits = this.raycaster.intersectObjects(meshes, false);
    if (hits.length > 0) {
      const card = this.forms.find((f) => f.mesh === hits[0].object)!;
      if (card.state === "held") {
        // lower it back to the desk
        card.state = "desk";
        card.layout(this.freeSlot(), this.env.deskY);
        this.held = null;
        this.heldLight.intensity = 0;
        this.os.currentForm = null;
        this.blips.click();
        this.emit();
        return;
      }
      card.state = "held";
      this.held = card;
      this.heldLight.intensity = 0.26;
      this.os.currentForm = card.data;
      this.blips.raise();
      const p = this.holdPlanePoint();
      card.hold(p, this.holdQuat(p));
      this.heldLight.position.copy(p).add(new THREE.Vector3(0.1, 0.2, 0.16));
      this.emit();
      return;
    }
  };

  private onMove = (e: PointerEvent) => {
    this.setPointer(e);
    if (Math.abs(e.clientX - this.pointerDownAt.x) + Math.abs(e.clientY - this.pointerDownAt.y) > 5) {
      this.pointerMoved = true;
    }
    if (this.draggingOS) {
      const r = this.renderer.domElement.getBoundingClientRect();
      const cx = ((e.clientX - r.left) / r.width) * 512;
      const cy = ((e.clientY - r.top) / r.height) * 384;
      this.os.pointerMove(cx, cy);
      return;
    }
    if (this.held) {
      const p = this.holdPlanePoint();
      this.held.hold(p, this.holdQuat(p));
      this.heldLight.position.copy(p).add(new THREE.Vector3(0.1, 0.2, 0.16));
    }
  };

  private onUp = (e: PointerEvent) => {
    this.setPointer(e);
    this.os.pointerUp();
    this.draggingOS = false;
    if (!this.held) return;
    this.raycaster.setFromCamera(this.pointer, this.camera);
    const hits = this.raycaster.intersectObjects(
      this.env.trays.map((t) => t.hit),
      false
    );
    if (hits.length > 0) {
      const tray = this.env.trays.find((t) => t.hit === hits[0].object)!;
      this.fileForm(this.held, tray.verdict);
      return;
    }
    if (!this.pointerMoved) {
      // a click: hold it up in the lower frame for reading
      const dist = 0.62;
      const halfH = Math.tan((this.camera.fov * Math.PI) / 360) * dist;
      const fwd = new THREE.Vector3();
      this.camera.getWorldDirection(fwd);
      const right = new THREE.Vector3().crossVectors(fwd, new THREE.Vector3(0, 1, 0)).normalize();
      const up = new THREE.Vector3().crossVectors(right, fwd).normalize();
      const p = this.camera.position
        .clone()
        .addScaledVector(fwd, dist)
        .addScaledVector(up, -halfH * 0.52)
        .addScaledVector(right, 0);
      this.held.hold(p, this.holdQuat(p));
      this.hint = "DRAG THE FORM ONTO A TRAY. CLICK IT AGAIN TO LOWER IT.";
      this.emit();
    } else {
      this.held.state = "desk";
      this.held.layout(this.freeSlot(), this.env.deskY);
      this.held = null;
      this.heldLight.intensity = 0;
      this.os.currentForm = null;
      this.emit();
    }
  };

  private onResize = () => {
    const w = this.container.clientWidth;
    const h = this.container.clientHeight;
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(w, h);
    this.postfx.setSize(w, h);
  };

  /* ------------------------------------------------------------ */
  /* loop                                                          */
  /* ------------------------------------------------------------ */

  private loop = () => {
    this.raf = requestAnimationFrame(this.loop);
    const dt = Math.min(0.05, this.clock.getDelta());
    const t = this.clock.elapsedTime;

    this.env.update(t);
    this.os.update(dt);

    for (const f of this.forms) f.update(dt, this.camera);

    if (this.standee) {
      this.standee.update(dt);
      if (this.standee.done) {
        this.scene.remove(this.standee.group);
        this.standee.dispose();
        this.standee = null;
      }
    }

    // climax: D-07 lands while day 3 is in progress
    if (this.phase === "play" && this.dayIndex === 2 && !this.climaxDone && this.filed >= 3) {
      this.climax();
    }

    if (this.dialogueTimer > 0) {
      this.dialogueTimer -= dt;
      if (this.dialogueTimer <= 0) {
        this.dialogueResult = null;
        this.emit();
      }
    }
    if (this.feedbackTimer > 0) {
      this.feedbackTimer -= dt;
      if (this.feedbackTimer <= 0) {
        this.feedback = null;
        this.emit();
      }
    }

    // misfile shake, always returning to the fixed pose
    this.camera.position.copy(this.basePos);
    this.camera.lookAt(this.baseTarget);
    if (this.shake > 0.001) {
      this.shake = Math.max(0, this.shake - dt * 1.5);
      const s = this.shake * this.shake * 0.05;
      this.camera.position.x += (Math.random() - 0.5) * s * 2;
      this.camera.position.y += (Math.random() - 0.5) * s * 2;
      this.camera.position.z += (Math.random() - 0.5) * s;
      this.camera.rotateZ((Math.random() - 0.5) * s * 0.6);
      this.camera.rotateX((Math.random() - 0.5) * s * 0.4);
    }

    this.postfx.render(this.renderer, this.scene, this.camera, t);
  };

  private emit() {
    const d = this.day;
    this.onSnapshot({
      phase: this.phase,
      dayIndex: this.dayIndex,
      dayTitle: d.title,
      dayBrief: d.brief,
      filed: this.filed,
      quota: d.quota,
      misfiles: this.misfiles,
      relation: this.relation,
      obedience: this.obedience,
      recallUsed: this.recallUsed,
      canRecall: !this.recallUsed && !!this.lastFiled && this.phase === "play",
      dialogue: this.dialogueKey ? DIALOGUES[this.dialogueKey] : null,
      dialogueResult: this.dialogueResult,
      feedback: this.feedback,
      ending: this.ending,
      hint: this.hint,
      onDesk: this.forms.filter((f) => f.state === "desk").length,
    });
  }
}
