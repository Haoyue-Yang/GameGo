import * as THREE from "three";
import type { FormData } from "./core";

/* ------------------------------------------------------------------ */
/* helpers                                                             */
/* ------------------------------------------------------------------ */

export function makeCanvas(w: number, h: number) {
  const c = document.createElement("canvas");
  c.width = w;
  c.height = h;
  const ctx = c.getContext("2d")!;
  return { c, ctx };
}

export function tex(canvas: HTMLCanvasElement, repeat = false) {
  const t = new THREE.CanvasTexture(canvas);
  t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 4;
  if (repeat) {
    t.wrapS = THREE.RepeatWrapping;
    t.wrapT = THREE.RepeatWrapping;
  }
  return t;
}

let seed = 1337;
export function rnd() {
  seed = (seed * 1664525 + 1013904223) % 4294967296;
  return seed / 4294967296;
}

function noise(ctx: CanvasRenderingContext2D, w: number, h: number, amount: number, alpha: number) {
  for (let i = 0; i < amount; i++) {
    const x = rnd() * w;
    const y = rnd() * h;
    const v = Math.floor(rnd() * 255);
    ctx.fillStyle = `rgba(${v},${v},${v},${alpha})`;
    ctx.fillRect(x, y, 1, 1);
  }
}

/* ------------------------------------------------------------------ */
/* surfaces                                                            */
/* ------------------------------------------------------------------ */

export function woodTexture() {
  const { c, ctx } = makeCanvas(512, 512);
  ctx.fillStyle = "#6b4326";
  ctx.fillRect(0, 0, 512, 512);
  // grain rings
  for (let i = 0; i < 150; i++) {
    const y = rnd() * 512;
    const amp = 4 + rnd() * 16;
    const dark = rnd() < 0.5;
    ctx.strokeStyle = dark
      ? `rgba(58,32,16,${0.12 + rnd() * 0.25})`
      : `rgba(150,98,54,${0.06 + rnd() * 0.16})`;
    ctx.lineWidth = 0.6 + rnd() * 2.6;
    ctx.beginPath();
    for (let x = 0; x <= 512; x += 8) {
      const yy = y + Math.sin((x / 512) * Math.PI * (1 + rnd() * 0.02) * 3) * amp;
      if (x === 0) ctx.moveTo(x, yy);
      else ctx.lineTo(x, yy);
    }
    ctx.stroke();
  }
  // knots
  for (let k = 0; k < 3; k++) {
    const cx = rnd() * 512;
    const cy = rnd() * 512;
    for (let r = 22; r > 0; r -= 2) {
      ctx.strokeStyle = `rgba(52,28,14,${0.05 + rnd() * 0.08})`;
      ctx.lineWidth = 1.4;
      ctx.beginPath();
      ctx.ellipse(cx, cy, r, r * 0.45, rnd(), 0, Math.PI * 2);
      ctx.stroke();
    }
  }
  noise(ctx, 512, 512, 26000, 0.05);
  return tex(c, true);
}

export function fabricTexture() {
  const { c, ctx } = makeCanvas(256, 256);
  ctx.fillStyle = "#0a1020";
  ctx.fillRect(0, 0, 256, 256);
  for (let y = 0; y < 256; y += 2) {
    for (let x = 0; x < 256; x += 2) {
      const v = rnd();
      ctx.fillStyle = `rgba(${18 + v * 26},${28 + v * 34},${48 + v * 44},${0.25 + v * 0.4})`;
      ctx.fillRect(x, y, 2, 2);
    }
  }
  // stitched seams
  ctx.strokeStyle = "rgba(40,60,96,0.35)";
  ctx.lineWidth = 1;
  for (let i = 0; i < 256; i += 64) {
    ctx.beginPath();
    ctx.moveTo(i, 0);
    ctx.lineTo(i, 256);
    ctx.stroke();
  }
  return tex(c, true);
}

export function metalTexture() {
  const { c, ctx } = makeCanvas(256, 256);
  ctx.fillStyle = "#1b2028";
  ctx.fillRect(0, 0, 256, 256);
  for (let i = 0; i < 900; i++) {
    const x = rnd() * 256;
    const y = rnd() * 256;
    ctx.fillStyle = `rgba(${120 + rnd() * 90},${130 + rnd() * 90},${150 + rnd() * 90},${rnd() * 0.12})`;
    ctx.fillRect(x, y, 1 + rnd() * 3, 1);
  }
  noise(ctx, 256, 256, 9000, 0.05);
  return tex(c, true);
}

export function paperTexture() {
  const { c, ctx } = makeCanvas(256, 256);
  ctx.fillStyle = "#e8e2d2";
  ctx.fillRect(0, 0, 256, 256);
  for (let i = 0; i < 2600; i++) {
    const x = rnd() * 256;
    const y = rnd() * 256;
    ctx.fillStyle = `rgba(${140 + rnd() * 60},${130 + rnd() * 50},${105 + rnd() * 50},${rnd() * 0.14})`;
    ctx.fillRect(x, y, 1 + rnd() * 2, 1);
  }
  return tex(c, true);
}

export function toonGradient(steps = 4) {
  const data = new Uint8Array(steps);
  for (let i = 0; i < steps; i++) {
    data[i] = Math.round(((i + 1) / steps) * 255);
  }
  const t = new THREE.DataTexture(data, steps, 1, THREE.RedFormat);
  t.minFilter = THREE.NearestFilter;
  t.magFilter = THREE.NearestFilter;
  t.generateMipmaps = false;
  t.needsUpdate = true;
  return t;
}

export function radialGlow(inner = "rgba(255,255,255,1)", outer = "rgba(255,255,255,0)") {
  const { c, ctx } = makeCanvas(128, 128);
  const g = ctx.createRadialGradient(64, 64, 0, 64, 64, 64);
  g.addColorStop(0, inner);
  g.addColorStop(0.35, "rgba(255,255,255,0.35)");
  g.addColorStop(1, outer);
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, 128, 128);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

export function labelTexture(main: string, sub: string, accent: string) {
  const { c, ctx } = makeCanvas(512, 128);
  ctx.fillStyle = "#12161c";
  ctx.fillRect(0, 0, 512, 128);
  ctx.fillStyle = accent;
  ctx.fillRect(0, 0, 512, 6);
  ctx.fillRect(0, 122, 512, 6);
  ctx.fillStyle = accent;
  ctx.font = "bold 62px 'Courier New', monospace";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillText(main, 256, 56);
  ctx.fillStyle = "rgba(200,214,235,0.7)";
  ctx.font = "22px 'Courier New', monospace";
  ctx.fillText(sub, 256, 100);
  return tex(c);
}

export function keycapTexture() {
  const { c, ctx } = makeCanvas(256, 256);
  ctx.fillStyle = "#22262c";
  ctx.fillRect(0, 0, 256, 256);
  for (let i = 0; i < 240; i++) {
    ctx.fillStyle = `rgba(255,255,255,${rnd() * 0.05})`;
    ctx.fillRect(rnd() * 256, rnd() * 256, 2, 1);
  }
  return tex(c, true);
}

export function panelTexture() {
  const { c, ctx } = makeCanvas(128, 64);
  const g = ctx.createLinearGradient(0, 0, 0, 64);
  g.addColorStop(0, "#cfe2ff");
  g.addColorStop(0.5, "#ffffff");
  g.addColorStop(1, "#bcd2f5");
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, 128, 64);
  // tube seams
  ctx.fillStyle = "rgba(120,150,190,0.35)";
  for (let i = 0; i < 128; i += 16) ctx.fillRect(i, 0, 1, 64);
  noise(ctx, 128, 64, 3000, 0.06);
  return tex(c, true);
}

/* ------------------------------------------------------------------ */
/* the attestation form                                                */
/* ------------------------------------------------------------------ */

function squiggle(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, forged: boolean) {
  ctx.strokeStyle = forged ? "#3a4a8c" : "#22283a";
  ctx.lineWidth = forged ? 3 : 4;
  ctx.lineCap = "round";
  ctx.beginPath();
  const n = 14;
  for (let i = 0; i <= n; i++) {
    const t = i / n;
    const px = x + t * w;
    const py =
      y -
      Math.sin(t * Math.PI * (forged ? 3.2 : 2.4)) * (forged ? 16 : 22) -
      Math.sin(t * 9) * 5;
    if (i === 0) ctx.moveTo(px, py);
    else ctx.lineTo(px, py);
  }
  ctx.stroke();
}

export function formTexture(f: FormData) {
  const W = 512;
  const H = 724;
  const { c, ctx } = makeCanvas(W, H);
  ctx.fillStyle = "#efe9da";
  ctx.fillRect(0, 0, W, H);
  // paper fibre
  for (let i = 0; i < 5200; i++) {
    const x = rnd() * W;
    const y = rnd() * H;
    ctx.fillStyle = `rgba(${150 + rnd() * 60},${140 + rnd() * 50},${115 + rnd() * 50},${rnd() * 0.12})`;
    ctx.fillRect(x, y, 1 + rnd() * 2, 1);
  }
  // faint ruled grid
  ctx.strokeStyle = "rgba(120,140,170,0.10)";
  ctx.lineWidth = 1;
  for (let y = 120; y < H; y += 22) {
    ctx.beginPath();
    ctx.moveTo(24, y);
    ctx.lineTo(W - 24, y);
    ctx.stroke();
  }

  // header
  ctx.fillStyle = "#141a26";
  ctx.fillRect(0, 0, W, 74);
  ctx.fillStyle = "#7fd6c8";
  ctx.fillRect(0, 70, W, 4);
  ctx.fillStyle = "#e8f2ff";
  ctx.font = "bold 27px 'Courier New', monospace";
  ctx.textBaseline = "middle";
  ctx.fillText("ATTESTATION FORM 7B", 22, 30);
  ctx.fillStyle = "#8fb6d8";
  ctx.font = "17px 'Courier New', monospace";
  ctx.fillText("COMPLIANCE OFFICE · INTERNAL", 22, 56);
  ctx.textAlign = "right";
  ctx.fillStyle = "#f0d08a";
  ctx.font = "bold 20px 'Courier New', monospace";
  ctx.fillText(f.id, W - 22, 32);
  ctx.fillStyle = "#8fb6d8";
  ctx.font = "17px 'Courier New', monospace";
  ctx.fillText(`FILED ${f.date}`, W - 22, 58);
  ctx.textAlign = "left";

  // applicant block
  ctx.fillStyle = "#1d2430";
  ctx.fillRect(22, 92, W - 44, 44);
  ctx.fillStyle = "#9fb4c9";
  ctx.font = "15px 'Courier New', monospace";
  ctx.fillText("APPLICANT", 34, 114);
  ctx.fillStyle = "#f2f6ff";
  ctx.font = "bold 26px 'Courier New', monospace";
  ctx.fillText(f.applicant, 170, 115);

  // fields
  const fields: [string, string][] = [
    ["DEPARTMENT", f.dept],
    ["DECLARED ROLE", f.role],
    ["CLEARANCE", `LVL ${f.clearance}`],
    ["SUPERVISOR", f.supervisor],
    ["AMOUNT", `${f.amount.toLocaleString()} CR`],
    ["FORM DATE", f.date],
  ];
  let y = 172;
  for (const [k, v] of fields) {
    ctx.fillStyle = "#7b8798";
    ctx.font = "16px 'Courier New', monospace";
    ctx.fillText(k, 30, y);
    ctx.fillStyle = "#20262f";
    ctx.font = "bold 22px 'Courier New', monospace";
    ctx.fillText(v, 214, y);
    ctx.strokeStyle = "rgba(60,70,86,0.35)";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(210, y + 12);
    ctx.lineTo(W - 30, y + 12);
    ctx.stroke();
    y += 40;
  }

  // signature
  ctx.fillStyle = "#7b8798";
  ctx.font = "16px 'Courier New', monospace";
  ctx.fillText("ATTESTING SIGNATURE", 30, y + 6);
  ctx.strokeStyle = "rgba(60,70,86,0.5)";
  ctx.beginPath();
  ctx.moveTo(210, y + 40);
  ctx.lineTo(W - 30, y + 40);
  ctx.stroke();
  if (f.signature === "VALID") {
    squiggle(ctx, 220, y + 36, 200, false);
  } else if (f.signature === "FORGED") {
    squiggle(ctx, 220, y + 36, 200, true);
    ctx.fillStyle = "#b8323a";
    ctx.font = "bold 15px 'Courier New', monospace";
    ctx.fillText("HANDS DO NOT MATCH", 224, y + 56);
  } else {
    ctx.fillStyle = "#b8323a";
    ctx.font = "bold 20px 'Courier New', monospace";
    ctx.fillText("— ABSENT —", 250, y + 28);
  }
  y += 84;

  // seal
  const sx = 108;
  const sy = y + 54;
  ctx.save();
  ctx.translate(sx, sy);
  ctx.rotate(-0.16);
  if (f.seal === "VALID") {
    ctx.strokeStyle = "#2f6f8f";
    ctx.lineWidth = 5;
    ctx.beginPath();
    ctx.arc(0, 0, 50, 0, Math.PI * 2);
    ctx.stroke();
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(0, 0, 42, 0, Math.PI * 2);
    ctx.stroke();
    ctx.fillStyle = "#2f6f8f";
    ctx.font = "bold 15px 'Courier New', monospace";
    ctx.textAlign = "center";
    ctx.fillText("COMPLIANCE", 0, -12);
    ctx.fillText("OFFICE", 0, 6);
    ctx.font = "11px 'Courier New', monospace";
    ctx.fillText("SEAL 114", 0, 26);
    ctx.textAlign = "left";
  } else {
    ctx.strokeStyle = "#b8323a";
    ctx.lineWidth = 3;
    ctx.setLineDash([7, 7]);
    ctx.beginPath();
    ctx.arc(0, 0, 48, 0, Math.PI * 2);
    ctx.stroke();
    ctx.setLineDash([]);
    ctx.fillStyle = "#b8323a";
    ctx.font = "bold 14px 'Courier New', monospace";
    ctx.textAlign = "center";
    ctx.fillText(f.seal === "MISSING" ? "SEAL ABSENT" : "NOT ISSUED", 0, 4);
    ctx.textAlign = "left";
  }
  ctx.restore();

  // seal caption
  ctx.fillStyle = "#7b8798";
  ctx.font = "16px 'Courier New', monospace";
  ctx.fillText("OFFICE SEAL", 190, y + 30);
  ctx.fillStyle = "#20262f";
  ctx.font = "bold 20px 'Courier New', monospace";
  ctx.fillText(f.seal, 190, y + 58);

  // barcode
  let bx = 30;
  while (bx < W - 60) {
    const w = 1 + Math.floor(rnd() * 4);
    ctx.fillStyle = "rgba(24,28,36,0.85)";
    ctx.fillRect(bx, H - 62, w, 34);
    bx += w + 1 + Math.floor(rnd() * 3);
  }
  ctx.fillStyle = "#7b8798";
  ctx.font = "13px 'Courier New', monospace";
  ctx.fillText("DO NOT REMOVE · ATTESTATION IS BINDING", 30, H - 18);

  // coffee ring
  if (f.stain) {
    ctx.save();
    ctx.globalAlpha = 0.28;
    ctx.strokeStyle = "#8a5a24";
    ctx.lineWidth = 9;
    ctx.beginPath();
    ctx.ellipse(392, 214, 46, 40, 0.4, 0, Math.PI * 2);
    ctx.stroke();
    ctx.globalAlpha = 0.14;
    ctx.fillStyle = "#8a5a24";
    ctx.beginPath();
    ctx.ellipse(392, 214, 42, 36, 0.4, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }

  // red tamper stamp
  if (f.stamp) {
    ctx.save();
    ctx.translate(W / 2, H / 2 - 40);
    ctx.rotate(-0.22);
    ctx.globalAlpha = 0.62;
    ctx.strokeStyle = "#c0303a";
    ctx.lineWidth = 7;
    ctx.strokeRect(-150, -40, 300, 80);
    ctx.fillStyle = "#c0303a";
    ctx.font = "bold 54px 'Courier New', monospace";
    ctx.textAlign = "center";
    ctx.fillText(f.stamp, 0, 18);
    ctx.restore();
  }

  return tex(c);
}

/* ------------------------------------------------------------------ */
/* flat cel-shaded colleague standee                                   */
/* ------------------------------------------------------------------ */

export interface ColleaguePalette {
  skin: string;
  skinShade: string;
  hair: string;
  shirt: string;
  shirtShade: string;
  trouser: string;
  accent: string;
  outline: string;
}

export const PALETTES: ColleaguePalette[] = [
  {
    skin: "#d9a273",
    skinShade: "#b9814f",
    hair: "#2a2118",
    shirt: "#3f6f8f",
    shirtShade: "#2c526b",
    trouser: "#26303c",
    accent: "#c8d6e6",
    outline: "#0b0e14",
  },
  {
    skin: "#e8c39a",
    skinShade: "#c99e72",
    hair: "#6b3f22",
    shirt: "#7d4a5c",
    shirtShade: "#5d3444",
    trouser: "#2b2b33",
    accent: "#e6d2b0",
    outline: "#0b0e14",
  },
  {
    skin: "#8d6244",
    skinShade: "#6f4a31",
    hair: "#151312",
    shirt: "#4a6b4a",
    shirtShade: "#365036",
    trouser: "#1f2530",
    accent: "#d8cfae",
    outline: "#080a0f",
  },
];

/** Flat, hard-edged, cel-shaded cardboard-standee artwork. */
export function colleagueTexture(kind: number) {
  const W = 320;
  const H = 1000;
  const { c, ctx } = makeCanvas(W, H);
  const p = PALETTES[kind % PALETTES.length];
  ctx.clearRect(0, 0, W, H);

  const O = p.outline;
  const outline = (path: () => void, width = 12) => {
    ctx.save();
    ctx.strokeStyle = O;
    ctx.lineWidth = width;
    ctx.lineJoin = "round";
    ctx.lineCap = "round";
    path();
    ctx.stroke();
    ctx.restore();
  };
  const fill = (color: string, path: () => void) => {
    ctx.save();
    ctx.fillStyle = color;
    path();
    ctx.fill();
    ctx.restore();
  };

  const cx = W / 2;

  // ---- legs
  const legL = () => ctx.beginPath();
  outline(() => {
    ctx.beginPath();
    ctx.moveTo(cx - 62, 700);
    ctx.lineTo(cx - 18, 700);
    ctx.lineTo(cx - 14, 960);
    ctx.lineTo(cx - 70, 960);
    ctx.closePath();
  });
  fill(p.trouser, () => {
    ctx.beginPath();
    ctx.moveTo(cx - 62, 700);
    ctx.lineTo(cx - 18, 700);
    ctx.lineTo(cx - 14, 960);
    ctx.lineTo(cx - 70, 960);
    ctx.closePath();
  });
  outline(() => {
    ctx.beginPath();
    ctx.moveTo(cx + 18, 700);
    ctx.lineTo(cx + 62, 700);
    ctx.lineTo(cx + 70, 960);
    ctx.lineTo(cx + 14, 960);
    ctx.closePath();
  });
  fill(p.trouser, () => {
    ctx.beginPath();
    ctx.moveTo(cx + 18, 700);
    ctx.lineTo(cx + 62, 700);
    ctx.lineTo(cx + 70, 960);
    ctx.lineTo(cx + 14, 960);
    ctx.closePath();
  });
  // shoes
  outline(() => {
    ctx.beginPath();
    ctx.rect(cx - 84, 952, 74, 34);
  });
  fill("#14161c", () => ctx.beginPath().rect(cx - 84, 952, 74, 34));
  outline(() => {
    ctx.beginPath();
    ctx.rect(cx + 10, 952, 74, 34);
  });
  fill("#14161c", () => ctx.beginPath().rect(cx + 10, 952, 74, 34));

  // ---- torso
  const torso = () => {
    ctx.beginPath();
    ctx.moveTo(cx - 74, 330);
    ctx.lineTo(cx + 74, 330);
    ctx.lineTo(cx + 66, 706);
    ctx.lineTo(cx - 66, 706);
    ctx.closePath();
  };
  outline(torso, 13);
  fill(p.shirt, torso);
  // cel shadow on the right side of the torso
  ctx.save();
  ctx.beginPath();
  ctx.rect(cx + 12, 330, 80, 380);
  ctx.clip();
  fill(p.shirtShade, torso);
  ctx.restore();

  // collar + tie
  fill(p.accent, () => {
    ctx.beginPath();
    ctx.moveTo(cx - 30, 330);
    ctx.lineTo(cx + 30, 330);
    ctx.lineTo(cx, 392);
    ctx.closePath();
  });
  fill(kind % 2 === 0 ? "#a8323c" : "#2f4f8f", () => {
    ctx.beginPath();
    ctx.moveTo(cx - 12, 386);
    ctx.lineTo(cx + 12, 386);
    ctx.lineTo(cx + 8, 560);
    ctx.lineTo(cx, 590);
    ctx.lineTo(cx - 8, 560);
    ctx.closePath();
  });
  // badge
  fill("#d8dee8", () => ctx.beginPath().rect(cx + 26, 430, 34, 22));
  fill("#8a94a4", () => ctx.beginPath().rect(cx + 26, 430, 34, 7));

  // ---- arms
  const armL = () => {
    ctx.beginPath();
    ctx.moveTo(cx - 74, 344);
    ctx.lineTo(cx - 118, 356);
    ctx.lineTo(cx - 108, 620);
    ctx.lineTo(cx - 66, 606);
    ctx.closePath();
  };
  outline(armL, 12);
  fill(p.shirt, armL);
  ctx.save();
  ctx.beginPath();
  ctx.rect(cx - 130, 330, 40, 320);
  ctx.clip();
  fill(p.shirtShade, armL);
  ctx.restore();
  fill(p.skin, () => {
    ctx.beginPath();
    ctx.ellipse(cx - 88, 640, 24, 30, 0.1, 0, Math.PI * 2);
  });
  outline(() => {
    ctx.beginPath();
    ctx.ellipse(cx - 88, 640, 24, 30, 0.1, 0, Math.PI * 2);
  }, 10);

  const armR = () => {
    ctx.beginPath();
    ctx.moveTo(cx + 74, 344);
    ctx.lineTo(cx + 122, 352);
    ctx.lineTo(cx + 112, 612);
    ctx.lineTo(cx + 68, 600);
    ctx.closePath();
  };
  outline(armR, 12);
  fill(p.shirt, armR);
  ctx.save();
  ctx.beginPath();
  ctx.rect(cx + 92, 330, 44, 320);
  ctx.clip();
  fill(p.shirtShade, armR);
  ctx.restore();
  // right hand raised (begging gesture)
  fill(p.skin, () => {
    ctx.beginPath();
    ctx.ellipse(cx + 108, 626, 25, 31, -0.1, 0, Math.PI * 2);
  });
  outline(() => {
    ctx.beginPath();
    ctx.ellipse(cx + 108, 626, 25, 31, -0.1, 0, Math.PI * 2);
  }, 10);

  // ---- neck + head
  fill(p.skinShade, () => ctx.beginPath().rect(cx - 20, 288, 40, 52));
  outline(() => ctx.beginPath().rect(cx - 20, 288, 40, 52), 10);
  const head = () => {
    ctx.beginPath();
    ctx.ellipse(cx, 214, 76, 92, 0, 0, Math.PI * 2);
  };
  outline(head, 13);
  fill(p.skin, head);
  ctx.save();
  ctx.beginPath();
  ctx.rect(cx + 26, 120, 90, 200);
  ctx.clip();
  fill(p.skinShade, head);
  ctx.restore();

  // hair variants
  if (kind % 3 === 0) {
    fill(p.hair, () => {
      ctx.beginPath();
      ctx.ellipse(cx, 148, 78, 56, 0, Math.PI, Math.PI * 2);
      ctx.rect(cx - 78, 148, 156, 16);
      ctx.closePath();
    });
    outline(() => {
      ctx.beginPath();
      ctx.ellipse(cx, 148, 78, 56, 0, Math.PI, Math.PI * 2);
    }, 10);
  } else if (kind % 3 === 1) {
    fill(p.hair, () => {
      ctx.beginPath();
      ctx.moveTo(cx - 80, 170);
      ctx.lineTo(cx - 66, 112);
      ctx.lineTo(cx + 40, 108);
      ctx.lineTo(cx + 78, 168);
      ctx.lineTo(cx + 40, 140);
      ctx.lineTo(cx - 30, 150);
      ctx.closePath();
    });
  } else {
    fill(p.hair, () => {
      ctx.beginPath();
      ctx.ellipse(cx, 156, 80, 62, 0, Math.PI * 1.02, Math.PI * 2);
      ctx.closePath();
    });
    fill(p.hair, () => ctx.beginPath().rect(cx - 82, 150, 22, 60));
  }

  // eyes
  fill("#10131a", () => {
    ctx.beginPath();
    ctx.ellipse(cx - 28, 214, 9, 11, 0, 0, Math.PI * 2);
    ctx.ellipse(cx + 28, 214, 9, 11, 0, 0, Math.PI * 2);
  });
  // brows
  fill("#10131a", () => {
    ctx.beginPath();
    ctx.rect(cx - 42, 186, 28, 6);
    ctx.rect(cx + 14, 186, 28, 6);
  });
  // mouth (worried)
  outline(
    () => {
      ctx.beginPath();
      ctx.arc(cx, 258, 16, Math.PI * 1.15, Math.PI * 1.85);
    },
    7
  );
  // glasses for one kind
  if (kind % 2 === 1) {
    outline(
      () => {
        ctx.beginPath();
        ctx.rect(cx - 46, 196, 38, 30);
        ctx.rect(cx + 8, 196, 38, 30);
        ctx.moveTo(cx - 8, 210);
        ctx.lineTo(cx + 8, 210);
      },
      6
    );
  }
  void legL;
  return tex(c);
}
