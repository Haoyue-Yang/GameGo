import * as THREE from "three";
import type { Verdict } from "./core";
import {
  fabricTexture,
  keycapTexture,
  labelTexture,
  metalTexture,
  panelTexture,
  paperTexture,
  radialGlow,
  toonGradient,
  woodTexture,
  rnd,
} from "./textures";

export interface TrayRef {
  verdict: Verdict;
  group: THREE.Group;
  hit: THREE.Mesh;
  center: THREE.Vector3;
  accent: number;
}

export interface Env {
  root: THREE.Group;
  deskY: number;
  deskPlane: THREE.Plane;
  trays: TrayRef[];
  screen: THREE.Mesh;
  crtLight: THREE.PointLight;
  crtGlow: THREE.Sprite;
  lampLight: THREE.SpotLight;
  update: (t: number) => void;
}

const TOON = toonGradient(4);

function toon(color: number, opts: Partial<THREE.MeshToonMaterialParameters> = {}) {
  return new THREE.MeshToonMaterial({ color, gradientMap: TOON, ...opts });
}
function std(color: number, rough = 0.7, metal = 0.1) {
  return new THREE.MeshStandardMaterial({ color, roughness: rough, metalness: metal });
}
function box(w: number, h: number, d: number, m: THREE.Material) {
  const g = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), m);
  g.castShadow = true;
  g.receiveShadow = true;
  return g;
}
function put(m: THREE.Object3D, x: number, y: number, z: number, ry = 0, rx = 0) {
  m.position.set(x, y, z);
  m.rotation.set(rx, ry, 0);
  return m;
}

export function buildEnvironment(scene: THREE.Scene): Env {
  const root = new THREE.Group();
  scene.add(root);

  const wood = woodTexture();
  wood.repeat.set(2, 2);
  const metal = metalTexture();
  metal.repeat.set(3, 3);
  const fab = fabricTexture();
  fab.repeat.set(4, 2);
  const paper = paperTexture();

  const woodMat = new THREE.MeshStandardMaterial({ map: wood, roughness: 0.55, metalness: 0.04 });
  const woodDark = new THREE.MeshStandardMaterial({ map: wood, color: 0x8a6a4a, roughness: 0.6 });
  const metalMat = new THREE.MeshStandardMaterial({ map: metal, roughness: 0.42, metalness: 0.75 });
  const fabMat = new THREE.MeshStandardMaterial({ map: fab, color: 0x3a4f78, roughness: 0.95 });
  const plastic = std(0x191d24, 0.75, 0.15);
  const plasticDark = std(0x0f1218, 0.8, 0.1);

  const DESK_Y = 0.75;

  /* ---------------- room shell ---------------- */
  const floor = new THREE.Mesh(new THREE.PlaneGeometry(14, 14), std(0x0a0e16, 0.95, 0.05));
  floor.rotation.x = -Math.PI / 2;
  floor.receiveShadow = true;
  root.add(floor);

  const ceil = new THREE.Mesh(new THREE.PlaneGeometry(14, 14), std(0x0b1119, 0.9));
  ceil.rotation.x = Math.PI / 2;
  ceil.position.y = 1.74;
  root.add(ceil);

  const backWall = box(14, 1.74, 0.1, std(0x0d1420, 0.9));
  backWall.position.set(0, 0.87, -3.4);
  root.add(backWall);

  // ceiling grid beams receding
  for (let i = 0; i < 7; i++) {
    const z = -0.9 - i * 0.42;
    const beam = box(6.4, 0.05, 0.06, std(0x121a26, 0.85));
    beam.position.set(0, 1.7, z);
    root.add(beam);
  }

  // suspended fluorescent strips, receding and cropping out of frame
  const panelTex = panelTexture();
  const panels: THREE.Mesh[] = [];
  for (let i = 0; i < 4; i++) {
    const z = -1.32 - i * 0.44;
    const housing = box(2.16, 0.075, 0.15, std(0x141b26, 0.8));
    housing.position.set(0, 1.05, z);
    root.add(housing);
    const p = new THREE.Mesh(
      new THREE.PlaneGeometry(2.0, 0.12),
      new THREE.MeshBasicMaterial({ map: panelTex, toneMapped: false })
    );
    p.rotation.x = Math.PI / 2;
    p.position.set(0, 1.008, z);
    root.add(p);
    panels.push(p);
  }

  // partitions: left, right and a back one, receding
  const partition = (x: number, z: number, w: number, ry: number) => {
    const g = new THREE.Group();
    const body = box(w, 1.05, 0.05, fabMat);
    body.position.y = 0.52;
    g.add(body);
    const cap = box(w + 0.02, 0.045, 0.08, metalMat);
    cap.position.y = 1.06;
    g.add(cap);
    const foot = box(w + 0.02, 0.03, 0.1, metalMat);
    foot.position.y = 0.015;
    g.add(foot);
    put(g, x, 0, z, ry);
    root.add(g);
    return g;
  };
  partition(-1.06, -0.5, 2.6, 0);
  partition(1.06, -0.5, 2.6, 0);
  partition(-0.55, -1.62, 1.6, Math.PI / 2);
  partition(0.62, -2.1, 1.6, Math.PI / 2);

  /* ---------------- distant workstations ---------------- */
  const distant: THREE.Mesh[] = [];
  const station = (x: number, z: number, ry: number, lit: boolean) => {
    const g = new THREE.Group();
    const top = box(1.0, 0.045, 0.6, std(0x2a2f38, 0.8));
    top.position.y = 0.72;
    g.add(top);
    for (const sx of [-0.42, 0.42]) {
      const leg = box(0.05, 0.72, 0.05, std(0x1a1f27, 0.8));
      leg.position.set(sx, 0.36, 0);
      g.add(leg);
    }
    const mon = box(0.34, 0.26, 0.06, plasticDark);
    mon.position.set(0, 0.88, -0.16);
    g.add(mon);
    const scr = new THREE.Mesh(
      new THREE.PlaneGeometry(0.29, 0.2),
      new THREE.MeshBasicMaterial({ color: lit ? 0x3f7fa8 : 0x0a1420, toneMapped: false })
    );
    scr.position.set(0, 0.88, -0.128);
    g.add(scr);
    if (lit) distant.push(scr);
    const chair = box(0.34, 0.42, 0.06, std(0x171c24, 0.9));
    chair.position.set(0.05, 0.5, 0.3);
    g.add(chair);
    const seat = box(0.34, 0.05, 0.32, std(0x171c24, 0.9));
    seat.position.set(0.05, 0.3, 0.16);
    g.add(seat);
    put(g, x, 0, z, ry);
    root.add(g);
  };
  station(-0.85, -1.35, 0.15, true);
  station(0.95, -1.5, -0.2, true);
  station(-0.4, -2.35, 0.05, false);
  station(0.75, -2.75, -0.1, true);

  // doorway with a cold spill
  const door = box(0.8, 1.5, 0.04, std(0x060a12, 0.9));
  door.position.set(-2.2, 0.75, -3.3);
  root.add(door);
  const doorGlow = new THREE.Mesh(
    new THREE.PlaneGeometry(0.78, 1.48),
    new THREE.MeshBasicMaterial({ color: 0x1a3550, toneMapped: false })
  );
  doorGlow.position.set(-2.2, 0.75, -3.27);
  root.add(doorGlow);

  /* ---------------- the desk ---------------- */
  const desk = new THREE.Group();
  root.add(desk);

  const top = box(1.72, 0.045, 1.36, woodMat);
  top.position.set(0, DESK_Y - 0.0225, 0);
  desk.add(top);
  const lip = box(1.76, 0.03, 1.4, woodDark);
  lip.position.set(0, DESK_Y - 0.055, 0);
  desk.add(lip);
  const apron = box(1.7, 0.16, 0.04, woodDark);
  apron.position.set(0, DESK_Y - 0.14, 0.66);
  desk.add(apron);
  const backApron = box(1.7, 0.1, 0.04, woodDark);
  backApron.position.set(0, DESK_Y - 0.1, -0.66);
  desk.add(backApron);

  for (const sx of [-0.68, 0.68]) {
    const ped = box(0.42, 0.68, 0.62, woodDark);
    ped.position.set(sx, 0.34, -0.3);
    desk.add(ped);
    for (let d = 0; d < 3; d++) {
      const drawer = box(0.38, 0.17, 0.02, std(0x3a3026, 0.7));
      drawer.position.set(sx, 0.16 + d * 0.21, -0.005);
      desk.add(drawer);
      const handle = box(0.14, 0.022, 0.02, metalMat);
      handle.position.set(sx, 0.16 + d * 0.21, 0.012);
      desk.add(handle);
    }
  }
  const cable = new THREE.Mesh(
    new THREE.CylinderGeometry(0.008, 0.008, 0.5, 6),
    plasticDark
  );
  cable.position.set(0.3, 0.36, -0.6);
  cable.rotation.z = 0.2;
  desk.add(cable);

  /* ---------------- keyboard + mouse ---------------- */
  const kb = new THREE.Group();
  const kbBase = box(0.44, 0.022, 0.15, plastic);
  kbBase.position.y = 0.011;
  kb.add(kbBase);
  const capTex = keycapTexture();
  const capMat = new THREE.MeshStandardMaterial({ map: capTex, color: 0x3a4048, roughness: 0.85 });
  for (let r = 0; r < 4; r++) {
    for (let cIdx = 0; cIdx < 13; cIdx++) {
      const cap = box(0.026, 0.012, 0.026, capMat);
      cap.position.set(-0.195 + cIdx * 0.032, 0.028, -0.05 + r * 0.032);
      kb.add(cap);
    }
  }
  const space = box(0.16, 0.012, 0.026, capMat);
  space.position.set(0.0, 0.028, 0.052);
  kb.add(space);
  put(kb, -0.64, DESK_Y, -0.28, 0.14);
  root.add(kb);

  const mouse = new THREE.Mesh(new THREE.SphereGeometry(0.036, 14, 10), plastic);
  mouse.scale.set(1, 0.55, 1.5);
  mouse.castShadow = true;
  put(mouse, 0.63, DESK_Y + 0.018, 0.12, 0.3);
  root.add(mouse);

  /* ---------------- CRT monitor ---------------- */
  const crt = new THREE.Group();
  put(crt, 0, DESK_Y, -0.46);
  root.add(crt);

  const shellMat = std(0x2c3138, 0.72, 0.12);
  const shell = box(0.58, 0.46, 0.46, shellMat);
  shell.position.set(0, 0.26, 0);
  crt.add(shell);
  // rounded top corners
  const topCap = new THREE.Mesh(new THREE.CylinderGeometry(0.29, 0.29, 0.46, 20, 1, false, 0, Math.PI), shellMat);
  topCap.rotation.z = Math.PI / 2;
  topCap.rotation.y = Math.PI / 2;
  topCap.position.set(0, 0.49, 0);
  topCap.scale.set(1, 1, 0.95);
  crt.add(topCap);
  // bezel
  const bezel = box(0.56, 0.42, 0.03, std(0x22262c, 0.6));
  bezel.position.set(0, 0.26, 0.235);
  crt.add(bezel);
  const bezelInner = new THREE.Mesh(
    new THREE.TorusGeometry(0.24, 0.016, 6, 24),
    std(0x191d22, 0.5, 0.2)
  );
  bezelInner.position.set(0, 0.26, 0.252);
  bezelInner.scale.set(1.1, 0.86, 1);
  crt.add(bezelInner);

  // curved screen
  const screenGeo = new THREE.PlaneGeometry(0.5, 0.375, 24, 18);
  {
    const pos = screenGeo.attributes.position as THREE.BufferAttribute;
    for (let i = 0; i < pos.count; i++) {
      const x = pos.getX(i);
      const y = pos.getY(i);
      const bulge = (1 - (x / 0.25) ** 2) * (1 - (y / 0.1875) ** 2);
      pos.setZ(i, bulge * 0.032);
    }
    screenGeo.computeVertexNormals();
  }
  const screen = new THREE.Mesh(
    screenGeo,
    new THREE.MeshBasicMaterial({ color: 0x0a1418, toneMapped: false, fog: false })
  );
  screen.position.set(0, 0.26, 0.256);
  crt.add(screen);

  // glass sheen
  const sheen = new THREE.Mesh(
    new THREE.PlaneGeometry(0.5, 0.375),
    new THREE.MeshBasicMaterial({
      map: radialGlow("rgba(190,225,255,0.5)", "rgba(190,225,255,0)"),
      transparent: true,
      opacity: 0.16,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      toneMapped: false,
    })
  );
  sheen.position.set(-0.03, 0.34, 0.272);
  sheen.scale.set(1.1, 1.1, 1);
  crt.add(sheen);

  // vents + knobs + LED
  for (let i = 0; i < 9; i++) {
    const v = box(0.022, 0.006, 0.32, std(0x14181d, 0.9));
    v.position.set(-0.2 + i * 0.05, 0.495, -0.02);
    crt.add(v);
  }
  const knobMat = std(0x11141a, 0.6, 0.3);
  for (const kx of [-0.22, -0.17]) {
    const knob = new THREE.Mesh(new THREE.CylinderGeometry(0.014, 0.016, 0.018, 12), knobMat);
    knob.rotation.x = Math.PI / 2;
    knob.position.set(kx, 0.07, 0.245);
    crt.add(knob);
  }
  const led = new THREE.Mesh(
    new THREE.SphereGeometry(0.008, 8, 6),
    new THREE.MeshBasicMaterial({ color: 0x76f0b0, toneMapped: false })
  );
  led.position.set(0.22, 0.07, 0.248);
  crt.add(led);
  // stand
  const neck = box(0.14, 0.06, 0.18, shellMat);
  neck.position.set(0, 0.03, -0.02);
  crt.add(neck);
  const foot = box(0.34, 0.022, 0.24, shellMat);
  foot.position.set(0, 0.011, -0.01);
  crt.add(foot);

  const crtLight = new THREE.PointLight(0x74e0c4, 0.28, 1.7, 2);
  crtLight.position.set(0, 0.28, 0.4);
  crt.add(crtLight);

  const crtGlow = new THREE.Sprite(
    new THREE.SpriteMaterial({
      map: radialGlow("rgba(150,240,215,0.9)", "rgba(90,180,255,0)"),
      transparent: true,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      opacity: 0.5,
      toneMapped: false,
    })
  );
  crtGlow.scale.set(0.95, 0.75, 1);
  crtGlow.position.set(0, 0.27, 0.34);
  crt.add(crtGlow);

  /* ---------------- filing trays ---------------- */
  const trays: TrayRef[] = [];
  const traySpec: { verdict: Verdict; label: string; sub: string; accent: string; hex: number }[] = [
    { verdict: "CLEAR", label: "CLEAR", sub: "PROCEED", accent: "#5fd6a8", hex: 0x5fd6a8 },
    { verdict: "SANCTION", label: "SANCTION", sub: "HOLD", accent: "#e0655f", hex: 0xe0655f },
    { verdict: "ELEVATE", label: "ELEVATE", sub: "SUPERVISE", accent: "#e0b45f", hex: 0xe0b45f },
  ];
  traySpec.forEach((spec, i) => {
    const g = new THREE.Group();
    const x = -0.44 + i * 0.44;
    const z = -0.1;
    const floorM = box(0.3, 0.012, 0.2, std(0x23282f, 0.7, 0.2));
    floorM.position.y = 0.006;
    g.add(floorM);
    const lipMat = std(0x2b3138, 0.6, 0.25);
    const front = box(0.3, 0.055, 0.012, lipMat);
    front.position.set(0, 0.028, 0.1);
    g.add(front);
    const backL = box(0.3, 0.07, 0.012, lipMat);
    backL.position.set(0, 0.035, -0.1);
    g.add(backL);
    for (const sx of [-0.15, 0.15]) {
      const side = box(0.012, 0.05, 0.2, lipMat);
      side.position.set(sx, 0.025, 0);
      g.add(side);
    }
    // label plate on the front lip
    const plate = new THREE.Mesh(
      new THREE.PlaneGeometry(0.27, 0.0675),
      new THREE.MeshBasicMaterial({ map: labelTexture(spec.label, spec.sub, spec.accent), toneMapped: false })
    );
    plate.position.set(0, 0.03, 0.107);
    g.add(plate);
    // accent strip
    const strip = new THREE.Mesh(
      new THREE.PlaneGeometry(0.3, 0.012),
      new THREE.MeshBasicMaterial({ color: spec.hex, toneMapped: false })
    );
    strip.rotation.x = -Math.PI / 2;
    strip.position.set(0, 0.013, 0.095);
    g.add(strip);
    // a few filed forms already in the tray
    for (let f = 0; f < 3; f++) {
      const sheet = new THREE.Mesh(
        new THREE.PlaneGeometry(0.2, 0.14),
        new THREE.MeshStandardMaterial({ map: paper, roughness: 0.9, side: THREE.DoubleSide })
      );
      sheet.rotation.x = -Math.PI / 2;
      sheet.rotation.z = (rnd() - 0.5) * 0.3;
      sheet.position.set((rnd() - 0.5) * 0.04, 0.016 + f * 0.004, (rnd() - 0.5) * 0.03);
      sheet.receiveShadow = true;
      g.add(sheet);
    }
    const hit = new THREE.Mesh(
      new THREE.BoxGeometry(0.34, 0.2, 0.24),
      new THREE.MeshBasicMaterial({ transparent: true, opacity: 0, depthWrite: false })
    );
    hit.position.set(0, 0.08, 0);
    g.add(hit);
    put(g, x, DESK_Y, z);
    root.add(g);
    trays.push({
      verdict: spec.verdict,
      group: g,
      hit,
      center: new THREE.Vector3(x, DESK_Y + 0.03, z),
      accent: spec.hex,
    });
  });

  /* ---------------- desk lamp (the only warm source) ---------------- */
  const lamp = new THREE.Group();
  put(lamp, -0.72, DESK_Y, -0.44);
  root.add(lamp);
  const lampBase = new THREE.Mesh(new THREE.CylinderGeometry(0.075, 0.085, 0.022, 20), std(0x2a2f36, 0.5, 0.5));
  lampBase.position.y = 0.011;
  lampBase.castShadow = true;
  lamp.add(lampBase);
  const armMat = std(0x30363e, 0.45, 0.6);
  const arm1 = new THREE.Mesh(new THREE.CylinderGeometry(0.009, 0.009, 0.34, 8), armMat);
  arm1.position.set(0.02, 0.17, 0.02);
  arm1.rotation.z = -0.18;
  lamp.add(arm1);
  const arm2 = new THREE.Mesh(new THREE.CylinderGeometry(0.008, 0.008, 0.3, 8), armMat);
  arm2.position.set(0.16, 0.4, 0.06);
  arm2.rotation.set(0.3, 0, -1.15);
  lamp.add(arm2);
  const shade = new THREE.Mesh(
    new THREE.CylinderGeometry(0.035, 0.085, 0.1, 20, 1, true),
    new THREE.MeshStandardMaterial({ color: 0x3b424c, roughness: 0.5, metalness: 0.4, side: THREE.DoubleSide })
  );
  shade.position.set(0.29, 0.45, 0.1);
  shade.rotation.set(0.5, 0, 0.9);
  lamp.add(shade);
  const bulb = new THREE.Mesh(
    new THREE.SphereGeometry(0.026, 12, 10),
    new THREE.MeshBasicMaterial({ color: 0xffd9a0, toneMapped: false })
  );
  bulb.position.set(0.31, 0.42, 0.13);
  lamp.add(bulb);

  const lampLight = new THREE.SpotLight(0xffb266, 4.6, 3.4, 0.82, 0.85, 1.6);
  lampLight.position.set(-0.41, DESK_Y + 0.42, -0.31);
  lampLight.target.position.set(0.02, DESK_Y, -0.12);
  lampLight.castShadow = true;
  lampLight.shadow.mapSize.set(1024, 1024);
  lampLight.shadow.bias = -0.0012;
  lampLight.shadow.camera.near = 0.2;
  lampLight.shadow.camera.far = 4;
  root.add(lampLight);
  root.add(lampLight.target);

  const lampFill = new THREE.PointLight(0xffa04c, 0.35, 1.6, 2);
  lampFill.position.set(-0.45, DESK_Y + 0.3, -0.28);
  root.add(lampFill);

  const bulbGlow = new THREE.Sprite(
    new THREE.SpriteMaterial({
      map: radialGlow("rgba(255,205,140,0.95)", "rgba(255,150,60,0)"),
      transparent: true,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      opacity: 0.75,
      toneMapped: false,
    })
  );
  bulbGlow.scale.set(0.3, 0.3, 1);
  bulbGlow.position.set(-0.41, DESK_Y + 0.42, -0.31);
  root.add(bulbGlow);

  /* ---------------- foreground desk clutter ---------------- */
  // mug
  const mug = new THREE.Group();
  const mugBody = new THREE.Mesh(new THREE.CylinderGeometry(0.042, 0.036, 0.095, 22, 1, true), toon(0xd8d2c4));
  mugBody.position.y = 0.0475;
  mugBody.castShadow = true;
  mug.add(mugBody);
  const mugInner = new THREE.Mesh(
    new THREE.CircleGeometry(0.041, 22),
    new THREE.MeshStandardMaterial({ color: 0x2a1a10, roughness: 0.35 })
  );
  mugInner.rotation.x = -Math.PI / 2;
  mugInner.position.y = 0.082;
  mug.add(mugInner);
  const mugBottom = new THREE.Mesh(new THREE.CircleGeometry(0.036, 22), toon(0xc8c2b4));
  mugBottom.rotation.x = Math.PI / 2;
  mugBottom.position.y = 0.002;
  mug.add(mugBottom);
  const handle = new THREE.Mesh(new THREE.TorusGeometry(0.026, 0.007, 8, 18, Math.PI * 1.3), toon(0xd8d2c4));
  handle.position.set(0.045, 0.05, 0);
  handle.rotation.set(0, Math.PI / 2, -0.4);
  mug.add(handle);
  put(mug, 0.58, DESK_Y, 0.19, 0.4);
  root.add(mug);

  // coffee ring
  const ring = new THREE.Mesh(
    new THREE.RingGeometry(0.05, 0.062, 26),
    new THREE.MeshBasicMaterial({ color: 0x5a3a1c, transparent: true, opacity: 0.5 })
  );
  ring.rotation.x = -Math.PI / 2;
  ring.position.set(0.42, DESK_Y + 0.001, 0.16);
  root.add(ring);

  // pen cup + pens
  const cup = new THREE.Mesh(new THREE.CylinderGeometry(0.036, 0.032, 0.1, 18, 1, true), toon(0x2f4a63));
  cup.position.set(-0.62, DESK_Y + 0.05, 0.16);
  cup.castShadow = true;
  root.add(cup);
  const cupBase = new THREE.Mesh(new THREE.CircleGeometry(0.032, 18), toon(0x24394d));
  cupBase.rotation.x = -Math.PI / 2;
  cupBase.position.set(-0.62, DESK_Y + 0.002, 0.16);
  root.add(cupBase);
  const penCols = [0xc8402f, 0x2f4ac8, 0xd8c040, 0x2f8f5f];
  penCols.forEach((c, i) => {
    const pen = new THREE.Mesh(new THREE.CylinderGeometry(0.005, 0.005, 0.17, 8), toon(c));
    pen.position.set(-0.62 + (i - 1.5) * 0.011, DESK_Y + 0.11, 0.16 + (i % 2) * 0.008);
    pen.rotation.set((rnd() - 0.5) * 0.3, 0, (rnd() - 0.5) * 0.35);
    pen.castShadow = true;
    root.add(pen);
  });

  // stapler
  const stapler = new THREE.Group();
  const stBase = box(0.13, 0.022, 0.045, toon(0x1f242c));
  stBase.position.y = 0.011;
  stapler.add(stBase);
  const stTop = box(0.13, 0.026, 0.042, toon(0x8f2f2f));
  stTop.position.set(0, 0.036, -0.004);
  stTop.rotation.x = -0.06;
  stapler.add(stTop);
  const stArm = box(0.05, 0.014, 0.04, metalMat);
  stArm.position.set(-0.05, 0.05, -0.006);
  stapler.add(stArm);
  put(stapler, 0.26, DESK_Y, 0.22, -0.35);
  root.add(stapler);

  // tape dispenser
  const tape = new THREE.Group();
  const tBase = box(0.11, 0.02, 0.09, toon(0x2b3038));
  tBase.position.y = 0.01;
  tape.add(tBase);
  const roll = new THREE.Mesh(new THREE.CylinderGeometry(0.032, 0.032, 0.018, 20), toon(0xc8b060));
  roll.rotation.z = Math.PI / 2;
  roll.position.set(0.01, 0.036, 0);
  tape.add(roll);
  const rollHole = new THREE.Mesh(new THREE.CylinderGeometry(0.014, 0.014, 0.02, 14), toon(0x14181e));
  rollHole.rotation.z = Math.PI / 2;
  rollHole.position.set(0.01, 0.036, 0);
  tape.add(rollHole);
  put(tape, -0.3, DESK_Y, 0.23, 0.5);
  root.add(tape);

  // paperclips
  for (let i = 0; i < 5; i++) {
    const clip = new THREE.Mesh(new THREE.TorusGeometry(0.011, 0.0016, 5, 14), metalMat);
    clip.rotation.set(Math.PI / 2, 0, rnd() * 3);
    clip.position.set(0.06 + i * 0.018 + rnd() * 0.01, DESK_Y + 0.002, 0.2 + rnd() * 0.03);
    root.add(clip);
  }

  // crumpled paper ball
  const ballGeo = new THREE.IcosahedronGeometry(0.032, 1);
  {
    const p = ballGeo.attributes.position as THREE.BufferAttribute;
    for (let i = 0; i < p.count; i++) {
      const s = 0.75 + rnd() * 0.45;
      p.setXYZ(i, p.getX(i) * s, p.getY(i) * s, p.getZ(i) * s);
    }
    ballGeo.computeVertexNormals();
  }
  const ball = new THREE.Mesh(ballGeo, new THREE.MeshStandardMaterial({ map: paper, roughness: 0.95, side: THREE.DoubleSide }));
  ball.position.set(0.74, DESK_Y + 0.03, 0.12);
  ball.castShadow = true;
  root.add(ball);

  // notepad + pen
  const pad = new THREE.Mesh(new THREE.BoxGeometry(0.13, 0.008, 0.17), new THREE.MeshStandardMaterial({ map: paper, roughness: 0.9 }));
  pad.position.set(0.8, DESK_Y + 0.004, 0.28);
  pad.rotation.y = 0.2;
  pad.receiveShadow = true;
  root.add(pad);
  const padPen = new THREE.Mesh(new THREE.CylinderGeometry(0.004, 0.004, 0.14, 8), toon(0x1c2028));
  padPen.position.set(0.79, DESK_Y + 0.012, 0.26);
  padPen.rotation.set(Math.PI / 2, 0, 0.25);
  root.add(padPen);

  // stack of blank forms at the left
  for (let i = 0; i < 7; i++) {
    const sheet = new THREE.Mesh(
      new THREE.BoxGeometry(0.19, 0.002, 0.26),
      new THREE.MeshStandardMaterial({ map: paper, roughness: 0.92 })
    );
    sheet.position.set(-0.74 + (rnd() - 0.5) * 0.01, DESK_Y + 0.002 + i * 0.0022, 0.14 + (rnd() - 0.5) * 0.01);
    sheet.rotation.y = 0.12 + (rnd() - 0.5) * 0.05;
    sheet.castShadow = true;
    sheet.receiveShadow = true;
    root.add(sheet);
  }

  // desk phone
  const phone = new THREE.Group();
  const pBody = box(0.11, 0.03, 0.16, toon(0x1d2128));
  pBody.position.y = 0.015;
  phone.add(pBody);
  const pHand = box(0.05, 0.022, 0.16, toon(0x14181e));
  pHand.position.y = 0.041;
  phone.add(pHand);
  for (const hx of [-0.014, 0.014]) {
    const pEar = box(0.036, 0.02, 0.04, toon(0x14181e));
    pEar.position.set(hx, 0.045, -0.06);
    phone.add(pEar);
  }
  put(phone, 0.72, DESK_Y, -0.16, -0.25);
  root.add(phone);

  /* ---------------- lights ---------------- */
  const hemi = new THREE.HemisphereLight(0x1d3557, 0x03060c, 0.5);
  root.add(hemi);
  const coldFill = new THREE.PointLight(0x7fa8ff, 2.4, 6, 2);
  coldFill.position.set(0, 1.5, -2.0);
  root.add(coldFill);
  const coldFill2 = new THREE.PointLight(0x6f96e8, 1.6, 4.5, 2);
  coldFill2.position.set(-1.2, 1.4, -0.6);
  root.add(coldFill2);
  const doorLight = new THREE.PointLight(0x4a7ab0, 1.2, 3, 2);
  doorLight.position.set(-2.2, 1.1, -3.1);
  root.add(doorLight);

  const panelMats = panels.map((p) => p.material as THREE.MeshBasicMaterial);

  return {
    root,
    deskY: DESK_Y,
    deskPlane: new THREE.Plane(new THREE.Vector3(0, 1, 0), -DESK_Y),
    trays,
    screen,
    crtLight,
    crtGlow,
    lampLight,
    update(t: number) {
      // fluorescent flicker
      for (let i = 0; i < panelMats.length; i++) {
        const f = 0.82 + Math.sin(t * (3 + i) + i) * 0.03 + (rnd() < 0.01 ? -0.35 : 0);
        panelMats[i].color.setScalar(f);
      }
      // phosphor breathing
      const pulse = 0.9 + Math.sin(t * 2.3) * 0.06;
      crtLight.intensity = 0.28 * pulse;
      (crtGlow.material as THREE.SpriteMaterial).opacity = 0.3 * pulse;
      // lamp hum
      lampLight.intensity = 4.6 + Math.sin(t * 11) * 0.08;
      bulbGlow.material.opacity = 0.42 + Math.sin(t * 9) * 0.03;
    },
  };
}
