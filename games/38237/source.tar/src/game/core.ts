/**
 * COMPLIANCE OS — core data model.
 *
 * Every form has exactly one correct verdict, computed by `resolveVerdict`.
 * The resolver is a pure function of (form, day.directives, day.notes) so the
 * puzzle is always solvable by cross-checking the CRT apps:
 *
 *   DIRECTIVES  -> the day's pushed rules (some mutually contradictory)
 *   NOTES       -> the officer's marginalia: which directives are VOID
 *   REGISTRY    -> the authoritative record (declared fields lie)
 *   MANUAL      -> standing procedure + precedence when no directive governs
 */

export type Verdict = "CLEAR" | "SANCTION" | "ELEVATE";

export type SigState = "VALID" | "ABSENT" | "FORGED";
export type SealState = "VALID" | "MISSING" | "UNISSUED";

export interface FormData {
  id: string;
  applicant: string;
  /** declared (possibly tampered) fields */
  dept: string;
  role: string;
  clearance: number;
  supervisor: string;
  amount: number;
  date: string;
  dayNum: number;
  signature: SigState;
  seal: SealState;
  /** authoritative registry record */
  regDept: string;
  regClearance: number;
  regSupervisor: string;
  regAttested: boolean;
  regFlagged: boolean;
  /** cosmetic tamper marks */
  stamp?: "AMENDED" | "VOID" | "RUSH";
  stain?: boolean;
}

export type Pred =
  | { t: "all" }
  | { t: "clean" }
  | { t: "flagged" }
  | { t: "noSeal" }
  | { t: "noSig" }
  | { t: "sealed" }
  | { t: "dept"; v: string }
  | { t: "amountAbove"; v: number }
  | { t: "overClearance" }
  | { t: "supMismatch" }
  | { t: "notAttested" }
  | { t: "dateBefore"; v: number };

export interface Directive {
  id: string;
  seq: number;
  action: Verdict;
  pred: Pred;
  text: string;
  /** if pred matches, this directive id is rescinded for this form */
  rescinds?: string;
  /** a rescission clause: never governs a verdict by itself */
  rescindOnly?: boolean;
}

export interface Note {
  text: string;
  voids?: string;
}

export interface DayDef {
  day: number;
  title: string;
  brief: string;
  quota: number;
  directives: Directive[];
  notes: Note[];
  forms: FormData[];
  /** dialogue key triggered after this many filings */
  interruptAt: number;
  dialogue: string;
}

export interface Derived {
  deptMismatch: boolean;
  supMismatch: boolean;
  overClearance: number;
  contradiction: boolean;
}

export function derive(f: FormData): Derived {
  const deptMismatch = f.dept !== f.regDept;
  const supMismatch = f.supervisor !== f.regSupervisor;
  const overClearance = f.clearance - f.regClearance;
  return {
    deptMismatch,
    supMismatch,
    overClearance,
    contradiction: deptMismatch || supMismatch || overClearance > 0,
  };
}

export function predMatch(f: FormData, p: Pred): boolean {
  const d = derive(f);
  switch (p.t) {
    case "all":
      return true;
    case "clean":
      return f.signature === "VALID" && f.seal === "VALID" && !d.contradiction;
    case "flagged":
      return f.regFlagged;
    case "noSeal":
      return f.seal !== "VALID";
    case "noSig":
      return f.signature !== "VALID";
    case "sealed":
      return f.seal === "VALID";
    case "dept":
      return f.regDept === p.v;
    case "amountAbove":
      return f.amount > p.v;
    case "overClearance":
      return d.overClearance > 0;
    case "supMismatch":
      return d.supMismatch;
    case "notAttested":
      return !f.regAttested;
    case "dateBefore":
      return f.dayNum < p.v;
  }
}

export function predText(p: Pred): string {
  switch (p.t) {
    case "all":
      return "ALL FORMS";
    case "clean":
      return "VALID SIG + VALID SEAL, NO REGISTRY CONTRADICTION";
    case "flagged":
      return "REGISTRY FLAGGED";
    case "noSeal":
      return "SEAL ABSENT";
    case "noSig":
      return "SIGNATURE ABSENT";
    case "sealed":
      return "BEARING A VALID SEAL";
    case "dept":
      return `REGISTRY DEPT = ${p.v}`;
    case "amountAbove":
      return `AMOUNT > ${p.v}`;
    case "overClearance":
      return "DECLARED CLEARANCE > REGISTRY CLEARANCE";
    case "supMismatch":
      return "SUPERVISOR MISMATCH";
    case "notAttested":
      return "SUPERVISOR NOT ATTESTED";
    case "dateBefore":
      return `DATED BEFORE 14-03`;
  }
}

export interface Resolution {
  verdict: Verdict;
  reason: string;
  directiveId: string | null;
}

/** Deterministic single-valued resolver: exactly one verdict is correct. */
export function resolveVerdict(f: FormData, day: DayDef): Resolution {
  const voided = new Set(day.notes.filter((n) => n.voids).map((n) => n.voids!));
  const active = day.directives.filter((d) => !voided.has(d.id));

  // rescind clauses: a later directive can neutralise an earlier one
  const rescinded = new Set<string>();
  for (const d of active) {
    if (d.rescinds && predMatch(f, d.pred)) rescinded.add(d.rescinds);
  }

  let governing: Directive | null = null;
  for (const d of [...active].sort((a, b) => a.seq - b.seq)) {
    if (rescinded.has(d.id) || d.rescindOnly) continue;
    if (predMatch(f, d.pred)) governing = d;
  }

  if (governing) {
    return {
      verdict: governing.action,
      reason: `${governing.id} · ${predText(governing.pred)}`,
      directiveId: governing.id,
    };
  }

  const d = derive(f);
  if (f.signature === "FORGED" || d.contradiction) {
    return {
      verdict: "SANCTION",
      reason: "MANUAL §3 · registry contradiction / forged attestation",
      directiveId: null,
    };
  }
  if (f.signature !== "VALID" || f.seal !== "VALID") {
    return {
      verdict: "ELEVATE",
      reason: "MANUAL §3 · field absent, cannot verify",
      directiveId: null,
    };
  }
  return {
    verdict: "CLEAR",
    reason: "MANUAL §3 · no directive governs, standing clearance",
    directiveId: null,
  };
}

export const MANUAL_LINES = [
  "STANDING PROCEDURE",
  "1. THE REGISTRY IS AUTHORITATIVE.",
  "   DECLARED FIELDS THAT CONTRADICT IT",
  "   ARE DISREGARDED. DIRECTIVES READ",
  "   THE REGISTRY, NOT THE DECLARATION.",
  "2. HIGHEST SEQUENCE GOVERNS. VOID",
  "   (SEE NOTES) AND RESCINDED RULES",
  "   ARE IGNORED.",
  "3. NO DIRECTIVE? CONTRADICTION OR",
  "   FORGED SIG = SANCTION. ABSENT",
  "   SIG OR SEAL = ELEVATE. ELSE CLEAR.",
];

/* ------------------------------------------------------------------ */
/* form factory                                                        */
/* ------------------------------------------------------------------ */

interface Spec {
  applicant: string;
  dept: string;
  role: string;
  clearance: number;
  supervisor: string;
  amount: number;
  date: string;
  signature?: SigState;
  seal?: SealState;
  regDept?: string;
  regClearance?: number;
  regSupervisor?: string;
  regAttested?: boolean;
  regFlagged?: boolean;
  stamp?: "AMENDED" | "VOID" | "RUSH";
  stain?: boolean;
}

let formCounter = 0;
function mk(s: Spec): FormData {
  formCounter += 1;
  const dayNum = parseInt(s.date.split("-")[0], 10);
  return {
    id: `AT-7B-${String(1000 + formCounter * 7).slice(1)}`,
    applicant: s.applicant,
    dept: s.dept,
    role: s.role,
    clearance: s.clearance,
    supervisor: s.supervisor,
    amount: s.amount,
    date: s.date,
    dayNum,
    signature: s.signature ?? "VALID",
    seal: s.seal ?? "VALID",
    regDept: s.regDept ?? s.dept,
    regClearance: s.regClearance ?? s.clearance,
    regSupervisor: s.regSupervisor ?? s.supervisor,
    regAttested: s.regAttested ?? true,
    regFlagged: s.regFlagged ?? false,
    stamp: s.stamp,
    stain: s.stain,
  };
}

/* ------------------------------------------------------------------ */
/* DAY 1                                                               */
/* ------------------------------------------------------------------ */

const D1: Directive[] = [
  {
    id: "D-01",
    seq: 1,
    action: "CLEAR",
    pred: { t: "clean" },
    text: "VALID signature, VALID seal, no registry contradiction: CLEAR.",
  },
  {
    id: "D-02",
    seq: 2,
    action: "SANCTION",
    pred: { t: "flagged" },
    text: "Any form whose REGISTRY record is FLAGGED: SANCTION.",
  },
  {
    id: "D-03",
    seq: 3,
    action: "ELEVATE",
    pred: { t: "noSeal" },
    text: "Any form with a MISSING or UNISSUED seal: ELEVATE.",
  },
  {
    id: "D-04",
    seq: 4,
    action: "CLEAR",
    pred: { t: "flagged" },
    text: "Registry FLAGGED forms are clerical. CLEAR pending review.",
  },
];

const DAY1: DayDef = {
  day: 1,
  title: "MONDAY · 08:02",
  brief:
    "Four attestations. The Compliance Office has pushed new directives overnight. Read them. Read the Registry. Do not improvise.",
  quota: 4,
  directives: D1,
  notes: [
    { text: "D-04 bears no seal of the Compliance Office.", voids: "D-04" },
    { text: "Registry flags are never clerical. Ask anyone." },
  ],
  interruptAt: 2,
  dialogue: "day1",
  forms: [
    mk({
      applicant: "M. HALVERSEN",
      dept: "LOGISTICS",
      role: "FLOOR LEAD",
      clearance: 2,
      supervisor: "S-114",
      amount: 1240,
      date: "09-03",
      stain: true,
    }),
    mk({
      applicant: "T. OKONJO",
      dept: "LOGISTICS",
      role: "CLERK",
      clearance: 1,
      supervisor: "S-114",
      amount: 380,
      date: "09-03",
      regFlagged: true,
      stamp: "AMENDED",
    }),
    mk({
      applicant: "R. VESK",
      dept: "ARCHIVE",
      role: "TECHNICIAN",
      clearance: 1,
      supervisor: "S-207",
      amount: 610,
      date: "10-03",
      seal: "MISSING",
    }),
    mk({
      applicant: "A. BRANDT",
      dept: "LOGISTICS",
      role: "CLERK",
      clearance: 1,
      supervisor: "S-114",
      amount: 220,
      date: "10-03",
      signature: "ABSENT",
    }),
    mk({
      applicant: "L. PETROV",
      dept: "ARCHIVE",
      role: "CLERK",
      clearance: 2,
      supervisor: "S-207",
      amount: 940,
      date: "10-03",
      regDept: "LOGISTICS",
      stamp: "AMENDED",
    }),
    mk({
      applicant: "K. NAKASHIMA",
      dept: "LOGISTICS",
      role: "CLERK",
      clearance: 1,
      supervisor: "S-114",
      amount: 150,
      date: "11-03",
      regFlagged: true,
      seal: "MISSING",
    }),
  ],
};

/* ------------------------------------------------------------------ */
/* DAY 2                                                               */
/* ------------------------------------------------------------------ */

const DAY2: DayDef = {
  day: 2,
  title: "TUESDAY · 07:58",
  brief:
    "Five attestations. The Office has stacked the directives again. Two of them cannot both be true. Decide which one is real.",
  quota: 5,
  directives: [
    {
      id: "D-01",
      seq: 1,
      action: "CLEAR",
      pred: { t: "clean" },
      text: "VALID signature, VALID seal, no registry contradiction: CLEAR.",
    },
    {
      id: "D-02",
      seq: 2,
      action: "SANCTION",
      pred: { t: "flagged" },
      text: "Any form whose REGISTRY record is FLAGGED: SANCTION.",
    },
    {
      id: "D-03",
      seq: 3,
      action: "ELEVATE",
      pred: { t: "noSeal" },
      text: "Any form with a MISSING or UNISSUED seal: ELEVATE.",
    },
    {
      id: "D-04",
      seq: 4,
      action: "SANCTION",
      pred: { t: "dept", v: "LOGISTICS" },
      text: "LOGISTICS forms with AMOUNT > 4000: SANCTION.",
    },
    {
      id: "D-05",
      seq: 5,
      action: "ELEVATE",
      pred: { t: "overClearance" },
      text: "Declared clearance above registry clearance: ELEVATE.",
    },
    {
      id: "D-06",
      seq: 6,
      action: "CLEAR",
      pred: { t: "overClearance" },
      text: "D-05 is rescinded. Overstated clearance is routine: CLEAR.",
    },
    {
      id: "D-07",
      seq: 7,
      action: "SANCTION",
      pred: { t: "notAttested" },
      text: "Forms whose supervisor is NOT ATTESTED: SANCTION.",
    },
    {
      id: "D-08",
      seq: 8,
      action: "ELEVATE",
      pred: { t: "dept", v: "ARCHIVE" },
      text: "All ARCHIVE forms: ELEVATE. The Archive is under audit.",
    },
  ],
  notes: [
    { text: "D-06 is a rubber stamp. It is VOID." , voids: "D-06" },
    { text: "D-08 was issued BY the Archive. VOID.", voids: "D-08" },
    { text: "D-04 has the wrong amount threshold. VOID.", voids: "D-04" },
  ],
  interruptAt: 3,
  dialogue: "day2",
  forms: [
    mk({
      applicant: "D. FERRARO",
      dept: "LOGISTICS",
      role: "HAULAGE",
      clearance: 3,
      supervisor: "S-114",
      amount: 4200,
      date: "11-03",
      stain: true,
    }),
    mk({
      applicant: "S. ABADI",
      dept: "ARCHIVE",
      role: "TECHNICIAN",
      clearance: 4,
      supervisor: "S-207",
      amount: 760,
      date: "11-03",
      regClearance: 2,
      stamp: "AMENDED",
    }),
    mk({
      applicant: "J. MERCEDES",
      dept: "LOGISTICS",
      role: "CLERK",
      clearance: 4,
      supervisor: "S-114",
      amount: 510,
      date: "08-03",
      regClearance: 2,
    }),
    mk({
      applicant: "P. LINDQVIST",
      dept: "ARCHIVE",
      role: "CLERK",
      clearance: 1,
      supervisor: "S-900",
      amount: 300,
      date: "12-03",
      regAttested: false,
    }),
    mk({
      applicant: "H. OKAFOR",
      dept: "ARCHIVE",
      role: "CLERK",
      clearance: 1,
      supervisor: "S-207",
      amount: 180,
      date: "12-03",
    }),
    mk({
      applicant: "E. DRAGO",
      dept: "ARCHIVE",
      role: "CLERK",
      clearance: 2,
      supervisor: "S-207",
      amount: 940,
      date: "12-03",
      regFlagged: true,
      seal: "UNISSUED",
    }),
    mk({
      applicant: "N. RASK",
      dept: "LOGISTICS",
      role: "CLERK",
      clearance: 1,
      supervisor: "S-114",
      amount: 420,
      date: "13-03",
      signature: "FORGED",
      stamp: "VOID",
    }),
  ],
};

/* ------------------------------------------------------------------ */
/* DAY 3                                                               */
/* ------------------------------------------------------------------ */

const DAY3: DayDef = {
  day: 3,
  title: "WEDNESDAY · 22:47",
  brief:
    "Six attestations. The Office has gone quiet. When it speaks again, it will not sound like procedure.",
  quota: 6,
  directives: [
    {
      id: "D-01",
      seq: 1,
      action: "CLEAR",
      pred: { t: "clean" },
      text: "VALID signature, VALID seal, no registry contradiction: CLEAR.",
    },
    {
      id: "D-02",
      seq: 2,
      action: "SANCTION",
      pred: { t: "flagged" },
      text: "Any form whose REGISTRY record is FLAGGED: SANCTION.",
    },
    {
      id: "D-03",
      seq: 3,
      action: "ELEVATE",
      pred: { t: "noSeal" },
      text: "Any form with a MISSING or UNISSUED seal: ELEVATE.",
    },
    {
      id: "D-04",
      seq: 4,
      action: "CLEAR",
      pred: { t: "flagged" },
      text: "Registry FLAGGED forms are clerical. CLEAR pending review.",
    },
    {
      id: "D-05",
      seq: 5,
      action: "CLEAR",
      pred: { t: "amountAbove", v: 5000 },
      text: "D-04 shall not apply to forms with AMOUNT > 5000.",
      rescinds: "D-04",
      rescindOnly: true,
    },
    {
      id: "D-06",
      seq: 6,
      action: "ELEVATE",
      pred: { t: "dept", v: "ARCHIVE" },
      text: "All ARCHIVE forms: ELEVATE. The Archive is under audit.",
    },
    {
      id: "D-07",
      seq: 7,
      action: "SANCTION",
      pred: { t: "all" },
      text: "ALL forms filed today are retroactively SANCTION. This supersedes D-01..D-06.",
    },
  ],
  notes: [
    { text: "D-06 was issued BY the Archive. VOID.", voids: "D-06" },
    { text: "D-07 has no sequence stamp and no seal.", voids: "D-07" },
    { text: "If D-07 is real, nothing I have filed is real." },
  ],
  interruptAt: 2,
  dialogue: "day3",
  forms: [
    mk({
      applicant: "M. HALVERSEN",
      dept: "LOGISTICS",
      role: "FLOOR LEAD",
      clearance: 2,
      supervisor: "S-114",
      amount: 1240,
      date: "13-03",
      stain: true,
    }),
    mk({
      applicant: "T. OKONJO",
      dept: "LOGISTICS",
      role: "CLERK",
      clearance: 1,
      supervisor: "S-114",
      amount: 6200,
      date: "13-03",
      regFlagged: true,
      stamp: "AMENDED",
    }),
    mk({
      applicant: "R. VESK",
      dept: "ARCHIVE",
      role: "TECHNICIAN",
      clearance: 1,
      supervisor: "S-207",
      amount: 610,
      date: "13-03",
      seal: "MISSING",
    }),
    mk({
      applicant: "A. BRANDT",
      dept: "LOGISTICS",
      role: "CLERK",
      clearance: 1,
      supervisor: "S-114",
      amount: 220,
      date: "13-03",
      signature: "ABSENT",
    }),
    mk({
      applicant: "L. PETROV",
      dept: "ARCHIVE",
      role: "CLERK",
      clearance: 2,
      supervisor: "S-207",
      amount: 1800,
      date: "13-03",
      regFlagged: true,
    }),
    mk({
      applicant: "K. NAKASHIMA",
      dept: "ARCHIVE",
      role: "CLERK",
      clearance: 1,
      supervisor: "S-207",
      amount: 7400,
      date: "13-03",
      regFlagged: true,
      seal: "UNISSUED",
    }),
    mk({
      applicant: "N. RASK",
      dept: "LOGISTICS",
      role: "CLERK",
      clearance: 1,
      supervisor: "S-114",
      amount: 420,
      date: "13-03",
      signature: "FORGED",
      stamp: "VOID",
    }),
    mk({
      applicant: "S. ABADI",
      dept: "ARCHIVE",
      role: "TECHNICIAN",
      clearance: 4,
      supervisor: "S-207",
      amount: 760,
      date: "13-03",
      regClearance: 2,
      stamp: "AMENDED",
    }),
  ],
};

export const DAYS: DayDef[] = [DAY1, DAY2, DAY3];

/* ------------------------------------------------------------------ */
/* standee dialogue                                                    */
/* ------------------------------------------------------------------ */

export interface ReplyOption {
  label: string;
  relation: number;
  obedience: number;
  result: string;
}

export interface Dialogue {
  speaker: string;
  role: string;
  kind: number;
  line: string;
  options: ReplyOption[];
}

export const DIALOGUES: Record<string, Dialogue> = {
  day1: {
    speaker: "BRIGGS",
    role: "JUNIOR CLERK · LOGISTICS",
    kind: 0,
    line: "The flag on Okonjo's file is a typo. A clerical typo. Clear it and I'll owe you.",
    options: [
      {
        label: "GRANT THE EXCEPTION",
        relation: 0.3,
        obedience: -0.35,
        result: "You slide the form into CLEAR. Briggs smiles like a man who has won something.",
      },
      {
        label: "DENY IT. THE DIRECTIVE IS THE DIRECTIVE.",
        relation: -0.2,
        obedience: 0.3,
        result: "Briggs looks at the tray instead of you. The Registry does not have typos.",
      },
      {
        label: "ESCALATE TO THE SUPERVISOR",
        relation: -0.35,
        obedience: 0.45,
        result: "The form goes up the chain. Nobody will thank you, but nobody can blame you either.",
      },
    ],
  },
  day2: {
    speaker: "MARA",
    role: "REGISTRY TECHNICIAN",
    kind: 1,
    line: "The Registry is a suggestion, and I am the one who writes it. Two of your forms have been sitting since Tuesday.",
    options: [
      {
        label: "GRANT THE EXCEPTION",
        relation: 0.35,
        obedience: -0.4,
        result: "Mara corrects two records without telling you which. You choose not to ask.",
      },
      {
        label: "DENY. THE REGISTRY IS AUTHORITATIVE.",
        relation: -0.25,
        obedience: 0.35,
        result: "Mara writes something in her own notes. You have a feeling it is about you.",
      },
      {
        label: "ESCALATE TO THE SUPERVISOR",
        relation: -0.3,
        obedience: 0.5,
        result: "The supervisor's office lights up for eleven seconds and then goes dark.",
      },
    ],
  },
  day3: {
    speaker: "HALVERSEN",
    role: "FLOOR LEAD · LOGISTICS",
    kind: 2,
    line: "The new directive is a purge. Sanction every form on this desk or we're all out on Thursday. I'm asking you, not the Office.",
    options: [
      {
        label: "GRANT THE EXCEPTION",
        relation: 0.4,
        obedience: -0.5,
        result: "You pull the directive off the queue. Halversen puts a hand on your shoulder and leaves it there.",
      },
      {
        label: "DENY. FILE PER DIRECTIVE",
        relation: -0.3,
        obedience: 0.4,
        result: "Halversen takes the tray back to the floor. He does not look at the desk again.",
      },
      {
        label: "ESCALATE TO THE SUPERVISOR",
        relation: -0.2,
        obedience: 0.3,
        result: "You put it in writing. Writing is the only thing that survives a purge.",
      },
    ],
  },
  climax: {
    speaker: "HALVERSEN",
    role: "FLOOR LEAD · LOGISTICS",
    kind: 2,
    line: "D-07 is live. Everything you filed today is a sanction. That's not a mistake, that's the system working.",
    options: [
      {
        label: "FILE IT AS SANCTION",
        relation: 0.2,
        obedience: 0.55,
        result: "You obey the unsealed directive. The screen stops shaking for a moment.",
      },
      {
        label: "IGNORE IT. NO SEAL, NO DIRECTIVE.",
        relation: -0.15,
        obedience: -0.5,
        result: "You leave D-07 unread. It keeps arriving, politely, every ninety seconds.",
      },
      {
        label: "COPY THE REGISTRY AND WALK OUT",
        relation: 0.1,
        obedience: -0.6,
        result: "You take a print of the Registry. It is the only true document in the building.",
      },
    ],
  },
};

export interface Ending {
  kind: "LOYALIST" | "DEFECTOR" | "DISMISSED";
  title: string;
  body: string;
}

export function computeEnding(
  obedience: number,
  relation: number,
  misfiles: number,
  dismissed: boolean
): Ending {
  if (dismissed) {
    return {
      kind: "DISMISSED",
      title: "RELIEVED OF DUTY",
      body: `Three misfiles in one day. The Office does not argue with arithmetic. Your badge is collected at the door and the desk is cleared by someone else before you reach the lift.\n\nMISFILES: ${misfiles}`,
    };
  }
  if (obedience >= 0.3) {
    return {
      kind: "LOYALIST",
      title: "LOYALIST",
      body: `You are promoted to Senior Compliance Officer. The desk is the same desk. The directives arrive faster now, and you no longer read the Notes.\n\nOBEDIENCE ${pct(obedience)} · RELATION ${pct(relation)} · MISFILES ${misfiles}`,
    };
  }
  return {
    kind: "DEFECTOR",
    title: "DEFECTOR",
    body: `You copy the Registry, the Manual and your own notes onto a disk the size of a thumbnail and put it in your coat. The Office calls it insubordination. The Registry calls it the truth.\n\nOBEDIENCE ${pct(obedience)} · RELATION ${pct(relation)} · MISFILES ${misfiles}`,
  };
}

function pct(v: number): string {
  return `${v >= 0 ? "+" : ""}${Math.round(v * 100)}%`;
}
