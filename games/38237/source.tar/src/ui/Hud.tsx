import type { Game, Snapshot } from "../game/Game";

const VERDICT_COLOR: Record<string, string> = {
  CLEAR: "text-emerald-300",
  SANCTION: "text-rose-300",
  ELEVATE: "text-amber-300",
};

function Panel({
  children,
  className = "",
}: {
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <div
      className={
        "border border-cyan-300/20 bg-[#050b14]/80 px-3 py-2 font-mono text-[11px] leading-tight text-cyan-100/90 shadow-[0_0_24px_rgba(0,0,0,0.6)] " +
        className
      }
    >
      {children}
    </div>
  );
}

function Bar({ label, value, tone }: { label: string; value: number; tone: string }) {
  const pct = Math.round((value + 1) / 2 * 100);
  return (
    <div className="w-40">
      <div className="flex justify-between text-[9px] tracking-widest text-cyan-200/60">
        <span>{label}</span>
        <span>
          {value >= 0 ? "+" : ""}
          {Math.round(value * 100)}
        </span>
      </div>
      <div className="mt-1 h-[6px] w-full border border-cyan-300/20 bg-black/60">
        <div className={"h-full " + tone} style={{ width: `${pct}%` }} />
      </div>
    </div>
  );
}

export function Hud({ snap, game }: { snap: Snapshot; game: Game | null }) {
  const playing = snap.phase === "play";

  return (
    <div className="pointer-events-none absolute inset-0 select-none">
      {/* top left: day / quota / misfiles */}
      <div className="absolute left-4 top-4 flex flex-col gap-2">
        <Panel>
          <div className="flex items-baseline gap-3">
            <span className="text-[10px] tracking-[0.25em] text-cyan-300/70">DAY</span>
            <span className="text-lg font-bold text-cyan-100">{snap.dayIndex + 1}</span>
            <span className="text-[10px] tracking-[0.2em] text-cyan-300/50">/ 3</span>
          </div>
          <div className="mt-1 flex items-center gap-1">
            <span className="mr-1 text-[9px] tracking-widest text-cyan-200/60">QUOTA</span>
            {Array.from({ length: snap.quota }).map((_, i) => (
              <span
                key={i}
                className={
                  "inline-block h-[9px] w-[9px] border " +
                  (i < snap.filed ? "border-emerald-300/70 bg-emerald-400/80" : "border-cyan-300/30 bg-black/50")
                }
              />
            ))}
          </div>
          <div className="mt-1 flex items-center gap-1">
            <span className="mr-1 text-[9px] tracking-widest text-cyan-200/60">MISFILE</span>
            {[0, 1, 2].map((i) => (
              <span
                key={i}
                className={
                  "inline-block h-[9px] w-[9px] rotate-45 border " +
                  (i < snap.misfiles ? "border-rose-300/80 bg-rose-500/80" : "border-cyan-300/25 bg-black/50")
                }
              />
            ))}
            <span className="ml-1 text-[9px] text-cyan-200/40">3 = DISMISSAL</span>
          </div>
        </Panel>
      </div>

      {/* top right: axes */}
      <div className="absolute right-4 top-4 flex flex-col items-end gap-2">
        <Panel>
          <div className="flex flex-col gap-2">
            <Bar label="RELATION" value={snap.relation} tone="bg-sky-400/80" />
            <Bar label="OBEDIENCE" value={snap.obedience} tone="bg-amber-400/80" />
          </div>
        </Panel>
        {playing && (
          <button
            onClick={() => game?.recall()}
            disabled={!snap.canRecall}
            className={
              "pointer-events-auto border px-3 py-1.5 font-mono text-[10px] tracking-[0.2em] transition-colors " +
              (snap.canRecall
                ? "border-amber-300/50 bg-amber-400/10 text-amber-200 hover:bg-amber-400/25"
                : "border-cyan-300/15 bg-black/40 text-cyan-200/25")
            }
          >
            {snap.recallUsed ? "RECALL USED" : "RECALL LAST FILED"}
          </button>
        )}
      </div>

      {/* bottom: hint + feedback */}
      <div className="absolute bottom-4 left-1/2 flex w-[min(760px,92vw)] -translate-x-1/2 flex-col items-center gap-2">
        {snap.feedback && (
          <Panel className={snap.feedback.correct ? "border-emerald-300/40" : "border-rose-400/60"}>
            <div className="flex items-center justify-between gap-4">
              <span className={"text-[11px] font-bold tracking-[0.2em] " + (snap.feedback.correct ? "text-emerald-300" : "text-rose-300")}>
                {snap.feedback.correct ? "FILED CORRECTLY" : "MISFILE"}
              </span>
              <span className="text-[10px] text-cyan-200/60">{snap.feedback.formId}</span>
            </div>
            <div className="mt-1 text-[10px] text-cyan-100/80">
              CORRECT: <span className={"font-bold " + VERDICT_COLOR[snap.feedback.verdict]}>{snap.feedback.verdict}</span>
              {"  ·  "}
              {snap.feedback.reason}
            </div>
          </Panel>
        )}
        {playing && (
          <Panel className="w-full text-center">
            <span className="text-[10px] tracking-[0.15em] text-cyan-200/70">{snap.hint}</span>
          </Panel>
        )}
      </div>

      {/* standee dialogue */}
      {snap.dialogue && (
        <div className="pointer-events-auto absolute bottom-24 left-1/2 w-[min(680px,92vw)] -translate-x-1/2">
          <div className="border border-amber-300/40 bg-[#07090f]/95 p-4 font-mono shadow-[0_0_40px_rgba(0,0,0,0.8)]">
            <div className="flex items-baseline justify-between">
              <span className="text-sm font-bold tracking-[0.2em] text-amber-200">{snap.dialogue.speaker}</span>
              <span className="text-[9px] tracking-[0.2em] text-amber-200/50">{snap.dialogue.role}</span>
            </div>
            <p className="mt-2 text-[12px] leading-relaxed text-cyan-50/90">“{snap.dialogue.line}”</p>
            <div className="mt-3 flex flex-col gap-1.5">
              {snap.dialogue.options.map((o, i) => (
                <button
                  key={o.label}
                  onClick={() => game?.reply(i)}
                  className="border border-cyan-300/25 bg-cyan-400/5 px-3 py-2 text-left text-[11px] tracking-[0.12em] text-cyan-100/90 transition-colors hover:border-cyan-300/60 hover:bg-cyan-400/15"
                >
                  <span className="mr-2 text-cyan-300/50">{i + 1}</span>
                  {o.label}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {snap.dialogueResult && !snap.dialogue && (
        <div className="absolute bottom-24 left-1/2 w-[min(620px,92vw)] -translate-x-1/2">
          <Panel className="border-amber-300/30">
            <span className="text-[11px] leading-relaxed text-amber-100/80">{snap.dialogueResult}</span>
          </Panel>
        </div>
      )}

      {/* overlays */}
      {snap.phase !== "play" && (
        <div className="pointer-events-auto absolute inset-0 flex items-center justify-center bg-[#02040a]/72 backdrop-blur-[2px]">
          <div className="w-[min(720px,92vw)] border border-cyan-300/25 bg-[#050a12]/95 p-7 font-mono shadow-[0_0_60px_rgba(0,0,0,0.9)]">
            {snap.phase === "intro" && (
              <>
                <div className="text-[10px] tracking-[0.4em] text-cyan-300/60">COMPLIANCE OFFICE · CUBICLE 14-C</div>
                <h1 className="mt-2 text-3xl font-bold tracking-[0.18em] text-cyan-100">ATTESTATION</h1>
                <p className="mt-4 text-[12px] leading-relaxed text-cyan-100/75">
                  Three workdays. You sort attestation forms against directives the Compliance Office
                  pushes onto your screen — directives that sometimes contradict each other, and some of
                  which are forgeries you can only spot in your own notes.
                </p>
                <ul className="mt-4 space-y-1 text-[11px] leading-relaxed text-cyan-200/60">
                  <li>· CLICK a form to raise it toward you. DRAG it onto CLEAR, SANCTION or ELEVATE.</li>
                  <li>· CROSS-CHECK the DIRECTIVES, REGISTRY, MANUAL and NOTES apps on the CRT.</li>
                  <li>· Exactly one verdict is correct. Three misfiles in a day ends your employment.</li>
                  <li>· One recall per day. Colleagues will ask you for exceptions. Choose carefully.</li>
                </ul>
                <button
                  onClick={() => game?.start()}
                  className="mt-6 border border-emerald-300/50 bg-emerald-400/10 px-5 py-2 text-[12px] tracking-[0.25em] text-emerald-200 transition-colors hover:bg-emerald-400/25"
                >
                  SIGN IN
                </button>
              </>
            )}

            {snap.phase === "brief" && (
              <>
                <div className="text-[10px] tracking-[0.4em] text-cyan-300/60">
                  DAY {snap.dayIndex + 1} OF 3
                </div>
                <h2 className="mt-2 text-2xl font-bold tracking-[0.15em] text-cyan-100">{snap.dayTitle}</h2>
                <p className="mt-4 text-[12px] leading-relaxed text-cyan-100/75">{snap.dayBrief}</p>
                <div className="mt-4 border border-cyan-300/20 bg-black/40 p-3 text-[11px] text-cyan-200/70">
                  QUOTA: {snap.quota} ATTESTATIONS · MISFILE LIMIT: 3 · RECALLS: 1
                </div>
                <button
                  onClick={() => game?.beginPlay()}
                  className="mt-6 border border-emerald-300/50 bg-emerald-400/10 px-5 py-2 text-[12px] tracking-[0.25em] text-emerald-200 transition-colors hover:bg-emerald-400/25"
                >
                  BEGIN SHIFT
                </button>
              </>
            )}

            {snap.phase === "dayEnd" && (
              <>
                <div className="text-[10px] tracking-[0.4em] text-emerald-300/70">QUOTA CLEARED</div>
                <h2 className="mt-2 text-2xl font-bold tracking-[0.15em] text-cyan-100">
                  DAY {snap.dayIndex + 1} CLOSED
                </h2>
                <div className="mt-4 grid grid-cols-3 gap-3 text-[11px]">
                  <div className="border border-cyan-300/20 bg-black/40 p-3">
                    <div className="text-[9px] tracking-widest text-cyan-300/50">FILED</div>
                    <div className="text-lg text-emerald-300">
                      {snap.filed}/{snap.quota}
                    </div>
                  </div>
                  <div className="border border-cyan-300/20 bg-black/40 p-3">
                    <div className="text-[9px] tracking-widest text-cyan-300/50">MISFILES</div>
                    <div className="text-lg text-rose-300">{snap.misfiles}</div>
                  </div>
                  <div className="border border-cyan-300/20 bg-black/40 p-3">
                    <div className="text-[9px] tracking-widest text-cyan-300/50">OBEDIENCE</div>
                    <div className="text-lg text-amber-300">
                      {snap.obedience >= 0 ? "+" : ""}
                      {Math.round(snap.obedience * 100)}%
                    </div>
                  </div>
                </div>
                <button
                  onClick={() => game?.nextDay()}
                  className="mt-6 border border-emerald-300/50 bg-emerald-400/10 px-5 py-2 text-[12px] tracking-[0.25em] text-emerald-200 transition-colors hover:bg-emerald-400/25"
                >
                  {snap.dayIndex >= 2 ? "CLOSE THE FILE" : "NEXT DAY"}
                </button>
              </>
            )}

            {snap.phase === "ending" && snap.ending && (
              <>
                <div
                  className={
                    "text-[10px] tracking-[0.4em] " +
                    (snap.ending.kind === "LOYALIST"
                      ? "text-amber-300/70"
                      : snap.ending.kind === "DEFECTOR"
                        ? "text-sky-300/70"
                        : "text-rose-400/70")
                  }
                >
                  END OF CONTRACT
                </div>
                <h2
                  className={
                    "mt-2 text-3xl font-bold tracking-[0.18em] " +
                    (snap.ending.kind === "LOYALIST"
                      ? "text-amber-200"
                      : snap.ending.kind === "DEFECTOR"
                        ? "text-sky-200"
                        : "text-rose-300")
                  }
                >
                  {snap.ending.title}
                </h2>
                <p className="mt-4 whitespace-pre-line text-[12px] leading-relaxed text-cyan-100/75">
                  {snap.ending.body}
                </p>
                <button
                  onClick={() => game?.restart()}
                  className="mt-6 border border-cyan-300/50 bg-cyan-400/10 px-5 py-2 text-[12px] tracking-[0.25em] text-cyan-100 transition-colors hover:bg-cyan-400/25"
                >
                  START A NEW CONTRACT
                </button>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
