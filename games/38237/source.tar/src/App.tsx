import { useEffect, useRef, useState } from "react";
import { Game, type Snapshot } from "./game/Game";
import { Hud } from "./ui/Hud";

export default function App() {
  const mount = useRef<HTMLDivElement>(null);
  const [game, setGame] = useState<Game | null>(null);
  const [snap, setSnap] = useState<Snapshot | null>(null);

  useEffect(() => {
    if (!mount.current) return;
    const g = new Game(mount.current, setSnap);
    setGame(g);
    return () => {
      g.dispose();
      setGame(null);
    };
  }, []);

  return (
    <div className="relative h-screen w-screen overflow-hidden bg-black">
      <div ref={mount} className="absolute inset-0" />

      {/* CRT glass over the whole frame */}
      <div
        className="pointer-events-none absolute inset-0 opacity-[0.16] mix-blend-overlay"
        style={{
          backgroundImage:
            "repeating-linear-gradient(0deg, rgba(255,255,255,0.14) 0px, rgba(255,255,255,0.14) 1px, rgba(0,0,0,0) 1px, rgba(0,0,0,0) 3px)",
        }}
      />
      <div
        className="pointer-events-none absolute inset-0"
        style={{ boxShadow: "inset 0 0 220px 60px rgba(0,0,0,0.85)" }}
      />

      {snap ? (
        <Hud snap={snap} game={game} />
      ) : (
        <div className="absolute inset-0 flex items-center justify-center font-mono text-[11px] tracking-[0.3em] text-cyan-300/60">
          BOOTING COMPLIANCE OS…
        </div>
      )}
    </div>
  );
}
