import { makeRng } from "../game/rng";
import { T, TILE_COUNT } from "../game/world";

export const TILE = 16;
export const VIEW_W = 15;
export const VIEW_H = 11;
export const CANVAS_W = VIEW_W * TILE;
export const CANVAS_H = VIEW_H * TILE;

/* ------------------------------------------------------------------ *
 * Grid drawing
 * ------------------------------------------------------------------ */

export function drawGrid(
  ctx: CanvasRenderingContext2D,
  grid: number[],
  palette: string[],
  x: number,
  y: number,
  scale = 1,
  flip = false,
) {
  for (let i = 0; i < 256; i++) {
    const v = grid[i];
    if (!v) continue;
    const gx = i % 16;
    const gy = (i / 16) | 0;
    const px = flip ? 15 - gx : gx;
    ctx.fillStyle = palette[v] ?? palette[2] ?? "#fff";
    ctx.fillRect(x + px * scale, y + gy * scale, scale, scale);
  }
}

/* ------------------------------------------------------------------ *
 * Terrain textures
 * ------------------------------------------------------------------ */

const C = {
  grass: ["#2b5c34", "#336b3c", "#24502d", "#3d7a45"],
  tall: ["#4f9a52", "#6fbf63", "#3d7f45"],
  water: ["#1f3f6d", "#2b5590", "#4a80c4", "#79b0e8"],
  canopy: ["#1c4a2b", "#276b39", "#358a48"],
  trunk: ["#4a3220", "#5f4429"],
  path: ["#7a6a4c", "#8d7c5b", "#6b5c42", "#9c8a68"],
  rock: ["#4e535b", "#666c76", "#828994"],
  wall: ["#0b0b0f", "#14141a", "#1d1d25"],
  shrine: ["#14141a", "#24242e", "#7de0d0", "#3f8f86"],
  heal: ["#2b5f8f", "#3f7fb5", "#cfe6ff", "#8fc0ee"],
  boss: ["#131318", "#22222a", "#b03a4a", "#e06a72"],
  flower: ["#d9c04a", "#c9566b", "#6f8fd9", "#e08ab0"],
};

function paintTile(ctx: CanvasRenderingContext2D, type: number, variant: number) {
  const rng = makeRng(`tile:${type}:${variant}`);
  const px = (x: number, y: number, c: string) => {
    ctx.fillStyle = c;
    ctx.fillRect(x, y, 1, 1);
  };
  const fill = (c: string) => {
    ctx.fillStyle = c;
    ctx.fillRect(0, 0, 16, 16);
  };
  const dither = (colors: string[], density = 0.22) => {
    for (let y = 0; y < 16; y++) {
      for (let x = 0; x < 16; x++) {
        if (rng.next() < density) px(x, y, rng.pick(colors));
      }
    }
  };
  const grassBase = () => {
    fill(C.grass[0]);
    dither([C.grass[1], C.grass[2]], 0.3);
    for (let i = 0; i < 3; i++) {
      const x = rng.int(15);
      const y = rng.int(14);
      px(x, y, C.grass[3]);
      px(x, y + 1, C.grass[3]);
    }
  };

  switch (type) {
    case T.GRASS:
      grassBase();
      break;

    case T.TALL: {
      grassBase();
      for (let i = 0; i < 9; i++) {
        const x = rng.int(15);
        const h = 5 + rng.int(6);
        const top = 15 - h;
        for (let y = top; y < 16; y++) {
          px(x, y, C.tall[y < top + 2 ? 1 : 0]);
          if (y > top + 1 && rng.chance(0.4)) px(x + 1, y, C.tall[2]);
        }
        px(x, top, C.tall[1]);
      }
      break;
    }

    case T.WATER: {
      fill(C.water[0]);
      dither([C.water[1]], 0.16);
      for (let i = 0; i < 4; i++) {
        const y = rng.int(15);
        const x = rng.int(11);
        const len = 2 + rng.int(3);
        for (let k = 0; k < len; k++) px(x + k, y, C.water[2]);
        px(x + len - 1, y, C.water[3]);
      }
      break;
    }

    case T.TREE: {
      grassBase();
      const cx = 8;
      const cy = 6;
      for (let y = 0; y < 16; y++) {
        for (let x = 0; x < 16; x++) {
          const d = Math.hypot(x + 0.5 - cx, y + 0.5 - cy);
          if (d > 6.2) continue;
          const shade = x + (12 - y) * 0.5;
          px(x, y, shade > 15 ? C.canopy[2] : shade > 10 ? C.canopy[1] : C.canopy[0]);
        }
      }
      for (let y = 11; y < 16; y++) {
        px(7, y, C.trunk[0]);
        px(8, y, C.trunk[1]);
      }
      break;
    }

    case T.PATH: {
      fill(C.path[0]);
      dither([C.path[1], C.path[2]], 0.34);
      for (let i = 0; i < 3; i++) {
        const x = rng.int(14);
        const y = rng.int(14);
        px(x, y, C.path[3]);
        px(x + 1, y + 1, C.path[2]);
      }
      break;
    }

    case T.FLOWER: {
      grassBase();
      for (let i = 0; i < 3; i++) {
        const x = 2 + rng.int(11);
        const y = 3 + rng.int(10);
        const col = rng.pick(C.flower);
        px(x, y, col);
        px(x + 1, y, col);
        px(x, y + 1, col);
        px(x, y - 1, "#2f6b3a");
      }
      break;
    }

    case T.ROCK: {
      grassBase();
      for (let y = 4; y < 15; y++) {
        for (let x = 2; x < 14; x++) {
          const d = Math.hypot((x - 8) * 0.85, (y - 10) * 1.15);
          if (d > 5) continue;
          const shade = x + (13 - y) * 0.6;
          px(x, y, shade > 16 ? C.rock[2] : shade > 11 ? C.rock[1] : C.rock[0]);
        }
      }
      px(5, 14, "#1b2b1e");
      px(6, 14, "#1b2b1e");
      px(7, 14, "#1b2b1e");
      break;
    }

    case T.SHRINE: {
      fill(C.shrine[0]);
      dither([C.shrine[1]], 0.1);
      for (let x = 1; x < 15; x++) {
        px(x, 1, C.shrine[1]);
        px(x, 14, C.shrine[1]);
      }
      for (let y = 1; y < 15; y++) {
        px(1, y, C.shrine[1]);
        px(14, y, C.shrine[1]);
      }
      // glyph
      const g = C.shrine[2];
      const dim = C.shrine[3];
      const glyph = ["..###..", ".#...#.", "#..#..#", ".#...#.", "..###.."];
      for (let y = 0; y < glyph.length; y++) {
        for (let x = 0; x < 7; x++) {
          if (glyph[y][x] === "#") px(4 + x, 5 + y, (x + y) % 2 === 0 ? g : dim);
        }
      }
      break;
    }

    case T.HEAL: {
      fill(C.water[0]);
      for (let y = 0; y < 16; y++) {
        for (let x = 0; x < 16; x++) {
          const d = Math.hypot(x - 7.5, y - 7.5);
          if (d < 6.5) px(x, y, C.heal[0]);
          if (d < 5.4) px(x, y, C.heal[1]);
        }
      }
      for (let a = 0; a < 24; a++) {
        const ang = (a / 24) * Math.PI * 2;
        px(8 + Math.round(Math.cos(ang) * 5), 8 + Math.round(Math.sin(ang) * 5), C.heal[2]);
      }
      px(6, 6, C.heal[2]);
      px(10, 9, C.heal[3]);
      break;
    }

    case T.BOSS: {
      fill(C.boss[0]);
      dither([C.boss[1]], 0.14);
      for (let a = 0; a < 20; a++) {
        const ang = (a / 20) * Math.PI * 2;
        px(8 + Math.round(Math.cos(ang) * 6), 8 + Math.round(Math.sin(ang) * 6), C.boss[2]);
      }
      px(7, 6, C.boss[3]);
      px(8, 6, C.boss[3]);
      px(7, 7, C.boss[2]);
      px(8, 7, C.boss[2]);
      px(7, 9, C.boss[3]);
      px(8, 9, C.boss[3]);
      break;
    }

    default: {
      fill(C.wall[0]);
      dither([C.wall[1], C.wall[2]], 0.14);
      break;
    }
  }
}

let tileCache: HTMLCanvasElement[][] | null = null;

export function tileSet(): HTMLCanvasElement[][] {
  if (tileCache) return tileCache;
  const set: HTMLCanvasElement[][] = [];
  for (let t = 0; t < TILE_COUNT; t++) {
    const arr: HTMLCanvasElement[] = [];
    for (let v = 0; v < 4; v++) {
      const c = document.createElement("canvas");
      c.width = TILE;
      c.height = TILE;
      const ctx = c.getContext("2d");
      if (ctx) {
        ctx.imageSmoothingEnabled = false;
        paintTile(ctx, t, v);
      }
      arr.push(c);
    }
    set.push(arr);
  }
  tileCache = set;
  return set;
}

/* ------------------------------------------------------------------ *
 * Player sprite
 * ------------------------------------------------------------------ */

export const PLAYER_PALETTE = [
  "#000000",
  "#2a1e38",
  "#e8b98f",
  "#3f6bb5",
  "#2b3450",
  "#000000",
  "#000000",
  "#000000",
  "#ffffff",
  "#100d16",
];

const ART_DOWN = [
  "................",
  ".....999999.....",
  "....91111119....",
  "....91111119....",
  "....92222229....",
  "....92922929....",
  "....92222229....",
  ".....922229.....",
  "....93333339....",
  "...933333339....",
  "..92333333329...",
  "..92333333329...",
  "....93333339....",
  "....94499449....",
  "....94499449....",
  "................",
];

const ART_UP = [
  "................",
  ".....999999.....",
  "....91111119....",
  "....91111119....",
  "....91111119....",
  "....91111119....",
  "....91111119....",
  ".....911119.....",
  "....93333339....",
  "...933333339....",
  "..92333333329...",
  "..92333333329...",
  "....93333339....",
  "....94499449....",
  "....94499449....",
  "................",
];

const ART_SIDE = [
  "................",
  ".....999999.....",
  "....91111119....",
  "....911111119...",
  "....911111119...",
  "....92222299....",
  "....92229299....",
  "....92222299....",
  ".....922229.....",
  "....9333339.....",
  "...933333339....",
  "...933333339....",
  "....9333339.....",
  "....9449949.....",
  "....9449949.....",
  "................",
];

function artToGrid(art: string[]): number[] {
  const g = new Array<number>(256).fill(0);
  for (let y = 0; y < 16; y++) {
    const row = art[y] ?? "";
    for (let x = 0; x < 16; x++) {
      const ch = row[x] ?? ".";
      if (ch === "." || ch === " ") continue;
      const v = Number(ch);
      if (!Number.isNaN(v)) g[y * 16 + x] = v;
    }
  }
  return g;
}

export const PLAYER_GRIDS = {
  down: artToGrid(ART_DOWN),
  up: artToGrid(ART_UP),
  side: artToGrid(ART_SIDE),
};
