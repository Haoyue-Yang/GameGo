export type Element = "Ember" | "Tide" | "Verdant" | "Volt" | "Stone" | "Gale" | "Void";

export type Archetype = "blob" | "beast" | "bird" | "serpent" | "crystal" | "wisp" | "slime";

export type MoveKind = "attack" | "heal" | "buff" | "debuff" | "drain" | "guard";

export interface Move {
  id: string;
  name: string;
  element: Element;
  kind: MoveKind;
  power: number;
  acc: number;
  stat?: "atk" | "def" | "spd";
  amount?: number;
  desc: string;
}

export interface Stats {
  hp: number;
  atk: number;
  def: number;
  spd: number;
}

export interface Creature {
  uid: string;
  seed: string;
  name: string;
  element: Element;
  archetype: Archetype;
  level: number;
  xp: number;
  hp: number;
  base: Stats;
  moves: Move[];
  captureRate: number;
  palette: string[];
  /** flat 16x16 grid of palette indices (0 = transparent) */
  sprite: number[];
  fused: boolean;
  origin?: string;
  badges: number;
}

export interface Badge {
  name: string;
  seed: string;
  element: Element;
  world: number;
  bossName: string;
}
