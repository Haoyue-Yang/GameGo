import { makeRng, clamp, hashString, type Rng } from "./rng";
import type { Archetype, Creature, Element, Move, Stats } from "./types";

/* ------------------------------------------------------------------ *
 * Elements
 * ------------------------------------------------------------------ */

export const ELEMENTS: Element[] = ["Ember", "Tide", "Verdant", "Volt", "Stone", "Gale", "Void"];

export const ELEMENT_COLOR: Record<Element, string> = {
  Ember: "#e2703a",
  Tide: "#3f8fd6",
  Verdant: "#57b06a",
  Volt: "#e0c24a",
  Stone: "#a2896a",
  Gale: "#79c9c2",
  Void: "#9a72d6",
};

const STRONG: Record<Element, Element[]> = {
  Ember: ["Verdant", "Gale"],
  Tide: ["Ember", "Stone"],
  Verdant: ["Tide", "Stone"],
  Volt: ["Tide", "Gale"],
  Stone: ["Ember", "Volt"],
  Gale: ["Verdant", "Volt"],
  Void: [],
};

const WEAK: Record<Element, Element[]> = {
  Ember: ["Tide", "Stone"],
  Tide: ["Verdant", "Volt"],
  Verdant: ["Ember", "Gale"],
  Volt: ["Stone", "Verdant"],
  Stone: ["Tide", "Verdant"],
  Gale: ["Stone", "Ember"],
  Void: [],
};

export function typeMult(atk: Element, def: Element): number {
  if (STRONG[atk].includes(def)) return 1.6;
  if (WEAK[atk].includes(def)) return 0.6;
  return 1;
}

export function typeLabel(mult: number): string {
  if (mult > 1) return "SUPER EFFECTIVE";
  if (mult < 1) return "NOT VERY EFFECTIVE";
  return "";
}

/* ------------------------------------------------------------------ *
 * Sprite rasterisation (16x16, mirrored, outlined)
 * palette index: 0 empty | 1 dark | 2 mid | 3 light | 4 accent
 *               8 white | 9 outline
 * ------------------------------------------------------------------ */

interface Arch {
  parts: [number, number, number][];
  eyes: number;
  legs?: [number, number, number][];
  wings?: boolean;
  horns?: boolean;
  tail?: boolean;
  float?: number;
}

export const ARCHETYPES: Archetype[] = ["blob", "beast", "bird", "serpent", "crystal", "wisp", "slime"];

const ARCH: Record<Archetype, Arch> = {
  blob: { parts: [[7.5, 9.5, 4.3], [7.5, 6.4, 2.3]], eyes: 8 },
  beast: {
    parts: [[7.5, 9.6, 3.4], [7.5, 6.0, 2.7], [5.4, 11.2, 1.5]],
    eyes: 6,
    legs: [[5, 12, 2], [9, 12, 2]],
  },
  bird: {
    parts: [[7.5, 9.6, 3.0], [7.5, 5.6, 2.3]],
    eyes: 5,
    wings: true,
    legs: [[6, 13, 1], [9, 13, 1]],
  },
  serpent: { parts: [[7.5, 12.6, 2.2], [7.5, 9.6, 2.1], [7.5, 6.4, 2.5]], eyes: 6, tail: true },
  crystal: { parts: [[7.5, 9.8, 3.3], [7.5, 7.0, 2.0]], eyes: 9, horns: true },
  wisp: { parts: [[7.5, 7.6, 3.3], [7.5, 5.0, 1.9]], eyes: 7, float: 1 },
  slime: { parts: [[7.5, 10.6, 4.1], [7.5, 8.0, 2.7]], eyes: 9 },
};

export function paletteFromSeed(rng: Rng): string[] {
  const h = rng.int(360);
  const s = 42 + rng.int(38);
  const l = 52 + rng.int(12);
  const hsl = (hh: number, ss: number, ll: number) =>
    `hsl(${((hh % 360) + 360) % 360} ${ss}% ${clamp(ll, 8, 88)}%)`;
  return [
    "#000000", // 0 unused
    hsl(h, s, l * 0.5), // 1 dark
    hsl(h, s, l), // 2 mid
    hsl(h - 10, s - 6, l * 1.32), // 3 light
    hsl((h + 155) % 360, s + 8, 58), // 4 accent
    "#000000",
    "#000000",
    "#000000",
    "#f4f4f8", // 8 white
    hsl(h, Math.round(s * 0.55), 13), // 9 outline
  ];
}

function rasterize(arch: Archetype, rng: Rng): number[] {
  const g = new Array<number>(256).fill(0);
  const A = ARCH[arch];
  const float = A.float ?? 0;
  const parts = A.parts.map(
    ([x, y, r]) =>
      [x + (rng.next() - 0.5) * 0.9, y + (rng.next() - 0.5) * 0.9, r + (rng.next() - 0.5) * 1.1] as [
        number,
        number,
        number,
      ],
  );

  for (let y = 0; y < 16; y++) {
    for (let x = 0; x < 8; x++) {
      let h = 0;
      for (const [px, py, pr] of parts) {
        const dx = x + 0.5 - px;
        const dy = y + 0.5 - (py - float);
        h = Math.max(h, pr - Math.sqrt(dx * dx + dy * dy));
      }
      if (h > 0) {
        const t = (x + (15 - y) * 0.55) / 16;
        g[y * 16 + x] = t > 0.6 ? 3 : t > 0.28 ? 2 : 1;
      }
    }
  }

  if (A.legs) {
    for (const [lx, ly, lw] of A.legs) {
      for (let i = 0; i < lw; i++) {
        const x = lx + i;
        if (x < 8) {
          g[(ly + 1) * 16 + x] = 1;
          g[(ly + 2) * 16 + x] = 1;
        }
      }
    }
  }
  if (A.wings) {
    for (let i = 0; i < 3; i++) {
      const x = 1 - i;
      if (x >= 0) {
        g[(8 + i) * 16 + x] = 4;
        g[(9 + i) * 16 + x] = 4;
      }
    }
  }
  if (A.horns) {
    g[2 * 16 + 6] = 4;
    g[3 * 16 + 6] = 4;
    g[4 * 16 + 6] = 4;
    g[1 * 16 + 5] = 4;
    g[2 * 16 + 5] = 4;
  }
  if (A.tail) {
    g[13 * 16 + 2] = 2;
    g[14 * 16 + 1] = 2;
    g[14 * 16 + 2] = 2;
    g[15 * 16 + 1] = 4;
  }

  // mirror left half onto the right half
  for (let y = 0; y < 16; y++) {
    for (let x = 0; x < 8; x++) g[y * 16 + (15 - x)] = g[y * 16 + x];
  }

  // eyes: white sclera with a dark pupil, always symmetric
  const ey = A.eyes;
  for (const ex of [5, 10]) {
    g[ey * 16 + ex] = 8;
    g[(ey + 1) * 16 + ex] = 9;
  }

  return outline(g);
}

/** Any empty cell touching a filled cell becomes the outline colour. */
export function outline(g: number[]): number[] {
  const src = g.slice();
  const out = g.slice();
  const filled = (x: number, y: number) =>
    x >= 0 && x < 16 && y >= 0 && y < 16 && src[y * 16 + x] !== 0;
  for (let y = 0; y < 16; y++) {
    for (let x = 0; x < 16; x++) {
      if (out[y * 16 + x] !== 0) continue;
      if (
        filled(x - 1, y) ||
        filled(x + 1, y) ||
        filled(x, y - 1) ||
        filled(x, y + 1) ||
        filled(x - 1, y - 1) ||
        filled(x + 1, y + 1) ||
        filled(x - 1, y + 1) ||
        filled(x + 1, y - 1)
      ) {
        out[y * 16 + x] = 9;
      }
    }
  }
  return out;
}

/** Glitch-blend two grids: per-pixel parent vote, then row shear + colour bleed. */
export function glitchBlend(a: number[], b: number[], rng: Rng): number[] {
  const out = new Array<number>(256).fill(0);
  for (let i = 0; i < 256; i++) {
    const av = a[i];
    const bv = b[i];
    if (av && bv) out[i] = rng.chance(0.5) ? av : bv;
    else if (av) out[i] = av;
    else if (bv) out[i] = bv;
  }
  // row shear
  for (let y = 0; y < 16; y++) {
    if (!rng.chance(0.4)) continue;
    const dir = rng.chance(0.5) ? -1 : 1;
    const row = out.slice(y * 16, y * 16 + 16);
    for (let x = 0; x < 16; x++) out[y * 16 + x] = row[((x - dir + 16) % 16)];
  }
  // colour bleed
  for (let i = 0; i < 256; i++) {
    const v = out[i];
    if (!v || v === 8 || v === 9) continue;
    if (rng.chance(0.16)) out[i] = v === 1 ? 3 : v === 3 ? 1 : 4;
  }
  // stray noise pixels
  for (let k = 0; k < 5; k++) {
    const i = rng.int(256);
    if (out[i]) out[i] = rng.chance(0.5) ? 4 : 9;
  }
  return outline(out);
}

/* ------------------------------------------------------------------ *
 * Naming
 * ------------------------------------------------------------------ */

const SYL_A = ["ka", "vu", "ze", "mo", "ta", "ri", "no", "lu", "se", "ga", "pi", "xo", "fe", "da", "ku", "mi", "or", "th", "el", "sa", "ba", "ju", "qi", "wa"];
const SYL_B = ["ra", "mi", "do", "ka", "sha", "lu", "na", "vo", "ri", "ta", "go", "zu", "ma", "ki", "ne", "lo", "pa", "xi", "to", "wa", "si", "un", "ae", "or"];
const SYL_C = ["n", "x", "r", "k", "m", "s", "l", "th", "zz", "q", "v", ""];

export function nameFromSeed(rng: Rng): string {
  const a = rng.pick(SYL_A);
  const b = rng.pick(SYL_B);
  const c = rng.pick(SYL_C);
  const raw = (a + b + c).toUpperCase();
  return raw[0] + raw.slice(1).toLowerCase();
}

/** Glitch-interleave two names for a fused hybrid. */
export function glitchName(a: string, b: string, rng: Rng): string {
  const gl = ["#", "%", "@", "&", "!", "*", "?", "~", "^", "+"];
  const out: string[] = [];
  const al = a.replace(/[^a-z]/gi, "").toUpperCase();
  const bl = b.replace(/[^a-z]/gi, "").toUpperCase();
  const n = Math.max(al.length, bl.length);
  for (let i = 0; i < n; i++) {
    const ch = i % 2 === 0 ? al[i] ?? bl[i] : bl[i] ?? al[i];
    out.push(rng.chance(0.16) ? rng.pick(gl) : ch);
  }
  const s = out.join("").slice(0, 8);
  return s.length < 3 ? "GL1TCH" : s;
}

/* ------------------------------------------------------------------ *
 * Moves
 * ------------------------------------------------------------------ */

const ATTACK_WORDS = ["Sear", "Lash", "Bolt", "Gust", "Quake", "Bite", "Slam", "Pulse", "Rend", "Spore", "Dive", "Rush", "Hex", "Cleave", "Snap", "Flare", "Crush", "Sting", "Fang", "Wave"];
const ATTACK_SUFFIX = ["", " Strike", " Burst", " Fang", " Coil", " Lash", " Wave", " Rush", " Break", " Fang"];
const HEAL_WORDS = ["Mend", "Bloom", "Sip", "Knit", "Dew", "Balm"];
const BUFF_WORDS = ["Rally", "Harden", "Sprint", "Brace", "Focus"];
const DEBUFF_WORDS = ["Wither", "Cling", "Snare", "Daze", "Chill"];
const DRAIN_WORDS = ["Leech", "Siphon", "Drain", "Feast", "Maw"];

function mkMove(rng: Rng, element: Element, kind: Move["kind"], id: string): Move {
  const acc = kind === "attack" ? rng.range(82, 100) : rng.range(88, 100);
  const power = kind === "attack" ? rng.range(26, 58) : kind === "drain" ? rng.range(22, 40) : 0;
  let name: string;
  let desc: string;
  switch (kind) {
    case "attack":
      name = rng.pick(ATTACK_WORDS) + rng.pick(ATTACK_SUFFIX);
      desc = `Deals ${power} power damage.`;
      break;
    case "drain":
      name = rng.pick(DRAIN_WORDS);
      desc = `Damage; heals half the damage dealt.`;
      break;
    case "heal":
      name = rng.pick(HEAL_WORDS);
      desc = "Restores a slice of HP.";
      break;
    case "buff": {
      const st = rng.pick(["atk", "def", "spd"] as const);
      name = rng.pick(BUFF_WORDS);
      desc = `Raises own ${st.toUpperCase()} for 3 turns.`;
      return { id, name, element, kind, power: 0, acc, stat: st, amount: 1.3, desc };
    }
    case "debuff": {
      const st = rng.pick(["atk", "def", "spd"] as const);
      name = rng.pick(DEBUFF_WORDS);
      desc = `Lowers foe's ${st.toUpperCase()} for 3 turns.`;
      return { id, name, element, kind, power: 0, acc, stat: st, amount: 0.7, desc };
    }
    default:
      name = "Guard";
      desc = "Halves incoming damage this round.";
      break;
  }
  return { id, name, element, kind, power, acc, desc };
}

export function movesFromSeed(rng: Rng, element: Element, count = 4): Move[] {
  const kinds: Move["kind"][] = ["attack", "attack", "attack"];
  while (kinds.length < count) kinds.push(rng.pick(["heal", "buff", "debuff", "drain", "guard"] as const));
  const shuffled = rng.shuffle(kinds);
  return shuffled.map((k, i) => mkMove(rng, element, k, `m${i}`));
}

/* ------------------------------------------------------------------ *
 * Stats
 * ------------------------------------------------------------------ */

const ARCH_BIAS: Record<Archetype, Partial<Stats>> = {
  blob: { atk: 1.05, def: 1.0 },
  beast: { atk: 1.2, def: 1.0, spd: 1.05 },
  bird: { spd: 1.25, atk: 1.0 },
  serpent: { atk: 1.1, spd: 1.05, def: 0.95 },
  crystal: { def: 1.3, spd: 0.85 },
  wisp: { spd: 1.2, hp: 0.9 },
  slime: { hp: 1.35, def: 1.1, spd: 0.8 },
};

export function baseStatsFromSeed(rng: Rng, arch: Archetype): Stats {
  const b = ARCH_BIAS[arch];
  return {
    hp: Math.round(rng.range(22, 38) * (b.hp ?? 1)),
    atk: Math.round(rng.range(9, 16) * (b.atk ?? 1)),
    def: Math.round(rng.range(8, 15) * (b.def ?? 1)),
    spd: Math.round(rng.range(7, 16) * (b.spd ?? 1)),
  };
}

export const statAt = (base: number, level: number) => Math.max(1, Math.floor(base * (1 + (level - 1) * 0.075)));
export const maxHpAt = (base: number, level: number) => Math.max(1, Math.floor(base * (1 + (level - 1) * 0.09)));
export const xpToNext = (level: number) => 24 + level * level * 5;

export function statsOf(c: Creature): Stats {
  return {
    hp: maxHpAt(c.base.hp, c.level),
    atk: statAt(c.base.atk, c.level),
    def: statAt(c.base.def, c.level),
    spd: statAt(c.base.spd, c.level),
  };
}

/* ------------------------------------------------------------------ *
 * Creature factory
 * ------------------------------------------------------------------ */

let uidCounter = 0;
export const nextUid = () => `c${Date.now().toString(36)}${(uidCounter++).toString(36)}`;

export interface GenOpts {
  level?: number;
  element?: Element;
  archetype?: Archetype;
  boss?: boolean;
  name?: string;
  seed?: string;
}

export function generateCreature(seed: string, opts: GenOpts = {}): Creature {
  const rng = makeRng(seed);
  const level = opts.level ?? 3;
  const element = opts.element ?? rng.pick(ELEMENTS);
  const archetype = opts.archetype ?? rng.pick(ARCHETYPES);
  const base = baseStatsFromSeed(rng, archetype);
  const boss = !!opts.boss;
  if (boss) {
    base.hp = Math.round(base.hp * 1.35);
    base.atk = Math.round(base.atk * 1.2);
    base.def = Math.round(base.def * 1.2);
    base.spd = Math.round(base.spd * 1.1);
  }
  const moves = movesFromSeed(rng, element, boss ? 5 : 4);
  const maxHp = maxHpAt(base.hp, level);
  return {
    uid: nextUid(),
    seed,
    name: opts.name ?? nameFromSeed(rng),
    element,
    archetype,
    level,
    xp: 0,
    hp: maxHp,
    base,
    moves,
    captureRate: boss ? 0.07 : clamp(0.34 - level * 0.008 + rng.next() * 0.14, 0.1, 0.55),
    palette: paletteFromSeed(rng),
    sprite: rasterize(archetype, rng),
    fused: false,
    badges: 0,
  };
}

/** Award XP; returns log lines for level-ups. */
export function grantXp(c: Creature, amount: number): string[] {
  const lines: string[] = [];
  c.xp += amount;
  let guard = 0;
  while (c.xp >= xpToNext(c.level) && c.level < 60 && guard++ < 20) {
    c.xp -= xpToNext(c.level);
    c.level += 1;
    const before = maxHpAt(c.base.hp, c.level - 1);
    const after = maxHpAt(c.base.hp, c.level);
    c.hp = Math.min(after, c.hp + (after - before));
    lines.push(`${c.name} grew to Lv.${c.level}!`);
  }
  return lines;
}

/* ------------------------------------------------------------------ *
 * Fusion — two team creatures become one glitch-blended hybrid
 * ------------------------------------------------------------------ */

export function fuseCreatures(a: Creature, b: Creature, seedSalt: string): Creature {
  const seed = `${a.seed}+${b.seed}+${seedSalt}`;
  const rng = makeRng(seed);
  const avg = (k: keyof Stats) => Math.round((a.base[k] + b.base[k]) / 2 * 1.12);
  const base: Stats = {
    hp: avg("hp"),
    atk: avg("atk"),
    def: avg("def"),
    spd: avg("spd"),
  };
  const level = Math.max(a.level, b.level) + 1;
  const element = rng.chance(0.5) ? a.element : b.element;
  const archetype = rng.chance(0.5) ? a.archetype : b.archetype;
  const pool = [...a.moves, ...b.moves];
  const attacks = rng.shuffle(pool.filter((m) => m.power > 0)).sort((x, y) => y.power - x.power);
  const support = rng.shuffle(pool.filter((m) => m.power === 0));
  const moves = [...attacks.slice(0, 3), ...(support.length ? [support[0]] : [])];
  const maxHp = maxHpAt(base.hp, level);
  return {
    uid: nextUid(),
    seed,
    name: glitchName(a.name, b.name, rng),
    element,
    archetype,
    level,
    xp: 0,
    hp: maxHp,
    base,
    moves: moves.length >= 4 ? moves : [...moves, ...movesFromSeed(rng, element, 4 - moves.length)],
    captureRate: clamp((a.captureRate + b.captureRate) / 2 * 0.55, 0.05, 0.3),
    palette: a.palette,
    sprite: glitchBlend(a.sprite, b.sprite, rng),
    fused: true,
    origin: `${a.name} + ${b.name}`,
    badges: Math.max(a.badges, b.badges),
  };
}

/** Random starter seed like "K7-2F19". */
export function randomSeed(): string {
  const hex = "0123456789ABCDEF";
  let s = "";
  for (let i = 0; i < 8; i++) s += hex[Math.floor(Math.random() * 16)];
  return s.slice(0, 4) + "-" + s.slice(4, 8);
}

export const hashSeed = hashString;
