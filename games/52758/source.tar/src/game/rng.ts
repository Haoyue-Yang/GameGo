/** Deterministic, seed-driven randomness. Everything in the game derives from these. */

export interface Rng {
  seed: string;
  next(): number;
  int(n: number): number;
  range(a: number, b: number): number;
  pick<T>(arr: readonly T[]): T;
  chance(p: number): boolean;
  shuffle<T>(arr: T[]): T[];
  fork(tag: string): Rng;
}

/** FNV-1a 32-bit string hash. */
export function hashString(str: string): number {
  let h = 2166136261 >>> 0;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

/** Short human-readable seed label. */
export function seedLabel(seed: string): string {
  const h = hashString(seed).toString(16).toUpperCase().padStart(8, "0");
  return h.slice(0, 4) + "-" + h.slice(4, 8);
}

function mulberry32(a: number) {
  let s = a >>> 0;
  return function () {
    s = (s + 0x6d2b79f5) >>> 0;
    let t = s;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function makeRng(seed: string | number): Rng {
  const key = String(seed);
  const fn = mulberry32(hashString(key));
  const api: Rng = {
    seed: key,
    next: fn,
    int: (n: number) => Math.floor(fn() * n) % Math.max(1, n),
    range: (a: number, b: number) => a + Math.floor(fn() * (b - a + 1)),
    pick: <T,>(arr: readonly T[]) => arr[Math.floor(fn() * arr.length) % arr.length],
    chance: (p: number) => fn() < p,
    shuffle: <T,>(arr: T[]) => {
      const out = arr.slice();
      for (let i = out.length - 1; i > 0; i--) {
        const j = Math.floor(fn() * (i + 1));
        const t = out[i];
        out[i] = out[j];
        out[j] = t;
      }
      return out;
    },
    fork: (tag: string) => makeRng(key + "::" + tag),
  };
  return api;
}

export const clamp = (v: number, lo: number, hi: number) => Math.max(lo, Math.min(hi, v));
