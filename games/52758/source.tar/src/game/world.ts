import { makeRng, hashString, clamp, type Rng } from "./rng";
import { ELEMENTS, ELEMENT_COLOR, generateCreature, nameFromSeed } from "./creatures";
import type { Badge, Element } from "./types";

export const T = {
  GRASS: 0,
  TALL: 1,
  WATER: 2,
  TREE: 3,
  PATH: 4,
  FLOWER: 5,
  ROCK: 6,
  SHRINE: 7,
  HEAL: 8,
  BOSS: 9,
  WALL: 10,
} as const;

export const TILE_COUNT = 11;

const SOLID = new Set<number>([T.WATER, T.TREE, T.ROCK, T.WALL]);
export const isSolid = (t: number) => SOLID.has(t);

export interface World {
  seed: string;
  name: string;
  index: number;
  w: number;
  h: number;
  tiles: number[];
  spawn: { x: number; y: number };
  boss: { x: number; y: number };
  bossSeed: string;
  bossName: string;
  badgeSeed: string;
  badgeName: string;
  badgeElement: Element;
  heal: { x: number; y: number }[];
  shrine: { x: number; y: number }[];
  tallCount: number;
  encounterLevel: number;
}

const WORLD_NAMES = [
  "HOLLOW MEADOWS",
  "ASHEN FLATS",
  "GLASS MARSH",
  "CINDER STEPPE",
  "DRIFT WILDS",
  "NULL BASIN",
  "PRISM REACH",
  "SUNKEN VERGE",
  "ECHO HIGHLANDS",
  "STATIC DELTA",
  "PALE THICKET",
  "IRON HOLLOW",
];

const ROMAN = ["I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X", "XI", "XII"];

function makeNoise(rng: Rng, w: number, h: number, freq: number) {
  const gw = Math.ceil(w / freq) + 3;
  const gh = Math.ceil(h / freq) + 3;
  const grid = new Float32Array(gw * gh);
  for (let i = 0; i < grid.length; i++) grid[i] = rng.next();
  return (x: number, y: number) => {
    const fx = x / freq;
    const fy = y / freq;
    const x0 = Math.floor(fx);
    const y0 = Math.floor(fy);
    const tx = fx - x0;
    const ty = fy - y0;
    const sx = tx * tx * (3 - 2 * tx);
    const sy = ty * ty * (3 - 2 * ty);
    const a = grid[y0 * gw + x0];
    const b = grid[y0 * gw + x0 + 1];
    const c = grid[(y0 + 1) * gw + x0];
    const d = grid[(y0 + 1) * gw + x0 + 1];
    return (a * (1 - sx) + b * sx) * (1 - sy) + (c * (1 - sx) + d * sx) * sy;
  };
}

export function generateWorld(seed: string, index: number): World {
  const rng = makeRng(seed + "::world" + index);
  const w = 46;
  const h = 46;
  const tiles = new Array<number>(w * h).fill(T.GRASS);
  const at = (x: number, y: number) => y * w + x;
  const inb = (x: number, y: number) => x >= 0 && y >= 0 && x < w && y < h;

  const terrain = makeNoise(rng.fork("terrain"), w, h, 7);
  const detail = makeNoise(rng.fork("detail"), w, h, 3);
  const grassNoise = makeNoise(rng.fork("tall"), w, h, 4);

  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const n = terrain(x, y) * 0.65 + detail(x, y) * 0.35;
      let t: number = T.GRASS;
      if (n < 0.33) t = T.WATER;
      else if (n > 0.71) t = T.TREE;
      else if (n > 0.855) t = T.ROCK;
      else if (n > 0.44 && n < 0.475) t = T.FLOWER;
      tiles[at(x, y)] = t;
    }
  }

  // tall grass patches
  let tallCount = 0;
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const t = tiles[at(x, y)];
      if (t !== T.GRASS && t !== T.FLOWER) continue;
      if (grassNoise(x, y) > 0.56) {
        tiles[at(x, y)] = T.TALL;
        tallCount++;
      }
    }
  }

  // guarantee a decent amount of tall grass
  const target = Math.floor(w * h * 0.16);
  let guard = 0;
  while (tallCount < target && guard++ < 400) {
    const cx = rng.range(3, w - 4);
    const cy = rng.range(3, h - 4);
    const r = rng.range(1, 3);
    for (let y = cy - r; y <= cy + r; y++) {
      for (let x = cx - r; x <= cx + r; x++) {
        if (!inb(x, y) || Math.abs(x - cx) + Math.abs(y - cy) > r) continue;
        const t = tiles[at(x, y)];
        if (t === T.GRASS || t === T.FLOWER) {
          tiles[at(x, y)] = T.TALL;
          tallCount++;
        }
      }
    }
  }

  // border walls
  for (let x = 0; x < w; x++) {
    tiles[at(x, 0)] = T.WALL;
    tiles[at(x, 1)] = T.WALL;
    tiles[at(x, h - 1)] = T.WALL;
    tiles[at(x, h - 2)] = T.WALL;
  }
  for (let y = 0; y < h; y++) {
    tiles[at(0, y)] = T.WALL;
    tiles[at(1, y)] = T.WALL;
    tiles[at(w - 1, y)] = T.WALL;
    tiles[at(w - 2, y)] = T.WALL;
  }

  const spawn = { x: 4, y: 4 };
  const boss = { x: w - 5, y: h - 5 };

  // clear spawn plaza
  for (let y = spawn.y - 2; y <= spawn.y + 2; y++) {
    for (let x = spawn.x - 2; x <= spawn.x + 2; x++) {
      if (!inb(x, y)) continue;
      tiles[at(x, y)] = T.PATH;
    }
  }
  // clear boss arena
  for (let y = boss.y - 2; y <= boss.y + 2; y++) {
    for (let x = boss.x - 2; x <= boss.x + 2; x++) {
      if (!inb(x, y)) continue;
      tiles[at(x, y)] = T.PATH;
    }
  }
  tiles[at(boss.x, boss.y)] = T.BOSS;

  // carve a wandering corridor so the boss is always reachable
  let cx = spawn.x;
  let cy = spawn.y;
  let steps = 0;
  while ((cx !== boss.x || cy !== boss.y) && steps++ < 3000) {
    const dx = Math.sign(boss.x - cx);
    const dy = Math.sign(boss.y - cy);
    if (rng.chance(0.55) && dx !== 0) cx += dx;
    else if (dy !== 0) cy += dy;
    else cx += dx;
    if (!inb(cx, cy)) continue;
    const t = tiles[at(cx, cy)];
    if (isSolid(t) || t === T.WALL) tiles[at(cx, cy)] = T.GRASS;
  }

  // flood fill from spawn to find reachable ground
  const seen = new Uint8Array(w * h);
  const queue: number[] = [at(spawn.x, spawn.y)];
  seen[queue[0]] = 1;
  const reachable: number[] = [];
  while (queue.length) {
    const cur = queue.pop() as number;
    reachable.push(cur);
    const x = cur % w;
    const y = (cur / w) | 0;
    const nb = [
      [x + 1, y],
      [x - 1, y],
      [x, y + 1],
      [x, y - 1],
    ];
    for (const [nx, ny] of nb) {
      if (!inb(nx, ny)) continue;
      const idx = at(nx, ny);
      if (seen[idx]) continue;
      if (isSolid(tiles[idx])) continue;
      seen[idx] = 1;
      queue.push(idx);
    }
  }

  const pickOpen = (minDistFromSpawn: number) => {
    for (let tries = 0; tries < 500; tries++) {
      const idx = rng.pick(reachable);
      const x = idx % w;
      const y = (idx / w) | 0;
      if (Math.abs(x - spawn.x) + Math.abs(y - spawn.y) < minDistFromSpawn) continue;
      if (tiles[idx] !== T.GRASS && tiles[idx] !== T.FLOWER) continue;
      return { x, y };
    }
    return null;
  };

  const heal: { x: number; y: number }[] = [];
  const shrine: { x: number; y: number }[] = [];
  for (let i = 0; i < 3; i++) {
    const p = pickOpen(14);
    if (p) heal.push(p);
  }
  for (let i = 0; i < 2; i++) {
    const p = pickOpen(9);
    if (p) shrine.push(p);
  }
  for (const p of heal) tiles[at(p.x, p.y)] = T.HEAL;
  for (const p of shrine) tiles[at(p.x, p.y)] = T.SHRINE;

  const brng = makeRng(seed + "::boss" + index);
  const bossName = nameFromSeed(brng);
  const badgeElement = brng.pick(ELEMENTS);
  const badgeName = `${badgeElement.toUpperCase()} SIGIL ${ROMAN[Math.min(index, ROMAN.length - 1)]}`;
  const badgeSeed = `${hashString(seed + "::badge" + index).toString(16)}${badgeElement}`;

  return {
    seed,
    name: WORLD_NAMES[brng.int(WORLD_NAMES.length)] + " " + ROMAN[Math.min(index, ROMAN.length - 1)],
    index,
    w,
    h,
    tiles,
    spawn,
    boss,
    bossSeed: `${seed}::boss${index}`,
    bossName,
    badgeSeed,
    badgeName,
    badgeElement,
    heal,
    shrine,
    tallCount,
    encounterLevel: 3 + index * 4,
  };
}

export function tileAt(world: World, x: number, y: number): number {
  if (x < 0 || y < 0 || x >= world.w || y >= world.h) return T.WALL;
  return world.tiles[y * world.w + x];
}

export function makeBadge(world: World): Badge {
  return {
    name: world.badgeName,
    seed: world.badgeSeed,
    element: world.badgeElement,
    world: world.index,
    bossName: world.bossName,
  };
}

export function nextWorldSeed(badge: Badge): string {
  return `${badge.seed}::w${badge.world + 1}`;
}

export const elementColor = (e: Element) => ELEMENT_COLOR[e];

export function rollEncounter(world: World, rng: Rng): ReturnType<typeof generateCreature> {
  const lvl = clamp(world.encounterLevel + rng.range(-1, 2), 1, 60);
  const seed = `${world.seed}::wild${rng.int(1 << 28)}`;
  return generateCreature(seed, { level: lvl });
}
