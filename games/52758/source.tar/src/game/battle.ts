import { makeRng, clamp, type Rng } from "./rng";
import { grantXp, maxHpAt, statAt, typeLabel, typeMult } from "./creatures";
import type { Creature, Move } from "./types";

export type Side = "player" | "enemy";

export interface Buffs {
  atk: number;
  def: number;
  spd: number;
  guard: number;
}

const NB: Buffs = { atk: 1, def: 1, spd: 1, guard: 0 };

export type BattlePhase = "intro" | "menu" | "busy" | "won" | "lost" | "captured" | "fled";

export interface BattleState {
  player: Creature;
  enemy: Creature;
  isBoss: boolean;
  buffs: Buffs;
  ebuffs: Buffs;
  order: Side[];
  turnIdx: number;
  round: number;
  log: string[];
  phase: BattlePhase;
  orbs: number;
  attempts: number;
  hit: { side: Side; kind: "hit" | "heal" | "buff" | "miss" | "crit" | "capture"; t: number } | null;
  xpGained: number;
  captureOdds: number;
  /** every creature that has been sent out, for HP sync on battle end */
  spent: Creature[];
}

export const cloneBattle = (s: BattleState): BattleState => JSON.parse(JSON.stringify(s)) as BattleState;

export function initBattle(player: Creature, enemy: Creature, isBoss: boolean, orbs: number): BattleState {
  return {
    player,
    enemy,
    isBoss,
    buffs: { ...NB },
    ebuffs: { ...NB },
    order: [],
    turnIdx: 0,
    round: 0,
    log: [isBoss ? `GUARDIAN ${enemy.name} bars the way!` : `A wild ${enemy.name} bursts from the grass!`],
    phase: "intro",
    orbs,
    attempts: 0,
    hit: null,
    xpGained: 0,
    captureOdds: 0,
    spent: [player],
  };
}

export const statOf = (c: Creature, k: "atk" | "def" | "spd") => statAt(c.base[k], c.level);
export const maxHpOf = (c: Creature) => maxHpAt(c.base.hp, c.level);

export function spdOf(s: BattleState, side: Side): number {
  const c = side === "player" ? s.player : s.enemy;
  const b = side === "player" ? s.buffs : s.ebuffs;
  return statOf(c, "spd") * b.spd;
}

export function rollOrder(s: BattleState, rng: Rng): Side[] {
  const p = spdOf(s, "player");
  const e = spdOf(s, "enemy");
  if (Math.abs(p - e) > 0.4) return p > e ? ["player", "enemy"] : ["enemy", "player"];
  return rng.chance(0.5) ? ["player", "enemy"] : ["enemy", "player"];
}

function push(s: BattleState, line: string) {
  s.log.push(line);
  if (s.log.length > 40) s.log.splice(0, s.log.length - 40);
}

export function decay(s: BattleState) {
  for (const b of [s.buffs, s.ebuffs]) {
    b.atk += (1 - b.atk) * 0.25;
    b.def += (1 - b.def) * 0.25;
    b.spd += (1 - b.spd) * 0.25;
    b.guard = 0;
  }
}

function damage(
  s: BattleState,
  side: Side,
  move: Move,
  rng: Rng,
): { dmg: number; mult: number; crit: boolean } {
  const actor = side === "player" ? s.player : s.enemy;
  const target = side === "player" ? s.enemy : s.player;
  const ab = side === "player" ? s.buffs : s.ebuffs;
  const tb = side === "player" ? s.ebuffs : s.buffs;
  const atk = statOf(actor, "atk") * ab.atk;
  const def = statOf(target, "def") * tb.def;
  let dmg = ((2 * actor.level) / 5 + 2) * move.power * (atk / Math.max(1, def));
  dmg = (dmg / 50 + 2) * typeMult(move.element, target.element);
  const crit = rng.chance(0.07);
  if (crit) dmg *= 1.5;
  dmg *= 0.9 + rng.next() * 0.2;
  dmg *= tb.guard > 0 ? 0.5 : 1;
  return { dmg: Math.max(1, Math.floor(dmg)), mult: typeMult(move.element, target.element), crit };
}

/** Resolve one action. Mutates state. */
export function useMove(s: BattleState, side: Side, moveIdx: number, rng: Rng): void {
  const actor = side === "player" ? s.player : s.enemy;
  const target = side === "player" ? s.enemy : s.player;
  const ab = side === "player" ? s.buffs : s.ebuffs;
  const tb = side === "player" ? s.ebuffs : s.buffs;
  const move = actor.moves[moveIdx];
  if (!move) return;

  s.hit = null;
  if (!rng.chance(move.acc / 100)) {
    push(s, `${actor.name}'s ${move.name} missed!`);
    s.hit = { side: target === s.enemy ? "enemy" : "player", kind: "miss", t: Date.now() };
    return;
  }

  switch (move.kind) {
    case "attack":
    case "drain": {
      const { dmg, mult, crit } = damage(s, side, move, rng);
      target.hp = Math.max(0, target.hp - dmg);
      push(s, `${actor.name} uses ${move.name}!`);
      const tag = typeLabel(mult);
      if (tag) push(s, tag + "!");
      if (crit) push(s, "CRITICAL HIT!");
      if (move.kind === "drain") {
        const heal = Math.floor(dmg / 2);
        actor.hp = Math.min(maxHpOf(actor), actor.hp + heal);
        push(s, `${actor.name} siphoned ${heal} HP.`);
      }
      s.hit = { side: target === s.enemy ? "enemy" : "player", kind: crit ? "crit" : "hit", t: Date.now() };
      break;
    }
    case "heal": {
      const amount = Math.floor(maxHpOf(actor) * 0.3);
      actor.hp = Math.min(maxHpOf(actor), actor.hp + amount);
      push(s, `${actor.name} uses ${move.name}! +${amount} HP.`);
      s.hit = { side, kind: "heal", t: Date.now() };
      break;
    }
    case "buff": {
      const st = move.stat ?? "atk";
      ab[st] = clamp(ab[st] * (move.amount ?? 1.3), 0.4, 2.4);
      push(s, `${actor.name} uses ${move.name}! ${st.toUpperCase()} up.`);
      s.hit = { side, kind: "buff", t: Date.now() };
      break;
    }
    case "debuff": {
      const st = move.stat ?? "atk";
      tb[st] = clamp(tb[st] * (move.amount ?? 0.7), 0.4, 2.4);
      push(s, `${actor.name} uses ${move.name}! ${target.name}'s ${st.toUpperCase()} down.`);
      s.hit = { side: target === s.enemy ? "enemy" : "player", kind: "buff", t: Date.now() };
      break;
    }
    case "guard": {
      ab.guard = 1;
      ab.def = clamp(ab.def * 1.15, 0.4, 2.4);
      push(s, `${actor.name} braces behind a guard!`);
      s.hit = { side, kind: "buff", t: Date.now() };
      break;
    }
  }
}

export function checkFaint(s: BattleState): boolean {
  if (s.enemy.hp <= 0) {
    push(s, `${s.enemy.name} collapsed!`);
    const amount = Math.floor((s.enemy.level * 11 + 14) * (s.isBoss ? 3.2 : 1));
    s.xpGained = amount;
    push(s, `+${amount} XP to ${s.player.name}.`);
    for (const line of grantXp(s.player, amount)) push(s, line);
    s.phase = "won";
    return true;
  }
  if (s.player.hp <= 0) {
    push(s, `${s.player.name} fainted!`);
    s.phase = "lost";
    return true;
  }
  return false;
}

/** Odds climb steeply as HP falls. */
export function captureOdds(enemy: Creature, isBoss: boolean): number {
  const ratio = clamp(enemy.hp / maxHpOf(enemy), 0, 1);
  const base = isBoss ? enemy.captureRate * 0.35 : enemy.captureRate;
  const c = base * (1.45 - ratio * 1.2);
  return clamp(c, 0.02, 0.95);
}

export function tryCapture(s: BattleState, rng: Rng): boolean {
  s.attempts++;
  s.orbs = Math.max(0, s.orbs - 1);
  const odds = captureOdds(s.enemy, s.isBoss);
  s.captureOdds = odds;
  const ok = rng.next() < odds;
  if (ok) {
    push(s, `The orb locks on... ${s.enemy.name} is captured!`);
    s.enemy.hp = Math.max(1, Math.floor(maxHpOf(s.enemy) * 0.25));
    s.phase = "captured";
    s.hit = { side: "enemy", kind: "capture", t: Date.now() };
  } else {
    push(s, `The orb rattles... ${s.enemy.name} breaks free! (${Math.round(odds * 100)}%)`);
    s.hit = { side: "enemy", kind: "capture", t: Date.now() };
  }
  return ok;
}

export function tryFlee(s: BattleState, rng: Rng): boolean {
  if (s.isBoss) {
    push(s, "The guardian blocks every exit!");
    return false;
  }
  const chance = clamp(0.72 - (s.enemy.level - s.player.level) * 0.04, 0.25, 0.95);
  if (rng.next() < chance) {
    push(s, "You slip away into the grass.");
    s.phase = "fled";
    return true;
  }
  push(s, "You can't escape!");
  return false;
}

/** Wild creatures favour damage, and heal when hurt. */
export function pickEnemyMove(s: BattleState, rng: Rng): number {
  const moves = s.enemy.moves;
  const hpRatio = s.enemy.hp / maxHpOf(s.enemy);
  if (hpRatio < 0.35) {
    const heal = moves.findIndex((m) => m.kind === "heal");
    if (heal >= 0 && rng.chance(0.7)) return heal;
  }
  const attacks = moves.map((m, i) => ({ m, i })).filter((x) => x.m.kind === "attack" || x.m.kind === "drain");
  if (!attacks.length) return rng.int(moves.length);
  const best = attacks
    .map((x) => ({ ...x, score: x.m.power * typeMult(x.m.element, s.player.element) * (0.7 + rng.next()) }))
    .sort((a, b) => b.score - a.score);
  return rng.chance(0.75) ? best[0].i : rng.pick(attacks).i;
}

export function buffSummary(b: Buffs): string {
  const parts: string[] = [];
  if (b.atk > 1.05) parts.push("ATK↑");
  if (b.atk < 0.95) parts.push("ATK↓");
  if (b.def > 1.05) parts.push("DEF↑");
  if (b.def < 0.95) parts.push("DEF↓");
  if (b.spd > 1.05) parts.push("SPD↑");
  if (b.spd < 0.95) parts.push("SPD↓");
  if (b.guard) parts.push("GUARD");
  return parts.join(" ");
}

export function makeBattleRng(seed: string): Rng {
  return makeRng(seed);
}
