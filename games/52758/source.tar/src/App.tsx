import { useCallback, useEffect, useRef, useState } from "react";
import Handheld from "./components/Handheld";
import MapView, { MiniMap, type Anim, type Dir } from "./components/MapView";
import BattleView, { type BattleResult } from "./components/BattleView";
import TeamView from "./components/TeamView";
import { BadgeScreen, CreatureStrip, TitleScreen, WipeScreen } from "./components/Screens";
import { generateCreature, maxHpAt, randomSeed } from "./game/creatures";
import { makeRng, seedLabel } from "./game/rng";
import {
  T,
  generateWorld,
  isSolid,
  makeBadge,
  nextWorldSeed,
  rollEncounter,
  tileAt,
  type World,
} from "./game/world";
import type { Badge, Creature } from "./game/types";

type Screen = "title" | "field" | "battle" | "team" | "badge" | "wipe";

const SAVE_KEY = "seedling.save.v1";

interface Encounter {
  enemy: Creature;
  isBoss: boolean;
}

export default function App() {
  const [screen, setScreen] = useState<Screen>("title");
  const [seed, setSeed] = useState(() => randomSeed());
  const [worldIndex, setWorldIndex] = useState(0);
  const [world, setWorld] = useState<World>(() => generateWorld(seed, 0));
  const [pos, setPos] = useState({ x: 4, y: 4 });
  const [team, setTeam] = useState<Creature[]>([]);
  const [orbs, setOrbs] = useState(6);
  const [badges, setBadges] = useState<Badge[]>([]);
  const [activeUid, setActiveUid] = useState<string | null>(null);
  const [encounter, setEncounter] = useState<Encounter | null>(null);
  const [battleKey, setBattleKey] = useState(0);
  const [toast, setToast] = useState<string | null>(null);
  const [hasSave, setHasSave] = useState(false);

  const animRef = useRef<Anim>({
    fx: 4,
    fy: 4,
    tx: 4,
    ty: 4,
    dir: "down",
    moving: false,
    walkT: 0,
    flash: 0,
    shake: 0,
  });
  const encCount = useRef(0);
  const stepsRef = useRef(0);
  const rollRef = useRef(4);
  const busyRef = useRef(false);

  /* ---------------- helpers ---------------- */

  const resetAnim = (p: { x: number; y: number }) => {
    const a = animRef.current;
    a.fx = p.x;
    a.fy = p.y;
    a.tx = p.x;
    a.ty = p.y;
    a.moving = false;
    a.flash = 0;
    a.shake = 0;
  };

  const rollEnemy = useCallback(() => {
    const rng = makeRng(`${world.seed}::wild${encCount.current}`);
    encCount.current += 1;
    return rollEncounter(world, rng);
  }, [world]);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(SAVE_KEY);
      if (raw && JSON.parse(raw)?.v === 1) setHasSave(true);
    } catch {
      /* ignore */
    }
  }, []);

  useEffect(() => {
    if (screen === "title") return;
    try {
      localStorage.setItem(
        SAVE_KEY,
        JSON.stringify({ v: 1, seed, worldIndex, world, pos, team, orbs, badges, activeUid }),
      );
    } catch {
      /* ignore */
    }
  }, [screen, seed, worldIndex, world, pos, team, orbs, badges, activeUid]);

  useEffect(() => {
    if (!toast) return;
    const id = window.setTimeout(() => setToast(null), 2800);
    return () => window.clearTimeout(id);
  }, [toast]);

  /* ---------------- flow ---------------- */

  const startGame = (s: string) => {
    const w = generateWorld(s, 0);
    const starters = [0, 1, 2].map((i) => generateCreature(`${s}::starter${i}`, { level: 3 }));
    setSeed(s);
    setWorldIndex(0);
    setWorld(w);
    setTeam(starters);
    setActiveUid(starters[0].uid);
    setOrbs(6);
    setBadges([]);
    setEncounter(null);
    setPos(w.spawn);
    resetAnim(w.spawn);
    stepsRef.current = 0;
    encCount.current = 0;
    setScreen("field");
    setToast("Step into tall grass to roll encounters. Find the guardian.");
  };

  const loadSave = () => {
    try {
      const raw = localStorage.getItem(SAVE_KEY);
      if (!raw) return;
      const d = JSON.parse(raw);
      if (!d?.world) return;
      setSeed(d.seed);
      setWorldIndex(d.worldIndex ?? 0);
      setWorld(d.world);
      setPos(d.pos);
      setTeam(d.team ?? []);
      setOrbs(d.orbs ?? 6);
      setBadges(d.badges ?? []);
      setActiveUid(d.activeUid ?? null);
      resetAnim(d.pos);
      setScreen("field");
    } catch {
      /* ignore */
    }
  };

  const triggerEncounter = useCallback(
    (boss: boolean) => {
      if (busyRef.current) return;
      busyRef.current = true;
      animRef.current.flash = 1;
      setToast(null);
      window.setTimeout(() => {
        const enemy = boss
          ? generateCreature(world.bossSeed, {
              level: world.encounterLevel + 7,
              boss: true,
              name: world.bossName,
            })
          : rollEnemy();
        busyRef.current = false;
        setEncounter({ enemy, isBoss: boss });
        setBattleKey((k) => k + 1);
        setScreen("battle");
      }, 560);
    },
    [rollEnemy, world],
  );

  const onEnterTile = useCallback(
    (x: number, y: number) => {
      const t = tileAt(world, x, y);
      if (t === T.TALL) {
        stepsRef.current += 1;
        if (stepsRef.current >= rollRef.current) {
          stepsRef.current = 0;
          rollRef.current = 4 + Math.floor(Math.random() * 5);
          triggerEncounter(false);
        }
      } else if (t === T.HEAL) {
        setTeam((ts) => ts.map((c) => ({ ...c, hp: maxHpAt(c.base.hp, c.level) })));
        setToast("The spring restores your team.");
      } else if (t === T.SHRINE) {
        setToast("Fusion shrine hums — open TEAM (T) to blend two creatures.");
      } else if (t === T.BOSS) {
        triggerEncounter(true);
      }
    },
    [triggerEncounter, world],
  );

  const step = useCallback(
    (dx: number, dy: number) => {
      if (screen !== "field" || busyRef.current) return;
      const a = animRef.current;
      if (a.moving) return;
      a.dir = (dx === 1 ? "right" : dx === -1 ? "left" : dy === 1 ? "down" : "up") as Dir;
      const nx = pos.x + dx;
      const ny = pos.y + dy;
      if (isSolid(tileAt(world, nx, ny))) return;
      a.tx = nx;
      a.ty = ny;
      a.moving = true;
      setPos({ x: nx, y: ny });
      onEnterTile(nx, ny);
    },
    [screen, pos, world, onEnterTile],
  );

  const onBattleEnd = useCallback(
    (result: BattleResult, p: { player: Creature; enemy: Creature; orbs: number; spent: Creature[] }) => {
      const sync = (list: Creature[]) =>
        list.map((c) => {
          const s = p.spent.find((x) => x.uid === c.uid);
          return s ? { ...s } : c;
        });
      const isBoss = encounter?.isBoss ?? false;
      setOrbs(p.orbs);
      setActiveUid(p.player.uid);

      if (result === "win") {
        setTeam(sync(team));
        setOrbs(p.orbs + (isBoss ? 4 : 1));
        if (isBoss) {
          setBadges((b) => [...b, makeBadge(world)]);
          setEncounter(null);
          setScreen("badge");
        } else {
          setEncounter(null);
          setScreen("field");
          setToast(`${p.player.name} wins.`);
        }
        return;
      }
      if (result === "captured") {
        const t = sync(team);
        if (t.length < 6) {
          setTeam([...t, p.enemy]);
          setToast(`${p.enemy.name} joined your team!`);
        } else {
          setTeam(t);
          setToast("Team full — the capture was released.");
        }
        setEncounter(null);
        setScreen("field");
        return;
      }
      if (result === "fled") {
        setTeam(sync(team));
        setEncounter(null);
        setScreen("field");
        return;
      }
      const t = sync(team);
      setTeam(t);
      const nextAlive = t.find((c) => c.hp > 0);
      if (nextAlive) {
        setActiveUid(nextAlive.uid);
        setEncounter({ enemy: p.enemy, isBoss });
        setBattleKey((k) => k + 1);
      } else {
        setEncounter(null);
        setScreen("wipe");
      }
    },
    [encounter, team, world],
  );

  const travel = useCallback(() => {
    const badge = makeBadge(world);
    const nextSeed = nextWorldSeed(badge);
    const wi = worldIndex + 1;
    const w = generateWorld(nextSeed, wi);
    setSeed(nextSeed);
    setWorldIndex(wi);
    setWorld(w);
    setPos(w.spawn);
    resetAnim(w.spawn);
    setOrbs((o) => o + 4);
    setTeam((ts) => ts.map((c) => ({ ...c, hp: maxHpAt(c.base.hp, c.level), badges: c.badges + 1 })));
    stepsRef.current = 0;
    encCount.current = 0;
    setScreen("field");
    setToast(`${w.name} — world seed ${seedLabel(nextSeed)}`);
  }, [world, worldIndex]);

  const recover = useCallback(() => {
    setTeam((ts) => ts.map((c) => ({ ...c, hp: maxHpAt(c.base.hp, c.level) })));
    setPos(world.spawn);
    resetAnim(world.spawn);
    setEncounter(null);
    setScreen("field");
    setToast("Recovered at the spawn spring.");
  }, [world]);

  const rest = useCallback(() => {
    setTeam((ts) => ts.map((c) => ({ ...c, hp: maxHpAt(c.base.hp, c.level) })));
    setToast("Team restored.");
  }, []);

  const doFuse = useCallback((a: Creature, b: Creature, hybrid: Creature) => {
    setTeam((ts) => [...ts.filter((c) => c.uid !== a.uid && c.uid !== b.uid), hybrid]);
    setActiveUid((u) => (u === a.uid || u === b.uid ? hybrid.uid : u));
    setToast(`Glitch hybrid formed: ${hybrid.name}`);
  }, []);

  /* ---------------- input ---------------- */

  const press = useCallback(
    (k: string) => {
      if (screen === "field") {
        if (k === "arrowup" || k === "w") step(0, -1);
        else if (k === "arrowdown" || k === "s") step(0, 1);
        else if (k === "arrowleft" || k === "a") step(-1, 0);
        else if (k === "arrowright" || k === "d") step(1, 0);
        else if (k === "t") setScreen("team");
        return;
      }
      if (screen === "team") {
        if (k === "x" || k === "escape" || k === "t" || k === "z") setScreen("field");
        return;
      }
      if (screen === "badge" && (k === "z" || k === "enter" || k === " ")) travel();
      if (screen === "wipe" && (k === "z" || k === "enter" || k === " ")) recover();
    },
    [screen, step, travel, recover],
  );

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (screen === "title") return;
      const k = e.key.toLowerCase();
      if (["arrowup", "arrowdown", "arrowleft", "arrowright", " "].includes(k)) e.preventDefault();
      press(k);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [screen, press]);

  /* ---------------- render ---------------- */

  const active =
    team.find((c) => c.uid === activeUid && c.hp > 0) ?? team.find((c) => c.hp > 0) ?? team[0] ?? null;
  const tile = tileAt(world, pos.x, pos.y);
  const canRest = tile === T.HEAL || (pos.x === world.spawn.x && pos.y === world.spawn.y);
  const badgeBoss =
    screen === "badge"
      ? generateCreature(world.bossSeed, { level: world.encounterLevel + 7, boss: true, name: world.bossName })
      : null;

  const status =
    screen === "battle"
      ? "BATTLE · SPD-ordered turns"
      : screen === "team"
        ? "TEAM · fusion bench"
        : `${world.name} · ${pos.x},${pos.y} · SIGILS ${badges.length}`;

  return (
    <Handheld onPress={press} status={status} seedText={seedLabel(seed)}>
      {screen === "title" && (
        <TitleScreen
          seed={seed}
          setSeed={setSeed}
          onStart={() => startGame(seed)}
          onContinue={loadSave}
          hasSave={hasSave}
        />
      )}

      {(screen === "field" || screen === "team") && (
        <div className="absolute inset-0">
          <MapView world={world} anim={animRef} paused={screen !== "field"} />
          {screen === "field" && (
            <div className="pointer-events-none absolute inset-0">
              <div className="absolute left-1 top-1 border border-ink-500 bg-ink-900/85 px-1 py-[2px]">
                <CreatureStrip team={team} activeUid={activeUid} />
              </div>
              <div className="absolute right-1 top-1 border border-ink-500 bg-ink-900/85 px-1 font-term text-[10px] leading-[11px] text-ink-100">
                ORB {orbs}
              </div>
              <div className="absolute bottom-1 right-1 border border-ink-500 bg-ink-900/70 p-[1px] opacity-80">
                <MiniMap world={world} pos={pos} />
              </div>
              {toast && (
                <div className="pop absolute bottom-1 left-1 max-w-[150px] border border-ink-400 bg-ink-900/92 px-1 py-[2px] font-term text-[12px] leading-[12px] text-bone">
                  {toast}
                </div>
              )}
            </div>
          )}
          {screen === "team" && (
            <TeamView
              team={team}
              orbs={orbs}
              badges={badges}
              canRest={canRest}
              salt={`${world.seed}:${team.length}:${badges.length}`}
              onFuse={doFuse}
              onRest={rest}
              onClose={() => setScreen("field")}
            />
          )}
        </div>
      )}

      {screen === "battle" && encounter && active && (
        <BattleView
          key={battleKey}
          player={active}
          enemy={encounter.enemy}
          isBoss={encounter.isBoss}
          orbs={orbs}
          team={team}
          onEnd={onBattleEnd}
        />
      )}

      {screen === "badge" && badgeBoss && (
        <BadgeScreen
          badge={makeBadge(world)}
          boss={badgeBoss}
          nextSeed={nextWorldSeed(makeBadge(world))}
          onNext={travel}
        />
      )}

      {screen === "wipe" && <WipeScreen team={team} onRecover={recover} />}
    </Handheld>
  );
}
