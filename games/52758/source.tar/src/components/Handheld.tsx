import { useEffect, useLayoutEffect, useRef, useState, type ReactNode } from "react";
import { cn } from "../utils/cn";

export const STAGE_W = 240;
export const STAGE_H = 176;

interface Props {
  children: ReactNode;
  onPress: (key: string) => void;
  status: string;
  seedText: string;
}

export default function Handheld({ children, onPress, status, seedText }: Props) {
  const wrapRef = useRef<HTMLDivElement | null>(null);
  const [scale, setScale] = useState(1);

  useLayoutEffect(() => {
    const el = wrapRef.current;
    if (!el) return;
    const measure = () => {
      const w = el.clientWidth;
      const h = window.innerHeight;
      const byW = w / STAGE_W;
      const byH = (h - 250) / STAGE_H;
      setScale(Math.max(0.7, Math.min(2.6, Math.min(byW, byH))));
    };
    measure();
    const ro = new ResizeObserver(measure);
    ro.observe(el);
    window.addEventListener("resize", measure);
    return () => {
      ro.disconnect();
      window.removeEventListener("resize", measure);
    };
  }, []);

  useEffect(() => {
    const stop = (e: KeyboardEvent) => {
      if (e.key === " " && (e.target as HTMLElement)?.tagName === "BUTTON") e.preventDefault();
    };
    window.addEventListener("keydown", stop);
    return () => window.removeEventListener("keydown", stop);
  }, []);

  const pad = (label: string, key: string, cls: string, aria: string) => (
    <button
      type="button"
      aria-label={aria}
      onClick={(e) => {
        onPress(key);
        e.currentTarget.blur();
      }}
      className={cn(
        "flex items-center justify-center border border-ink-600 bg-ink-700 font-pixel text-[8px] text-ink-100",
        "active:bg-ink-500 hover:bg-ink-600",
        cls,
      )}
    >
      {label}
    </button>
  );

  return (
    <div className="flex min-h-screen flex-col items-center justify-center gap-3 px-3 py-4">
      <div ref={wrapRef} className="w-full max-w-[540px]">
        <div className="rounded-[26px] border border-ink-500 bg-ink-800 p-3 shadow-[0_20px_50px_rgba(0,0,0,0.7)]">
          {/* device top strip */}
          <div className="mb-2 flex items-center justify-between px-1">
            <span className="font-pixel text-[7px] tracking-widest text-ink-200">SEEDLING</span>
            <span className="flex items-center gap-2">
              <span className="font-term text-[11px] text-ink-300">{seedText}</span>
              <span className="flex items-center gap-1">
                <span className="h-[6px] w-[6px] rounded-full bg-[#3f8f86] shadow-[0_0_6px_#3f8f86]" />
                <span className="h-[6px] w-[6px] rounded-full bg-[#b03a4a] shadow-[0_0_6px_#b03a4a]" />
              </span>
            </span>
          </div>

          {/* screen */}
          <div
            className="relative mx-auto overflow-hidden rounded-[5px] border-2 border-ink-600 bg-black"
            style={{ width: STAGE_W * scale, height: STAGE_H * scale }}
          >
            <div className="scanlines glass vignette absolute inset-0">
              <div
                className="relative overflow-hidden"
                style={{ width: STAGE_W, height: STAGE_H, transform: `scale(${scale})`, transformOrigin: "top left" }}
              >
                {children}
              </div>
            </div>
          </div>

          {/* status line */}
          <div className="mt-2 flex items-center justify-between px-1">
            <span className="truncate font-term text-[12px] text-ink-100">{status}</span>
            <span className="font-pixel text-[6px] text-ink-300">DOT MATRIX</span>
          </div>

          {/* controls */}
          <div className="mt-2 flex items-end justify-between px-1">
            <div className="grid grid-cols-3 grid-rows-3 gap-[3px]">
              <span />
              {pad("▲", "arrowup", "h-7 w-7", "move up")}
              <span />
              {pad("◀", "arrowleft", "h-7 w-7", "move left")}
              <span className="h-7 w-7" />
              {pad("▶", "arrowright", "h-7 w-7", "move right")}
              <span />
              {pad("▼", "arrowdown", "h-7 w-7", "move down")}
              <span />
            </div>
            <div className="flex items-end gap-2">
              <div className="flex flex-col items-center gap-1">
                <button
                  type="button"
                  aria-label="team"
                  onClick={(e) => {
                    onPress("t");
                    e.currentTarget.blur();
                  }}
                  className="h-7 w-7 rounded-full border border-ink-600 bg-ink-700 font-pixel text-[7px] text-ink-100 hover:bg-ink-600 active:bg-ink-500"
                >
                  T
                </button>
                <span className="font-pixel text-[6px] text-ink-300">TEAM</span>
              </div>
              <div className="flex items-end gap-2">
                <button
                  type="button"
                  aria-label="cancel"
                  onClick={(e) => {
                    onPress("x");
                    e.currentTarget.blur();
                  }}
                  className="h-9 w-9 rounded-full border border-ink-500 bg-ink-600 font-pixel text-[9px] text-bone hover:bg-ink-500 active:bg-ink-400"
                >
                  X
                </button>
                <button
                  type="button"
                  aria-label="confirm"
                  onClick={(e) => {
                    onPress("z");
                    e.currentTarget.blur();
                  }}
                  className="h-11 w-11 rounded-full border border-ink-400 bg-ink-500 font-pixel text-[9px] text-bone hover:bg-ink-400 active:bg-ink-300"
                >
                  Z
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <p className="max-w-[540px] text-center font-term text-[13px] leading-tight text-ink-300">
        arrows/WASD move · Z confirm · X back · T team · tall grass rolls encounters · boss badges seed the next world
      </p>
    </div>
  );
}
