import { useMemo, useState } from "react";
import PixelSprite from "./PixelSprite";
import { Bar, Btn, Label, Panel } from "./Ui";
import { ELEMENT_COLOR, fuseCreatures, maxHpAt, statsOf } from "../game/creatures";
import type { Badge, Creature } from "../game/types";

interface Props {
  team: Creature[];
  orbs: number;
  badges: Badge[];
  canRest: boolean;
  salt: string;
  onFuse: (a: Creature, b: Creature, hybrid: Creature) => void;
  onRest: () => void;
  onClose: () => void;
}

export default function TeamView({ team, orbs, badges, canRest, salt, onFuse, onRest, onClose }: Props) {
  const [sel, setSel] = useState<string[]>([]);
  const [inspect, setInspect] = useState(0);
  const [mode, setMode] = useState<"list" | "fuse">("list");

  const toggle = (uid: string) => {
    setSel((s) => (s.includes(uid) ? s.filter((x) => x !== uid) : s.length >= 2 ? [s[1], uid] : [...s, uid]));
  };

  const a = team.find((c) => c.uid === sel[0]);
  const b = team.find((c) => c.uid === sel[1]);
  const hybrid = useMemo(() => (a && b && a !== b ? fuseCreatures(a, b, salt) : null), [a, b, salt]);

  const shown = hybrid ?? team[inspect] ?? team[0];
  const st = shown ? statsOf(shown) : null;

  return (
    <div className="absolute inset-0 flex flex-col bg-ink-900">
      {/* header */}
      <div className="flex items-center gap-1 px-1 pt-[2px]">
        <span className="font-pixel text-[7px] text-bone">TEAM</span>
        <span className="font-term text-[11px] text-ink-200">
          {team.length}/6
        </span>
        <span className="ml-auto font-term text-[11px] text-[#7de0d0]">ORB {orbs}</span>
        <span className="flex items-center gap-[2px]">
          {badges.map((bd) => (
            <span
              key={bd.seed}
              title={bd.name}
              className="inline-block h-[7px] w-[7px] border border-ink-400"
              style={{ background: ELEMENT_COLOR[bd.element] }}
            />
          ))}
        </span>
      </div>

      <div className="mt-[2px] flex gap-1 px-1" style={{ height: 122 }}>
        {/* roster */}
        <div className="flex w-[104px] shrink-0 flex-col gap-[2px]">
          {team.map((c, i) => {
            const picked = sel.includes(c.uid);
            const isShown = shown?.uid === c.uid;
            return (
              <button
                key={c.uid}
                type="button"
                onClick={() => {
                  setInspect(i);
                  if (mode === "fuse") toggle(c.uid);
                }}
                className={
                  "flex items-center gap-1 border px-[2px] py-[1px] text-left " +
                  (picked
                    ? "border-[#e08ab0] bg-[#1d1017]"
                    : isShown
                      ? "border-ink-300 bg-ink-700"
                      : "border-ink-500 bg-ink-800 hover:bg-ink-700") +
                  (c.hp <= 0 ? " opacity-40" : "")
                }
              >
                <PixelSprite grid={c.sprite} palette={c.palette} scale={1} alt={c.name} />
                <span className="min-w-0 flex-1">
                  <span className="flex items-baseline justify-between">
                    <span className="truncate font-term text-[11px] leading-[11px] text-bone">{c.name}</span>
                    <span className="font-term text-[10px] leading-[10px] text-ink-200">
                      {c.fused ? "F" : ""}
                      {c.level}
                    </span>
                  </span>
                  <Bar
                    value={c.hp}
                    max={maxHpAt(c.base.hp, c.level)}
                    color={c.hp <= 0 ? "#4a4a55" : ELEMENT_COLOR[c.element]}
                    height={3}
                  />
                </span>
              </button>
            );
          })}
          {!team.length && (
            <div className="font-term text-[11px] text-ink-200">No creatures. Step in tall grass.</div>
          )}
        </div>

        {/* detail */}
        <Panel tone="dark" className="min-w-0 flex-1 px-1 py-[2px]">
          {shown && st ? (
            <div>
              <div className="flex items-start gap-1">
                <div className={hybrid ? "glitch shrink-0" : "shrink-0"}>
                  <PixelSprite grid={shown.sprite} palette={shown.palette} scale={2} alt={shown.name} />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="truncate font-pixel text-[7px]" style={{ color: ELEMENT_COLOR[shown.element] }}>
                    {shown.name}
                  </div>
                  <div className="font-term text-[10px] leading-[11px] text-ink-200">
                    {shown.element} · {shown.archetype}
                    {shown.fused ? " · HYBRID" : ""}
                  </div>
                  <div className="font-term text-[10px] leading-[11px] text-ink-300">
                    LV{shown.level} · HP {shown.hp}/{st.hp}
                  </div>
                  <div className="mt-[1px] grid grid-cols-3 gap-x-1 font-term text-[10px] leading-[11px] text-ink-100">
                    <span>ATK {st.atk}</span>
                    <span>DEF {st.def}</span>
                    <span>SPD {st.spd}</span>
                  </div>
                </div>
              </div>
              <div className="mt-[2px] border-t border-ink-600 pt-[2px]">
                {shown.moves.map((m, i) => (
                  <div key={m.id + i} className="flex justify-between font-term text-[10px] leading-[11px]">
                    <span style={{ color: ELEMENT_COLOR[m.element] }}>{m.name}</span>
                    <span className="text-ink-300">{m.power ? m.power : m.kind.toUpperCase()}</span>
                  </div>
                ))}
              </div>
              {shown.origin && (
                <div className="mt-[1px] truncate font-term text-[10px] text-ink-300">from {shown.origin}</div>
              )}
            </div>
          ) : (
            <div className="font-term text-[11px] text-ink-200">—</div>
          )}
        </Panel>
      </div>

      {/* footer */}
      <div className="mt-auto flex items-center gap-1 px-1 pb-1">
        <Btn tone="accent" active={mode === "fuse"} onClick={() => setMode(mode === "fuse" ? "list" : "fuse")}>
          {mode === "fuse" ? "FUSE ON" : "FUSE"}
        </Btn>
        {mode === "fuse" ? (
          <Btn
            tone="accent"
            disabled={!hybrid}
            onClick={() => {
              if (!a || !b || !hybrid) return;
              onFuse(a, b, hybrid);
              setSel([]);
              setMode("list");
            }}
            className="flex-1"
          >
            {hybrid ? `FUSE → ${hybrid.name}` : `PICK 2 (${sel.length}/2)`}
          </Btn>
        ) : (
          <Btn onClick={onRest} disabled={!canRest} className="flex-1">
            REST
          </Btn>
        )}
        <Btn onClick={onClose}>CLOSE</Btn>
      </div>

      {mode === "fuse" && (
        <div className="px-1 pb-[2px]">
          <Label>
            {hybrid
              ? "hybrid consumes both parents · stats +12% · capture rate drops"
              : "fusion mode: tap two creatures to blend them into a glitch hybrid"}
          </Label>
        </div>
      )}
    </div>
  );
}
