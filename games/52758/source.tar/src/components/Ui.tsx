import type { ReactNode } from "react";
import { cn } from "../utils/cn";

export function Panel({
  children,
  className,
  tone = "default",
}: {
  children: ReactNode;
  className?: string;
  tone?: "default" | "dark" | "glow";
}) {
  return (
    <div
      className={cn(
        "border",
        tone === "default" && "border-ink-400 bg-ink-800",
        tone === "dark" && "border-ink-500 bg-ink-900",
        tone === "glow" && "border-ink-300 bg-ink-700",
        className,
      )}
    >
      {children}
    </div>
  );
}

export function Label({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <span className={cn("font-pixel text-[6px] tracking-widest text-ink-200 uppercase", className)}>{children}</span>
  );
}

export function Bar({
  value,
  max,
  color = "#57b06a",
  height = 4,
  className,
}: {
  value: number;
  max: number;
  color?: string;
  height?: number;
  className?: string;
}) {
  const pct = Math.max(0, Math.min(100, (value / Math.max(1, max)) * 100));
  return (
    <div
      className={cn("w-full border border-ink-400 bg-ink-900", className)}
      style={{ height }}
      role="progressbar"
      aria-valuenow={Math.round(value)}
      aria-valuemin={0}
      aria-valuemax={Math.round(max)}
    >
      <div
        className="h-full transition-[width] duration-300 ease-out"
        style={{ width: `${pct}%`, background: color }}
      />
    </div>
  );
}

export function Btn({
  children,
  onClick,
  active = false,
  disabled = false,
  className,
  tone = "default",
  title,
  onMouseEnter,
}: {
  children: ReactNode;
  onClick?: () => void;
  active?: boolean;
  disabled?: boolean;
  className?: string;
  tone?: "default" | "danger" | "accent";
  title?: string;
  onMouseEnter?: () => void;
}) {
  return (
    <button
      type="button"
      title={title}
      onClick={onClick}
      onMouseEnter={onMouseEnter}
      disabled={disabled}
      className={cn(
        "border px-1.5 py-[3px] font-term text-[12px] leading-none tracking-wide transition-colors select-none",
        active
          ? "border-bone bg-bone text-ink-900"
          : tone === "danger"
            ? "border-[#5c2530] bg-[#1a0d11] text-[#e08a94] hover:bg-[#2a1218]"
            : tone === "accent"
              ? "border-ink-300 bg-ink-600 text-bone hover:bg-ink-500"
              : "border-ink-400 bg-ink-700 text-bone hover:bg-ink-600",
        disabled && "cursor-not-allowed opacity-35 hover:bg-ink-700",
        className,
      )}
    >
      {children}
    </button>
  );
}

export function Divider({ className }: { className?: string }) {
  return <div className={cn("h-px w-full bg-ink-500", className)} />;
}
