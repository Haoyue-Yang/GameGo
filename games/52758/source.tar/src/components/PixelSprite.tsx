import { useEffect, useRef } from "react";
import { drawGrid } from "../render/pixel";

interface Props {
  grid: number[];
  palette: string[];
  scale?: number;
  flip?: boolean;
  className?: string;
  alt?: string;
}

/** Renders a 16x16 palette-indexed grid as crisp nearest-neighbour pixels. */
export default function PixelSprite({ grid, palette, scale = 3, flip = false, className = "", alt }: Props) {
  const ref = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const c = ref.current;
    if (!c) return;
    const ctx = c.getContext("2d");
    if (!ctx) return;
    ctx.imageSmoothingEnabled = false;
    ctx.clearRect(0, 0, c.width, c.height);
    drawGrid(ctx, grid, palette, 0, 0, scale, flip);
  }, [grid, palette, scale, flip]);

  return (
    <canvas
      ref={ref}
      width={16 * scale}
      height={16 * scale}
      className={"pixelated " + className}
      role="img"
      aria-label={alt ?? "creature sprite"}
    />
  );
}
