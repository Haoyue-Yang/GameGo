import { useMemo } from "react";
import PixelSprite from "./PixelSprite";
import { Btn, Label, Panel } from "./Ui";
import { ELEMENT_COLOR, generateCreature, maxHpAt, statsOf } from "../game/creatures";
import { seedLabel } from "../game/rng";
import type { Badge, Creature } from "../game/types";

/* ------------------------------------------------------------------ */

export function TitleScreen({
  seed,
  setSeed,
  onStart,
  onContinue,
  hasSave,
}: {
  seed: string;
  setSeed: (s: string) => void;
  onStart: () => void;
  onContinue: () => void;
  hasSave: boolean;
}) {
  const preview = useMemo(
    () => [0, 1, 2].map((i) => generateCreature(`${seed}::preview${i}`, { level: 3 + i * 2 })),
    [seed],
  );

  return (
    <div className="absolute inset-0 flex flex-col bg-ink-900 px-2 py-2">
      <div className="text-center">
        <h1 className="font-pixel text-[15px] leading-none text-bone">SEEDLING</h1>
        <p className="mt-1 font-term text-[12px] leading-none text-ink-200">
          every creature rolled from one seed
        </p>
      </div>

      <div className="mt-2 flex justify-center gap-1">
        {preview.map((c) => (
          <div key={c.uid} className="flex flex-col items-center">
            <div className="floaty">
              <PixelSprite grid={c.sprite} palette={c.palette} scale={2} alt={c.name} />
            </div>
            <span className="font-term text-[10px] leading-[11px]" style={{ color: ELEMENT_COLOR[c.element] }}>
              {c.name}
            </span>
          </div>
        ))}
      </div>

      <Panel tone="dark" className="mt-2 px-2 py-1">
        <Label>world seed</Label>
        <input
          value={seed}
          onChange={(e) => setSeed(e.target.value.slice(0, 24))}
          onKeyDown={(e) => {
            if (e.key === "Enter") onStart();
          }}
          className="mt-[2px] w-full border border-ink-400 bg-ink-900 px-1 py-[2px] font-pixel text-[8px] text-bone outline-none focus:border-ink-200"
          aria-label="world seed"
        />
        <div className="mt-[2px] flex justify-between font-term text-[10px] text-ink-300">
          <span>hash {seedLabel(seed)}</span>
          <span>3 starters · 6 slots</span>
        </div>
      </Panel>

      <div className="mt-auto flex gap-1">
        <Btn tone="accent" className="flex-1" onClick={onStart}>
          START
        </Btn>
        {hasSave && <Btn className="flex-1" onClick={onContinue}>
          CONTINUE
        </Btn>}
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */

export function BadgeScreen({
  badge,
  boss,
  nextSeed,
  onNext,
}: {
  badge: Badge;
  boss: Creature;
  nextSeed: string;
  onNext: () => void;
}) {
  return (
    <div className="absolute inset-0 flex flex-col items-center justify-center bg-ink-900 px-3">
      <Label>guardian defeated</Label>
      <h2 className="mt-1 font-pixel text-[11px] text-bone">{badge.name}</h2>
      <div className="mt-2 flex items-center gap-3">
        <div className="glitch">
          <PixelSprite grid={boss.sprite} palette={boss.palette} scale={3} alt={boss.name} />
        </div>
        <div className="flex h-[42px] w-[42px] items-center justify-center border-2" style={{ borderColor: ELEMENT_COLOR[badge.element] }}>
          <span className="font-pixel text-[13px]" style={{ color: ELEMENT_COLOR[badge.element] }}>
            {badge.element[0]}
          </span>
        </div>
      </div>
      <p className="mt-2 max-w-[210px] text-center font-term text-[12px] leading-[13px] text-ink-100">
        {boss.name} yields a sigil. Its seed becomes the soil of the next world.
      </p>
      <div className="mt-1 font-term text-[11px] text-ink-300">
        next world seed <span className="text-[#7de0d0]">{seedLabel(nextSeed)}</span>
      </div>
      <Btn tone="accent" className="mt-2 blink" onClick={onNext}>
        PRESS Z — TRAVEL
      </Btn>
    </div>
  );
}

/* ------------------------------------------------------------------ */

export function WipeScreen({ team, onRecover }: { team: Creature[]; onRecover: () => void }) {
  return (
    <div className="absolute inset-0 flex flex-col items-center justify-center bg-ink-900 px-3">
      <h2 className="font-pixel text-[12px] text-[#e06a72]">SYSTEM RESET</h2>
      <p className="mt-2 text-center font-term text-[12px] leading-[13px] text-ink-100">
        Your whole team collapsed. The spawn spring pulls you back — HP restored, world intact.
      </p>
      <div className="mt-3 flex gap-1">
        {team.slice(0, 6).map((c) => (
          <div key={c.uid} className="flex flex-col items-center opacity-60">
            <PixelSprite grid={c.sprite} palette={c.palette} scale={2} alt={c.name} />
            <span className="font-term text-[10px] text-ink-200">
              {c.name} {c.hp}/{maxHpAt(c.base.hp, c.level)}
            </span>
          </div>
        ))}
      </div>
      <Btn tone="danger" className="mt-3 blink" onClick={onRecover}>
        PRESS Z — RECOVER AT SPAWN
      </Btn>
    </div>
  );
}

/* ------------------------------------------------------------------ */

export function CreatureStrip({ team, activeUid }: { team: Creature[]; activeUid?: string | null }) {
  return (
    <div className="flex items-center gap-1">
      {team.map((c) => {
        const st = statsOf(c);
        return (
          <div
            key={c.uid}
            className={
              "flex items-center gap-[2px] border px-[1px] " +
              (c.uid === activeUid ? "border-ink-200 bg-ink-700" : "border-transparent")
            }
          >
            <PixelSprite grid={c.sprite} palette={c.palette} scale={1} alt={c.name} />
            <div className="w-[26px]">
              <div className="font-term text-[10px] leading-[10px] text-ink-100">
                {c.level}
                {c.fused ? "F" : ""}
              </div>
              <div className="h-[3px] w-full border border-ink-500 bg-ink-900">
                <div
                  className="h-full"
                  style={{
                    width: `${Math.max(0, (c.hp / st.hp) * 100)}%`,
                    background: c.hp <= 0 ? "#4a4a55" : ELEMENT_COLOR[c.element],
                  }}
                />
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}
