import { useCallback, useEffect, useRef, useState } from "react";
import PixelSprite from "./PixelSprite";
import { Bar, Btn, Label, Panel } from "./Ui";
import {
  buffSummary,
  captureOdds,
  checkFaint,
  cloneBattle,
  decay,
  initBattle,
  maxHpOf,
  pickEnemyMove,
  rollOrder,
  tryCapture,
  tryFlee,
  useMove,
  type BattleState,
} from "../game/battle";
import { ELEMENT_COLOR, statsOf } from "../game/creatures";
import { makeRng } from "../game/rng";
import type { Creature } from "../game/types";

export type BattleResult = "win" | "lose" | "captured" | "fled";

interface Props {
  player: Creature;
  enemy: Creature;
  isBoss: boolean;
  orbs: number;
  team: Creature[];
  onEnd: (
    result: BattleResult,
    payload: { player: Creature; enemy: Creature; orbs: number; spent: Creature[] },
  ) => void;
}

type Menu = "root" | "moves" | "swap";

const wait = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));

export default function BattleView({ player, enemy, isBoss, orbs, team, onEnd }: Props) {
  const bsRef = useRef<BattleState | null>(null);
  if (!bsRef.current) bsRef.current = initBattle(player, enemy, isBoss, orbs);
  const [bs, setBs] = useState<BattleState>(bsRef.current as BattleState);
  const rng = useRef(makeRng(`${enemy.seed}::fight${player.uid}`));
  const [menu, setMenu] = useState<Menu>("root");
  const [cursor, setCursor] = useState(0);
  const [detail, setDetail] = useState(0);
  const alive = useRef(true);
  const animKey = useRef(0);

  useEffect(() => {
    alive.current = true;
    return () => {
      alive.current = false;
    };
  }, []);

  const mutate = useCallback((fn: (s: BattleState) => void) => {
    const next = cloneBattle(bsRef.current as BattleState);
    fn(next);
    bsRef.current = next;
    animKey.current += 1;
    setBs(next);
  }, []);

  const log = (s: BattleState, line: string) => {
    s.log.push(line);
  };

  const startRound = () =>
    mutate((x) => {
      x.round += 1;
      decay(x);
      x.order = rollOrder(x, rng.current);
      x.turnIdx = 0;
    });

  const finish = useCallback(async () => {
    const st = bsRef.current as BattleState;
    await wait(st.phase === "won" ? 1600 : 1300);
    if (!alive.current) return;
    onEnd(st.phase as BattleResult, {
      player: st.player,
      enemy: st.enemy,
      orbs: st.orbs,
      spent: st.spent,
    });
  }, [onEnd]);

  /** Runs the enemy's turn(s) until it is the player's turn or the battle ends. */
  const drive = useCallback(async () => {
    let guard = 0;
    while (alive.current && guard++ < 80) {
      const st = bsRef.current as BattleState;
      if (st.phase === "won" || st.phase === "lost" || st.phase === "captured" || st.phase === "fled") break;
      if (st.phase === "intro") {
        await wait(1050);
        if (!alive.current) return;
        mutate((x) => {
          x.phase = "menu";
          x.round = 1;
          x.order = rollOrder(x, rng.current);
          x.turnIdx = 0;
        });
        continue;
      }
      if (st.phase === "menu") break;
      if (st.order[st.turnIdx] !== "enemy") {
        mutate((x) => {
          x.phase = "menu";
        });
        setMenu("root");
        setCursor(0);
        break;
      }
      const idx = pickEnemyMove(st, rng.current);
      mutate((x) => {
        useMove(x, "enemy", idx, rng.current);
      });
      await wait(780);
      if (!alive.current) return;
      let ended = false;
      mutate((x) => {
        ended = checkFaint(x);
      });
      if (ended) {
        finish();
        return;
      }
      mutate((x) => {
        x.turnIdx += 1;
      });
      await wait(90);
      if (!alive.current) return;
      const s2 = bsRef.current as BattleState;
      if (s2.turnIdx >= s2.order.length) {
        startRound();
        await wait(220);
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [finish, mutate]);

  const started = useRef(false);
  useEffect(() => {
    if (started.current) return;
    started.current = true;
    void drive();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [drive]);

  const afterPlayerAction = useCallback(async () => {
    await wait(800);
    if (!alive.current) return;
    let ended = false;
    mutate((x) => {
      ended = checkFaint(x);
    });
    if (ended) {
      finish();
      return;
    }
    mutate((x) => {
      x.turnIdx += 1;
    });
    await wait(90);
    if (!alive.current) return;
    const s = bsRef.current as BattleState;
    if (s.turnIdx >= s.order.length) {
      startRound();
      await wait(220);
    }
    void drive();
  }, [drive, finish, mutate]);

  const chooseMove = (idx: number) => {
    if (bs.phase !== "menu") return;
    setMenu("root");
    mutate((x) => {
      x.phase = "busy";
      useMove(x, "player", idx, rng.current);
    });
    void afterPlayerAction();
  };

  const throwOrb = () => {
    if (bs.phase !== "menu") return;
    if (bs.orbs <= 0) {
      mutate((x) => log(x, "No orbs left!"));
      return;
    }
    setMenu("root");
    mutate((x) => {
      x.phase = "busy";
      tryCapture(x, rng.current);
    });
    if ((bsRef.current as BattleState).phase === "captured") {
      void finish();
      return;
    }
    void afterPlayerAction();
  };

  const runAway = () => {
    if (bs.phase !== "menu") return;
    setMenu("root");
    mutate((x) => {
      x.phase = "busy";
      tryFlee(x, rng.current);
    });
    if ((bsRef.current as BattleState).phase === "fled") {
      void finish();
      return;
    }
    void afterPlayerAction();
  };

  const swapIn = (target: Creature) => {
    if (bs.phase !== "menu") return;
    setMenu("root");
    mutate((x) => {
      x.phase = "busy";
      x.spent.push(x.player);
      log(x, `${x.player.name} withdraws.`);
      log(x, `Go, ${target.name}!`);
      x.player = target;
      x.buffs = { atk: 1, def: 1, spd: 1, guard: 0 };
    });
    void afterPlayerAction();
  };

  const bench = team.filter((c) => c.uid !== bs.player.uid && c.hp > 0);

  /* ---------------- keyboard ---------------- */
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const k = e.key.toLowerCase();
      if (["arrowup", "arrowdown", "arrowleft", "arrowright", " ", "enter", "z", "x"].includes(k)) e.preventDefault();
      if (bs.phase !== "menu") return;
      const opts = menu === "root" ? 4 : menu === "moves" ? bs.player.moves.length : bench.length;
      if (k === "z" || k === "enter" || k === " ") {
        if (menu === "root") {
          if (cursor === 0) setMenu("moves");
          else if (cursor === 1) throwOrb();
          else if (cursor === 2) {
            if (bench.length) setMenu("swap");
          } else runAway();
        } else if (menu === "moves") chooseMove(cursor);
        else if (menu === "swap" && bench[cursor]) swapIn(bench[cursor]);
        return;
      }
      if (k === "x" || k === "escape" || k === "backspace") {
        if (menu !== "root") {
          setMenu("root");
          setCursor(0);
        }
        return;
      }
      if (k === "arrowup" || k === "arrowleft" || k === "w") {
        setCursor((c) => (c - 1 + opts) % Math.max(1, opts));
        setDetail((c) => (c - 1 + opts) % Math.max(1, opts));
      }
      if (k === "arrowdown" || k === "arrowright" || k === "s") {
        setCursor((c) => (c + 1) % Math.max(1, opts));
        setDetail((c) => (c + 1) % Math.max(1, opts));
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  });

  /* ---------------- render ---------------- */
  const eCol = ELEMENT_COLOR[bs.enemy.element];
  const pCol = ELEMENT_COLOR[bs.player.element];
  const odds = Math.round(captureOdds(bs.enemy, isBoss) * 100);
  const lines = bs.log.slice(-3);
  const hitSide = bs.hit?.side;
  const hitKind = bs.hit?.kind;
  const busy = bs.phase !== "menu";
  const stats = statsOf(bs.player);
  const sel = bs.player.moves[detail];

  const shakeCls = (side: string) =>
    hitSide === side && (hitKind === "hit" || hitKind === "crit") ? "shake" : "";

  return (
    <div className="absolute inset-0 flex flex-col overflow-hidden bg-ink-900">
      {/* enemy plate */}
      <div className="flex h-[22px] shrink-0 items-center gap-1 px-1">
        <PixelSprite grid={bs.enemy.sprite} palette={bs.enemy.palette} scale={1} alt={bs.enemy.name} />
        <div className="min-w-0 flex-1">
          <div className="flex items-baseline justify-between gap-1">
            <span className="truncate font-pixel text-[7px] leading-[8px]" style={{ color: eCol }}>
              {bs.enemy.name}
            </span>
            <span className="font-term text-[11px] leading-[11px] text-ink-100">
              {isBoss ? "GUARDIAN " : "LV"}
              {bs.enemy.level}
            </span>
          </div>
          <Bar value={bs.enemy.hp} max={maxHpOf(bs.enemy)} color={eCol} height={3} />
          <div className="flex justify-between font-term text-[10px] leading-[10px] text-ink-200">
            <span>{buffSummary(bs.ebuffs)}</span>
            <span>
              {bs.enemy.hp}/{maxHpOf(bs.enemy)}
            </span>
          </div>
        </div>
      </div>

      {/* turn order */}
      <div className="flex h-[11px] shrink-0 items-center gap-1 px-1">
        <Label>turn</Label>
        {bs.order.map((side, i) => (
          <span
            key={i}
            className={
              "border px-1 font-pixel text-[6px] leading-[8px] " +
              (i === bs.turnIdx && !busy ? "border-bone bg-bone text-ink-900" : "border-ink-500 text-ink-200")
            }
          >
            {side === "player" ? "YOU" : "FOE"}
          </span>
        ))}
        <span className="ml-auto font-term text-[10px] leading-[10px] text-ink-300">RND {bs.round}</span>
      </div>

      {/* arena */}
      <div className="relative min-h-0 flex-1">
        <div
          className="absolute inset-0 opacity-40"
          style={{ background: "radial-gradient(60% 80% at 50% 100%, rgba(90,100,120,0.35) 0%, rgba(0,0,0,0) 70%)" }}
        />
        <div key={"e" + animKey.current} className={"absolute right-2 top-1 " + shakeCls("enemy")}>
          <PixelSprite grid={bs.enemy.sprite} palette={bs.enemy.palette} scale={3} alt={bs.enemy.name} />
        </div>
        <div key={"p" + animKey.current} className={"absolute bottom-0 left-3 " + shakeCls("player")}>
          <PixelSprite grid={bs.player.sprite} palette={bs.player.palette} scale={3} flip alt={bs.player.name} />
        </div>
        {hitKind === "heal" && (
          <div className="absolute left-1/2 top-0 -translate-x-1/2 font-pixel text-[7px] text-[#8fe0a0]">+HP</div>
        )}
        {hitKind === "crit" && (
          <div className="absolute left-1/2 top-0 -translate-x-1/2 font-pixel text-[8px] text-[#f0d060]">CRIT!</div>
        )}
        {hitKind === "capture" && (
          <div className="absolute left-1/2 top-0 -translate-x-1/2 font-pixel text-[7px] text-[#7de0d0]">ORB</div>
        )}
      </div>

      {/* player plate */}
      <div className="flex h-[22px] shrink-0 items-center gap-1 px-1">
        <div className="min-w-0 flex-1">
          <div className="flex items-baseline justify-between gap-1">
            <span className="truncate font-pixel text-[7px] leading-[8px]" style={{ color: pCol }}>
              {bs.player.name}
            </span>
            <span className="font-term text-[11px] leading-[11px] text-ink-100">LV{bs.player.level}</span>
          </div>
          <Bar value={bs.player.hp} max={maxHpOf(bs.player)} color={pCol} height={3} />
          <div className="flex justify-between font-term text-[10px] leading-[10px] text-ink-200">
            <span>{buffSummary(bs.buffs)}</span>
            <span>
              {bs.player.hp}/{maxHpOf(bs.player)}
            </span>
          </div>
        </div>
        <div className="shrink-0 text-right font-term text-[10px] leading-[10px] text-ink-300">
          <div>ATK {stats.atk}</div>
          <div>SPD {stats.spd}</div>
        </div>
      </div>

      {/* message */}
      <Panel tone="dark" className="mx-1 h-[30px] shrink-0 px-1">
        {lines.map((l, i) => (
          <div
            key={i}
            className={
              "truncate font-term text-[11px] leading-[9px] " +
              (i === lines.length - 1 ? "text-bone" : "text-ink-200")
            }
          >
            {l}
          </div>
        ))}
      </Panel>

      {/* menu */}
      <div className="h-[32px] shrink-0 px-1">
        {menu === "root" && (
          <div className="flex h-full flex-col justify-between">
            <div className="grid grid-cols-4 gap-[3px]">
              <Btn active={cursor === 0 && !busy} onClick={() => setMenu("moves")} disabled={busy}>
                FIGHT
              </Btn>
              <Btn
                active={cursor === 1 && !busy}
                onClick={throwOrb}
                disabled={busy || bs.orbs <= 0}
                title="Capture odds rise as HP drops"
              >
                ORB {bs.orbs}
              </Btn>
              <Btn
                active={cursor === 2 && !busy}
                onClick={() => bench.length && setMenu("swap")}
                disabled={busy || !bench.length}
              >
                SWAP
              </Btn>
              <Btn tone="danger" active={cursor === 3 && !busy} onClick={runAway} disabled={busy}>
                RUN
              </Btn>
            </div>
            <div className="flex items-center justify-between font-term text-[10px] leading-[10px] text-ink-300">
              <span>
                ORB ODDS <span className="text-[#7de0d0]">{odds}%</span>
              </span>
              <span>Z select · X back</span>
            </div>
          </div>
        )}

        {menu === "moves" && (
          <div className="flex h-full flex-col gap-[2px]">
            <div className="grid flex-1 grid-cols-4 gap-[3px]">
              {bs.player.moves.map((m, i) => (
                <Btn
                  key={m.id + i}
                  active={cursor === i && !busy}
                  onClick={() => {
                    setCursor(i);
                    setDetail(i);
                    if (!busy) chooseMove(i);
                  }}
                  onMouseEnter={() => setDetail(i)}
                  disabled={busy}
                  className="flex flex-col items-center justify-center py-0"
                >
                  <span
                    className="w-full truncate text-center font-term text-[10px] leading-[10px]"
                    style={{ color: active(cursor === i, busy) ? "#07070a" : ELEMENT_COLOR[m.element] }}
                  >
                    {m.name}
                  </span>
                  <span className="font-term text-[9px] leading-[9px] opacity-70">
                    {m.power ? `PWR ${m.power}` : m.kind.toUpperCase()}
                  </span>
                </Btn>
              ))}
            </div>
            <div className="truncate font-term text-[10px] leading-[10px] text-ink-200">
              {sel ? `${sel.name} — ${sel.desc}` : ""}
            </div>
          </div>
        )}

        {menu === "swap" && (
          <div className="grid h-full grid-cols-3 gap-[3px]">
            {bench.map((c, i) => (
              <Btn key={c.uid} active={cursor === i && !busy} onClick={() => swapIn(c)} disabled={busy}>
                <span className="flex items-center justify-center gap-1">
                  <PixelSprite grid={c.sprite} palette={c.palette} scale={1} alt={c.name} />
                  <span className="truncate font-term text-[10px] leading-[10px]">{c.name}</span>
                </span>
              </Btn>
            ))}
            {!bench.length && <span className="font-term text-[11px] text-ink-200">no bench</span>}
          </div>
        )}
      </div>

    </div>
  );
}

function active(c: boolean, busy: boolean) {
  return c && !busy;
}
