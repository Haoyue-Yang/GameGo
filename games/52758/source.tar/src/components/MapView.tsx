import { useEffect, useRef, type RefObject } from "react";
import { CANVAS_H, CANVAS_W, PLAYER_GRIDS, PLAYER_PALETTE, TILE, VIEW_H, VIEW_W, drawGrid, tileSet } from "../render/pixel";
import { tileAt, type World } from "../game/world";

export type Dir = "up" | "down" | "left" | "right";

export interface Anim {
  fx: number;
  fy: number;
  tx: number;
  ty: number;
  dir: Dir;
  moving: boolean;
  walkT: number;
  flash: number;
  shake: number;
}

interface Props {
  world: World;
  anim: RefObject<Anim>;
  paused?: boolean;
}

const SPEED = 6.2; // tiles per second

const MINI_COLORS = [
  "#2b5c34", // grass
  "#4f9a52", // tall grass
  "#1f3f6d", // water
  "#1c4a2b", // tree
  "#7a6a4c", // path
  "#3d7a45", // flower
  "#4e535b", // rock
  "#3f8f86", // shrine
  "#8fc0ee", // heal
  "#b03a4a", // boss
  "#0b0b0f", // wall
];

/** One pixel per tile. Drawn only when the player moves. */
export function MiniMap({ world, pos }: { world: World; pos: { x: number; y: number } }) {
  const ref = useRef<HTMLCanvasElement | null>(null);
  useEffect(() => {
    const c = ref.current;
    if (!c) return;
    const ctx = c.getContext("2d");
    if (!ctx) return;
    ctx.clearRect(0, 0, world.w, world.h);
    for (let y = 0; y < world.h; y++) {
      for (let x = 0; x < world.w; x++) {
        ctx.fillStyle = MINI_COLORS[world.tiles[y * world.w + x]] ?? "#000";
        ctx.fillRect(x, y, 1, 1);
      }
    }
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(pos.x, pos.y, 1, 1);
    ctx.fillStyle = "#ff5566";
    ctx.fillRect(world.boss.x - 1, world.boss.y - 1, 3, 3);
  }, [world, pos]);
  return <canvas ref={ref} width={world.w} height={world.h} className="pixelated" aria-hidden="true" />;
}

export default function MapView({ world, anim, paused = false }: Props) {
  const ref = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    ctx.imageSmoothingEnabled = false;
    const set = tileSet();
    let raf = 0;
    let last = performance.now();

    const frame = (now: number) => {
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      const a = anim.current;
      if (a) {
        if (!paused) {
          if (a.moving) {
            const dx = a.tx - a.fx;
            const dy = a.ty - a.fy;
            const dist = Math.hypot(dx, dy);
            const step = SPEED * dt;
            if (dist <= step) {
              a.fx = a.tx;
              a.fy = a.ty;
              a.moving = false;
            } else {
              a.fx += (dx / dist) * step;
              a.fy += (dy / dist) * step;
              a.walkT += dt;
            }
          }
          if (a.flash > 0) a.flash = Math.max(0, a.flash - dt * 1.6);
          if (a.shake > 0) a.shake = Math.max(0, a.shake - dt * 3);
        }

        // camera, clamped to map edges
        const camX = Math.max(0, Math.min(world.w - VIEW_W, Math.round(a.fx - (VIEW_W - 1) / 2)));
        const camY = Math.max(0, Math.min(world.h - VIEW_H, Math.round(a.fy - (VIEW_H - 1) / 2)));

        ctx.fillStyle = "#0b0b0f";
        ctx.fillRect(0, 0, CANVAS_W, CANVAS_H);

        const shakeX = a.shake > 0 ? Math.round(Math.sin(a.shake * 40) * 2) : 0;
        ctx.save();
        ctx.translate(shakeX, 0);

        for (let sy = 0; sy < VIEW_H; sy++) {
          for (let sx = 0; sx < VIEW_W; sx++) {
            const tx = camX + sx;
            const ty = camY + sy;
            const t = tileAt(world, tx, ty);
            const variant = ((tx * 7 + ty * 13) & 3) as 0 | 1 | 2 | 3;
            ctx.drawImage(set[t][variant], sx * TILE, sy * TILE);
          }
        }

        // player shadow
        const px = Math.round(a.fx * TILE - camX * TILE);
        const py = Math.round(a.fy * TILE - camY * TILE);
        ctx.fillStyle = "rgba(0,0,0,0.32)";
        ctx.fillRect(px + 3, py + 14, 10, 2);

        const bob = a.moving ? (Math.floor(a.walkT * 9) % 2 === 0 ? 0 : -1) : 0;
        const grid = a.dir === "up" ? PLAYER_GRIDS.up : a.dir === "down" ? PLAYER_GRIDS.down : PLAYER_GRIDS.side;
        drawGrid(ctx, grid, PLAYER_PALETTE, px, py + bob, 1, a.dir === "left");

        // boss compass chevron
        const bdx = world.boss.x - a.fx;
        const bdy = world.boss.y - a.fy;
        if (Math.hypot(bdx, bdy) > 9) {
          const ang = Math.atan2(bdy, bdx);
          const r = 74;
          const cx = CANVAS_W / 2 + Math.cos(ang) * r;
          const cy = CANVAS_H / 2 + Math.sin(ang) * r;
          ctx.fillStyle = "rgba(224,106,114,0.85)";
          ctx.fillRect(Math.round(cx) - 1, Math.round(cy) - 1, 3, 3);
          ctx.fillStyle = "rgba(224,106,114,0.35)";
          ctx.fillRect(Math.round(cx) - 3, Math.round(cy) - 3, 7, 7);
        }

        ctx.restore();

        if (a.flash > 0) {
          const f = a.flash;
          ctx.fillStyle = `rgba(255,255,255,${(f * 0.85).toFixed(3)})`;
          ctx.fillRect(0, 0, CANVAS_W, CANVAS_H);
          ctx.fillStyle = `rgba(0,0,0,${(f * 0.5).toFixed(3)})`;
          const inset = Math.round((1 - f) * 60);
          ctx.fillRect(0, 0, CANVAS_W, inset);
          ctx.fillRect(0, CANVAS_H - inset, CANVAS_W, inset);
        }
      }
      raf = requestAnimationFrame(frame);
    };
    raf = requestAnimationFrame(frame);
    return () => cancelAnimationFrame(raf);
  }, [world, anim, paused]);

  return (
    <canvas
      ref={ref}
      width={CANVAS_W}
      height={CANVAS_H}
      className="pixelated absolute inset-0 h-full w-full"
      aria-label="world map"
      role="img"
    />
  );
}


